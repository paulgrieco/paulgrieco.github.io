% This function computes the standard errors by formular:
% para is the final estimate;
% W is the optimal weight used in the second stage GMM
function [std] = getStd(para,qualityData,W)
%% compute G:
[~,~, moment] = obj_quality_gmm(para, qualityData, W);
myepsilon = 1e-6;
for j = 1:length(para)
    para_new = para;
    para_new(j) = para(j) +myepsilon;
    [~,~, moment_new] = obj_quality_gmm(para_new, qualityData, W);
    moment_grd(j,:) = (moment_new - moment)/myepsilon;
end
G = moment_grd;

%% compute Omega (similar to optimal weight):
[~, errors] = obj_quality_gmm(para,qualityData, W) ;

m_time_m_w = 0;
for j = 1:length(errors)
    if qualityData.valid_ind(j)==1
        temp = qualityData.IV_w(j,:)'*errors(j,1);
        m_time_m_w = m_time_m_w + temp*temp';
    end
end

m_time_m_p = 0;
for j = 1:length(errors)
    if qualityData.valid_ind(j)==1
        temp = qualityData.IV_p(j,:)'*errors(j,2);
        m_time_m_p = m_time_m_p + temp*temp';
    end
end

Omega = [m_time_m_w, zeros(size(m_time_m_w,1), size(m_time_m_p,2));
    zeros(size(m_time_m_p,1), size(m_time_m_w,2)), m_time_m_p];%/sum(valid_ind==1);

%% computes the std:
std = diag(inv(G*inv(Omega)*G')).^.5;
