% this script estimate offline ccp
clear
clc

myfilein = ['..' filesep 'Data' filesep 'quality_out'];
load(myfilein);

phyOmega_lag = zeros(nObs,1);
phyOmega_lag(2:end) = phyOmega(1:end-1);

log_P0_lag = zeros(nObs,1);
log_P0_lag(2:end) = log_P0(1:end-1);

X_ie= [exp_ind_lag, imp_ind_lag, phyOmega_lag, log_P0_lag,  log_wagerate_lag, log_capital_norm_lag];

%% Use biprobit to estimate CCP
wagerate_lag_high = (log_wagerate_lag>quantile(log_wagerate_lag,.66));
wagerate_lag_low = (log_wagerate_lag<quantile(log_wagerate_lag,.33));
qualityData.wageDum = [wagerate_lag_low, wagerate_lag_high];

% construct time dummies: yearly (yearDum) or by WTO (3-part b/o unstationary, but drop year == 2001 since constant kept).
time_dum = [year>=2002]; % treat year<2002 as the baseline period.

% with wage dummies
X_exp= [ones(size(exp_ind_lag)), exp_ind_lag, imp_ind_lag, phyOmega_lag, log_P0_lag, log_capital_norm_lag, wagerate_lag_low, wagerate_lag_high,  exp_ind_lag .* imp_ind_lag, time_dum];
X_imp= [ones(size(exp_ind_lag)), exp_ind_lag, imp_ind_lag, phyOmega_lag, log_P0_lag,  log_capital_norm_lag, wagerate_lag_low, wagerate_lag_high, exp_ind_lag .* imp_ind_lag, time_dum];

trim = 0;
Y_exp = exp_ind;
Y_imp = imp_ind;
 
good_obs_ie = (valid_ind == 1) & (export_sh >= 0)& (import_sh >= 0) & (export_sh <= 1) & (import_sh <= 1) & (sum(isnan(X_ie),2)==0) & (sum(imag(X_ie),2)==0) & ( log_P0_lag<quantile( log_P0_lag,1 - trim)) & ( log_P0_lag>quantile( log_P0_lag,trim)) ;

opt_ktr=optimset('TolX',1e-15,'TolFun',1e-5,'MaxIter',2000,'MaxFunEvals',1000000, 'Display','iter', 'GradObj','off');  
para0 = zeros(size(X_exp,2)+size(X_imp,2)+1,1);
lb = -Inf*ones(size(para0));
ub = Inf*ones(size(para0));
lb(end) = -.99;
ub(end) = .99;
[beta_biprobit] = knitrolink(@(x) LLF_biprobit(x, Y_exp(good_obs_ie,:), Y_imp(good_obs_ie,:),X_exp(good_obs_ie,:),X_imp(good_obs_ie,:)), para0 ,[],[],[],[],lb,ub,[],opt_ktr);
est.beta_biprobit =beta_biprobit; %  

opt_fmin=optimset('TolX',1e-15,'TolFun',1e-5,'MaxIter',50,'MaxFunEvals',1000000, 'Display','iter', 'GradObj','off');  
[beta_biprobit_ck,~,~,~,~,hessian] = fminunc(@(x) LLF_biprobit(x, Y_exp(good_obs_ie,:), Y_imp(good_obs_ie,:),X_exp(good_obs_ie,:),X_imp(good_obs_ie,:)), beta_biprobit,opt_fmin);
est.beta_biprobit_se = (diag(inv(hessian))).^.5;

%% save files
myfileout = ['..' filesep 'Data' filesep 'quality_out'];
save(myfileout);

 