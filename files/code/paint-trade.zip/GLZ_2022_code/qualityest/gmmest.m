 % e is the matrix of errors of the evolution processes, which is used to
 % construct the var-cov of the two errors.
function [gmm_out, e] = gmmest(para0,qualityData)
global data data_lag

myData = constructX(qualityData);
data = myData.data;
data_lag = myData.data_lag;

Y_w = qualityData.omega(qualityData.valid_ind);
Z_w = qualityData.IV_w(qualityData.valid_ind,:);
Y_p = qualityData.omega(qualityData.valid_ind);
Z_p = qualityData.IV_p(qualityData.valid_ind,:);

Y = [Y_w ; Y_p];

Z = [Z_w, zeros(size(Z_w,1),size(Z_p,2));
            zeros(size(Z_p,1),size(Z_w,2)), Z_p];
        
X = Z;

gmmopt.plot = 0; % 0 is to have some plot, 1 is not.
gmmopt.infoz.momt='gmm_step1';
gmmopt.gmmit = 5;
gmmopt.W0 = 'I';
gmm_out = gmm(para0,gmmopt,Y,X,Z);

[~,e] = gmm_step1(gmm_out.b,[],[],Y,X,Z); % this produces the errors of the evolution processes after the estimation.

    
    
    