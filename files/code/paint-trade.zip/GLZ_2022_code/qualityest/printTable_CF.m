% this function produce tables of results of counterfacutals
function [CF_tab] = printTable_CF(CF_res_name)

load(CF_res_name) 
CF_tab.lambda = lambda_chosen;

%%%% 1) For the comparison between baseline and no trade gains:
baseline_case = 2; % the second case is the baseline
CF_set = [2,4,5]; % [2, 4, 5] are the baseline, No productivity gain, and No price gain, respectively. 
V_CF = [];

for i = 1:length(CF_set)
    CF_i = CF_set(i); 
    V_CF(i,:)= computeV(firmSim,counterRes(CF_i), mynorm, est);
end

xi_normalization =  0.5772156649; % this is the mean of unconditional distribution of the trade cost shock.  
V_CF = V_CF - xi_normalization /(1-0.95); % we need to take it out of the value because V_CF contains accumulation of such xi_normalization

% report the mean firm value change:
firmvalue_diff = mean(V_CF - repmat(V_CF(1,:),size(V_CF,1),1),2) * dynData.profit_unit/8;
firmvalue_diff_rel = mean(V_CF./repmat(V_CF(1,:),size(V_CF,1),1) - 1, 2);

%fprintf('In no-gain-from-productivity counterfactual, the mean firm value change is %g KUSD \n', firmvalue_diff(2))
%fprintf('In no-gain-from-productivity counterfactual, the mean firm value change is relatively %g percent \n',  firmvalue_diff_rel(2)*100 )

%fprintf('In no-gain-from-price counterfactual, the mean firm value change is %g KUSD \n', firmvalue_diff(3))
%fprintf('In no-gain-from-price counterfactual, the mean firm value change is relatively %g percent \n',  firmvalue_diff_rel(3)*100 )

% Table: Effect of Trade Participation on Productivity and Input Prices (firm value changes, perc and mill USD)
CF_tab.omega_p_V = [firmvalue_diff_rel(2)*100, firmvalue_diff(2)/1000;
                    firmvalue_diff_rel(3)*100, firmvalue_diff(3)/1000;];

% now for the other variables
[agg_diff] = computeKeyvarDiff(agg_revenue_weighted, CF_set, baseline_case);

% % for no-gain-from-productivity counterfactual
% fprintf('In no-gain-from-productivity counterfactual, the changes of productivity in 2, 5, 10, 15 years are:  \n')
% disp([agg_diff.omega(2,3), agg_diff.omega(2,6), agg_diff.omega(2,11), agg_diff.omega(2,16)])
% fprintf('In no-gain-from-productivity counterfactual, the changes of price  in 2, 5, 10, 15 years are:  \n')
% disp([agg_diff.PM(2,3), agg_diff.PM(2,6), agg_diff.PM(2,11), agg_diff.PM(2,16)])
% fprintf('In no-gain-from-productivity counterfactual, the changes of export probabilty in 2, 5, 10, 15 years are:  \n')
% disp([agg_diff.exp(2,3), agg_diff.exp(2,6), agg_diff.exp(2,11), agg_diff.exp(2,16)])
% fprintf('In no-gain-from-productivity counterfactual, the changes of import probabilty in 2, 5, 10, 15 years are:  \n')
% disp([agg_diff.imp(2,3), agg_diff.imp(2,6), agg_diff.imp(2,11), agg_diff.imp(2,16)])
% 
% % for no-gain-from-price counterfactual
% fprintf('In no-gain-from-price counterfactual, the changes of productivity in 2, 5, 10, 15 years are:  \n')
% disp([agg_diff.omega(3,3), agg_diff.omega(3,6), agg_diff.omega(3,11), agg_diff.omega(3,16)])
% fprintf('In no-gain-from-price counterfactual, the changes of price  in 2, 5, 10, 15 years are:  \n')
% disp([agg_diff.PM(3,3), agg_diff.PM(3,6), agg_diff.PM(3,11), agg_diff.PM(3,16)])
% fprintf('In no-gain-from-price counterfactual, the changes of export probabilty in 2, 5, 10, 15 years are:  \n')
% disp([agg_diff.exp(3,3), agg_diff.exp(3,6), agg_diff.exp(3,11), agg_diff.exp(3,16)])
% fprintf('In no-gain-from-price counterfactual, the changes of import probabilty in 2, 5, 10, 15 years are:  \n')
% disp([agg_diff.imp(3,3), agg_diff.imp(3,6), agg_diff.imp(3,11), agg_diff.imp(3,16)])

% Table: Effect of Trade Participation on Productivity and Input Prices 
% (other key variables -- productivity CF on top, and price CF in below)
CF_tab.omega_p_keyVar = [
agg_diff.omega(2,3), agg_diff.omega(2,6), agg_diff.omega(2,11), agg_diff.omega(2,16);
agg_diff.PM(2,3), agg_diff.PM(2,6), agg_diff.PM(2,11), agg_diff.PM(2,16);
agg_diff.exp_point(2,3), agg_diff.exp_point(2,6), agg_diff.exp_point(2,11), agg_diff.exp_point(2,16);
agg_diff.exp(2,3), agg_diff.exp(2,6), agg_diff.exp(2,11), agg_diff.exp(2,16);
agg_diff.imp_point(2,3), agg_diff.imp_point(2,6), agg_diff.imp_point(2,11), agg_diff.imp_point(2,16);
agg_diff.imp(2,3), agg_diff.imp(2,6), agg_diff.imp(2,11), agg_diff.imp(2,16);
...
agg_diff.omega(3,3), agg_diff.omega(3,6), agg_diff.omega(3,11), agg_diff.omega(3,16);
agg_diff.PM(3,3), agg_diff.PM(3,6), agg_diff.PM(3,11), agg_diff.PM(3,16);
agg_diff.exp_point(3,3), agg_diff.exp_point(3,6), agg_diff.exp_point(3,11), agg_diff.exp_point(3,16);
agg_diff.exp(3,3), agg_diff.exp(3,6), agg_diff.exp(3,11), agg_diff.exp(3,16);
agg_diff.imp_point(3,3), agg_diff.imp_point(3,6), agg_diff.imp_point(3,11), agg_diff.imp_point(3,16)
agg_diff.imp(3,3), agg_diff.imp(3,6), agg_diff.imp(3,11), agg_diff.imp(3,16)];


%%%% 2) For the comparison between baseline and WTO effect:
baseline_case = 7; % the 7th case is the baseline -- no WTO effect
CF_set = [7,8,2]; % [7, 8, 2] are the new no WTO, new only direct effect of WTO, and full model respectively. 
V_CF = [];

for i = 1:length(CF_set)
    CF_i = CF_set(i); 
    V_CF(i,:)= computeV(firmSim,counterRes(CF_i), mynorm, est);
end

xi_normalization =  0.5772156649; % this is the mean of unconditional distribution of the trade cost shock.  
V_CF = V_CF - xi_normalization /(1-0.95); % we need to take it out of the value because V_CF contains accumulation of such xi_normalization

% report the mean firm value change:
firmvalue_diff = mean(V_CF - repmat(V_CF(1,:),size(V_CF,1),1),2) * dynData.profit_unit/8;
firmvalue_diff_rel = mean(V_CF./repmat(V_CF(1,:),size(V_CF,1),1) - 1, 2);

%fprintf('In Direct WTO effect counterfactual, the mean firm value change is %g KUSD \n', firmvalue_diff(2))
%fprintf('In Direct WTO effect counterfactual, the mean firm value change is relatively %g percent \n',  firmvalue_diff_rel(2)*100 )

%fprintf('In full WTO effect counterfactual, the mean firm value change is %g KUSD \n', firmvalue_diff(3))
%fprintf('In full WTO effect counterfactual, the mean firm value change is relatively %g percent \n',  firmvalue_diff_rel(3)*100 )

% Table: Effect of WTO Price-Incentive to Import
% Full on top, direct in below.
CF_tab.wto_incentive_V = [firmvalue_diff_rel(3)*100, firmvalue_diff(3)/1000;
                          firmvalue_diff_rel(2)*100, firmvalue_diff(2)/1000;];
    
% now for the other variables: here we use the agg_omega etc that define
% above -- because the results are still from the counterfactual results.
[agg_diff] = computeKeyvarDiff(agg_revenue_weighted, CF_set, baseline_case);

% % for Direct effect
% fprintf('In Direct WTO effect counterfactual, the changes of productivity in 2, 5, 10, 15 years are:  \n')
% disp([agg_diff.omega(2,3), agg_diff.omega(2,6), agg_diff.omega(2,11), agg_diff.omega(2,16)])
% fprintf('In Direct WTO effect counterfactual, the changes of price  in 2, 5, 10, 15 years are:  \n')
% disp([agg_diff.PM(2,3), agg_diff.PM(2,6), agg_diff.PM(2,11), agg_diff.PM(2,16)])
% fprintf('In Direct WTO effect counterfactual, the changes of export probabilty in 2, 5, 10, 15 years are:  \n')
% disp([agg_diff.exp(2,3), agg_diff.exp(2,6), agg_diff.exp(2,11), agg_diff.exp(2,16)])
% fprintf('In Direct WTO effect counterfactual, the changes of import probabilty in 2, 5, 10, 15 years are:  \n')
% disp([agg_diff.imp(2,3), agg_diff.imp(2,6), agg_diff.imp(2,11), agg_diff.imp(2,16)])
% 
% % for full effect
% fprintf('In full WTO effect counterfactual, the changes of productivity in 2, 5, 10, 15 years are:  \n')
% disp([agg_diff.omega(3,3), agg_diff.omega(3,6), agg_diff.omega(3,11), agg_diff.omega(3,16)])
% fprintf('In full WTO effect counterfactual, the changes of price  in 2, 5, 10, 15 years are:  \n')
% disp([agg_diff.PM(3,3), agg_diff.PM(3,6), agg_diff.PM(3,11), agg_diff.PM(3,16)])
% fprintf('In full WTO effect counterfactual, the changes of export probabilty in 2, 5, 10, 15 years are:  \n')
% disp([agg_diff.exp(3,3), agg_diff.exp(3,6), agg_diff.exp(3,11), agg_diff.exp(3,16)])
% fprintf('In full WTO effect counterfactual, the changes of import probabilty in 2, 5, 10, 15 years are:  \n')
% disp([agg_diff.imp(3,3), agg_diff.imp(3,6), agg_diff.imp(3,11), agg_diff.imp(3,16)])

% Table: Effect of WTO Price-Incentive to Import -- other key variables
% Full on top, direct in below.
CF_tab.wto_incentive_keyVar = [ 
agg_diff.omega(3,3), agg_diff.omega(3,6), agg_diff.omega(3,11), agg_diff.omega(3,16);
agg_diff.PM(3,3), agg_diff.PM(3,6), agg_diff.PM(3,11), agg_diff.PM(3,16);
agg_diff.exp_point(3,3), agg_diff.exp_point(3,6), agg_diff.exp_point(3,11), agg_diff.exp_point(3,16);
agg_diff.exp(3,3), agg_diff.exp(3,6), agg_diff.exp(3,11), agg_diff.exp(3,16);
agg_diff.imp_point(3,3), agg_diff.imp_point(3,6), agg_diff.imp_point(3,11), agg_diff.imp_point(3,16)
agg_diff.imp(3,3), agg_diff.imp(3,6), agg_diff.imp(3,11), agg_diff.imp(3,16);
...
agg_diff.omega(2,3), agg_diff.omega(2,6), agg_diff.omega(2,11), agg_diff.omega(2,16);
agg_diff.PM(2,3), agg_diff.PM(2,6), agg_diff.PM(2,11), agg_diff.PM(2,16);
agg_diff.exp_point(2,3), agg_diff.exp_point(2,6), agg_diff.exp_point(2,11), agg_diff.exp_point(2,16);
agg_diff.exp(2,3), agg_diff.exp(2,6), agg_diff.exp(2,11), agg_diff.exp(2,16);
agg_diff.imp_point(2,3), agg_diff.imp_point(2,6), agg_diff.imp_point(2,11), agg_diff.imp_point(2,16);
agg_diff.imp(2,3), agg_diff.imp(2,6), agg_diff.imp(2,11), agg_diff.imp(2,16);];


%%%% 3) For the comparison of WHO gains from WTO table
tradeFirms = (firmSim.imp_ind>-999); % for all firms
V_CF_sub = V_CF(:,tradeFirms);
firmvalue_diff(1) = mean(V_CF_sub(3,:) - V_CF_sub(1,:),2) * dynData.profit_unit/8;
%fprintf('In full WTO counterfactual, the overall firm value change is %g KUSD \n', firmvalue_diff(1))

tradeFirms = (firmSim.omega <= quantile(firmSim.omega, 1/2) ); % low productivity firms
V_CF_sub = V_CF(:,tradeFirms);
firmvalue_diff(2) = mean(V_CF_sub(3,:) - V_CF_sub(1,:),2) * dynData.profit_unit/8;
%fprintf('In full WTO counterfactual, the low producitivity firm value change is %g KUSD \n', firmvalue_diff(2))

tradeFirms = (firmSim.omega > quantile(firmSim.omega, 1/2) ); % high productivity firms
V_CF_sub = V_CF(:,tradeFirms);
firmvalue_diff(3) = mean(V_CF_sub(3,:) - V_CF_sub(1,:),2) * dynData.profit_unit/8;
%fprintf('In full WTO counterfactual, the high producitivity firm value change is %g KUSD \n', firmvalue_diff(3))

tradeFirms = (firmSim.log_PM <= quantile(firmSim.log_PM, 1/2) ); % low price firms
V_CF_sub = V_CF(:,tradeFirms);
firmvalue_diff(4) = mean(V_CF_sub(3,:) - V_CF_sub(1,:),2) * dynData.profit_unit/8;
%fprintf('In full WTO counterfactual, the low price firm value change is %g KUSD \n', firmvalue_diff(4))

tradeFirms = (firmSim.log_PM > quantile(firmSim.log_PM, 1/2) ); % high price firms
V_CF_sub = V_CF(:,tradeFirms);
firmvalue_diff(5) = mean(V_CF_sub(3,:) - V_CF_sub(1,:),2) * dynData.profit_unit/8;
%fprintf('In full WTO counterfactual, the high price firm value change is %g KUSD \n', firmvalue_diff(5))

tradeFirms = (firmSim.imp_ind==0 & firmSim.exp_ind==0); % no exporting no importing
V_CF_sub = V_CF(:,tradeFirms);
firmvalue_diff(6) = mean(V_CF_sub(3,:) - V_CF_sub(1,:),2) * dynData.profit_unit/8;
%fprintf('In full WTO counterfactual, the none trade firm value change is %g KUSD \n', firmvalue_diff(6))

tradeFirms = (firmSim.imp_ind==0 & firmSim.exp_ind==1); % exporting only
V_CF_sub = V_CF(:,tradeFirms);
firmvalue_diff(7) = mean(V_CF_sub(3,:) - V_CF_sub(1,:),2) * dynData.profit_unit/8;
%fprintf('In full WTO counterfactual, the exporting only firm value change is %g KUSD \n', firmvalue_diff(7))

tradeFirms = (firmSim.imp_ind==1 & firmSim.exp_ind==0); % importing only
V_CF_sub = V_CF(:,tradeFirms);
firmvalue_diff(8) = mean(V_CF_sub(3,:) - V_CF_sub(1,:),2) * dynData.profit_unit/8;
%fprintf('In full WTO counterfactual, the importing only firm value change is %g KUSD \n', firmvalue_diff(8))

tradeFirms = (firmSim.imp_ind==1 & firmSim.exp_ind==1); % both 
V_CF_sub = V_CF(:,tradeFirms);
firmvalue_diff(9) = mean(V_CF_sub(3,:) - V_CF_sub(1,:),2) * dynData.profit_unit/8;
%fprintf('In full WTO counterfactual, the both exporting and importing firm value change is %g KUSD \n', firmvalue_diff(9))

% Table: Effect of WTO Accession Price-Incentive to Import by Firm Type
% million USD
CF_tab.wto_firmtype_V = firmvalue_diff(1:9)'/1000;

% now for the other variables: note that here we cannot use the values
% computed above -- we need to use fixed sale weight for this exercise, as
% shown in the paper.
baseline_case = 7; % the 7th case is the new baseline -- no WTO price effect
CF_set = [7,2]; % [7,2] are the new no WTO and full model respectively. 

% for 15 years:
end_year = 16; % this is the 15th year

[agg_diff] = computeKeyvarDiff(agg_revenue_weighted_overall, CF_set, baseline_case);
%fprintf('In full WTO effect counterfactual of all firms, the changes of productivity, price, exp, imp in 15 years are:  \n')
temp_overall = [agg_diff.omega(2,end_year), agg_diff.PM(2,end_year), agg_diff.exp_point(2,end_year), agg_diff.exp(2,end_year), agg_diff.imp_point(2,end_year), agg_diff.imp(2,end_year)]';
 
[agg_diff] = computeKeyvarDiff(agg_revenue_weighted_lowOmega, CF_set, baseline_case);
%fprintf('In full WTO effect counterfactual low productivity firms, the changes of productivity, price, exp, imp in 15 years are:  \n')
temp_lowprod =[agg_diff.omega(2,end_year), agg_diff.PM(2,end_year), agg_diff.exp_point(2,end_year), agg_diff.exp(2,end_year), agg_diff.imp_point(2,end_year), agg_diff.imp(2,end_year)]';

[agg_diff] = computeKeyvarDiff(agg_revenue_weighted_hiOmega, CF_set, baseline_case);
%fprintf('In full WTO effect counterfactual of high productivity firms, the changes of productivity, price, exp, imp in 15 years are:  \n')
temp_hiprod = [agg_diff.omega(2,end_year), agg_diff.PM(2,end_year), agg_diff.exp_point(2,end_year), agg_diff.exp(2,end_year), agg_diff.imp_point(2,end_year), agg_diff.imp(2,end_year)]';

[agg_diff] = computeKeyvarDiff(agg_revenue_weighted_lowPrice, CF_set, baseline_case);
%fprintf('In full WTO effect counterfactual low price firms, the changes of productivity, price, exp, imp in 15 years are:  \n')
temp_lowprice =[agg_diff.omega(2,end_year), agg_diff.PM(2,end_year), agg_diff.exp_point(2,end_year), agg_diff.exp(2,end_year), agg_diff.imp_point(2,end_year), agg_diff.imp(2,end_year)]';

[agg_diff] = computeKeyvarDiff(agg_revenue_weighted_hiPrice, CF_set, baseline_case);
%fprintf('In full WTO effect counterfactual of high price firms, the changes of productivity, price, exp, imp in 15 years are:  \n')
temp_hiprice = [agg_diff.omega(2,end_year), agg_diff.PM(2,end_year), agg_diff.exp_point(2,end_year), agg_diff.exp(2,end_year), agg_diff.imp_point(2,end_year), agg_diff.imp(2,end_year)]';

[agg_diff] = computeKeyvarDiff(agg_revenue_weighted_none, CF_set, baseline_case);
%fprintf('In full WTO effect counterfactual no trading firms, the changes of productivity, price, exp, imp in 15 years are:  \n')
temp_none = [agg_diff.omega(2,end_year), agg_diff.PM(2,end_year), agg_diff.exp_point(2,end_year), agg_diff.exp(2,end_year), agg_diff.imp_point(2,end_year), agg_diff.imp(2,end_year)]';

[agg_diff] = computeKeyvarDiff(agg_revenue_weighted_exp, CF_set, baseline_case);
%fprintf('In full WTO effect counterfactual exporting only firms, the changes of productivity, price, exp, imp in 15 years are:  \n')
temp_exp = [agg_diff.omega(2,end_year), agg_diff.PM(2,end_year), agg_diff.exp_point(2,end_year), agg_diff.exp(2,end_year), agg_diff.imp_point(2,end_year), agg_diff.imp(2,end_year)]';

[agg_diff] = computeKeyvarDiff(agg_revenue_weighted_imp, CF_set, baseline_case);
%fprintf('In full WTO effect counterfactual importing only firms, the changes of productivity, price, exp, imp in 15 years are:  \n')
temp_imp = [agg_diff.omega(2,end_year), agg_diff.PM(2,end_year), agg_diff.exp_point(2,end_year), agg_diff.exp(2,end_year), agg_diff.imp_point(2,end_year), agg_diff.imp(2,end_year)]';

[agg_diff] = computeKeyvarDiff(agg_revenue_weighted_both, CF_set, baseline_case);
%fprintf('In full WTO effect counterfactual both exp and imp firms, the changes of productivity, price, exp, imp in 15 years are:  \n')
temp_both = [agg_diff.omega(2,end_year), agg_diff.PM(2,end_year), agg_diff.exp_point(2,end_year), agg_diff.exp(2,end_year), agg_diff.imp_point(2,end_year), agg_diff.imp(2,end_year)]';

% Table: Effect of WTO Accession Price-Incentive to Import by Firm Type
CF_tab.wto_firmtype_keyVar_15 = [temp_overall, temp_lowprod, temp_hiprod, temp_lowprice, temp_hiprice, temp_none, temp_exp, temp_imp, temp_both];

% for 5 years:
end_year = 6; % this is the 15th year

[agg_diff] = computeKeyvarDiff(agg_revenue_weighted_overall, CF_set, baseline_case);
%fprintf('In full WTO effect counterfactual of all firms, the changes of productivity, price, exp, imp in 5 years are:  \n')
temp_overall = [agg_diff.omega(2,end_year), agg_diff.PM(2,end_year), agg_diff.exp_point(2,end_year), agg_diff.exp(2,end_year), agg_diff.imp_point(2,end_year), agg_diff.imp(2,end_year)]';
 
[agg_diff] = computeKeyvarDiff(agg_revenue_weighted_lowOmega, CF_set, baseline_case);
%fprintf('In full WTO effect counterfactual low productivity firms, the changes of productivity, price, exp, imp in 5 years are:  \n')
temp_lowprod =[agg_diff.omega(2,end_year), agg_diff.PM(2,end_year), agg_diff.exp_point(2,end_year), agg_diff.exp(2,end_year), agg_diff.imp_point(2,end_year), agg_diff.imp(2,end_year)]';

[agg_diff] = computeKeyvarDiff(agg_revenue_weighted_hiOmega, CF_set, baseline_case);
%fprintf('In full WTO effect counterfactual of high productivity firms, the changes of productivity, price, exp, imp in 5 years are:  \n')
temp_hiprod = [agg_diff.omega(2,end_year), agg_diff.PM(2,end_year), agg_diff.exp_point(2,end_year), agg_diff.exp(2,end_year), agg_diff.imp_point(2,end_year), agg_diff.imp(2,end_year)]';

[agg_diff] = computeKeyvarDiff(agg_revenue_weighted_lowPrice, CF_set, baseline_case);
%fprintf('In full WTO effect counterfactual low price firms, the changes of productivity, price, exp, imp in 5 years are:  \n')
temp_lowprice =[agg_diff.omega(2,end_year), agg_diff.PM(2,end_year), agg_diff.exp_point(2,end_year), agg_diff.exp(2,end_year), agg_diff.imp_point(2,end_year), agg_diff.imp(2,end_year)]';

[agg_diff] = computeKeyvarDiff(agg_revenue_weighted_hiPrice, CF_set, baseline_case);
%fprintf('In full WTO effect counterfactual of high price firms, the changes of productivity, price, exp, imp in 5 years are:  \n')
temp_hiprice = [agg_diff.omega(2,end_year), agg_diff.PM(2,end_year), agg_diff.exp_point(2,end_year), agg_diff.exp(2,end_year), agg_diff.imp_point(2,end_year), agg_diff.imp(2,end_year)]';

[agg_diff] = computeKeyvarDiff(agg_revenue_weighted_none, CF_set, baseline_case);
%fprintf('In full WTO effect counterfactual no trading firms, the changes of productivity, price, exp, imp in 5 years are:  \n')
temp_none = [agg_diff.omega(2,end_year), agg_diff.PM(2,end_year), agg_diff.exp_point(2,end_year), agg_diff.exp(2,end_year), agg_diff.imp_point(2,end_year), agg_diff.imp(2,end_year)]';

[agg_diff] = computeKeyvarDiff(agg_revenue_weighted_exp, CF_set, baseline_case);
%fprintf('In full WTO effect counterfactual exporting only firms, the changes of productivity, price, exp, imp in 5 years are:  \n')
temp_exp = [agg_diff.omega(2,end_year), agg_diff.PM(2,end_year), agg_diff.exp_point(2,end_year), agg_diff.exp(2,end_year), agg_diff.imp_point(2,end_year), agg_diff.imp(2,end_year)]';

[agg_diff] = computeKeyvarDiff(agg_revenue_weighted_imp, CF_set, baseline_case);
%fprintf('In full WTO effect counterfactual importing only firms, the changes of productivity, price, exp, imp in 5 years are:  \n')
temp_imp = [agg_diff.omega(2,end_year), agg_diff.PM(2,end_year), agg_diff.exp_point(2,end_year), agg_diff.exp(2,end_year), agg_diff.imp_point(2,end_year), agg_diff.imp(2,end_year)]';

[agg_diff] = computeKeyvarDiff(agg_revenue_weighted_both, CF_set, baseline_case);
%fprintf('In full WTO effect counterfactual both exp and imp firms, the changes of productivity, price, exp, imp in 5 years are:  \n')
temp_both = [agg_diff.omega(2,end_year), agg_diff.PM(2,end_year), agg_diff.exp_point(2,end_year), agg_diff.exp(2,end_year), agg_diff.imp_point(2,end_year), agg_diff.imp(2,end_year)]';

% Table: Effect of WTO Accession Price-Incentive to Import by Firm Type
CF_tab.wto_firmtype_keyVar_5 = [temp_overall, temp_lowprod, temp_hiprod, temp_lowprice, temp_hiprice, temp_none, temp_exp, temp_imp, temp_both];

% Finally, compute OP decomposition for Omega and price (in level) from
% counterfactual (full WTO compared with baseline)
baseline_case = 7; % it uses removed tariff case as the baseline
cf_case = 2; %  % the case of counterfactual: the full model

% For 15 years:
end_year = 16; % take a number of years table_firstline =  {'Year', 'Weighted','Un-weighted','Cov','Weighted','Un-weighted','Cov'};

norminator_Omega = agg_revenue_weighted.omega_agg_avg(baseline_case,end_year);
norminator_P0 = agg_revenue_weighted.log_PM_agg_avg(baseline_case,end_year);
Omega_weighted = agg_revenue_weighted.omega_agg_avg(cf_case,end_year) ./norminator_Omega - 1;
P0_weighted = agg_revenue_weighted.log_PM_agg_avg(cf_case,end_year) ./ norminator_P0  - 1 ;
        
Omega_uwmean = (agg_mean.omega_agg_avg(cf_case,end_year) -   agg_mean.omega_agg_avg(baseline_case,end_year) ) ./ norminator_Omega; % unweighted average
P0_uwmean= (agg_mean.log_PM_agg_avg(cf_case,end_year) - agg_mean.log_PM_agg_avg(baseline_case,end_year) )./norminator_P0; % unweighted average
        
corr_Omega_share  = (agg_revenue_weighted.corr_omega_share_avg(cf_case,end_year) - agg_revenue_weighted.corr_omega_share_avg(baseline_case,end_year)) ./ norminator_Omega;
corr_P0_share  =  (agg_revenue_weighted.corr_log_PM_share_avg(cf_case,end_year) - agg_revenue_weighted.corr_log_PM_share_avg(baseline_case,end_year) ) ./ norminator_P0;

temp1 = [Omega_weighted', Omega_uwmean', corr_Omega_share'];
temp2 = [P0_weighted', P0_uwmean', corr_P0_share'];
CF_tab.OP_15 = 100*[temp1; temp2];

%fprintf('In full WTO effect counterfactual of all firms, the OP decomposition of productivity in 15 years are (weighted, mean, cov):  \n')
%CF_tab.OP_15

% For 5 years:
end_year = 6; % take a number of years table_firstline =  {'Year', 'Weighted','Un-weighted','Cov','Weighted','Un-weighted','Cov'};

norminator_Omega = agg_revenue_weighted.omega_agg_avg(baseline_case,end_year);
norminator_P0 = agg_revenue_weighted.log_PM_agg_avg(baseline_case,end_year);
Omega_weighted = agg_revenue_weighted.omega_agg_avg(cf_case,end_year) ./norminator_Omega - 1;
P0_weighted = agg_revenue_weighted.log_PM_agg_avg(cf_case,end_year) ./ norminator_P0  - 1 ;
        
Omega_uwmean = (agg_mean.omega_agg_avg(cf_case,end_year) -   agg_mean.omega_agg_avg(baseline_case,end_year) ) ./ norminator_Omega; % unweighted average
P0_uwmean= (agg_mean.log_PM_agg_avg(cf_case,end_year) - agg_mean.log_PM_agg_avg(baseline_case,end_year) )./norminator_P0; % unweighted average
        
corr_Omega_share  = (agg_revenue_weighted.corr_omega_share_avg(cf_case,end_year) - agg_revenue_weighted.corr_omega_share_avg(baseline_case,end_year)) ./ norminator_Omega;
corr_P0_share  =  (agg_revenue_weighted.corr_log_PM_share_avg(cf_case,end_year) - agg_revenue_weighted.corr_log_PM_share_avg(baseline_case,end_year) ) ./ norminator_P0;

temp1 = [Omega_weighted', Omega_uwmean', corr_Omega_share'];
temp2 = [P0_weighted', P0_uwmean', corr_P0_share'];
CF_tab.OP_5 = 100*[temp1; temp2];

%fprintf('In full WTO effect counterfactual of all firms, the OP decomposition of productivity in 5 years are (weighted, mean, cov):  \n')
%CF_tab.OP_5

CF_tab.est = est;
 

