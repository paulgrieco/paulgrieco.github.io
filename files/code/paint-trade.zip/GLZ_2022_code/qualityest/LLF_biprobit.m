% This function produce the log likelyhood function that is ued to estimate the biprobit model for export and import
% participation.

% Input Data: y = [y1, y2] = [export_ind, import_ind]
%                   x1 is the independent variables for y1, export_ind
%                   x2 is the independent variables for y2, import_ind
% Output: LLF_biprobit is the negative log likelyhood;
%             Prob is Prob(y1,y2).

function [LLF_biprobit, Prob] = LLF_biprobit(para,y1,y2,x1,x2)

% unpack parameters
len_1 = size(x1,2);
len_2 = size(x2,2);

y1Para = para(1:len_1);
y2Para = para(len_1 + 1:end-1);
rho = para(end);

assert(len_2 == length(y2Para));

% The notations here follow the one used in the pdf file note in the
% dropbox about biprobit estimation (Also in stata manual).
q1 = 2*y1 - 1;
q2 = 2*y2 - 1;
z1 = x1*y1Para;
z2 = x2*y2Para;
w1 = q1.*z1;
w2 = q2.*z2;
rho_tilde = q1.*q2.*rho;

Cov_pos = [1, rho; rho, 1]; % positive rho
Cov_neg = [1, -rho; -rho, 1]; % negative rho
Prob_pos = mvncdf([w1, w2],0,Cov_pos);
Prob_neg = mvncdf([w1, w2],0,Cov_neg);

Prob = (q1.*q2==1) .* Prob_pos + (q1.*q2== -1) .* Prob_neg;

LLF_biprobit = - sum(log(Prob));

