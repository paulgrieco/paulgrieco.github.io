% This script save data for the dynamic estimation
clear
clc

path_name = ['..' filesep 'dynest' ];
addpath(genpath(path_name))

% Then we need to add other estimates
estOfflineCCP
estEvolution

myfilein = ['..' filesep 'Data' filesep 'quality_out'];
load(myfilein);


%% use grid of capital instead of assuming it is fixed
% Here we replace log_K in dynData by gird points, and compute its
% transition matrix before and after WTO.
quan_set = [0.1,0.3,0.5,0.7,0.9];
quan_bracket = [0, 0.2,0.4,0.6,0.8, 1];
Kgd = quantile(log_capital_norm,quan_set);
Kgd_bracket = quantile(log_capital_norm,quan_bracket);

% compute transition matrix:

for yr = 2000:2005
    yr_ind = (year_lag==yr) & (year==yr+1)&valid_ind;
    logK_ind_set = [ (log_capital_norm_lag<=Kgd_bracket(2)) & (yr_ind), ...
        (log_capital_norm_lag>Kgd_bracket(2))&(log_capital_norm_lag<=Kgd_bracket(3))& (yr_ind), ...
        (log_capital_norm_lag>Kgd_bracket(3))&(log_capital_norm_lag<=Kgd_bracket(4))& (yr_ind), ...
        (log_capital_norm_lag>Kgd_bracket(4))&(log_capital_norm_lag<=Kgd_bracket(5))& (yr_ind), ...
        (log_capital_norm_lag>Kgd_bracket(5))&(yr_ind)];
    for i = 1:length(quan_set)
        logK_ind =  logK_ind_set(:,i);
        logK_next_1_perc = sum((log_capital_norm<=Kgd_bracket(2))&logK_ind&yr_ind)/sum(logK_ind);
        logK_next_2_perc = sum((log_capital_norm>Kgd_bracket(2))&(log_capital_norm<=Kgd_bracket(3))&logK_ind&yr_ind)/sum(logK_ind);
        logK_next_3_perc = sum((log_capital_norm>Kgd_bracket(3))&(log_capital_norm<=Kgd_bracket(4))&logK_ind&yr_ind)/sum(logK_ind);
        logK_next_4_perc = sum((log_capital_norm>Kgd_bracket(4))&(log_capital_norm<=Kgd_bracket(5))&logK_ind&yr_ind)/sum(logK_ind);
        logK_next_5_perc = sum((log_capital_norm>Kgd_bracket(5))&logK_ind&yr_ind)/sum(logK_ind);
        tran(i,:,yr-1999) = [logK_next_1_perc, logK_next_2_perc, logK_next_3_perc, logK_next_4_perc, logK_next_5_perc];
    end
end

est.tran_preWTO = mean(tran(:,:,1:2),3);
est.tran_postWTO = mean(tran(:,:,3:5),3);
est.Kgd = Kgd;

% replace:
log_K_grid = log_capital_norm;

for i = 1:length(quan_set)
    ind_temp = (log_capital_norm>Kgd_bracket(i)) & (log_capital_norm<=Kgd_bracket(i+1));
    log_K_grid(ind_temp) = Kgd(i);
end
log_K_grid(log_capital_norm<=Kgd_bracket(2)) = Kgd(1); % take care the last one (lowest log_K)

log_capital_norm_orig = log_capital_norm; % keep the original data
log_capital_norm = log_K_grid;

%% save the data and offline estimate for dynamic estimation
mytrim = .05; 
keep_ind = (omega_imputed>quantile(omega_imputed,mytrim)) & (omega_imputed<quantile(omega_imputed,1-mytrim)) & (log(PM_imputed)>quantile(log(PM_imputed),mytrim)) & (log(PM_imputed)<quantile(log(PM_imputed),1-mytrim));

dynData.id = id(keep_ind);
dynData.year = year(keep_ind);

dynData.omega = phyOmega(keep_ind);
dynData.log_PM = log_P0(keep_ind);
dynData.log_PL = log_wagerate(keep_ind);
dynData.log_K = log_capital_norm(keep_ind);
dynData.log_K_orig = log_capital_norm_orig(keep_ind);

dynData.exp_ind = exp_ind(keep_ind);
dynData.imp_ind = imp_ind(keep_ind)+0;
dynData.exp_ind_lead = exp_ind_lead(keep_ind);
dynData.imp_ind_lead = imp_ind_lead(keep_ind);

dynData.tariff_use = qualityData.tariff_use(keep_ind);
dynData.wtoDum = qualityData.wtoDum(keep_ind,:);
dynData.wageDum = qualityData.wageDum(keep_ind,:);

dynData.EL = labor_cost(keep_ind);
dynData.EM = material_cost(keep_ind);

dynData.log_qm = log_qm(keep_ind); % just for reference

save(['..' filesep 'Data' filesep 'temp_res.mat'])

%% solve for profit on data:
N = length(dynData.omega);
omega_guess = dynData.omega(1:N);
q_guess = exp(dynData.log_qm(1:N));
L_guess = dynData.EL(1:N)./exp(dynData.log_PL(1:N));
PM0_guess = exp(dynData.log_PM(1:N)) .* q_guess.^est.phi;
M0_guess = dynData.EM(1:N)./PM0_guess;
M_guess = q_guess.*M0_guess;
h_guess = (est.beta*exp(est.theta*omega_guess) + (1-est.beta)*q_guess.^est.theta).^(est.kappa/est.theta);
K_guess = exp(dynData.log_K_orig(1:N));
QD_guess = getProduction(h_guess, L_guess,M_guess,K_guess,est);

guess = [L_guess, M_guess, log(q_guess),QD_guess];
est.guess_max = median(guess,1); % using median gives surprisingly good solution! Not sure why
est.guess_foc = [est.guess_max(3), 0.1*est.guess_max(4)]; % only 10% produced for domestic market

parfor i = 1:length(dynData.omega)
    [profit(i), L(i), M(i), QD(i), QX(i), EL(i),EM(i), exitflag(i), qm(i)] = solveFirmProblem_max(est.guess_max, dynData.omega(i), (dynData.log_K_orig(i)), (dynData.log_PM(i)), (dynData.log_PL(i)),  dynData.exp_ind(i),est);
end

% report how much of the data point is solved:
temp = EM./dynData.EM';
keep_ind = (abs(temp-1)<.001) & (profit > 0); 
fprintf('Note: %g out of a total of %g data points are solved and verified. Percentage: %g. \n', sum(keep_ind), length(keep_ind), sum(keep_ind)./length(keep_ind));
fprintf('The remaining unsolved ones will be re-checked and verified. \n')

%% compute profit directly from the data
for i = 1:N
    if dynData.exp_ind(i) == 1
        z = (est.etaX*(1+est.etaD)/(1+est.etaX)/est.etaD/est.ka)^est.etaX;
        option = optimset('Display','off');
        [QD_solved(i),~,exitflag] = fsolve(@(x) z .* x.^ (est.etaX./est.etaD) + x -  QD_guess(i), QD_guess(i)/2, option);
        QX_solved(i) = QD_guess(i) - QD_solved(i);
    else
        QD_solved(i) = QD_guess(i);
        QX_solved(i) = 0;
    end
end

profit_solved = QD_solved.^(1+1/est.etaD) + est.ka .* QX_solved.^(1+1/est.etaX) - (dynData.EM + dynData.EL)';

assert( sum(abs(profit_solved.\profit-1)>.001 &(keep_ind==1)) == 0 , 'Profit maximization and direct solution do not matach!')

dynData.imp_ind = dynData.imp_ind+0;
dynData.profit = profit_solved';
est.guess_range_max = max([L_guess, M0_guess, log(q_guess), QD_solved'], [], 1); % saved to be used in solving maximization on eds
est.guess_range_min = min([L_guess, M0_guess, log(q_guess), QD_solved'], [], 1);

myfilename = 'painting_res';
myfilename_out = ['..' filesep 'Data' filesep myfilename '_forDyn_prepare'];
save(myfilename_out, 'est', 'dynData')


