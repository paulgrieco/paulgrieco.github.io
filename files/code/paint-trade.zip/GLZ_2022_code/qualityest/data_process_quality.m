% This script is to process the data for quality estimation

%%%%%%%%%%%%%% %%%%%%%%%%%%
%% Prepare the variables (other variables are loaded previously)
yearDum = dummyvar(year-1999);
time_trend = year - 2000;

%%%%%%%% Produce lag indicator (==1 if this obs will used in the estimation) %%%%%%%
id_lag = NaN*zeros(size(id));
id_lag(2:end) = id(1:end-1);
valid_ind = (id == id_lag);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%% Produce no-gap indicator (==1 if there is a no gap between this obs and last obs) %%%%%%%
year_lag = NaN*zeros(size(id));
year_lag(2:end) = year(1:end-1);
temp = year - year_lag;
nogap_ind = (temp == 1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%% Whether or not to drop the obs with gap %%%%%%%
valid_ind = valid_ind.* nogap_ind; 
valid_ind = valid_ind.* (year<=2006); 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% produce lag term of omega
omega_imputed_lag = NaN*zeros(size(omega_imputed)); % make it NaN
omega_imputed_lag(2:end) = omega_imputed(1:end-1);

% produce lag term of PM
PM_imputed_lag = NaN*zeros(size(PM_imputed)); % make it NaN
PM_imputed_lag(2:end) = PM_imputed(1:end-1);

% produce lag term of export_ind
exp_ind = 1-no_exporter;
exp_ind_lag = NaN*zeros(size(exp_ind)); % make it NaN
exp_ind_lag(2:end) = exp_ind(1:end-1);

% produce lag term of export_sh
export_sh_lag = NaN*zeros(size(export_sh)); % make it NaN
export_sh_lag(2:end) = export_sh(1:end-1);

% produce lag term of imp_ind
imp_ind_lag = NaN*zeros(size(imp_ind)); % make it NaN
imp_ind_lag(2:end) = imp_ind(1:end-1);

% produce lag term of import_sh
import_sh_lag = NaN*zeros(size(import_sh)); % make it NaN
import_sh_lag(2:end) = import_sh(1:end-1);

% produce lag term of wage rate
log_wagerate_lag = NaN*zeros(size(PM_imputed)); % make it NaN
log_wagerate_lag(2:end) = log_wagerate(1:end-1);

% produce lag term of capital stock 
log_capital_norm = log(data.capital_norm);
log_capital_norm_lag = NaN*zeros(size(PM_imputed)); % make it NaN
log_capital_norm_lag(2:end) = log_capital_norm(1:end-1);

% produce lag term of number of workers
log_worker= log(data.labor);
log_worker_lag = NaN*zeros(size(PM_imputed)); % make it NaN
log_worker_lag(2:end) = log_worker(1:end-1);

% produce lead term of export_ind
exp_ind_lead = NaN*zeros(size(exp_ind)); % make it NaN
for i = 1:length(exp_ind)-1 % the last one always has no lead
    if id(i) == id(i+1) % if the lead exist
        exp_ind_lead(i) = exp_ind(i+1);
    end
end

% produce lead term of import_ind
imp_ind_lead = NaN*zeros(size(imp_ind)); % make it NaN
for i = 1:length(imp_ind)-1 % the last one always has no lead
    if id(i) == id(i+1) % if the lead exist
        imp_ind_lead(i) = imp_ind(i+1);
    end
end