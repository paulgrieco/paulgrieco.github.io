% This script collects the evolution processes, including the var-cov
% matrix of errors.
clear
clc

myfilein = ['..' filesep 'Data' filesep 'quality_out'];
load(myfilein);

%% For wage regression
X_wage = [ones(length(omega_imputed),1 ),   log_wagerate_lag];  

N_yearDum = size(yearDum(:,2:end-1),2); % record the year dummy number
trim = 0;
good_obs_wage = (valid_ind == 1) &(sum(isnan(X_wage),2)==0) & (sum(imag(X_wage),2)==0) & (log_wagerate<quantile(log_wagerate,1 - trim)) & (log_wagerate>quantile(log_wagerate,trim)) ;
X_wage = X_wage(good_obs_wage ,:);

log_wagerate_used = log_wagerate(good_obs_wage);
[beta_wage , std_beta_wage ] =  lscov(X_wage ,log_wagerate_used);
beta_wage_sign = abs(beta_wage./std_beta_wage)>1.96;
beta_wage_disp = [beta_wage , std_beta_wage, beta_wage_sign];

% % check R^2
SS_tot = sum((log_wagerate_used-mean(log_wagerate_used)).^2);
Y_fit = X_wage*beta_wage;
SS_r = sum((Y_fit-mean(log_wagerate_used)).^2);
R2_wage = SS_r/SS_tot;
e_wage = log_wagerate_used - Y_fit;

% save the estimate
est.wagePara = beta_wage;
est.wage_shockstd = sqrt(sum((Y_fit-log_wagerate_used).^2)/length(Y_fit));
 est.Sigma = cov([e_w_p(good_obs_wage,:), e_wage]); % if use the code write by ourselves

myfileout = ['..' filesep 'Data' filesep 'quality_out'];
save(myfileout);