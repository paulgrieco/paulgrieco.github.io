% This function unpack the parameters for the quality estimation
% use kappa_ind to indicate if we need to estimate kappa.
function [theta_inv, kappa, phi, g0, gt, ge, gi, g1, f0, ft, fi0, fi1, f1] = unpackQualityPara(para, kappa_ind, phi_ind)

if (kappa_ind == 1) & (phi_ind == 0)
    theta_inv = para(1);
    kappa = para(2);
    phi = [];
    g0 = para(3);
    gt = para(4);
    ge = para(5);
    gi = para(6);
    g1 = para(7);
    f0 = para(8);
    ft = para(9);
    fi0 = para(10);
    fi1 = para(11);
    f1 = para(12);
 
 
elseif (kappa_ind == 0) & (phi_ind == 1)
    theta_inv = para(1);
    kappa = [];
    phi = para(2);
    g0 = para(3);
    gt = para(4);
    ge = para(5);
    gi = para(6);
    g1 = para(7);
    f0 = para(8);
    ft = para(9);
    fi0 = para(10);
    fi1 = para(11);
    f1 = para(12);
 
 
elseif (kappa_ind == 0) & (phi_ind == 0)
    theta_inv = para(1);
    phi = [];
    g0 = para(2);
    gt = para(3);
    ge = para(4);
    gi = para(5);
    g1 = para(6);
    f0 = para(7);
    ft = para(8);
    fi0 = para(9);
    fi1 = para(10);
    f1 = para(11);
    kappa = [];
 
 
end
return