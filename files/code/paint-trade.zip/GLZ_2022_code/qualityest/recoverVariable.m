%% This function recover the key variables given the parameters

function [phyOmega, log_qm, log_h, log_P0] = recoverVariable(para,qualityData)
 %% first we unpack the para
 if (qualityData.kappa_ind == 1) & (qualityData.phi_ind == 0)
     [theta_inv, kappa, ~, g0, ge, gi, g1, f0, ft, fi, f1] = unpackQualityPara(para, qualityData.kappa_ind,qualityData.phi_ind); % note that theta_inv = 1/theta to increase stability
     phi = qualityData.phi;
 elseif (qualityData.kappa_ind == 0) & (qualityData.phi_ind == 1)
     [theta_inv, ~, phi, g0, ge, gi, g1, f0, ft, fi, f1] = unpackQualityPara(para, qualityData.kappa_ind,qualityData.phi_ind); % note that theta_inv = 1/theta to increase stability
     kappa = qualityData.kappa;     
 elseif (qualityData.kappa_ind == 0) & (qualityData.phi_ind == 0)
     [theta_inv, ~, ~, g0, ge, gi, g1, f0, ft, fi, f1] = unpackQualityPara(para, qualityData.kappa_ind, qualityData.phi_ind); % note that theta_inv = 1/theta to increase stability
     kappa = qualityData.kappa;
     phi = qualityData.phi;
 end
beta = qualityData.beta; % since beta is not identified, we set it outside of this function

%% construct key variables: phyOmega, log_P0
%  productivity
phyOmega = 1/(kappa)*qualityData.omega -    theta_inv * log(beta*kappa./(kappa-(phi-1)*qualityData.sigmaM));
% log of input quality
log_qm = theta_inv*log(beta/(1-beta)) + theta_inv*log((phi-1) * qualityData.sigmaM./(kappa- (phi-1) * qualityData.sigmaM)) + phyOmega;
% log of output quality
log_h = kappa*theta_inv .* log(beta*kappa./(kappa- (phi-1) * qualityData.sigmaM)) + kappa*phyOmega; % note that this is the log of output quality after optimally choosing input quality 
% log of P0
log_P0 = log(qualityData.PM) - (phi-1) * log_qm; 

end