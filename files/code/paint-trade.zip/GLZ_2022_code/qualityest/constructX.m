% This function produces the structure X for gmm. It contains two
% structures: data and data_lag.

function X = constructX(qualityData)

data.nObs = qualityData.nObs;
data.beta = qualityData.beta;
data.kappa = qualityData.kappa;
data.kappa_ind = qualityData.kappa_ind;  
data.omega = qualityData.omega(qualityData.valid_ind);
data.PM = qualityData.PM(qualityData.valid_ind);
data.sigmaM = qualityData.sigmaM(qualityData.valid_ind);
data.exp_ind = qualityData.exp_ind(qualityData.valid_ind);
data.imp_ind =qualityData. imp_ind(qualityData.valid_ind);
data.exp_ind_lag = qualityData.exp_ind_lag(qualityData.valid_ind);
data.imp_ind_lag = qualityData.imp_ind_lag(qualityData.valid_ind);
data.tariff_use = qualityData.tariff_use(qualityData.valid_ind);
data.yrDum = qualityData.yrDum(qualityData.valid_ind,:);
data.phi_ind = qualityData.phi_ind;  
data.phi = qualityData.phi;

data_lag.nObs = qualityData.nObs;
data_lag.beta = qualityData.beta;
data_lag.kappa = qualityData.kappa;
data_lag.kappa_ind = qualityData.kappa_ind;  
data_lag.phi_ind = qualityData.phi_ind;  
data_lag.phi = qualityData.phi;

PM_lag = zeros(qualityData.nObs,1);
PM_lag(2:end) = qualityData.PM(1:end-1);
omega_lag = zeros(qualityData.nObs,1);
omega_lag(2:end) = qualityData.omega(1:end-1);
sigmaM_lag = zeros(qualityData.nObs,1);
sigmaM_lag(2:end) = qualityData.sigmaM(1:end-1);
tariff_use_lag = zeros(qualityData.nObs,1);
tariff_use_lag(2:end) = qualityData.tariff_use(1:end-1);

data_lag.omega = omega_lag(qualityData.valid_ind);
data_lag.PM = PM_lag(qualityData.valid_ind);
data_lag.sigmaM = sigmaM_lag(qualityData.valid_ind);
data_lag.tariff_use = tariff_use_lag(qualityData.valid_ind);

X.data = data;
X.data_lag = data_lag; 

end