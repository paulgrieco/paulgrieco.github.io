% This function estimate the quality of input and output from the previous
% estimate of omega_hat and PM_hat.

clearvars -except para_boot exitflag_bs i N
clc

global data data_lag

%% load data

path_name = ['..' filesep 'Data' ];
addpath(genpath(path_name))
path_name = ['..' filesep 'staticest' ];
addpath(genpath(path_name))
path_name = ['..' filesep 'GMMpackage' ];
addpath(genpath(path_name))


load('painting_res.mat') % load the result from the previous estimation
data_orig = data; % keep the original data in this new structure

data_process_quality
tariff_avg(year == 2000) =  15;

%% construct the data that used in this estimation
qualityData.nObs = nObs;
qualityData.beta = .5;
qualityData.kappa = 1;
qualityData.kappa_ind = 0; % if we want to estimate kappa
qualityData.phi =  2; 
qualityData.phi_ind = 1; % =1:if we want to estimate phi

qualityData.omega = omega_imputed;
qualityData.PM = PM_imputed;

qualityData.exp_ind = exp_ind;
qualityData.imp_ind = imp_ind;
qualityData.exp_ind_lag = exp_ind_lag;
qualityData.imp_ind_lag = imp_ind_lag;
qualityData.tariff_use = (log(1+tariff_avg/100));
qualityData.yrDum = yearDum(:,2:end-1); 
qualityData.wtoDum = (year>2001);

% make sure the first observation is not NaN
qualityData.exp_ind_lag(1) = 0;
qualityData.imp_ind_lag(1) = 0;

qualityData.tariff_use_lag = zeros(nObs,1);
qualityData.tariff_use_lag(2:end) = qualityData.tariff_use(1:end-1);

% construct simgaM: the elasticity of F wrt M
temp1 = L_norm_sh .* data.labor_norm.^gamma .* (data.material_cost./data.labor_cost) ;
temp2 = L_norm_sh .* data.labor_norm.^gamma .* (1 + data.material_cost./data.labor_cost) + K_norm_sh.* data.capital_norm.^gamma;
sigmaM = temp1 ./ temp2;
qualityData.sigmaM = sigmaM;

sigmaM_lag = zeros(nObs,1);
sigmaM_lag(2:end) = qualityData.sigmaM(1:end-1);

id_lag = zeros(nObs,1);
id_lag(2:end) = id(1:end-1);
valid_ind = (id == id_lag);

qualityData.valid_ind = valid_ind;

L_lag = zeros(nObs,1);
L_lag(2:end) = data.log_labor_norm(1:end-1);

K_lag = zeros(nObs,1);
K_lag(2:end) = data.log_capital_norm(1:end-1);

EL_lag = zeros(nObs,1);
EL_lag(2:end) = data.log_labor_cost_norm(1:end-1);

EM_lag = zeros(nObs,1);
EM_lag(2:end) = data.log_material_cost_norm(1:end-1);

logPM_lag = zeros(nObs,1);
logPM_lag(2:end) = log(PM_imputed(1:end-1));

%% main body of the estimation
if (qualityData.kappa_ind == 1) & (qualityData.phi_ind == 0)
    para0 = [-.2, 2, 0,0,0,.5, .5, 0,0,0,.5, .5 ]';
elseif (qualityData.kappa_ind == 0) & (qualityData.phi_ind == 1)
    para0 = [-.2, 2, 0,0,0,.5, .5, 0,0,0,.5, .5 ]';
elseif (qualityData.kappa_ind == 0) & (qualityData.phi_ind == 0)
    para0 = [-.2, 0, 0,0,.5, .5, 0,0,0,.5, .5 ]'; 
end

% construct the IV set
IV =[ones(size(K_lag)),  (sigmaM_lag ), data.log_capital_norm, K_lag, EM_lag,  L_lag, K_lag.*EM_lag, K_lag.*L_lag, L_lag.*EM_lag, qualityData.exp_ind_lag, qualityData.imp_ind_lag,  ...
    (qualityData.tariff_use - 1*qualityData.tariff_use_lag).*K_lag];

% use current import and export for price:
qualityData.IV_w = [ones(size(K_lag)),  (sigmaM_lag ),  data.log_capital_norm,    K_lag, EM_lag,  L_lag, K_lag.*EM_lag, K_lag.*L_lag, L_lag.*EM_lag,  EL_lag, K_lag.*EL_lag, EM_lag.*EL_lag, EL_lag.*L_lag.*EM_lag,   qualityData.exp_ind_lag, qualityData.imp_ind_lag, qualityData.exp_ind_lag.*qualityData.imp_ind_lag,   (qualityData.wtoDum)  ,qualityData.wtoDum.*qualityData.imp_ind_lag];
qualityData.IV_p = [ones(size(K_lag)),  (sigmaM_lag ),   data.log_capital_norm,  K_lag, EM_lag,  L_lag,  K_lag.*EM_lag, K_lag.*L_lag, L_lag.*EM_lag,  EL_lag, K_lag.*EL_lag, EM_lag.*EL_lag, EL_lag.*L_lag.*EM_lag,   qualityData.exp_ind , qualityData.imp_ind , qualityData.exp_ind .*qualityData.imp_ind ,   (qualityData.wtoDum)   ,qualityData.wtoDum.*qualityData.imp_ind ];

qualityData.IV = IV;

if (qualityData.kappa_ind == 0) & (qualityData.phi_ind == 0)
    % If we want to use the GMM package:
    [gmm_out, shocks]= gmmest(para0,qualityData);
    [phyOmega, log_qm, log_h, log_P0] = recoverVariable(gmm_out.b,qualityData);
    para_final = gmm_out.b;
    corr(phyOmega, log_qm)
    corr(phyOmega, log_P0)
    corr(phyOmega, log_h)
    close all

    % save the estimate of evolution process as well the shocks
    [theta_inv, kappa, phi, g0, gt, ge, gi, g1, f0, ft, fi0, fi1, f1] = unpackQualityPara(gmm_out.b, qualityData.kappa_ind, qualityData.kappa_ind);
    est.omegaPara = [g0, gt, ge, gi, g1]'; % the order should be consistent with getStateTransition.m
    est.pmPara = [f0, ft, fi0, fi1, f1]';
    e_w = shocks(shocks(:,1)~= 0,1);
    e_p = shocks(shocks(:,2)~= 0,2);
    e_w_p = [e_w, e_p]; % the shocks of phyOmega and logP0 combined in a matrix

    est.theta = 1/theta_inv;
    est.kappa = qualityData.kappa;
    est.beta = qualityData.beta;
    est.phi = phi;
    if qualityData.phi_ind == 0; % if phi is not estimated, then the above phi is empty, so we use the prefixed one
        est.phi = qualityData.phi;
    end


else % In the other case, when either phi or kappa needs to be estimated, gmm package will not work, so use the following

    Z =  [qualityData.IV_w(valid_ind,:), zeros(size(qualityData.IV_w(valid_ind,:),1),size(qualityData.IV_p(valid_ind,:),2));
        zeros(size(qualityData.IV_p(valid_ind,:),1),size(qualityData.IV_w(valid_ind,:),2)), qualityData.IV_p(valid_ind,:)];
    W = inv(Z'*Z);

    % 1st stage gmm
    opt_ktr=optimset('TolX',1e-15,'TolFun',1e-6,'MaxIter',2000,'MaxFunEvals',1000000, 'Display','iter');
    lb = -Inf*ones(size(para0));
    ub = Inf*ones(size(para0));
    if (qualityData.kappa_ind == 1) & (qualityData.phi_ind == 0)
        lb(2) = (qualityData.phi +1)*max(max([sigmaM(valid_ind), sigmaM_lag(valid_ind)])) ; %
    elseif (qualityData.kappa_ind == 0) & (qualityData.phi_ind == 1)
        ub(2) = qualityData.kappa./max(max([sigmaM(valid_ind), sigmaM_lag(valid_ind)])) +1; %
    end

    [para_1st, obj_value_1st] = knitrolink(@(x) obj_quality_gmm(x,qualityData, W), para0 ,[],[],[],[],lb,ub,[],opt_ktr);

    [phyOmega, log_qm, log_h, log_P0] = recoverVariable(para_1st,qualityData);
    corr(phyOmega, log_qm)
    corr(phyOmega, log_P0)
    corr(phyOmega, log_h)

    % % 2nd stage gmm
    [~, errors] = obj_quality_gmm(para_1st,qualityData, W) ;
    IV_both = [qualityData.IV, qualityData.IV];
    errors_both = [errors(:,1); errors(:,2)];
    valid_ind_both = [qualityData.valid_ind;qualityData.valid_ind];

    m_time_m_w = 0;
    for j = 1:length(errors)
        if valid_ind(j)==1
            temp = qualityData.IV_w(j,:)'*errors(j,1);
            m_time_m_w = m_time_m_w + temp*temp';
        end
    end

    m_time_m_p = 0;
    for j = 1:length(errors)
        if valid_ind(j)==1
            temp = qualityData.IV_p(j,:)'*errors(j,2);
            m_time_m_p = m_time_m_p + temp*temp';
        end
    end

    V_m = [m_time_m_w, zeros(size(m_time_m_w,1), size(m_time_m_p,2));
        zeros(size(m_time_m_p,1), size(m_time_m_w,2)), m_time_m_p];%/sum(valid_ind==1);

    W_opt = inv(V_m);

    % If we need to do bootstrapping:
    % Step 1: block bootstrapping
    id_valid = id(valid_ind);
    idx_valid = 1:length(id_valid);
    id_set = unique(id_valid);
    n_id = length(id_set); % number of firms
    qualityData.draw = [];
    for i = 1:n_id
        id_draw = id_set(randi(n_id));
        block_draw = idx_valid(id_draw == id_valid);
        qualityData.draw = [qualityData.draw; block_draw'];
    end

    % Step 2: replace obj_quality_gmm by obj_quality_gmm_bs
    [para_2nd, obj_value_2nd,exitflag_para,output_para] = knitrolink(@(x) obj_quality_gmm(x,qualityData, W_opt), para_1st ,[],[],[],[],lb,ub,[],opt_ktr);

    std_2nd = getStd(para_2nd,qualityData,W_opt);

    [phyOmega, log_qm, log_h, log_P0] = recoverVariable(para_2nd,qualityData);
    corr(phyOmega, log_qm)
    corr(phyOmega, log_P0)
    corr(phyOmega, log_h)

    % save the estimate of evolution process as well the shocks
    [theta_inv, kappa, phi, g0, gt, ge, gi, g1, f0, ft, fi0, fi1, f1] = unpackQualityPara(para_2nd, qualityData.kappa_ind, qualityData.phi_ind);

    est.omegaPara = [g0, gt, ge, gi, g1]'; % the order should be consistent with getStateTransition.m
    est.pmPara = [f0, ft, fi0, fi1, f1]';

    [~, errors] = obj_quality_gmm(para_2nd,qualityData, W_opt) ;
    e_w = errors(:,1);
    e_p = errors(:,2);
    e_w_p = [e_w, e_p]; % the shocks of phyOmega and logP0 combined in a matrix

    est.theta = 1/theta_inv;
    est.kappa = qualityData.kappa;
    est.beta = qualityData.beta;
    est.phi = phi;

end

est.Q_avg = exp(data_orig.log_Q_avg); % since we use normalized CES, we need to multiply the output by this.
est.p_idx_D = 1;
est.p_idx_X = 1;

myfileout = ['..' filesep 'Data' filesep 'quality_out'];
save(myfileout);