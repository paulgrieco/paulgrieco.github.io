% This function calculate the objective of the quality estimating equation.
% This one use GMM method (IV is constructed here)

function [obj_quality_gmm, errors, moment] = obj_quality_gmm(para, qualityData, W) % W is the weight
%% first we unpack the para
 if (qualityData.kappa_ind == 1) & (qualityData.phi_ind == 0)
     [theta_inv, kappa, phi, g0, gt, ge, gi, g1, f0, ft, fi0, fi1, f1]= unpackQualityPara(para, qualityData.kappa_ind,qualityData.phi_ind); % note that theta_inv = 1/theta to increase stability
     phi = qualityData.phi;
 elseif (qualityData.kappa_ind == 0) & (qualityData.phi_ind == 1)
     [theta_inv, kappa, phi, g0, gt, ge, gi, g1, f0, ft, fi0, fi1, f1]= unpackQualityPara(para, qualityData.kappa_ind,qualityData.phi_ind); % note that theta_inv = 1/theta to increase stability
     kappa = qualityData.kappa;     
 elseif (qualityData.kappa_ind == 0) & (qualityData.phi_ind == 0)
     [theta_inv, kappa, phi, g0, gt, ge, gi, g1, f0, ft, fi0, fi1, f1] = unpackQualityPara(para, qualityData.kappa_ind); % note that theta_inv = 1/theta to increase stability
     kappa = qualityData.kappa;
     phi = qualityData.phi;
 end

%% recover the key variables given the parameters
[phyOmega, log_qm, log_h, log_P0] = recoverVariable(para,qualityData);

%% construct the IV set
IV_w =  qualityData.IV_w;
IV_p =  qualityData.IV_p;

%% construct the error terms of the evolution process
phyOmega_lag = zeros(qualityData.nObs,1);
phyOmega_lag(2:end) = phyOmega(1:end-1);

log_P0_lag = zeros(qualityData.nObs,1);
log_P0_lag(2:end) = log_P0(1:end-1);

error_w = phyOmega - g0 - g1*phyOmega_lag - ge * qualityData.exp_ind_lag - gi * qualityData.imp_ind_lag  - gt* qualityData.wtoDum;
error_p = log_P0 - f0 - f1*log_P0_lag - ft * qualityData.wtoDum   - fi0 * qualityData.imp_ind.*(1-qualityData.wtoDum) - fi1 * qualityData.imp_ind.*qualityData.wtoDum   ;
errors = [error_w, error_p];

%% construct the moment
valid_ind = qualityData.valid_ind;
M_omega = sum(IV_w(valid_ind,:).*repmat(error_w(valid_ind,:), 1, size(IV_w,2)),1);
M_p = sum(IV_p(valid_ind,:).*repmat(error_p(valid_ind,:) , 1, size(IV_p,2)),1);
moment = [M_omega, M_p];

%% construct the gmm objective
obj_quality_gmm = moment * W * moment';

return