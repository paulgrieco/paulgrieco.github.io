% This script export matlab data to Stata for futher analysis
main_quality

phyOmega_lag = zeros(nObs,1);
phyOmega_lag(2:end) = phyOmega(1:end-1);

log_P0_lag = zeros(nObs,1);
log_P0_lag(2:end) = log_P0(1:end-1);

filename = 'ForStatadata_quality.xlsx';
varName = {'phyOmega','phyOmega_lag', 'log_P0', 'log_P0_lag', 'asset_liquid' 'exp_ind' 'imp_ind' 'lage' 'lliquid' 'log_capital_norm' 'log_wagerate' 'p_capcoll'  'p_capcorporate', 'p_capforeign', 'p_caphkmactai', 'p_capindividual', 'p_capstate' 'year' 'zipcode2' 'pid' 'tariff_avg', 'valid_ind', 'value_fy_exp'};
xlswrite(filename,varName)
A = [phyOmega, phyOmega_lag, log_P0, log_P0_lag, asset_liquid exp_ind+0 imp_ind+0 lage lliquid log_capital_norm log_wagerate p_capcoll p_capcorporate p_capforeign p_caphkmactai p_capindividual p_capstate year zipcode2 pid_0 tariff_avg, valid_ind, value_fy_exp];
xlswrite(filename,A,1, 'A2')

 