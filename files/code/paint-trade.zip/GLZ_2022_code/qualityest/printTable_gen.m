% This function print the table of statistics

function printTable_gen(fid, table_firstline, table_para,table_est,table_se,caption, se_ind) % if se_ind == 1 then print se, otherwise do not print se.
if exist('se_ind') == 0
    se_ind = 1; % the default is to print se
end
    fprintf(fid, '\\begin{table} \n');
    fprintf(fid, '\\caption{ %s }\\centering \n',caption);
    fprintf(fid, '\\begin{tabular}{@{}c');
    
    for i = 1:size(table_est,2)
         fprintf(fid, 'c');
    end
    fprintf(fid, '}\n');
    
    fprintf(fid, '\\toprule   \n');
    
    fprintf(fid,'%s ', table_firstline{1});
    for n = 2:length(table_firstline)
    fprintf(fid,'&%s ', table_firstline{n});
    end
    fprintf(fid, '\\\\ \n ');
    
    fprintf(fid, '\\midrule ');
    
    for n = 1:size(table_est,1)
         fprintf(fid, '%s ', table_para{n});
         if sum(table_est(n,:)) == 0
             fprintf(fid, '&  ');
         fprintf(fid, '\\\\ \n ');
         else
         fprintf(fid, '&%4.3f ', table_est(n,:));
         fprintf(fid, '\\\\ \n ');
         end
         
         if se_ind == 1
         fprintf(fid, '&\\footnotesize(%.3f) ', table_se(n,:));
         fprintf(fid, '\\\\ \n ');
         end
    end
    
    fprintf(fid, '\\bottomrule \n');
    fprintf(fid, '\\end{tabular} \n');
    fprintf(fid, '\\end{table} \n');

   
end