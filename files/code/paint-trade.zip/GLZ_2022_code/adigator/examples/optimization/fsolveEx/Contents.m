% ADiGator system of equations example
%
% Copyright 2011-2015 Matthew J. Weinstein and Anil V. Rao
% Distributed under the GNU General Public License version 3.0
%
% ----------------------------------------------------------------------- %
% FILES:
% bananaf.m  - banana function
% main.m     - solves banana problem using ADiGator derivatives and fsolve