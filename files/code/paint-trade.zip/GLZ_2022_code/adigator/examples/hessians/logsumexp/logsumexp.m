function y = logsumexp(x)

y = log(sum(exp(x)));