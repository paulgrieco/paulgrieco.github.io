% ADiGator Jacobian example problems
%
% Copyright 2011-2015 Matthew J. Weinstein and Anil V. Rao
% Distributed under the GNU General Public License version 3.0
%
% ----------------------------------------------------------------------- %
% DIRECTORIES:
% arrowhead       - Jacobian of arrowhead function
% polydatafit     - Jacobian of polynomial data fitting function