% ADiGator arrowhead Jacobian example
%
% Copyright 2011-2015 Matthew J. Weinstein and Anil V. Rao
% Distributed under the GNU General Public License version 3.0
%
% ----------------------------------------------------------------------- %
% FILES:
% arrowhead.m        - arrowhead function
% arrowhead4numjac.m - arrowhead function to be called by numjac
% main.m             - computes Jacobian of arrowhead function using
%                      ADiGator and numjac