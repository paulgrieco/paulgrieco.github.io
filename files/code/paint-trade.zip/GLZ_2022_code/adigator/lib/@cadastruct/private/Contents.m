% ADiGator overloaded @cadastruct class private library folder
%
% Copyright 2011-2015 Matthew J. Weinstein and Anil V. Rao
% Distributed under the GNU General Public License version 3.0
%
% ----------------------------------------------------------------------- %
% FILES:
% adigatorPrintStructAsgn.m - prints out structure assignments recursively
% cadaloopstructderivref.m  - prints loop iteration dependent derivative
%                             variable references from within structures
% cadaloopstructfuncref.m   - prints loop iteration dependent function
%                             variable references from within structures
