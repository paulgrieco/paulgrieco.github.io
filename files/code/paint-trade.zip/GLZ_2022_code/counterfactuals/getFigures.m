% This function plot the figures given the simulated data.
% Input: counterRes is the result; show_ind is the binary logic indicator
% of firms to be shown out of the full sample of firms. (For example, only aggregate over exporting firms in 2000.)

% 'aggregateMethod': 'mean', 'median', 'weighted', 'industrial'
function [agg] = getFigures(counterRes,show_ind, rel_ind,aggregateMethod,print_ind, firmSim) % if rel_ind == 1, then show the difference relative to the baseline; print_ind==1: print figures (0--not print)

if exist('print_ind') == 0
    print_ind=1;
end

MyStyles = {'-ok'; '-b'; '-sr'; '-xy'; '->m'; '--c'; '-dg'; '-oc';  '-xr';'->c';'*-g';'->m';'-oc';'-+b';'-sr';'-dc';'-xg'}; % if absolute values are plotted.
MyStyles_rel = {'-ok'; '-b'; '-+b'; '-sr'; '-xy'; '->m'; '--c'; '-dg'; '-oc';  '-xr';'->c';'*-g';'->m';'-oc';'-+b';'-sr';'-dc';'-xg'}; % if relative values are plotted.
myLineWidth = 2;

for i = 1:length(counterRes)
    mypath = counterRes(i).sim_path;

    switch aggregateMethod
        case 'mean'
            for j = 1:length(mypath)

                omega_agg(j,:) = mean(exp(mypath{j}.omega(show_ind,:)), 1); % industrial level omega (aggregate)
                log_PM_agg(j,:) = mean(exp(mypath{j}.log_PM(show_ind,:)), 1);
                log_PL_agg(j,:) = mean(mypath{j}.log_PL(show_ind,:), 1);
                exp_ind_agg(j,:) = mean(mypath{j}.exp_ind(show_ind,:), 1);
                imp_ind_agg(j,:) = mean(mypath{j}.imp_ind(show_ind,:), 1);
                profit_agg(j,:) = mean(mypath{j}.profit(show_ind,:), 1);

            end
            omega_agg_avg(i,:) = mean(omega_agg,1); % take average over simulations
            log_PM_agg_avg(i,:) = mean(log_PM_agg,1); % take average over simulations
            log_PL_agg_avg(i,:) = mean(log_PL_agg,1); % take average over simulations
            exp_ind_agg_avg(i,:) = mean(exp_ind_agg,1); % take average over simulations
            imp_ind_agg_avg(i,:) = mean(imp_ind_agg,1); % take average over simulations
            profit_agg_avg(i,:) = mean(profit_agg,1); % take average over simulations

        case 'median' % note that when aggregate over path, we can only take mean here --------- this is used to plot the graphs in the draft
            for j = 1:length(mypath)
                omega_agg(j,:) = mean(mypath{j}.omega(show_ind,:), 1); % industrial level omega (aggregate)
                log_PM_agg(j,:) = mean(mypath{j}.log_PM(show_ind,:), 1);
                log_PL_agg(j,:) = mean(mypath{j}.log_PL(show_ind,:), 1);
                exp_ind_agg(j,:) = mean(mypath{j}.exp_ind(show_ind,:), 1);
                imp_ind_agg(j,:) = mean(mypath{j}.imp_ind(show_ind,:), 1);
                profit_agg(j,:) = mean(mypath{j}.profit_net_expected(show_ind,:), 1);
            end
            omega_agg_avg(i,:) = median(omega_agg,1); % take average over simulations
            log_PM_agg_avg(i,:) = median(log_PM_agg,1); % take average over simulations
            log_PL_agg_avg(i,:) = median(log_PL_agg,1); % take average over simulations
            exp_ind_agg_avg(i,:) = median(exp_ind_agg,1); % take average over simulations
            imp_ind_agg_avg(i,:) = median(imp_ind_agg,1); % take average over simulations
            profit_agg_avg(i,:) = median(profit_agg,1); % take average over simulations

        case 'weighted' % profit weighted
            for j = 1:length(mypath)
                show_ind_temp = show_ind  ;
                omega_agg(j,:) = sum(mypath{j}.omega(show_ind_temp,:) .* repmat(firmSim.sale_sh(show_ind_temp,:), 1, size(mypath{j}.omega,2)) )   ; % industrial level omega (aggregate)
                log_PM_agg(j,:) = sum(mypath{j}.log_PM(show_ind_temp,:) .* repmat(firmSim.sale_sh(show_ind_temp,:), 1, size(mypath{j}.omega,2)) )   ;
                log_PL_agg(j,:) = sum(mypath{j}.log_PL(show_ind_temp,:) .* repmat(firmSim.sale_sh(show_ind_temp,:), 1, size(mypath{j}.omega,2)) )   ;
                exp_ind_agg(j,:) = sum(mypath{j}.exp_ind(show_ind_temp,:) .* repmat(firmSim.sale_sh(show_ind_temp,:), 1, size(mypath{j}.omega,2)) )  ;
                imp_ind_agg(j,:) = sum(mypath{j}.imp_ind(show_ind_temp,:) .* repmat(firmSim.sale_sh(show_ind_temp,:), 1, size(mypath{j}.omega,2)) )   ;
                profit_agg(j,:) = sum(mypath{j}.profit(show_ind_temp,:) .* repmat(firmSim.sale_sh(show_ind_temp,:), 1, size(mypath{j}.omega,2)) )   ;
            end
            omega_agg_avg(i,:) = mean(omega_agg,1); % take average over simulations
            log_PM_agg_avg(i,:) = mean(log_PM_agg,1); % take average over simulations
            log_PL_agg_avg(i,:) = mean(log_PL_agg,1); % take average over simulations
            exp_ind_agg_avg(i,:) = mean(exp_ind_agg,1); % take average over simulations
            imp_ind_agg_avg(i,:) = mean(imp_ind_agg,1); % take average over simulations
            profit_agg_avg(i,:) = mean(profit_agg,1); % take average over simulations

        case 'weighted_mean' % profit weighted
            for j = 1:length(mypath)
                show_ind_temp = show_ind  ;
                omega_agg(j,:) = sum(exp(mypath{j}.omega(show_ind_temp,:)) .* repmat(firmSim.sale_sh(show_ind_temp,:)/sum(firmSim.sale_sh(show_ind_temp,:)), 1, size(mypath{j}.omega,2)) )   ; % industrial level omega (aggregate)
                log_PM_agg(j,:) = sum(exp(mypath{j}.log_PM(show_ind_temp,:) ).* repmat(firmSim.sale_sh(show_ind_temp,:)/sum(firmSim.sale_sh(show_ind_temp,:)), 1, size(mypath{j}.omega,2)) )   ;
                log_PL_agg(j,:) = sum(mypath{j}.log_PL(show_ind_temp,:) .* repmat(firmSim.sale_sh(show_ind_temp,:)/sum(firmSim.sale_sh(show_ind_temp,:)), 1, size(mypath{j}.omega,2)) )   ;
                exp_ind_agg(j,:) = sum(mypath{j}.exp_ind(show_ind_temp,:) .* repmat(ones(size(firmSim.sale_sh(show_ind_temp,:)))/sum(ones(size(firmSim.sale_sh(show_ind_temp,:)))), 1, size(mypath{j}.omega,2)) )  ;
                imp_ind_agg(j,:) = sum(mypath{j}.imp_ind(show_ind_temp,:) .* repmat(ones(size(firmSim.sale_sh(show_ind_temp,:)))/sum(ones(size(firmSim.sale_sh(show_ind_temp,:)))),  1, size(mypath{j}.omega,2)) )   ;
                profit_agg(j,:) = sum(mypath{j}.profit(show_ind_temp,:) .* repmat(ones(size(firmSim.sale_sh(show_ind_temp,:))), 1, size(mypath{j}.omega,2)) )   ;
            end
            omega_agg_avg(i,:) = mean(omega_agg,1); % take average over simulations
            log_PM_agg_avg(i,:) = mean(log_PM_agg,1); % take average over simulations
            log_PL_agg_avg(i,:) = mean(log_PL_agg,1); % take average over simulations
            exp_ind_agg_avg(i,:) = mean(exp_ind_agg,1); % take average over simulations
            imp_ind_agg_avg(i,:) = mean(imp_ind_agg,1); % take average over simulations
            profit_agg_avg(i,:) = mean(profit_agg,1); % take average over simulations

        case 'revenue_weighted' % profit weighted
            for j = 1:length(mypath)

                show_ind_temp = show_ind  ;
                show_revenue_total = sum(mypath{j}.revenue(show_ind_temp,:)); % total share by selection
                revenue_share = mypath{j}.revenue(show_ind_temp,:)./repmat(show_revenue_total,sum(show_ind_temp),1);
                revenue_share_save(:,:,j) = revenue_share;
                omega_agg(j,:) = sum(exp(mypath{j}.omega(show_ind_temp,:) ).* revenue_share )   ; % industrial level omega (aggregate)
                log_PM_agg(j,:) = sum(exp(mypath{j}.log_PM(show_ind_temp,:) ).* revenue_share )   ;
                log_PL_agg(j,:) = sum(mypath{j}.log_PL(show_ind_temp,:) .* revenue_share)   ;
                exp_ind_agg(j,:) = sum(mypath{j}.exp_ind(show_ind_temp,:) .* repmat(ones(size(firmSim.sale_sh(show_ind_temp,:)))/sum(ones(size(firmSim.sale_sh(show_ind_temp,:)))), 1, size(mypath{j}.omega,2)) )  ;
                imp_ind_agg(j,:) = sum(mypath{j}.imp_ind(show_ind_temp,:) .* repmat(ones(size(firmSim.sale_sh(show_ind_temp,:)))/sum(ones(size(firmSim.sale_sh(show_ind_temp,:)))),  1, size(mypath{j}.omega,2)) )   ;
                profit_agg(j,:) = sum(mypath{j}.profit(show_ind_temp,:) .* repmat(ones(size(firmSim.sale_sh(show_ind_temp,:))), 1, size(mypath{j}.omega,2)) )   ;
            end
            omega_agg_avg(i,:) = mean(omega_agg,1); % take average over simulations
            log_PM_agg_avg(i,:) = mean(log_PM_agg,1); % take average over simulations
            log_PL_agg_avg(i,:) = mean(log_PL_agg,1); % take average over simulations
            exp_ind_agg_avg(i,:) = mean(exp_ind_agg,1); % take average over simulations
            imp_ind_agg_avg(i,:) = mean(imp_ind_agg,1); % take average over simulations
            profit_agg_avg(i,:) = mean(profit_agg,1); % take average over simulations
            revenue_share_agg_avg(:,:,i) = mean(revenue_share_save,3);

        case 'industrial' % aggregate profit to industiral total
            for j = 1:length(mypath)
                omega_agg(j,:) = mean(mypath{j}.omega(show_ind,:), 1); % industrial level omega (aggregate)
                log_PM_agg(j,:) = mean(mypath{j}.log_PM(show_ind,:), 1);
                log_PL_agg(j,:) = mean(mypath{j}.log_PL(show_ind,:), 1);
                exp_ind_agg(j,:) = mean(mypath{j}.exp_ind(show_ind,:), 1);
                imp_ind_agg(j,:) = mean(mypath{j}.imp_ind(show_ind,:), 1);
                profit_agg(j,:) = median(mypath{j}.profit(show_ind,:), 1);
            end
            omega_agg_avg(i,:) = mean(omega_agg,1); % take average over simulations
            log_PM_agg_avg(i,:) = mean(log_PM_agg,1); % take average over simulations
            log_PL_agg_avg(i,:) = mean(log_PL_agg,1); % take average over simulations
            exp_ind_agg_avg(i,:) = mean(exp_ind_agg,1); % take average over simulations
            imp_ind_agg_avg(i,:) = mean(imp_ind_agg,1); % take average over simulations
            profit_agg_avg(i,:) = median(profit_agg,1); % take average over simulations

        case 'drop_extreme' % note that when aggregate over path, we can only take mean here

            profit_all_temp = 0;
            for j = 1:length(mypath)
                profit_all_temp = sum(counterRes(1).sim_path{j}.profit, 2) + profit_all_temp;
            end
            show_ind_rev = show_ind & (profit_all_temp >  quantile(profit_all_temp,.03) ) & (profit_all_temp <  quantile(profit_all_temp,.97) );
            for j = 1:length(mypath)
                omega_agg(j,:) = mean(mypath{j}.omega(show_ind_rev,:), 1); % industrial level omega (aggregate)
                log_PM_agg(j,:) = mean(mypath{j}.log_PM(show_ind_rev,:), 1);
                log_PL_agg(j,:) = mean(mypath{j}.log_PL(show_ind_rev,:), 1);
                exp_ind_agg(j,:) = mean(mypath{j}.exp_ind(show_ind_rev,:), 1);
                imp_ind_agg(j,:) = mean(mypath{j}.imp_ind(show_ind_rev,:), 1);
                profit_agg(j,:) = mean(mypath{j}.profit(show_ind_rev,:), 1);
            end
            omega_agg_avg(i,:) = median(omega_agg,1); % take average over simulations
            log_PM_agg_avg(i,:) = median(log_PM_agg,1); % take average over simulations
            log_PL_agg_avg(i,:) = median(log_PL_agg,1); % take average over simulations
            exp_ind_agg_avg(i,:) = median(exp_ind_agg,1); % take average over simulations
            imp_ind_agg_avg(i,:) = median(imp_ind_agg,1); % take average over simulations
            profit_agg_avg(i,:) = median(profit_agg,1); % take average over simulations

    end

    for j = 1:length(mypath)
        n_show = sum(show_ind);
        omega_uwmean = mean(exp(mypath{j}.omega(show_ind,:)), 1); % unweighted average
        log_PM_uwmean = mean(exp(mypath{j}.log_PM(show_ind,:)), 1); % unweighted average

        delta_omega = exp(mypath{j}.omega(show_ind,:)) - repmat(omega_uwmean, n_show, 1);
        delta_log_PM = exp(mypath{j}.log_PM(show_ind,:)) - repmat(log_PM_uwmean, n_show, 1);
        delta_share = mypath{j}.revenue(show_ind,:)./ repmat(sum(mypath{j}.revenue(show_ind,:)), n_show, 1)    -   1/n_show * ones(n_show, size(delta_omega,2));

        corr_omega_share(j,:)  = sum(delta_omega .* delta_share);
        corr_log_PM_share(j,:)  = sum(delta_log_PM .* delta_share);
    end
    corr_omega_share_avg(i,:) = mean(corr_omega_share,1); % take average over simulations
    corr_log_PM_share_avg(i,:) = mean(corr_log_PM_share,1);


    % begin to plot
    x = 1:length(omega_agg_avg(i,:));

    if print_ind == 1

        if rel_ind == 1
            baseline_case = 2; % now the second case is the baseline
            if i>2
                figure(1)
                plot(x, 100*(omega_agg_avg(i,:) - omega_agg_avg(baseline_case,:)),MyStyles_rel{i},'LineWidth',myLineWidth)
                hold on
                figure(2)
                plot(x, 100*(log_PM_agg_avg(i,:) - log_PM_agg_avg(baseline_case,:)),MyStyles_rel{i},'LineWidth',myLineWidth)
                hold on
                figure(3)
                plot(x, 100*(exp_ind_agg_avg(i,:)-exp_ind_agg_avg(baseline_case,:)),MyStyles_rel{i},'LineWidth',myLineWidth)
                hold on
                figure(4)
                plot(x, 100*(imp_ind_agg_avg(i,:) - imp_ind_agg_avg(baseline_case,:)),MyStyles_rel{i},'LineWidth',myLineWidth)
                hold on
            end
        else
            figure(1)
            plot(x, omega_agg_avg(i,:),MyStyles{i},'LineWidth',myLineWidth)
            hold on
            figure(2)
            plot(x, log_PM_agg_avg(i,:),MyStyles{i},'LineWidth',myLineWidth)
            hold on
            hold on
            figure(3)
            plot(x, exp_ind_agg_avg(i,:),MyStyles{i},'LineWidth',myLineWidth)
            hold on
            figure(4)
            plot(x, imp_ind_agg_avg(i,:),MyStyles{i},'LineWidth',myLineWidth)
            hold on
        end
    end

end

if print_ind == 1
    for f = 1:4
        figure(f)
        if rel_ind == 1
            legend( counterRes(3:end).name);  % if we use increased trade cost
            ylabel('Difference')
            xlabel('Year')
        else
            legend(counterRes([1:2]).name); % if we use increased trade cost
            xlabel('Year')
        end
        axis tight
    end

end

agg.omega_agg_avg = omega_agg_avg;
agg.log_PM_agg_avg = log_PM_agg_avg;
agg.log_PL_agg_avg = log_PL_agg_avg;
agg.exp_ind_agg_avg = exp_ind_agg_avg;
agg.imp_ind_agg_avg = imp_ind_agg_avg;
agg.profit_agg_avg = profit_agg_avg;
agg.corr_omega_share_avg = corr_omega_share_avg;
agg.corr_log_PM_share_avg = corr_log_PM_share_avg;

if exist('revenue_share_agg_avg') == 0
    revenue_share_agg_avg = [];
end
agg.revenue_share_agg_avg = revenue_share_agg_avg;

