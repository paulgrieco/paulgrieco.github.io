% This function takes the aggregated simulation result to compute the
% average differences of key variables over years in different
% counterfactuals.

% Input:
% agg is the result data
% CF_set is the set of counterfactuals to be considered;
% baseline_case is the case in the CF result that serves as the baseline.

% Output:
% agg_diff is the returned result that only contains the ones corresponding
% to CF_set.

function [agg_diff] = computeKeyvarDiff(agg, CF_set, baseline_case)

% prepare the results: we can always use the first number (1,1) because it
% is the same for all cases.
agg_omega = agg.omega_agg_avg./agg.omega_agg_avg(1,1); % prodcutivity is in exponential format, so take it as relative ratio first.
agg_PM = agg.log_PM_agg_avg./agg.log_PM_agg_avg(1,1);  % price is in exponential format, so take it as relative ratio first.
agg_exp = agg.exp_ind_agg_avg;
agg_imp = agg.imp_ind_agg_avg;

for i = 1:length(CF_set) % this include all results in the counterfactual result file
    CF_i = CF_set(i);
    agg_diff.omega(i,:) = 100*(agg_omega(CF_i,:)./agg_omega(baseline_case,:) - 1);  % so this is percentage change, not the absolute difference
    agg_diff.PM(i,:) = 100*(agg_PM(CF_i,:)./agg_PM(baseline_case,:) - 1);
    agg_diff.exp(i,:) = 100*(agg_exp(CF_i,:) ./ agg_exp(baseline_case,:) - 1);
    agg_diff.imp(i,:) = 100*(agg_imp(CF_i,:) ./ agg_imp(baseline_case,:) - 1);
    agg_diff.exp_point(i,:) = 100*(agg_exp(CF_i,:) - agg_exp(baseline_case,:));
    agg_diff.imp_point(i,:) = 100*(agg_imp(CF_i,:) - agg_imp(baseline_case,:));
end