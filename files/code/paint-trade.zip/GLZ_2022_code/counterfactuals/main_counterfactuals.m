clear
clc

path_name = ['..' filesep 'ARESLab' ];
addpath(genpath(path_name))
path_name = ['..' filesep 'Data' ];
addpath(genpath(path_name))
path_name = ['..' filesep 'dynest' ];
addpath(genpath(path_name))
path_name = ['..' filesep 'qualityest' ];
addpath(genpath(path_name))

IndustryName = 'painting';
myfilename_in = ['..'  filesep 'Data' filesep IndustryName '_DynEst'];
load(myfilename_in)

% This is to adjust the lambda_xi = 1
dynData.profit_unit = dynData.profit_unit/lambda(1);
lambda = lambda(2:end);
lambda(end+1) = 1;

MARS_model = profitApp_model;
tradeCost =  lambda;

tariff_limit = 1; % now it is wto dummy -- since we are looking at post-wto peirod, it is always 1
firmSim.tariff_limit = tariff_limit;
dynData.tariff_limit = tariff_limit;
N_g = [3,3,1];
delta = .95;
log_ind = 0;
MARS_ind = 3; % The method for approximating VF: 0 is poly; 1 is MARS; 2 is grid approximation; 3 is standard regtangle grid point approx.
order_poly = 5;
onEds = 0; % whether or not to evaluate VF on EDS points
onregt = 1; % if we use regtangle grid points
Tsim =15;
Nsim = 30;
standard_ind = 1;
dist = 0.01;

tariff_schedule = [];
tariff_use_lead = (dynData.year +  1 >2001);

% save additional variables in structures
est.tradeCost = tradeCost;
dynData.N_g = N_g;
dynData.MARS_ind = MARS_ind;
dynData.onEds = onEds;
dynData.onregt = onregt;
dynData.dist = dist;

% prepare the firms to be used in the simulation of paths
firm_ind = (dynData.year ==2006)  ;

firmSim.wageDum = dynData.wageDum(firm_ind,:);
firmSim.year = dynData.year(firm_ind);
firmSim.omega = dynData.omega(firm_ind);
firmSim.log_PM = dynData.log_PM(firm_ind);
firmSim.log_PL = dynData.log_PL(firm_ind);
firmSim.log_K = dynData.log_K(firm_ind);
firmSim.exp_ind = dynData.exp_ind(firm_ind);
firmSim.imp_ind = dynData.imp_ind(firm_ind);
firmSim.profit = dynData.profit(firm_ind);
firmSim.wageDum= dynData.wageDum(firm_ind,:);
firmSim.year= dynData.year(firm_ind);
firmSim.profit_unit = dynData.profit_unit;
firmSim.pullback_ind = dynData.pullback_ind;
firmSim.N_g = N_g;
firmSim.MARS_ind = MARS_ind;
firmSim.dist = dist;
sales_temp = dynData.EL + dynData.EM + dynData.profit;
firmSim.sale_sh = sales_temp(firm_ind)./sum(sales_temp(firm_ind));

% generate GQ grid point and weight for integration
[GQ_grid, weight]=qnwnorm(N_g,[0,0,0],est.Sigma); % state_key is the state of the three key variable in the next period
GQ_shocks = GQ_grid; % for the new quality specification, there is no interaction between pm and omega

if onregt == 1
    myfilename_regt = ['..'  filesep 'Data' filesep 'painting_regGrid_k_6s_2006'];
    load(myfilename_regt)
    state_eds = grid_6s;
    profit_eds = profit_6s;
end

%% Construct Structure Array For Countefactuals, the baseline will be counterRes(1)
numCounters = 1;

%%%%%%%%%%%% Simulate the data from the data ccp.
idx         = 1; %

counterRes(idx).name = 'DataCCPSimulated';
counterRes(idx).descr = 'Construct baseline using the data offline ccp';

fprintf('Counterfactual Number %g: %s ...\n', idx, counterRes(idx).descr)

% keep the data tariff when we simulate from data ccp
tariff_schedule_data = [];
tariff_use_lead_data = (dynData.year +  1 >2001);

% setup result files that used in simulation
dynResCF.shocks = GQ_shocks;
dynResCF.weight = weight;
dynResCF.tradeCost = tradeCost;
dynResCF.delta = delta;
dynResCF.order_poly = order_poly;
dynResCF.V_poly_para = [];
dynResCF.log_ind = log_ind;
dynResCF.standard_ind = standard_ind;
dynResCF.mynorm = [];
dynResCF.V_data = [];
dynResCF.MARS_ind = MARS_ind;
dynResCF.dist = dist;

% save counterfactual result for the value function
counterRes(idx).V_data    = [];

% simulation for paths, and save it
ccpdatasimulate = 1; % =1: use data ccp to simulate; =0 or do not take it as input of the following function: use value function to get ccp for simulation.
counterRes(idx).sim_path = getSimulationPath(firmSim, est, tariff_schedule_data, Tsim, Nsim, MARS, dynResCF, ccpdatasimulate, pct);

myfilename_out = ['..'  filesep 'Data' filesep IndustryName '_CFDynOut_dataccp'];
save(myfilename_out)

% Let "Counterfactual 1" be the baseline data:
%% Case 1: Baseline
idx = idx + 1;

counterRes(idx).name = 'Baseline';
counterRes(idx).descr = 'Construct baseline using estimated parameters, matches data';

fprintf('Counterfactual Number %g: %s ...\n', idx, counterRes(idx).descr)

% calculate the value function in the baseline case
[V_data, V_fun, mynorm] = solveVF(tariff_use_lead, est,dynData,tradeCost, N_g,MARS_model,state_eds, profit_eds, delta, log_ind,MARS_ind,order_poly,standard_ind);

% setup result files that used in simulation
dynResCF.shocks = GQ_shocks;
dynResCF.weight = weight;
dynResCF.tradeCost = tradeCost;
dynResCF.delta = delta;
dynResCF.order_poly = order_poly;
dynResCF.V_poly_para = V_fun;
dynResCF.log_ind = log_ind;
dynResCF.standard_ind = standard_ind;
dynResCF.mynorm = mynorm;
dynResCF.V_data = V_data;
dynResCF.MARS_ind = MARS_ind;
dynResCF.dist = dist;

dynRes_baseline = dynResCF; % save it to be used in other counterfactuals

% save counterfactual result for the value function
counterRes(idx).V_data    = V_data;

% simulation for paths, and save it
ccpdatasimulate = 0;
counterRes(idx).sim_path = getSimulationPath(firmSim, est, tariff_schedule, Tsim, Nsim, MARS, dynResCF, ccpdatasimulate, pct);

myfilename_out = ['..'  filesep 'Data' filesep IndustryName '_CFDynOut'];
save(myfilename_out)

%% Case 2: No WTO effect
idx = idx + 1;

counterRes(idx).name = 'No WTO Effect';
counterRes(idx).descr = 'Set the import effect on price the same as pre-WTO period';

fprintf('Counterfactual Number %g: %s ...\n', idx, counterRes(idx).descr)

est_CF = est;
est_CF.pmPara(4) = est_CF.pmPara(3); %  Set the import effect on price the same as pre-WTO period

% calculate the value function
[V_data, V_fun, mynorm] = solveVF(tariff_use_lead, est_CF,dynData,tradeCost, N_g,MARS_model,state_eds, profit_eds, delta, log_ind,MARS_ind,order_poly,standard_ind);

% setup result files that used in simulation
dynResCF.shocks = GQ_shocks;
dynResCF.weight = weight;
dynResCF.tradeCost = tradeCost;
dynResCF.delta = delta;
dynResCF.order_poly = order_poly;
dynResCF.V_poly_para = V_fun;
dynResCF.log_ind = log_ind;
dynResCF.standard_ind = standard_ind;
dynResCF.V_data = V_data;
dynResCF.mynorm = mynorm;
dynResCF.MARS_ind = MARS_ind;
dynResCF.dist = dist;

dynRes_noWTO = dynResCF; % save it to be used in other counterfactuals

% save counterfactual result for the value function
counterRes(idx).V_data    = V_data;

ccpdatasimulate = 0;
counterRes(idx).sim_path = getSimulationPath(firmSim, est_CF, tariff_schedule, Tsim, Nsim, MARS, dynResCF, ccpdatasimulate, pct);

myfilename_out = ['..'  filesep 'Data' filesep IndustryName '_CFDynOut'];
save(myfilename_out)

%% Case 6: No Trade Effect on Productivity
idx = idx + 1;

counterRes(idx).name = 'No Gain on Prod.';
counterRes(idx).descr = 'Remove the productivity gain from both import and export';

fprintf('Counterfactual Number %g: %s ...\n', idx, counterRes(idx).descr)

est_CF = est;
est_CF.omegaPara(3) = 0; % 3 is the location of productivity gain from export. Set the coefficient to be zero.
est_CF.omegaPara(4) = 0; % 4 is the location of productivity gain from import. Set the coefficient to be zero.

% calculate the value function
[V_data, V_fun, mynorm] = solveVF(tariff_use_lead, est_CF, dynData,tradeCost, N_g,MARS_model,state_eds, profit_eds, delta, log_ind,MARS_ind,order_poly,standard_ind);

% setup result files that used in simulation
dynResCF.shocks = GQ_shocks;
dynResCF.weight = weight;
dynResCF.tradeCost = tradeCost;
dynResCF.delta = delta;
dynResCF.order_poly = order_poly;
dynResCF.V_poly_para = V_fun;
dynResCF.log_ind = log_ind;
dynResCF.standard_ind = standard_ind;
dynResCF.V_data = V_data;
dynResCF.mynorm = mynorm;

% save counterfactual result for the value function
counterRes(idx).V_data    = V_data;

% simulation for paths, and save it
ccpdatasimulate = 0;
counterRes(idx).sim_path = getSimulationPath(firmSim, est_CF, tariff_schedule, Tsim, Nsim, MARS, dynResCF, ccpdatasimulate, pct);

myfilename_out = ['..'  filesep 'Data' filesep IndustryName '_CFDynOut'];
save(myfilename_out)

%% Case 8: No Import Effect on PM
idx  = idx + 1;

counterRes(idx).name = 'No Gain on Price';
counterRes(idx).descr = 'Remove the PM gain from import';

fprintf('Counterfactual Number %g: %s ...\n', idx, counterRes(idx).descr)

est_CF = est;
est_CF.pmPara([3,4]) = 0; % 3 and 4 are the locations of PM gain from import before and after WTO

% calculate the value function
[V_data, V_fun, mynorm] = solveVF(tariff_use_lead, est_CF, dynData,tradeCost, N_g,MARS_model,state_eds, profit_eds, delta, log_ind,MARS_ind,order_poly,standard_ind);

% setup result files that used in simulation
dynResCF.shocks = GQ_shocks;
dynResCF.weight = weight;
dynResCF.tradeCost = tradeCost;
dynResCF.delta = delta;
dynResCF.order_poly = order_poly;
dynResCF.V_poly_para = V_fun;
dynResCF.log_ind = log_ind;
dynResCF.standard_ind = standard_ind;
dynResCF.V_data = V_data;
dynResCF.mynorm = mynorm;

% save counterfactual result for the value function
counterRes(idx).V_data    = V_data;

% simulation for paths, and save it
ccpdatasimulate  = 0;
counterRes(idx).sim_path = getSimulationPath(firmSim, est_CF, tariff_schedule, Tsim, Nsim, MARS, dynResCF,ccpdatasimulate,pct);

myfilename_out = ['..'  filesep 'Data' filesep IndustryName '_CFDynOut'];
save(myfilename_out)

%% Added Case 2: All for WTO-price effect, but use the original policy as the No-WTO-price-effect counterfactual (so no optimization of trade participation)
idx = idx + 1;

counterRes(idx).name = 'Direct Effect of WTO price effect ( firms do not update trade policy)';
counterRes(idx).descr = 'Allow for WTO-price effect, but use the original policy as the No-WTO-price-effect counterfactual (so no optimization of trade participation, but wto effect can carry over)';

fprintf('Counterfactual Number %g: %s ...\n', idx, counterRes(idx).descr)

est_CF = est;

% addstr.opti_ind can take 3 values: 1 (default) allowing for optimization
%                                                          -1 following the  supplied policy (chice can be  different), WTO price can carry over
%                                                          0 following the original participation choice (at the associated states), no WTO price carry over
addstr.opti_ind = -1; % no optimization of policy for trade participation  (Fix policy only, not the choice)
addstr.dynRes_supplied = dynRes_noWTO;

% calculate the value function
[V_data, V_fun, mynorm] = solveVF(tariff_use_lead, est_CF,dynData,tradeCost, N_g,MARS_model,state_eds, profit_eds, delta, log_ind,MARS_ind,order_poly,standard_ind, addstr);

% setup result files that used in simulation
dynResCF.shocks = GQ_shocks;
dynResCF.weight = weight;
dynResCF.tradeCost = tradeCost;
dynResCF.delta = delta;
dynResCF.order_poly = order_poly;
dynResCF.V_poly_para = V_fun;
dynResCF.log_ind = log_ind;
dynResCF.standard_ind = standard_ind;
dynResCF.V_data = V_data;
dynResCF.mynorm = mynorm;
dynResCF.MARS_ind = MARS_ind;
dynResCF.dist = dist;

% save counterfactual result for the value function
counterRes(idx).V_data    = V_data;

% simulation for paths, and save it
ccpdatasimulate = 0;
counterRes(idx).sim_path = getSimulationPath(firmSim, est_CF, tariff_schedule, Tsim, Nsim, MARS, addstr.dynRes_supplied, ccpdatasimulate, pct, addstr); % Note that here use dynRes_baseline to replace the solved result

myfilename_out = ['..'  filesep 'Data' filesep IndustryName '_CFDynOut'];
save(myfilename_out)

%% New Case 1: Reduce the WTO price effect by 25% (i.e., g1_new = g1*0.75) -- remove the price gain of WTO
idx = idx + 1;

counterRes(idx).name = 'Remove WTO price gain';
counterRes(idx).descr = 'Reduce the WTO price effect by 25 percent (g1_new = g1*0.75, pre-WTO period)';

fprintf('Counterfactual Number %g: %s ...\n', idx, counterRes(idx).descr)

est_CF = est;
est_CF.pmPara(4) = 0.75*est_CF.pmPara(4); %  Set the import effect on price the same as pre-WTO period

% calculate the value function
[V_data, V_fun, mynorm] = solveVF(tariff_use_lead, est_CF,dynData,tradeCost, N_g,MARS_model,state_eds, profit_eds, delta, log_ind,MARS_ind,order_poly,standard_ind);

% setup result files that used in simulation
dynResCF.shocks = GQ_shocks;
dynResCF.weight = weight;
dynResCF.tradeCost = tradeCost;
dynResCF.delta = delta;
dynResCF.order_poly = order_poly;
dynResCF.V_poly_para = V_fun;
dynResCF.log_ind = log_ind;
dynResCF.standard_ind = standard_ind;
dynResCF.V_data = V_data;
dynResCF.mynorm = mynorm;
dynResCF.MARS_ind = MARS_ind;
dynResCF.dist = dist;

dynRes_reduceWTOpricegain = dynResCF; % save it to be used in other counterfactuals

% save counterfactual result for the value function
counterRes(idx).V_data    = V_data;

% simulation for paths, and save it
ccpdatasimulate = 0;
counterRes(idx).sim_path = getSimulationPath(firmSim, est_CF, tariff_schedule, Tsim, Nsim, MARS, dynResCF, ccpdatasimulate, pct);

%% New Case 2: Allow for the WTO-price effect (as orginal g1), but use the original policy as the No-WTO-price-effect counterfactual (so no optimization of trade participation)
idx = idx + 1;

counterRes(idx).name = 'Direct Effect of removing WTO price gain ( firms do not update trade policy)';
counterRes(idx).descr = 'Allow for WTO-price effect (original g1), but use the original policy as the No-WTO-price-effect counterfactual (so no optimization of trade participation, but wto effect can carry over)';

fprintf('Counterfactual Number %g: %s ...\n', idx, counterRes(idx).descr)

est_CF = est;

% addstr.opti_ind can take 3 values: 1 (default) allowing for optimization
%                                                          -1 following the  supplied policy (chice can be  different), WTO price can carry over
%                                                          0 following the original participation choice (at the associated states), no WTO price carry over
addstr.opti_ind = -1; % no optimization of policy for trade participation  (Fix policy only, not the choice)
addstr.dynRes_supplied = dynRes_reduceWTOpricegain;

% calculate the value function
[V_data, V_fun, mynorm] = solveVF(tariff_use_lead, est_CF,dynData,tradeCost, N_g,MARS_model,state_eds, profit_eds, delta, log_ind,MARS_ind,order_poly,standard_ind, addstr);

% setup result files that used in simulation
dynResCF.shocks = GQ_shocks;
dynResCF.weight = weight;
dynResCF.tradeCost = tradeCost;
dynResCF.delta = delta;
dynResCF.order_poly = order_poly;
dynResCF.V_poly_para = V_fun;
dynResCF.log_ind = log_ind;
dynResCF.standard_ind = standard_ind;
dynResCF.V_data = V_data;
dynResCF.mynorm = mynorm;
dynResCF.MARS_ind = MARS_ind;
dynResCF.dist = dist;

% save counterfactual result for the value function
counterRes(idx).V_data    = V_data;

% simulation for paths, and save it
ccpdatasimulate = 0;
counterRes(idx).sim_path = getSimulationPath(firmSim, est_CF, tariff_schedule, Tsim, Nsim, MARS, addstr.dynRes_supplied, ccpdatasimulate, pct, addstr); % Note that here use dynRes_baseline to replace the solved result

%% Analyze the result
expFirms = (firmSim.exp_ind == 1); % firms exporting in 2000
impFirms = (firmSim.imp_ind == 1); % firms importing in 2000
showFirms = (expFirms == 1&  impFirms == 1); % firms either exporting or importing in 2000

% showFirms = (firmSim.sale_sh > quantile(firmSim.sale_sh, 2/3) );
% showFirms = (firmSim.sale_sh > quantile(firmSim.sale_sh, 1/3) ) &   (firmSim.sale_sh < quantile(firmSim.sale_sh, 2/3) );
% showFirms = (firmSim.sale_sh < quantile(firmSim.sale_sh, 1/3) );

%showFirms = ( expFirms == 1); % firms either exporting or importing in 2000

% showFirms = (firmSim.omega > quantile(firmSim.omega, 2/3) );
% showFirms = (firmSim.omega > quantile(firmSim.omega, 1/3) ) &   (firmSim.omega < quantile(firmSim.omega, 2/3) );
% showFirms = (firmSim.omega < quantile(firmSim.omega, 1/3) );

rel_ind = 1;
%agg = getFigures(counterRes,showFirms); % for trade firms only
%agg = getFigures(counterRes,showFirms>-999, rel_ind,'weighted_mean', 0, firmSim); % for all firms
agg_mean = getFigures(counterRes,showFirms>-999, rel_ind,'mean', 0, firmSim); % for all firms

% this is for the table that breakdown the changes into different types of
% firms. (weighted_mean is use the fixed revenue share from the data/first year)
agg_revenue_weighted = getFigures(counterRes,showFirms>-999, rel_ind,'revenue_weighted', 0, firmSim); % for all firms


% For different groups of firms:
% first, the over all change
agg_revenue_weighted_overall = getFigures(counterRes,showFirms>-999, rel_ind,'weighted_mean', 0, firmSim); % for all firms

% for high and low Omega firms:
showFirms = (firmSim.omega > quantile(firmSim.omega, 1/2) );
agg_revenue_weighted_hiOmega = getFigures(counterRes,showFirms, rel_ind,'weighted_mean', 0, firmSim); % for all firms
showFirms = (firmSim.omega <= quantile(firmSim.omega, 1/2) );
agg_revenue_weighted_lowOmega = getFigures(counterRes,showFirms, rel_ind,'weighted_mean', 0, firmSim); % for all firms

% for high and low price firms:
showFirms = (firmSim.log_PM > quantile(firmSim.log_PM, 1/2) );
agg_revenue_weighted_hiPrice = getFigures(counterRes,showFirms, rel_ind,'weighted_mean', 0, firmSim); % for all firms
showFirms = (firmSim.log_PM <= quantile(firmSim.log_PM, 1/2) );
agg_revenue_weighted_lowPrice = getFigures(counterRes,showFirms, rel_ind,'weighted_mean', 0, firmSim); % for all firms

% for different types of trading firms
showFirms = (expFirms == 0&  impFirms == 0); % firms either exporting or importing in 2000
agg_revenue_weighted_none = getFigures(counterRes,showFirms, rel_ind,'weighted_mean', 0, firmSim); % for all firms
showFirms = (expFirms == 1&  impFirms == 0); %
agg_revenue_weighted_exp = getFigures(counterRes,showFirms, rel_ind,'weighted_mean', 0, firmSim); % for all firms
showFirms = (expFirms == 0&  impFirms == 1); %
agg_revenue_weighted_imp = getFigures(counterRes,showFirms, rel_ind,'weighted_mean', 0, firmSim); % for all firms
showFirms = (expFirms == 1&  impFirms == 1); %
agg_revenue_weighted_both = getFigures(counterRes,showFirms, rel_ind,'weighted_mean', 0, firmSim); % for all firms

%% save the result
myfilename_out = ['..'  filesep 'Data' filesep IndustryName '_CFDynOut'];
save(myfilename_out)

