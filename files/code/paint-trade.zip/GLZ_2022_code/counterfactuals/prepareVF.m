% This function prepare the intermediate input for Value function iteration

function [state_data, state_full, grid_idx, grid_weight, GQ_weight, TC, TC_std, profit_app] = prepareVF(nObs, tariff_use_lead, est,dynData, tradeCost,N_g, MARS_ind)
% save seed
rng(1)
profit_norm = dynData.profit_unit; % was 4, normalize the profit by this to get a reasonable scale

% we only need to use
% first five dim to calculate profit.
state_data = [dynData.omega, dynData.log_K ,dynData.log_PM ,dynData.log_PL, dynData.exp_ind, dynData.imp_ind];
state_data_min = min(state_data,[],1); % record the min and max in the data as the reference point
state_data_max = max(state_data,[],1);

% get profit on data point
profit_app = dynData.profit./profit_norm; % use the actual profit on data. If we need to use profit on other points (other than data and eds which we do not have profit on, then we need to use approximation)

% get the determinstic part of the trade cost, given the trade status
TC_est = tradeCost(1:end-1); % the first part is the determinstic part, and the last one is the sigma for EV1 distribution
TC_std = tradeCost(end);

TC(:,1) = getTC(dynData.exp_ind, dynData.imp_ind, 0, 0, TC_est);
TC(:,2) = getTC(dynData.exp_ind, dynData.imp_ind, 1, 0, TC_est); % if only export
TC(:,3) = getTC(dynData.exp_ind, dynData.imp_ind, 0, 1, TC_est); % if only import
TC(:,4) = getTC(dynData.exp_ind, dynData.imp_ind, 1, 1, TC_est);

wtoDum_lead = (dynData.year +  1 >2001);

% get the new MEAN state in the next period: in all four cases
[omega_mu(:,1), log_PM_mu(:,1), log_PL_mu(:,1)] = getStateTransition(dynData.omega, dynData.log_PM, dynData.log_PL, dynData.log_K, dynData.exp_ind, dynData.imp_ind, ...
    wtoDum_lead,[], 0*ones(nObs,1), 0*ones(nObs,1), est); % (0,0) means (exp_ind_lead, imp_ind_lead) = (0,0)
[omega_mu(:,2), log_PM_mu(:,2), log_PL_mu(:,2)] = getStateTransition(dynData.omega, dynData.log_PM, dynData.log_PL, dynData.log_K, dynData.exp_ind, dynData.imp_ind, ...
    wtoDum_lead,[], 1*ones(nObs,1), 0*ones(nObs,1), est); % (1,0) means (exp_ind_lead, imp_ind_lead) = (1,0)
[omega_mu(:,3), log_PM_mu(:,3), log_PL_mu(:,3)] = getStateTransition(dynData.omega, dynData.log_PM, dynData.log_PL, dynData.log_K, dynData.exp_ind, dynData.imp_ind, ...
    wtoDum_lead,[], 0*ones(nObs,1), 1*ones(nObs,1), est);
[omega_mu(:,4), log_PM_mu(:,4), log_PL_mu(:,4)] = getStateTransition(dynData.omega, dynData.log_PM, dynData.log_PL, dynData.log_K, dynData.exp_ind, dynData.imp_ind, ...
    wtoDum_lead,[], 1*ones(nObs,1), 1*ones(nObs,1), est);

%get the new state with GQ shocks
state_full = cell(nObs,4); % 4 means we have four cases of export and import
grid_weight = cell(nObs,4);
grid_idx = cell(nObs,4);

% Instead of drawn shocks for each of the variables, we draw shocks
% according to our model. So the shock of omega is going to be in the pm
% for the next period. Remember to multiply the shock by the coefficient
% for omega.
[GQ_grid, GQ_weight]=qnwnorm(N_g,[0,0,0],est.Sigma); % state_key is the state of the three key variable in the next period
shocks = GQ_grid; % for the new quality specification, there is no interaction between pm and omega

all_idx = 1:nObs;

IndustryName = 'painting';
myfilename = ['..'  filesep 'Data' filesep IndustryName '_grid_idx_k.mat'];
saved_ind = exist(myfilename);

tic
parfor i = 1: nObs
    if mod(i,5000) == 0
        %fprintf('Preparing VF: working on %g th of %g ... \n', i, nObs)
    end
    for ie = 1:4 % 4 means we have four trade cases
        mu = [omega_mu(i,ie), log_PM_mu(i,ie), log_PL_mu(i,ie)];
        state_key = repmat(mu, size(GQ_grid,1),1) + shocks;
        state_full{i,ie} = [state_key(:,1), repmat(dynData.log_K(i),size(state_key,1),1),state_key(:,2), state_key(:,3), (ie==2|ie==4)*ones(size(state_key,1),1), (ie==3|ie==4)*ones(size(state_key,1),1)];

        if MARS_ind == 2
            [~, grid_weight{i,ie}, grid_idx{i,ie}] = distanceWeight(state_data, state_full{i,ie},2, dynData.dist);
        elseif (MARS_ind == 3) % & (saved_ind == 0) % If we want a quick check, we can use saved_ind == 0
            % To speed up, we only provide the ones with the same discrete
            % variable (K, e, i) into the function.

            temp_ind = (state_data(:,2) == dynData.log_K(i)) & (state_data(:,5) == (ie==2|ie==4)) &  (state_data(:,6) == (ie==3|ie==4));
            temp_idx = all_idx(temp_ind);
            [idx_sub] = getidx(state_data(temp_ind,:),state_full{i,ie});
            grid_idx{i,ie} = temp_idx(idx_sub);

        end
    end
end
toc

if saved_ind == 0
    save(myfilename,'grid_idx')
end


return