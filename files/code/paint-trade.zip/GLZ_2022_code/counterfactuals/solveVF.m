% This function solve the value function

% Input: grid_data -- it should be ordered as in the same way of the state variables used in the estimation;
%                              it also contain import dummy as the last column.
%           tradeCost -- this is the estimated tradeCost in the order used
%                              in the estimation.
%           N_g -- the number of Guassian Points to be used in the
%                  integration;
%           N_xi -- the number of Monte Carlo draws for trade cost EV1
%           distribution.
%           delta -- the discount
% Output: V_solved is the solved value function on each grid point;
 
% This function use grid-approximation to calculate the value function: the
% value function at a point is approximated using a weighted average of the
% near points' value function values.

function [V_solved, V_solved_fun, norm_out] = solveVF(tariff_use_lead, est,dynData,tradeCost,N_g,MARS_model,state_eds, profit_eds, delta, log_ind, MARS_ind,order_poly,standard_ind, addstr)
if exist('addstr') == 0 % if dynRes_supplied is not supplied, then set the optimization indicator as 1; if it is supplied, then it will be used to compute CCP (in the non-optimization case)
    addstr.opti_ind = 1;
elseif addstr.opti_ind == -1
    fprintf('Solving the value function without optimization of trade participation POLICY (using the supplied policy) with WTO price effect carry over ... \n')
elseif addstr.opti_ind == 0
    fprintf('Solving the value function without optimization of trade participation CHOICE (using the supplied policy and adjusted states), without WTO price effect carry over ... \n')
else
    fprintf('Wrong indicator of optimization!  \n')
    assert(0)
end

% save seed
rng(100)
 
if dynData.onEds == 1 % if we want to evaluate VF on eds rather than the data points

    % due to the lack of memory, we have to choose a set of eds points
    % to use, rather than using all of them.
    temp_idx = randi([1,size(state_eds(:,1),1)],10000,1);
    temp_idx = unique(temp_idx);
    state_eds = state_eds(temp_idx,:);

    eds.omega = state_eds(:,1);
    eds.log_K = state_eds(:,2);
    eds.log_PM = state_eds(:,3);
    eds.log_PL = state_eds(:,4);
    eds.exp_ind = state_eds(:,5);

    nObs = length(eds.omega);
    %%%%%%%%%%%%%%%%%%%%%%%%% SET TARIFF AS 0.07 FIXED -- THIS NEED TO CHANGE.
    tariff_use_lead = []; % we use wto dummy
    eds.year = 2006*ones(nObs,1); % set it as 2006, as we are looking at 2006 only. It need to be changed if we are looking other year. In principle, it is because wto dummy should be a state.
    %%%%%%%%%%%%%%%%%%%%%%
    imp_ind_eds = (rand(nObs,1)>.5); % generate random import indicator as additional state.
    eds.imp_ind = imp_ind_eds;
    eds.profit = profit_eds;
    eds.profit_unit = dynData.profit_unit;
    eds.dist = dynData.dist;
    [state, state_full, grid_idx, grid_weight, weight, TC, TC_std, profit_app] = prepareVF(nObs, tariff_use_lead, est, eds, tradeCost,N_g, MARS_ind);
elseif dynData.onregt == 1 % if we want to evaluate VF on regtangle grid rather than the data points
    eds.omega = state_eds(:,1);
    eds.log_K = state_eds(:,2);
    eds.log_PM = state_eds(:,3);
    eds.log_PL = state_eds(:,4);
    eds.exp_ind = state_eds(:,5);
    eds.imp_ind = state_eds(:,6);
    nObs = length(eds.omega);
    %%%%%%%%%%%%%%%%%%%%%%%%% SET TARIFF AS 0.07 FIXED -- THIS NEED TO CHANGE.
    tariff_use_lead = []; % we use wto dummy
    eds.year = 2006*ones(nObs,1); % set it as 2006, as we are looking at 2006 only. It need to be changed if we are looking other year. In principle, it is because wto dummy should be a state.
    %%%%%%%%%%%%%%%%%%%%%%
    eds.profit = profit_eds;
    eds.profit_unit = dynData.profit_unit;
    eds.dist = dynData.dist;
    [state, state_full, grid_idx, grid_weight, weight, TC, TC_std, profit_app] = prepareVF(nObs, tariff_use_lead, est, eds, tradeCost,N_g, MARS_ind);
else
    nObs = length(dynData.omega);
    [state, state_full, grid_idx, grid_weight, weight, TC, TC_std, profit_app] = prepareVF(nObs, tariff_use_lead, est, dynData, tradeCost,N_g, MARS_ind);
end

CCP_ie_fixed = zeros(nObs,4); % pre-define this for all counterfactuals -- it cannot be empty since we use parfor
if addstr.opti_ind ~= 1 % This contains two cases for non-optimization (-1 and 0). If we restrict the firm to use a given policy function (supplied) or original choices -- so that the firm is not optimally choosing export and import participation.
    % the formulas is: [P1, P2, P3, P4] = getCCP(exp_ind, imp_ind, omega, log_PM,  log_PL, log_K, wageDum, est,dynRes,wtoDum_lead);
    wageDum = [];
    wtoDum_lead = 1;%*ones(size(state(:,1))); % since we are look at years after 2006, it is always 1
    wto_eff_on_pm = est.pmPara(4) - est.pmPara(3); % the wto effect on price -- it is negative
    state_pm_core = state(:,3) - wto_eff_on_pm * state(:,6); % note that state(i,3) is the state for pm: in this specific counterfactual, we need to track the core pm -- the price that is not affected by wto. So this is to translate the observed pm to core pm in order to use V (to produce CCP) in the other counterfactual (in which the observed pm is tracked)
    state_pm_for_ccp = (addstr.opti_ind == 0)*state_pm_core + (addstr.opti_ind ~= 0)*state(:,3); % the price used for compution ccp depends on whether we need to use the core pm or the observed pm. Only in the special counterfactual we need to use the core pm.

    % here we need to replace grid_idx, because we need to track core
    % pm rather than observed pm.
    if addstr.opti_ind == 0 % grid_idx need to be updated only for the counterfactual with `fixed' participation choice (ind == 0)
        grid_idx = cell(nObs,4);
    end
    grid_idx_1 = cell(nObs,1);
    grid_idx_2 = cell(nObs,1);
    grid_idx_3 = cell(nObs,1);
    grid_idx_4 = cell(nObs,1);
    parfor i = 1:nObs

        [P1, P2, P3, P4, ~, grid_idx_temp] = getCCP(state(i,5), state(i,6), state(i,1), state_pm_for_ccp(i),  state(i,4), state(i,2), wageDum, est, addstr.dynRes_supplied,wtoDum_lead);
        CCP_ie_fixed(i,:) = [P1, P2, P3, P4];
        grid_idx_1{i} = grid_idx_temp{:,1};
        grid_idx_2{i} = grid_idx_temp{:,2};
        grid_idx_3{i} = grid_idx_temp{:,3};
        grid_idx_4{i} = grid_idx_temp{:,4};

    end
    % combine them:
    if addstr.opti_ind == 0 % grid_idx need to be updated only for the counterfactual with `fixed' participation choice (ind == 0)
        for i = 1:nObs
            grid_idx{i,1} = grid_idx_1{i};
            grid_idx{i,2} = grid_idx_2{i};
            grid_idx{i,3} = grid_idx_3{i};
            grid_idx{i,4} = grid_idx_4{i};
        end
    end

end

%%
%%%%%%%%%%%%         Now begin the iteration       %%%%%%%%%%%%%%%%%%%%%%%%%%
if dynData.MARS_ind == 3
    N_max = 1000; %maximum of the iteration
    tol = 1*1e-4;%1e-2; % tolerance level
else
    N_max = 50; %maximum of the iteration
    tol = 1*1e-2;%1e-2; % tolerance level
end
diff = 999;
n = 1;
V = ones(nObs,1);
V_new = ones(nObs,1);
V_MARS = 1;

V_poly_para = 1;
mynorm = [];

while n<N_max && diff>tol

    parfor i = 1:nObs % for a given observation/data grid
        % Approximate the value function for the next period
        % Note that the profit is taken out of the expectation and max since it
        % deterministic.

        if n == 1 % for the first iteration, we just use one as the initial guess
            RHSpart_1  = 1 ;
            RHSpart_2  = 1 ;
            RHSpart_3  = 1 ;
            RHSpart_4  = 1 ;

        else
            if MARS_ind == 1 % 1 means to use MARS
                RHSpart_1  = - TC(i,1) + delta *weight' * approxV_MARS(state_full{i,1},V_MARS,state, V, log_ind,standard_ind) ;
                RHSpart_2  = - TC(i,2) + delta *weight' * approxV_MARS(state_full{i,2},V_MARS,state, V, log_ind,standard_ind) ;
                RHSpart_3  = - TC(i,3) + delta *weight' * approxV_MARS(state_full{i,3},V_MARS,state, V, log_ind,standard_ind) ;
                RHSpart_4  = - TC(i,4) + delta *weight' * approxV_MARS(state_full{i,4},V_MARS,state, V, log_ind,standard_ind) ;
            elseif MARS_ind == 2 % 2 means to use grid approximation
                RHSpart_1  = - TC(i,1) + delta *weight' * (grid_weight{i,1} * V(grid_idx{i,1}));
                RHSpart_2  = - TC(i,2) + delta *weight' * (grid_weight{i,2} * V(grid_idx{i,2}));
                RHSpart_3  = - TC(i,3) + delta *weight' * (grid_weight{i,3} * V(grid_idx{i,3}));
                RHSpart_4  = - TC(i,4) + delta *weight' * (grid_weight{i,4} * V(grid_idx{i,4}));
            elseif MARS_ind == 3 % 3 means to use standard regtangle grid approximation

                RHSpart_1  = - TC(i,1) + delta *weight' * V(grid_idx{i,1});
                RHSpart_2  = - TC(i,2) + delta *weight' * V(grid_idx{i,2});
                RHSpart_3  = - TC(i,3) + delta *weight' * V(grid_idx{i,3});
                RHSpart_4  = - TC(i,4) + delta *weight' * V(grid_idx{i,4});

            elseif MARS_ind == 0 % 0 means to use poly
                RHSpart_1  = - TC(i,1) + delta *weight' * appV_poly(state_full{i,1},order_poly, V_poly_para, log_ind,standard_ind,mynorm);
                RHSpart_2  = - TC(i,2) + delta *weight' * appV_poly(state_full{i,2},order_poly, V_poly_para, log_ind,standard_ind,mynorm);
                RHSpart_3  = - TC(i,3) + delta *weight' * appV_poly(state_full{i,3},order_poly, V_poly_para, log_ind,standard_ind,mynorm);
                RHSpart_4  = - TC(i,4) + delta *weight' * appV_poly(state_full{i,4},order_poly, V_poly_para, log_ind,standard_ind,mynorm);
            end

        end

        % use Monte Carlo method
        H = [RHSpart_1, RHSpart_2, RHSpart_3, RHSpart_4]; % See Paul's note for details: the CCP is affected by the dispersion parameter. (Note, solving value function also need to be changed as well.);


        if addstr.opti_ind == 1 % if the firm is optimally choosing export and import decisions, as the traditional value function iteration
            CCP_ie = exp(H./TC_std - max(H./TC_std))./sum(exp(H./TC_std - max(H./TC_std))); % minus max(H) to make sure we do not have Inf as we are using exponential
        else % For other two cases (following policy or following choice), use the pre-computed CCP.
            CCP_ie = CCP_ie_fixed(i,:); % use the pre-computed CCP
        end

        % if there is overflow:
        if (sum(abs(CCP_ie) == Inf)>0) | (sum(isnan(CCP_ie))>0)
            H_max = max(H);
            CCP_ie(H == H_max) = 1;
            CCP_ie(H ~= H_max) = 1e-10;
        end

        CCP_ie(CCP_ie == 0) = 1e-10;

        V_new(i) = profit_app(i) + sum( CCP_ie .* ( H + TC_std*(0.5772156649 - log(CCP_ie)) ) ); %0.5772156649
    end

    if n>1 & MARS_ind == 1
        V = approxV_MARS(state,V_MARS,state, V, log_ind,standard_ind); % to make a consistent comparison, we should compare V_data approximated by MARS
    end

    diff_rel =  max(abs(V_new ./ V - 1));
    diff_relmed =  median(abs(V_new ./ V - 1));
    diff_rel95 =  quantile(abs(V_new ./ V - 1), .95);
    diff_abs = max(abs(V_new - V));
    diff_absmed = median(abs(V_new - V));
    diff = diff_rel95; %diff_rel95; %diff_abs;

    if mod(n,1) == 0
        %fprintf('This is iteration %g, the abs max diff is %f, the abs med diff is %f,  rel max diff is %f, rel med diff is %f, rel 95 diff is %f  \n',n,diff_abs, diff_absmed, diff_rel, diff_relmed, diff_rel95)
    end

    V = V_new;

    if MARS_ind == 1
        V_MARS = getV_MARS(state,V, log_ind,standard_ind); % use MARS to approximate the value function for the next iteration
    elseif MARS_ind == 0
        [V_poly_para, mynorm.mu, mynorm.std, mynorm.mu_inter, mynorm.std_inter ] = getV_poly(state,V, order_poly, log_ind,standard_ind);
    end

    n = n+1;
end

V_solved = V_new;
if MARS_ind == 1
    V_solved_fun = V_MARS;
elseif MARS_ind == 0
    V_solved_fun = V_poly_para;
elseif MARS_ind == 2
    V_solved_fun = grid_weight;
elseif MARS_ind == 3
    V_solved_fun = grid_idx;
end

if MARS_ind == 0
    norm_out = mynorm;
elseif MARS_ind == 1
    norm_out = state;
elseif MARS_ind == 2
    norm_out = [];
elseif MARS_ind == 3
    norm_out = state_eds; % This is the grid
end

return