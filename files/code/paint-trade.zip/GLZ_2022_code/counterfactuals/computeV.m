% This function computes the value function value at each data point, after
% we solve the value function.

function V = computeV(dynData,dynRes,mynorm, est) % mynorm is the same across all CFs in the current setting -- using MARS

omega = dynData.omega;
log_K = dynData.log_K;
log_PM = dynData.log_PM;
log_PL = dynData.log_PL;
exp_ind = dynData.exp_ind;
imp_ind = dynData.imp_ind;
nObs = length(omega);

all_idx = 1:length(dynRes.V_data(:,1));
V = zeros(nObs,1);
parfor i = 1:nObs
    state = [ omega(i), log_K(i), log_PM(i),  log_PL(i), exp_ind(i), imp_ind(i)];

    temp_K = log_K(i); % this is log_K for this firm
    K_grid = unique( mynorm(:,2)); % This is the grid of log_K
    temp_K_ind = abs(temp_K  - K_grid) - min(abs(temp_K  - K_grid));
    K_on_grid = K_grid(temp_K_ind == 0);

    temp_ind = ( mynorm(:,2) == K_on_grid) & ( mynorm(:,5) == exp_ind(i)) &  ( mynorm(:,6) == imp_ind(i));
    temp_idx = all_idx(temp_ind);
    [idx_sub] = getidx( mynorm(temp_ind,:),state);
    grid_idx = temp_idx(idx_sub);
    V(i) = dynRes.V_data(grid_idx); % use the nearest grid point value
end
 

