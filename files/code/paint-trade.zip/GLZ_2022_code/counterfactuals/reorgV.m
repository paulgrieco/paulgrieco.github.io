% re-organize V in matrix
function [V_6d] = reorgV(V_2d, n_grid)

V_6d = zeros(n_grid(1),n_grid(2),n_grid(3),n_grid(4), 2, 2);
i = 0;
for i1 = 1:n_grid(1)
    for i2 = 1:n_grid(2)
        for i3 = 1:n_grid(3)
            for i4 = 1:n_grid(4)
                for i5 = 1:2
                    for i6 = 1:2
                    i = i + 1;                 
                    V_6d(i1,i2,i3,i4,i5,i6) = V_2d(i); 
                    end
                end
            end
        end
    end
end
