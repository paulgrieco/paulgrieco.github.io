% This function check and deal with some special cases
% Note: input V should have 6 dim structure, and it must order in the
% same way as [omega, k, p0, pl, e, i]
% This is similar to revProfit.m, but this one takes all six dim into
% account.
function [V_6d, V_2d, ind_6d] = revV(V)
n_tot = prod([size(V,1), size(V,2),size(V,3),size(V,4),size(V,5)]);
ind_6d = 0*V; % 1 means need to re-calculate V; 0 means no need to re-calculate
%% Check 1st dim: omega
n = 0;
    for i2 = 1:size(V,2)
        for i3 = 1:size(V,3)
            for i4 = 1:size(V,4)
                for i5 = 1:2
                    for i6 = 1:2  
                        V_pre = 0;
                        for i1 = 1:size(V,1)
                            if V(i1,i2,i3,i4,i5,i6) < V_pre
                                V(i1,i2,i3,i4,i5,i6) = V_pre;
                                n = n+1;
                                ind_6d(i1,i2,i3,i4,i5,i6) = 1;
                            else
                                V_pre = V(i1,i2,i3,i4,i5,i6);
                            end
                        end
                    end
                end
            end
        end
    end
    %fprintf('Dim 1: in total %g out of %g changed V.\n', n, n_tot)

%% Check 2nd dim: K
n=0;
    for i1 = 1:size(V,1)
        for i3 = 1:size(V,3)
            for i4 = 1:size(V,4)
                for i5 = 1:2
                    for i6 = 1:2  
                        V_pre = 0;
                        for i2 = 1:size(V,2)
                            if V(i1,i2,i3,i4,i5,i6) < V_pre
                                V(i1,i2,i3,i4,i5,i6) = V_pre;
                                n = n+1;
                                ind_6d(i1,i2,i3,i4,i5,i6) = 1;
                            else
                                V_pre = V(i1,i2,i3,i4,i5,i6);
                            end
                        end
                    end
                end
            end
        end
    end
    %fprintf('Dim 2: in total %g out of %g changed V.\n', n, n_tot)

%% Check 3rd dim: P0
n=0;
    for i1 = 1:size(V,1)
        for i2 = 1:size(V,2)
            for i4 = 1:size(V,4)
                for i5 = 1:2
                    for i6 = 1:2
                        V_pre = V(i1,i2,1,i4,i5,i6);
                        for i3 = 1:size(V,3)
                            if V(i1,i2,i3,i4,i5,i6) > V_pre
                                V(i1,i2,i3,i4,i5,i6) = V_pre;
                                n = n+1;
                                ind_6d(i1,i2,i3,i4,i5,i6) = 1;
                            else
                                V_pre = V(i1,i2,i3,i4,i5,i6);
                            end
                        end
                    end
                end
            end
        end
    end
    %fprintf('Dim 3: in total %g out of %g changed V.\n', n, n_tot)

%% Check 4th dim: PL
n=0;
    for i1 = 1:size(V,1)
        for i2 = 1:size(V,2)
            for i3 = 1:size(V,3)
                for i5 = 1:2
                    for i6 = 1:2
                        V_pre = V(i1,i2,i3,1,i5,i6);
                        for i4 = 1:size(V,4)
                            if V(i1,i2,i3,i4,i5,i6) > V_pre
                                V(i1,i2,i3,i4,i5,i6) = V_pre;
                                n = n+1;
                                ind_6d(i1,i2,i3,i4,i5,i6) = 1;
                            else
                                V_pre = V(i1,i2,i3,i4,i5,i6);
                            end
                        end
                    end
                end
            end
        end
    end
    %fprintf('Dim 4: in total %g out of %g changed V.\n', n, n_tot)
    
 %% Check 5th dim: exp_ind
 n=0;
    for i1 = 1:size(V,1)
        for i2 = 1:size(V,2)
            for i3 = 1:size(V,3)
                for i4 = 1:size(V,4)
                    for i6 = 1:2
                        V_pre = 0;
                        for i5 = 1:2
                            if V(i1,i2,i3,i4,i5,i6) < V_pre
                                V(i1,i2,i3,i4,i5,i6) = V_pre;
                                n = n+1;
                                ind_6d(i1,i2,i3,i4,i5,i6) = 1;
                            else
                                V_pre = V(i1,i2,i3,i4,i5,i6);
                            end
                        end
                    end
                end
            end
        end
    end
    %fprintf('Dim 5: in total %g out of %g changed V.\n', n, n_tot)
    
%% Check 6th dim: imp_ind
 n=0;
    for i1 = 1:size(V,1)
        for i2 = 1:size(V,2)
            for i3 = 1:size(V,3)
                for i4 = 1:size(V,4)
                    for i5 = 1:2
                        V_pre = 0;
                        for i6 = 1:2
                            if V(i1,i2,i3,i4,i5,i6) < V_pre
                                V(i1,i2,i3,i4,i5,i6) = V_pre;
                                n = n+1;
                                ind_6d(i1,i2,i3,i4,i5,i6) = 1;
                            else
                                V_pre = V(i1,i2,i3,i4,i5,i6);
                            end
                        end
                    end
                end
            end
        end
    end
    %fprintf('Dim 6: in total %g out of %g changed V.\n', n, n_tot)
        
 %% re-organize the V in 2-d matrix
i = 0;
for i1 = 1:size(V,1)
    for i2 = 1:size(V,2)
        for i3 = 1:size(V,3)
            for i4 = 1:size(V,4)
                for i5 = 1:2
                    for i6 = 1:2
                    i = i + 1;
                    V_2d(i) =  V(i1,i2,i3,i4,i5,i6);
                    end
                end
            end
        end
    end
end

V_6d = V;

return