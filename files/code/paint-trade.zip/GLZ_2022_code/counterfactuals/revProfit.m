% This function check and deal with some special cases
% Note: input profit should have 6 dim structure, and it must order in the
% same way as [omega, k, p0, pl, e, i]

function [profit_6d, profit_2d, ind_6d] = revProfit(profit)
n_tot = prod([size(profit,1), size(profit,2),size(profit,3),size(profit,4),size(profit,5)]);
ind_6d = 0*profit; % 1 means need to re-calculate profit; 0 means no need to re-calculate
%% Check 1st dim: omega
n = 0;
    for i2 = 1:size(profit,2)
        for i3 = 1:size(profit,3)
            for i4 = 1:size(profit,4)
                for i5 = 1:2
                    for i6 = 1:1 % only need to consider the first one as the other one is the same
                        profit_pre = 0;
                        for i1 = 1:size(profit,1)
                            if profit(i1,i2,i3,i4,i5,i6) < profit_pre
                                profit(i1,i2,i3,i4,i5,i6) = profit_pre;
                                profit(i1,i2,i3,i4,i5,2) = profit_pre; % also change the other one of import indicator
                                n = n+1;
                                ind_6d(i1,i2,i3,i4,i5,1) = 1;
                            else
                                profit_pre = profit(i1,i2,i3,i4,i5,i6);
                            end
                        end
                    end
                end
            end
        end
    end
    %fprintf('Dim 1: in total %g out of %g changed profit.\n', n, n_tot)

%% Check 2nd dim: K
n=0;
    for i1 = 1:size(profit,1)
        for i3 = 1:size(profit,3)
            for i4 = 1:size(profit,4)
                for i5 = 1:2
                    for i6 = 1:1 % only need to consider the first one as the other one is the same
                        profit_pre = 0;
                        for i2 = 1:size(profit,2)
                            if profit(i1,i2,i3,i4,i5,i6) < profit_pre
                                profit(i1,i2,i3,i4,i5,i6) = profit_pre;
                                profit(i1,i2,i3,i4,i5,2) = profit_pre; % also change the other one of import indicator
                                n = n+1;
                                ind_6d(i1,i2,i3,i4,i5,1) = 1;
                            else
                                profit_pre = profit(i1,i2,i3,i4,i5,i6);
                            end
                        end
                    end
                end
            end
        end
    end
    %fprintf('Dim 2: in total %g out of %g changed profit.\n', n, n_tot)

%% Check 3rd dim: P0
n=0;
    for i1 = 1:size(profit,1)
        for i2 = 1:size(profit,2)
            for i4 = 1:size(profit,4)
                for i5 = 1:2
                    for i6 = 1:1 % only need to consider the first one as the other one is the same
                        profit_pre = profit(i1,i2,1,i4,i5,1);
                        for i3 = 1:size(profit,3)
                            if profit(i1,i2,i3,i4,i5,i6) > profit_pre
                                profit(i1,i2,i3,i4,i5,i6) = profit_pre;
                                profit(i1,i2,i3,i4,i5,2) = profit_pre; % also change the other one of import indicator
                                n = n+1;
                                ind_6d(i1,i2,i3,i4,i5,1) = 1;
                            else
                                profit_pre = profit(i1,i2,i3,i4,i5,i6);
                            end
                        end
                    end
                end
            end
        end
    end
    %fprintf('Dim 3: in total %g out of %g changed profit.\n', n, n_tot)

%% Check 4th dim: PL
n=0;
    for i1 = 1:size(profit,1)
        for i2 = 1:size(profit,2)
            for i3 = 1:size(profit,3)
                for i5 = 1:2
                    for i6 = 1:1 % only need to consider the first one as the other one is the same
                        profit_pre = profit(i1,i2,i3,1,i5,i6);
                        for i4 = 1:size(profit,4)
                            if profit(i1,i2,i3,i4,i5,i6) > profit_pre
                                profit(i1,i2,i3,i4,i5,i6) = profit_pre;
                                profit(i1,i2,i3,i4,i5,2) = profit_pre; % also change the other one of import indicator
                                n = n+1;
                                ind_6d(i1,i2,i3,i4,i5,1) = 1;
                            else
                                profit_pre = profit(i1,i2,i3,i4,i5,i6);
                            end
                        end
                    end
                end
            end
        end
    end
    %fprintf('Dim 4: in total %g out of %g changed profit.\n', n, n_tot)
    
 %% Check 5th dim: exp_ind
 n=0;
    for i1 = 1:size(profit,1)
        for i2 = 1:size(profit,2)
            for i3 = 1:size(profit,3)
                for i4 = 1:size(profit,4)
                    for i6 = 1:1 % only need to consider the first one as the other one is the same
                        profit_pre = 0;
                        for i5 = 1:2
                            if profit(i1,i2,i3,i4,i5,i6) < profit_pre
                                profit(i1,i2,i3,i4,i5,i6) = profit_pre;
                                profit(i1,i2,i3,i4,i5,2) = profit_pre; % also change the other one of import indicator
                                n = n+1;
                                ind_6d(i1,i2,i3,i4,i5,1) = 1;
                            else
                                profit_pre = profit(i1,i2,i3,i4,i5,i6);
                            end
                        end
                    end
                end
            end
        end
    end
    %fprintf('Dim 5: in total %g out of %g changed profit.\n', n, n_tot)
    
 %% re-organize the profit in 2-d matrix
i = 0;
for i1 = 1:size(profit,1)
    for i2 = 1:size(profit,2)
        for i3 = 1:size(profit,3)
            for i4 = 1:size(profit,4)
                for i5 = 1:2
                    for i6 = 1:2
                    i = i + 1;
                    profit_2d(i) =  profit(i1,i2,i3,i4,i5,i6);
                    end
                end
            end
        end
    end
end

profit_6d = profit;

return


