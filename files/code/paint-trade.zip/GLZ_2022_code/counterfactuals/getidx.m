% This function construct a matrix/vector of index of value function on grids that can be used in the
% approximate of the value function.
% This function is similar to distanceWeight.m

% The input are:
% -- X: the set of target points (e.g., today's state). Dim: XObs x dim
% -- Y: the set of projection points (e.g., tomorrow's state). Dim: YObs x dim
% Note: X and Y must have the same order of variables. That is, if the
% first dim in X is productivity, then same to Y.

% The output are:
% -- idx: a sparse weight that measure the distance from Y to X. Dim:
% sparse(yObs x 1)

function  [idx] = getidx(X,Y)

% compute one by one:
z = 1:size(X,1);
idx = zeros(size(Y,1),1);
parfor i = 1:size(Y,1) % for each point of Y
    if mod(i,1000) == 0
        fprintf('working on %g th of Y ... \n', i)
    end
    diff_mat =  abs(bsxfun(@minus, X, Y(i,:))); % Dim: xObs x size(Y,2)
    ind_mat = (bsxfun(@minus, diff_mat, min(diff_mat,[],1)) == 0); % the indicator of the min of each column in diff_mat
    ind = sum(ind_mat,2) == size(Y,2); % Dim: xObs x 1
    idx(i) = z(ind);
end

assert(length(idx) == size(Y,1)); % make sure the size of idx is correct (there exists a unique "closest" point in X to each point in Y)

return
