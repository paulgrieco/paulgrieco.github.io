% This function simulate the path of trade decisions, profit, state
% variable, for counterfactual purpose, given the dynamic parameters and value function are estimated.
% This function has the same style of simul, but is independent to make
% things clear.
% ccpdatasimulate = 1: we just want to simulate using data ccp; =0: use
% value function to simulate.
function [sim_path] = getSimulationPath(dynData, est,  tariff_schedule, Tsim, Nsim, MARS, dynRes,ccpdatasimulate, pct, addstr)
if exist('addstr') == 0 % if dynRes_supplied is not supplied, then set the optimization indicator as 1; if it is supplied, then it will be used to compute CCP (in the non-optimization case)
    addstr.opti_ind = 1;
elseif addstr.opti_ind == -1
    fprintf('Solving the value function without optimization of trade participation POLICY (using the supplied policy) with WTO price effect carry over ... \n')
elseif addstr.opti_ind == 0
    fprintf('Solving the value function without optimization of trade participation CHOICE (using the supplied policy and adjusted states), without WTO price effect carry over ... \n')
else
    fprintf('Wrong indicator of optimization!  \n')
    assert(0)
end

%% Prepare
% profit unit -- re-scale the profit to make the absolute difference
% between profits across different types
profit_unit = dynData.profit_unit;
Ndata = size(dynData.omega,1);
sim_path = cell(Nsim,1);
temp_sigma = chol(est.Sigma);  % To be used when drawing shocks

% pull out trade cost
TC_est = est.tradeCost(1:end-1); % the first part is the determinstic part, and the last one is the sigma for EV1 distribution
TC_std = est.tradeCost(end);

nObs = length(dynData.omega);
dynData.onEds = 0;
tariff_use_lead_fixed = dynData.tariff_limit*ones(nObs,1);
if dynData.MARS_ind == 2 % only MARS_ind = 2 need this. MARS_ind = 3 will calculate in getCCP.m
    [~, ~, dynRes.grid_idx, dynRes.grid_weight] = prepareVF(nObs, tariff_use_lead_fixed, est, dynData, est.tradeCost,dynData.N_g, dynData.MARS_ind); % [] position is for tariff_use_lead. Here we fix it at 0.07, just for distance.
end

%% start simulation
parfor nsim=1:Nsim % for each simulation
    if mod(nsim,10) == 0
        %fprintf('Now working on %g th simulation...\n', nsim)
    end
    % keep the seed
    rng(nsim)

    % start from the actual data:
    omega = dynData.omega;
    log_PM = dynData.log_PM;
    log_PL = dynData.log_PL;
    exp_ind = dynData.exp_ind;
    imp_ind = dynData.imp_ind;
    log_K = dynData.log_K;
    wageDum = dynData.wageDum;

    mystate = [omega, log_K ,log_PM ,log_PL, exp_ind];
    profit_approx = appProfit_MARS(mystate,MARS.model_profit,    dynData.pullback_ind, pct) ./ profit_unit;
    revenue_approx = appRevenue_MARS(mystate,MARS.model_revenue,    dynData.pullback_ind, pct) ./ profit_unit;

    % save path of all variables
    sim_path{nsim}.omega(:,1) = omega;
    sim_path{nsim}.log_PM(:,1) = log_PM;
    sim_path{nsim}.log_PL(:,1) = log_PL;
    sim_path{nsim}.log_K(:,1) = log_K;
    sim_path{nsim}.exp_ind(:,1) = exp_ind;
    sim_path{nsim}.imp_ind(:,1) = imp_ind;
    sim_path{nsim}.profit(:,1) = profit_approx;
    sim_path{nsim}.revenue(:,1) = revenue_approx;

    %LOOP OVER TIME FOR A SINGLE PATH FOR EACH OBSERVATION.
    for tsim = 1:Tsim % for each future year
        wtoDum_lead = (dynData.year +  tsim >2001);

        % calculate CCP for the next period
        % first need to make sure whether we need to adjust the state
        % for price. Only in the case of (addstr.opti_ind == 0), with
        % WTO price effect but follow the policy without carryover,
        % need to be adjusted.
        wto_eff_on_pm = est.pmPara(4) - est.pmPara(3); % the wto effect on price -- it is negative
        log_PM_core = log_PM - wto_eff_on_pm * imp_ind;% note that log_PM is the state for pm: in this specific counterfactual, we need to track the core pm -- the price that is not affected by wto. So this is to translate the observed pm to core pm in order to use V (to produce CCP) in the other counterfactual (in which the observed pm is tracked)
        % note here: only need to track and use the core pirce
        % when addstr.opti_ind == 0.
        log_PM_for_ccp = (addstr.opti_ind == 0)*log_PM_core + (addstr.opti_ind ~= 0)*log_PM; % the price used for compution ccp depends on whether we need to use the core pm or the observed pm. Only in the special counterfactual we need to use the core pm.

        if ccpdatasimulate == 0
            [P1, P2, P3, P4] = getCCP(exp_ind, imp_ind, omega, log_PM_for_ccp,  log_PL, log_K, wageDum, est,dynRes,wtoDum_lead);
        else
            [P1, P2, P3, P4] = getCCP(exp_ind, imp_ind, omega, log_PM_for_ccp,  log_PL, log_K, wageDum, est, [], wtoDum_lead);
        end

        % calculate the net profit: today's profit minus the expected
        % trade cost paying for the next period.
        CCP_ie = [P1, P2, P3, P4];
        TC = zeros(size(CCP_ie));
        TC(:,1) = getTC(exp_ind, imp_ind, 0, 0, TC_est);
        TC(:,2) = getTC(exp_ind, imp_ind, 1, 0, TC_est); % if only export
        TC(:,3) = getTC(exp_ind, imp_ind, 0, 1, TC_est); % if only import
        TC(:,4) = getTC(exp_ind, imp_ind, 1, 1, TC_est);

        profit_net = profit_approx + sum( CCP_ie .* ( -TC + TC_std*(0.5772156649 - log(CCP_ie)) ), 2 );
        sim_path{nsim}.profit_net_expected(:,tsim) = profit_net;

        %Choose which acually occurs...
        temp = rand(Ndata,1);
        index1 = temp <=P1;
        index2 = temp<=P1+P2 & temp>P1;
        index3 = temp<=P1+P2+P3 & temp>P1+P2;
        index4 = temp>P1+P2+P3;
        ie_update = index1 + index2*2 +index3*3 + index4*4; % iejt+2 in equation (8) in dynmodel.pdf

        % This is the expected profit for the realized choice
        ie_temp = dummyvar(ie_update);
        profit_net_realized = profit_approx +  sum( -TC.*ie_temp, 2) + TC_std*(0.5772156649 - log(sum(CCP_ie.*ie_temp, 2) ) );
        sim_path{nsim}.profit_net_realized(:,tsim) = profit_net_realized;

        % trade decisions for the next period:
        imp_ind_lead = (ie_update==3 | ie_update ==4);
        exp_ind_lead = (ie_update==2 | ie_update ==4);

        % realized states in the beginning of the next period:
        [omega, log_PM, log_PL, log_K] = getStateTransition(omega, log_PM_for_ccp, log_PL, log_K, exp_ind, imp_ind, ...
            wtoDum_lead,[], exp_ind_lead, imp_ind_lead, est, temp_sigma);  % the [] should be dynData.wageDum

        % calculate profit for the next period:
        mystate = [omega, log_K ,log_PM ,log_PL, exp_ind_lead];
        profit_approx =appProfit_MARS(mystate,MARS.model_profit,   dynData.pullback_ind, pct) ./ profit_unit;
        revenue_approx =appRevenue_MARS(mystate,MARS.model_revenue,   dynData.pullback_ind, pct) ./ profit_unit;

        % record the variable for this simulation:
        sim_path{nsim}.omega(:,tsim+1) = omega;
        sim_path{nsim}.log_PM(:,tsim+1) = log_PM;
        sim_path{nsim}.log_PL(:,tsim+1) = log_PL;
        sim_path{nsim}.log_K(:,tsim+1) = log_K;
        sim_path{nsim}.exp_ind(:,tsim+1) = exp_ind_lead;
        sim_path{nsim}.imp_ind(:,tsim+1) = imp_ind_lead;
        sim_path{nsim}.profit(:,tsim+1) = profit_approx;
        sim_path{nsim}.revenue(:,tsim+1) = revenue_approx;

        % record probabilities of trade decisions: note that this is
        % based on the state of last period, so we use tsim
        sim_path{nsim}.imp0_exp0(:,tsim) = P1;
        sim_path{nsim}.imp0_exp1(:,tsim) = P2;
        sim_path{nsim}.imp1_exp0(:,tsim) = P3;
        sim_path{nsim}.imp1_exp1(:,tsim) = P4;

        % finally, we update the status of trade decision for the next
        % period:
        exp_ind = exp_ind_lead;
        imp_ind = imp_ind_lead;

    end
end

return
 