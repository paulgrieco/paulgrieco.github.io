function [grid_cell, profit_mat, grid_6s, profit_6s ] = getGrid_MARS(state_min, state_max, n_grid, MARS_model, state_eds, profit_eds, pullback_ind, old_profit, pct, est)

grid_cell = cell(n_grid(1),n_grid(2),n_grid(3),n_grid(4), 2, 2);
profit_mat = zeros(n_grid(1),n_grid(2),n_grid(3),n_grid(4), 2, 2);
v1 = linspace(state_min(1), state_max(1), n_grid(1));
v2 = est.Kgd; % the second dim is log_K. 
v3 = linspace(state_min(3), state_max(3), n_grid(3));
v4 = linspace(state_min(4), state_max(4), n_grid(4));
v5 = [0,1];
v6 = [0,1];

grid_all = [];

%% construct grid
for i1 = 1:n_grid(1)
    for i2 = 1:n_grid(2)
        for i3 = 1:n_grid(3)
            for i4 = 1:n_grid(4)
                for i5 = 1:2
                    for i6 = 1:2
                        grid_cell{i1,i2,i3,i4,i5,i6} = [v1(i1), v2(i2), v3(i3), v4(i4), v5(i5), v6(i6)];
                         
                    end
                end
            end
        end
    end
end

% construct grid without import_ind: it does not affect profit.
for i1 = 1:n_grid(1)
    for i2 = 1:n_grid(2)
        for i3 = 1:n_grid(3)
            for i4 = 1:n_grid(4)
                for i5 = 1:2
                     grid_all = [grid_all; [v1(i1), v2(i2), v3(i3), v4(i4), v5(i5)]];   
                end
            end
        end
    end
end

%% calulate profit

if isempty(old_profit) == 1 % if the old profit is not supplied
  [profit_all] = appProfit_MARS(grid_all,MARS_model, pullback_ind, pct);
    % re-organize the solved profit.
    i = 1;
    for i1 = 1:n_grid(1)
      for i2 = 1:n_grid(2)
        for i3 = 1:n_grid(3)
            for i4 = 1:n_grid(4)
                for i5 = 1:2
                    temp = [v1(i1), v2(i2), v3(i3), v4(i4), v5(i5)];
                    assert(sum(temp==grid_all(i,:)) == 5); % check the ordering is the same
                    profit_mat(i1,i2,i3,i4,i5,1) = profit_all(i);
                    profit_mat(i1,i2,i3,i4,i5,2) = profit_all(i);
                    
                    
                    i = i+1;
                end
            end
        end
      end
    end
    
else % use the supplied profit

    profit_mat = old_profit;

end

%% re-organize the grid and profit in matrix -- only take the first five states
n_6s = prod([n_grid(1),n_grid(2),n_grid(3),n_grid(4), 2, 2]);
profit_6s = zeros(n_6s,1);
grid_6s = zeros(n_6s,6);
i = 0;
for i1 = 1:n_grid(1)
    for i2 = 1:n_grid(2)
        for i3 = 1:n_grid(3)
            for i4 = 1:n_grid(4)
                for i5 = 1:2
                    for i6 = 1:2
                    i = i + 1;
                    grid_6s(i,:) =  grid_cell{i1,i2,i3,i4,i5,i6};
                    profit_6s(i) =  profit_mat(i1,i2,i3,i4,i5,i6);
                    end
                end
            end
        end
    end
end



return