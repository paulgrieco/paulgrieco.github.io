clear
clc

path_name = ['..' filesep 'ARESLab' ];
addpath(genpath(path_name))
path_name = ['..' filesep 'Data' ];
addpath(genpath(path_name))
path_name = ['..' filesep 'dynest' ];
addpath(genpath(path_name))

IndustryName = 'painting';
myfilename_in = ['..'  filesep 'Data' filesep IndustryName '_DynEst'];
load(myfilename_in)

firm_ind = (dynData.year ==2006);
firmSim.year = dynData.year(firm_ind);
firmSim.omega = dynData.omega(firm_ind);
firmSim.log_PM = dynData.log_PM(firm_ind);
firmSim.log_PL = dynData.log_PL(firm_ind);
firmSim.log_K = dynData.log_K(firm_ind);
firmSim.exp_ind = dynData.exp_ind(firm_ind);
firmSim.imp_ind = dynData.imp_ind(firm_ind);

% relax the grid range:
state_min = [quantile(firmSim.omega, 0), quantile(firmSim.log_K, 0), quantile(firmSim.log_PM, 0), quantile(firmSim.log_PL,0)];
state_max = [quantile(firmSim.omega,  1), quantile(firmSim.log_K, 1), quantile(firmSim.log_PM, 1), quantile(firmSim.log_PL, 1)];

n_grid = [45,length(est.Kgd),45,3];

% use MARS to approximate:
pullback_ind = 1;
[grid_cell, profit_mat, grid_6s, profit_6s] = ...
    getGrid_MARS(state_min, state_max, n_grid, profitApp_model, state_eds, profit_eds, pullback_ind, [], pct, est);

% save the original result
myfilename_out = ['..'  filesep 'Data' filesep IndustryName '_regGrid_k_2006'];
save(myfilename_out)

% deal with some special cases
[~, profit_2d] = revProfit(profit_mat);
profit_6s = profit_2d; % rename
myfilename_6s = ['..'  filesep 'Data' filesep IndustryName '_regGrid_k_6s_2006'];
save(myfilename_6s,'grid_6s', 'profit_6s')

