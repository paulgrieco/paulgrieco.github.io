README

Date: 8 February, 2022

This contains the Matlab code for the implementation of estimation and counterfactual analysis in 
"Input Prices, Productivity and Trade Dynamics: Long-run Effects of Liberalization on Chinese Paint Manufacturers", Paul Grieco, Shengyu Li, and Hongsong Zhang, 2022.


The "Master" folder contains the master file that conducts all the analysis in the following steps. In particular, 


1.      Static Estimation Stage 1: follow GLZ (2016) to estimate quality-inclusive H and P_M. 
        Main code: staticest\main_static.m
        Output file: painting_res.mat 

        Note that a toolbox called COMPECON has to be installed for this part of the code. The toolbox is available at www4.ncsu.edu/~pfackler/compecon

2.      Static Estimation Stage 2: estimate quality-adjusted omega and p.
        Main code: qualityest\main_quality.m
        Output file: quality_out.mat

 3.     Produce (or update) the gradients and hessian using auto differentiation 
        using ADi_getDeri_foc.m and ADi_getDeri_max.m.

        Note that ADiGator (Version 1.4) is a third party toolbox. 
        It is a Source Transformation via Operator Overloading Tool for 
        the Automatic Differentiation of Mathematical Functions Defined by MATLAB Code.
        The package is under the Copyright 2011-2017 Matthew J. Weinstein and Anil V. Rao.
        It is distributed under the GNU General Public License version 3.0.

4.	Prepare for Dynamic Estimation (1): compute offline CCP, collect evaluation processes (including that of wage rate).
        Main code: qualityest\getDataForDyn.m
        Output file: painting_res_forDyn_prepare.mat

 5.	Prepare for Dynamic Estimation (2): generate EDS, solve profit on EDS, and approximate profit and revenue by MARS;
        Main code: dynest\EDSprofitSolve.m
        Output file: painting_res_forDyn.mat

        Note that MARS is implemented by a third party toolbox, ARESLab (ver 1.13): Adaptive Regression Splines toolbox for Matlab/Octave. ARESLab is a Matlab/Octave toolbox for building piecewise-linear and piecewise-cubic regression models using the Multivariate Adaptive Regression Splines method. The author is Gints Jekabsons (gints.jekabsons@rtu.lv). This toolbox is under Copyright (C) 2009-2016  Gints Jekabsons.


 6.	Dynamic Estimation: estimate trade cost distribution parameters by forward simulation.
        Main code: dynest\main_dyn.m
        Output file: painting_DynEst.mat

 
 7.	Preprare for Counterfactual: setup grid of state and profit for value function iteration. 
        Main code: counterfactual\computeGridProfit.m
        Output file: painting_regGrid_k_6s_2006.mat (This file will be load in the value function iteration.)


8.	Counterfactual: conduct various counterfactuals.
        Main code: counterfactual\mian_counterfactual.m
        Output file: painting_CFDynOut.mat


9.      Print results: print tables
        Main code: master\print_result.m

