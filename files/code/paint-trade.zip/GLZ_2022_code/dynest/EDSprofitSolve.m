% This code solves for profit at EDS grids.

clear all
clc

path_name = ['..' filesep 'ARESLab' ];
addpath(genpath(path_name))
path_name = ['..' filesep 'Data' ];
addpath(genpath(path_name))
path_name = ['..' filesep 'counterfactuals' ];
addpath(genpath(path_name))
path_name = ['..' filesep 'qualityest' ];
addpath(genpath(path_name))

myfilename = 'painting_res';
myfilename_in = ['..'  filesep 'Data' filesep myfilename '_forDyn_prepare'];%_withMARS
load(myfilename_in);

%% setup method:
MARS_ind = 1;
order_poly = 3;
log_ind = 0;
standard_ind = 1;

%% Simulation out of the parameter iteration
Nsim= 30;    % simulate Nsim paths.
Tsim = 30;  % number of periods in each simulation path.
delta = 0.95;
Ndata = size(dynData.omega,1);

% Prepare for drawing shocks to productivity and material price
mu =     [0 0 0];
sigma2 = est.Sigma;
temp_sigma = chol(sigma2);  % To be used when drawing shocks in "simul"

%% Compute profit parameter from data

tariff_schedule = []; % we do not need it in this version

%% Simulation
purpose =0; % purpose=0 means we do the samulation for generating state_pool. outsim=[], and state_pool is the output
temp.model_profit = [];
[outsim, state_pool]  =  simul(dynData,est, mu, temp_sigma, tariff_schedule, Tsim, Nsim, delta,purpose, temp, []);  % simulation out of the dynamic estimation to save time---a nice property of linear-in-parameter setup

%% We do not need to use EDS for now:
% for simulated pool:
epsilon = 0.028.^2; % was 0.15; RAND draft uses 0.033.^2;
rDrop = .8; %
% Make sure the data states are inlcuded in the pool
temp_datastate = [dynData.omega, dynData.log_K , dynData.log_PM , dynData.log_PL, dynData.exp_ind];
state_pool_wdata = [temp_datastate; state_pool];% Make sure the data states are inlcuded in the pool
[statepool_eds, pct] = getSimEDS(state_pool_wdata, epsilon, rDrop);

% for data (make sure ech dim after trimming is within the range of the above simulated pool -- otherwise pct.pc_max and min are different)
epsilon = 0.001.^2; % was 0.15
rDrop = .75; %
% Make sure the data states are inlcuded in the pool
temp_datastate = [dynData.omega, dynData.log_K , dynData.log_PM , dynData.log_PL, dynData.exp_ind];
[statedata_eds] = getSimEDS(temp_datastate, epsilon, rDrop);

% add the data EDS in:
state_eds = statepool_eds;
for i = 1:size(statedata_eds,1)
    this_point = repmat(statedata_eds(i,:), size(statepool_eds,1),1);
    sameDim = sum(abs(this_point - statepool_eds)<1e-4, 2); % use 1e-4 because the mapping can change the points up to machine precision.
    if sum(sameDim == 5)==0 % not in the current statepool_eds
        state_eds = [state_eds; statedata_eds(i,:)];
    end
end

% report:
nn = 0;
for i = 1:size(temp_datastate,1)
    this_point = repmat(temp_datastate(i,:), size(state_eds,1),1);
    sameDim = sum(abs(this_point - state_eds)<1e-4, 2);
    if  sum(sameDim == 5)==1 % not in the current statepool_eds
        nn = nn +1;
    end
end
%fprintf('There are %g data points in EDS\n', nn)

state_eds(:,2) = floor(state_eds(:,2)*10000)/10000; % make sure the log_K has 5 grids as defined.

state_pool = []; % release the space
fprintf('temp_eds saved ...\n')
save(['..' filesep 'Data' filesep 'temp_eds.mat']) % save the temp result

% the first attempt:
n_MS = 10; % number of multi-starts for MAX method
myseed = 1024;
[profit_eds, exitflag_grid, verified_flag, ~, ~, ~, revenue_eds] = getProfit_grid_MS(state_eds,est, n_MS,myseed);

% second attempt:
re_ind = (exitflag_grid==0) | (verified_flag==0); % re-max either very small EM, or not verified ones.
if sum(re_ind) >0 % only do this if there is indeed some points exist
    re_ind = (exitflag_grid==0) | (verified_flag==0); % re-max either very small EM, or not verified ones.
    n_re = sum(re_ind);
    fprintf('Now re-max %g grid points ...\n', n_re)
    state_re = state_eds(re_ind,:);
    n_MS = min( ceil(n_MS*(length(profit_eds)/n_re)/2) * 2, 50); % number of multi-starts for MAX method
    %fprintf('Each of the will have %g multi-starts ...\n', n_MS)
    myseed = 2024;
    [profit_re, exitflag_re, verified_re, ~, ~, ~, revenue_re] = getProfit_grid_MS(state_re,est, n_MS,myseed);
    % fill in the new result:
    profit_eds(re_ind) = profit_re;
    revenue_eds(re_ind) = revenue_re;
    verified_flag(re_ind) = verified_re;
    exitflag_grid(re_ind) =exitflag_re;
    % report:
    n_remain = sum(exitflag_grid==0);
    %fprintf('Still remain %g grid points reporting unsolved after second attempt ...\n', n_remain)
else
    fprintf('All solved in one go!\n')
end

% % only use the well-solved part of the grid points:
state_eds = state_eds((verified_flag) & (exitflag_grid),:);
profit_eds = profit_eds((verified_flag) & (exitflag_grid),:);
revenue_eds = revenue_eds((verified_flag) & (exitflag_grid),:);

% Change: instead of force correcting them, we drop them.
badProfit_ind = abs(imag(profit_eds))>0 | profit_eds<=1 | profit_eds>1e+20 | abs(imag(revenue_eds))>0 | revenue_eds<=1 | revenue_eds>1e+20;
N_badProfit = sum(badProfit_ind);
%fprintf('There are a total of %g profit_eds revenue_eds are negative or have imag part -- they are taken as abs. \n', N_badProfit)

state_eds = state_eds(badProfit_ind==0,:);
profit_eds = profit_eds(badProfit_ind==0,:);
revenue_eds = revenue_eds(badProfit_ind==0,:);

%%%% save the profit before drop anything:
myfilename_out = ['..'  filesep 'Data' filesep myfilename '_forDyn_profitsolved'];
save(myfilename_out,'profit_eds','revenue_eds','state_eds','dynData','est','pct');

%%%%%%%%%%%%% Here we can drop some very large profit points, before going
%%%%%%%%%%%%% into MARS:
eds_keep = (profit_eds<quantile(profit_eds,0.99));
profit_eds = profit_eds(eds_keep);
revenue_eds = revenue_eds(eds_keep);
state_eds = state_eds(eds_keep,:);
%%%%%%%%%%%%% Finish the dropping %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if MARS_ind == 1
    %% get MARS model
    [MARS_model_profit, MARS_model_revenue, pct] = getMARS(state_eds,profit_eds, revenue_eds, pct, dynData); % for profit
    profitApp_model = MARS_model_profit;
    revenueApp_model = MARS_model_revenue;

else
    %% get Poly model
    if exist('Poly_model') == 0 % if we do not have MARS model in the data, we set it as empty temporarily
        [profit_poly_para, mu_norm, std_norm] = getProfit_poly(state_eds,profit_eds, order_poly, log_ind,standard_ind);
        Poly_model.profit_poly_para = profit_poly_para;
        Poly_model.order_poly = order_poly;
        Poly_model.log_ind = log_ind;
        Poly_model.standard_ind = standard_ind;
        Poly_model.mynorm.mu = mu_norm;
        Poly_model.mynorm.std = std_norm;
        profitApp_model = Poly_model;
    end
end

%% save
myfilename_out = ['..'  filesep 'Data' filesep myfilename '_forDyn'];
save(myfilename_out,'profit_eds','state_eds','dynData','est','profitApp_model', 'revenueApp_model', 'pct');