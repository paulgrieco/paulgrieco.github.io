% This function evaluate the FOC about qm -- input quality choice.
% The output is the difference of the LHS and RHS of the FOC, and the
% material quantity given qm

function [ineq_err, eq_err] = qmFOC(x,exog_var)
% unpack auxiliary data:
omega = exog_var.omega;
K = exog_var.K;
P0 = exog_var.P0;
PL = exog_var.PL;
export_ind = exog_var.export_ind;
est = exog_var.est;

[foc_temp] = qmFOC_base(x,omega, K, P0, PL, export_ind, est);
eq_err(1) = foc_temp(1);
eq_err(2) = foc_temp(2);

ineq_err = [];

return
