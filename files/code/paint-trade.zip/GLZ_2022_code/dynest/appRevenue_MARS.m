% Input data: the state at the original level -- no normalization
function  [revenue_predicted] = appRevenue_MARS(state_data,MARS_model,  pullback_ind, pct)
%% We must use Principal component transformation first,
state_temp = state_data(:,1:4)*pct.V;

%% First we normalize X to [0,1] and standardize Y
state_data_norm = bsxfun(@rdivide, bsxfun(@minus, state_temp, pct.min), pct.max  - pct.min);
% add the last binary variable on
state_data_norm = [state_data_norm , state_data(:,end)];

state_data_norm_0 = state_data_norm;
state_data_norm_0(:,end) = 0;
revenue_predicted_norm_0 = arespredict(MARS_model, state_data_norm_0);

state_data_norm_1 = state_data_norm;
state_data_norm_1(:,end) = 1;
revenue_predicted_norm_1 = arespredict(MARS_model, state_data_norm_1);

revenue_predicted_norm = revenue_predicted_norm_0.*(state_data_norm(:,end)==0) ... % nonexport case
                                      + revenue_predicted_norm_0.*(state_data_norm(:,end)==1).*( revenue_predicted_norm_0> revenue_predicted_norm_1) ... % export case but bad approx
                                      + revenue_predicted_norm_1.*(state_data_norm(:,end)==1).*( revenue_predicted_norm_0<= revenue_predicted_norm_1) ;   % export case and good approx

revenue_predicted = revenue_predicted_norm *pct.revenue_scale + pct.revenue_location;

ind_over = revenue_predicted>pct.revenue_eds_max;
ind_under = revenue_predicted<pct.revenue_eds_min;
revenue_predicted = (ind_over==0 & ind_under==0).*revenue_predicted ...
                           + (ind_over==1  ).*pct.revenue_eds_max ...
                           + (ind_under==1  ).*pct.revenue_eds_min;
                       
                       