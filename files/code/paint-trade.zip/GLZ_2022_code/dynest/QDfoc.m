% This function evaluate the FOC about QD.
% The output is the difference of the LHS and RHS of the FOC, and the
% material quantity given QD

function [diff, M] = QDfoc(x,omega, K, PM, PL,  export_ind, est)

gamma = (est.sigma-1)/est.sigma;

z = export_ind.*(est.etaX*(1+est.etaD)/(1+est.etaX)/est.etaD/est.ka)^est.etaX;

coeff_temp = est.aL.*(PL.*est.aM./PM./est.aL).^(gamma/(gamma-1)) + est.aM;

innerPart = (z.*x.^(est.etaX/est.etaD) + x)./(exp(omega).*est.Q_avg);

M_gamma =  (innerPart.^gamma - est.aK * K.^gamma)./coeff_temp; % This is M^gamma

M = M_gamma.^(1/gamma);

diff = (est.etaD+1)/est.etaD  .* est.p_idx_D .* est.aM .* M.^(gamma-1) .* exp(omega).*est.Q_avg .* innerPart.^(1-gamma) -  x.^(-1/est.etaD) .* PM;
