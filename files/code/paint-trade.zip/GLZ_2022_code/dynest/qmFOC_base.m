% This function evaluate the FOC about qm -- input quality choice.
% The output is the difference of the LHS and RHS of the FOC, and the
% material quantity given qm

function [diff, M, PM, QD, qm] = qmFOC_base(x,omega, K, P0, PL, export_ind, est)
% unpack variables:
%qm = x(1);
log_qm = x(1);
qm = exp(log_qm);
QD = x(2);

% set parameters
gamma = (est.sigma-1)/est.sigma;
z = export_ind.*(est.etaX*(1+est.etaD)/(1+est.etaX)/est.etaD/est.ka)^est.etaX;

% compute PM
PM = P0*qm.^(est.phi - 1);

% compute sigma_M -- the elasticity of M_jt (not M_0jt)
temp_beta = (1-est.beta)/est.beta;
temp_sigmaM = temp_beta .* exp(- est.theta*omega) .* qm.^est.theta;
temp_sigmaM = temp_sigmaM./(1 + temp_sigmaM);
sigma_M = (est.kappa/(est.phi - 1)) .* temp_sigmaM;

% compute M -- it is M_jt (not M_0jt)
A = 1 + est.aL/est.aM*(est.aM*PL./(est.aL*PM)).^(gamma/(gamma-1));
B = est.aK*K.^gamma;
M = (B.*sigma_M/(est.aM*(1 - A.*sigma_M))).^(1/gamma);
amMgamma = B.*sigma_M/(1 - A.*sigma_M);

% compute L
L = (est.aM.*PL ./ (est.aL*PM)).^(1/(gamma-1)) .* M;

% compute omega_hat -- the combination of omega and qm. 
omega_hat = est.kappa * omega + est.kappa/est.theta * log(est.beta*est.kappa./(est.kappa - (est.phi - 1)*sigma_M));

% compute QD
 innerPart = (amMgamma .* A + B).^(1/gamma);
diff_QD = z .* QD.^ (est.etaX./est.etaD) + QD - exp(omega_hat) .* est.Q_avg .* innerPart; % this is from production function.

diff_qm = (est.etaD+1)/est.etaD  .* est.p_idx_D .* est.aM .* M.^(gamma-1) .* exp(omega_hat).*est.Q_avg .* innerPart.^(1-gamma) -  QD.^(-1/est.etaD) .* PM;

diff = [diff_qm; diff_QD];