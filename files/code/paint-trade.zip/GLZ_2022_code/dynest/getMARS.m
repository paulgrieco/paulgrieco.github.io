%%%%%%%%%%%%%% USA MARS to approximate the profit funciton
function [MARS_model_profit, MARS_model_revenue, pct] = getMARS(state_eds,profit_eds, revenue_eds, pct, dynData)
%% We must use Principal component transformation first,
state_temp = state_eds(:,1:4)*pct.V;

%% First we normalize X to [0,1] and standardize Y
state_eds_norm = bsxfun(@rdivide, bsxfun(@minus, state_temp, pct.min), pct.max  - pct.min);
% add the last binary variable on
state_eds_norm = [state_eds_norm , state_eds(:,end)];

pct.profit_location  = mean(profit_eds);
pct.profit_scale  = std(profit_eds);
pct.revenue_location  = mean(revenue_eds);
pct.revenue_scale  = std(revenue_eds);

% In RAND R&R, we use capital grid points, so use the trim level as the original
% version.
pct.profit_eds_max = quantile(profit_eds,.98);
pct.profit_eds_min = quantile(profit_eds,.000);
pct.revenue_eds_max = quantile(revenue_eds,.98);
pct.revenue_eds_min = quantile(revenue_eds,.000);

profit_eds_norm = ((profit_eds) - pct.profit_location)/pct.profit_scale;
revenue_eds_norm = ((revenue_eds) - pct.revenue_location)/pct.revenue_scale;


params = aresparams2('maxFuncs', 81, 'maxInteractions', 5);
MARS_model_profit = aresbuild(state_eds_norm, profit_eds_norm, params);
MARS_model_revenue = aresbuild(state_eds_norm, revenue_eds_norm, params);

%% Test performance
% in sample performance
%fprintf('Testing in sample performance ... \n')
results_insample = arestest(MARS_model_profit, state_eds_norm, profit_eds_norm);
results_insample = arestest(MARS_model_revenue, state_eds_norm, revenue_eds_norm);

% out of sample performance
%fprintf('Testing out of sample performance ... \n')
state_data =  [dynData.omega, dynData.log_K, dynData.log_PM, dynData.log_PL, dynData.exp_ind];

%%%%%%%%%%%%%%%%%%%%% only look at a part of data:
state_data = state_data(dynData.profit<quantile(dynData.profit,.98), :);
dynData.profit = dynData.profit(dynData.profit<quantile(dynData.profit,.98));
%%%%%%%%%%%%%%%%%%%%%%%%%

state_temp = state_data(:,1:4)*pct.V;
%then we normalize X to [0,1] and standardize Y
state_data_norm = bsxfun(@rdivide, bsxfun(@minus, state_temp, pct.min), pct.max  - pct.min);
% add the last binary variable on
state_data_norm = [state_data_norm , state_data(:,end)];

profit_data_norm = ((dynData.profit) - pct.profit_location)/pct.profit_scale;

results_outsample = arestest(MARS_model_profit, state_data_norm, profit_data_norm);

% % in sample performance:
% figure(1)
% fprintf('Plotting in sample prediction  ... \n')
% profit_predicted_norm = arespredict(MARS_model_profit, state_eds_norm);
% plot( profit_eds_norm,  profit_predicted_norm,'*')
% hold on
% plot( min(profit_eds_norm):.01:max(profit_eds_norm), min(profit_eds_norm):0.01:max(profit_eds_norm), '-')
% 
% % in sample performance:
% figure(2)
% fprintf('Plotting in sample prediction (revenue) ... \n')
% revenue_predicted_norm = arespredict(MARS_model_revenue, state_eds_norm);
% plot( revenue_eds_norm,  revenue_predicted_norm,'*')
% hold on
% plot( min(revenue_eds_norm):.01:max(revenue_eds_norm), min(revenue_eds_norm):0.01:max(revenue_eds_norm), '-')

end