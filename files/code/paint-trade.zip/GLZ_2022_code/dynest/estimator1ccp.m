% This function provides one estimator to estimate model parameters
function [Error2sum, gradient, hessian, CCP_model] = estimator1ccp(lambda, outsim, W, keep_ind) % W is a weight vector for three dimension of errors. It must be row vector
global check;

if isempty(W) == 1 % if W is not provided
    W = [1,1,1];
end

if isempty(keep_ind) == 1 % if not provided, then all kept
    keep_ind = (outsim.year > 0); %
end

temp_ind =   (keep_ind);
outsim.pi = outsim.pi(temp_ind,:);
outsim.CIE = outsim.CIE(temp_ind,:,:);
outsim.Exicon = outsim.Exicon(temp_ind,:);
outsim.ccpdata = outsim.ccpdata(temp_ind,:);
outsim.log_K = outsim.log_K(temp_ind);

pi = outsim.pi /1;
CIE = outsim.CIE;
dim_cost = [1:12];
CIE = CIE(:,dim_cost, :);
Exicon = outsim.Exicon;
Vsjt = zeros(size(pi,1),4);

if nargout > 1
    grad_input = zeros(size(pi,1), length(dim_cost) + 1, 4); % for constructing gradient
end
for ie = 1:4
    pi_ie = pi(:,ie);
    CIE_ie = CIE(:,:,ie);
    Exicon_ie = Exicon(:,ie);
    Vsjt(:,ie) = [pi_ie, - CIE_ie] *lambda  + Exicon_ie ;
    if nargout > 1
        grad_input(:,:,ie) = [pi_ie, -CIE_ie];
    end
end
check.Vsjt = Vsjt;

% we can return the model predicted ccp as well:
adjust=max(Vsjt,[],2);   % Vsjt very large, its exp goes to infinite
V_expsum = sum(exp(Vsjt-repmat(adjust,1,4)),2);

CCP_model = zeros(size(pi,1),4);
for ie = 1:4
    CCP_model(:,ie) = exp(Vsjt(:,ie)-adjust)./V_expsum;
end

ccpdata = outsim.ccpdata;
diff_ccpdata = zeros(size(ccpdata,1),3);
diff_Vsjt = zeros(size(Vsjt,1),3);
for ie = 1:3
    diff_Vsjt(:,ie) = Vsjt(:,ie) - Vsjt(:,4);
    diff_ccpdata(:,ie) = log(ccpdata(:,ie)) - log(ccpdata(:,4));
end

error  = (diff_Vsjt - diff_ccpdata) .* repmat(W,size(diff_ccpdata,1),1); %/size(ccpdata,1);
Error2sum = sum(sum(error.*error));


check.CCP_model = CCP_model;
check.error = error;

% Add analytical gradient: see dynmodel.pdf for details
if nargout > 1

    error_stack = error(:);
    B_stack = [(grad_input(:,:,1) - grad_input(:,:,4)) * W(1)
        (grad_input(:,:,2) - grad_input(:,:,4)) * W(2)
        (grad_input(:,:,3) - grad_input(:,:,4)) * W(3)
        ];
    gradient = 2*error_stack'*B_stack;
end

% Add analytical Hessian: see dynmodel.pdf for details
if nargout>2
    hessian = 2*(B_stack'*B_stack);  % K by K matrix, where K is the number of parameters in \lambda
end
end

