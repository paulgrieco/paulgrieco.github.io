% this function calculate the negative of the profit in order to solve the
% firm's problem

% The input here should be L and M, and QD if export_ind == 1
% Prices should be normalized.
% 1 means export

function [negProfit ] = NegProfitFun_1(x,exog_var) % exog_var is the is the set of exogenous variables

[profit] = ProfitFun_1(x,exog_var.omega, exog_var.capital, exog_var.P0, exog_var.PL,  exog_var.est); % the input x include log_q rather than q

negProfit = - profit;


return