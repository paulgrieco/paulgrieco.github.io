% Input data: the state at the original level -- no normalization
function  [profit_predicted] = appProfit_MARS(state_data,MARS_model,  pullback_ind, pct)
%% We must use Principal component transformation first
state_temp = state_data(:,1:4)*pct.V;

%% First we normalize X to [0,1] and standardize Y
state_data_norm = bsxfun(@rdivide, bsxfun(@minus, state_temp, pct.min), pct.max  - pct.min);
% add the last binary variable on
state_data_norm = [state_data_norm , state_data(:,end)];

%%%%%%%%%%%%%%%%
state_data_norm_0 = state_data_norm;
state_data_norm_0(:,end) = 0;
profit_predicted_norm_0 = arespredict(MARS_model, state_data_norm_0);

state_data_norm_1 = state_data_norm;
state_data_norm_1(:,end) = 1;
profit_predicted_norm_1 = arespredict(MARS_model, state_data_norm_1);

profit_predicted_norm = profit_predicted_norm_0.*(state_data_norm(:,end)==0) ... % nonexport case
                                      + profit_predicted_norm_0.*(state_data_norm(:,end)==1).*( profit_predicted_norm_0> profit_predicted_norm_1) ... % export case but bad approx
                                      + profit_predicted_norm_1.*(state_data_norm(:,end)==1).*( profit_predicted_norm_0<= profit_predicted_norm_1) ;   % export case and good approx

profit_predicted = profit_predicted_norm *pct.profit_scale + pct.profit_location;

ind_over = profit_predicted>pct.profit_eds_max;
ind_under = profit_predicted<pct.profit_eds_min;
profit_predicted = (ind_over==0 & ind_under==0).*profit_predicted ...
                           + (ind_over==1  ).*pct.profit_eds_max ...
                           + (ind_under==1  ).*pct.profit_eds_min;
                