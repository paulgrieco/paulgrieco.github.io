
function [hessian] = hessian_ccp(x, lambda, outsim,W, keep_ind)

[~, ~, hessian] = estimator1ccp(x, outsim, W, keep_ind);





