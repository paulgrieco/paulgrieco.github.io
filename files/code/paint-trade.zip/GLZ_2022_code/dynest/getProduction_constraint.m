% This function provide the constraint for production: QX>0

function [ineq_err, eq_err] = getProduction_constraint(x,exog_var)
eq_err = [];

[temp, QX] = ProfitFun_1(x,exog_var.omega, exog_var.capital, exog_var.P0, exog_var.PL,  exog_var.est); 
ineq_err = - QX;

return