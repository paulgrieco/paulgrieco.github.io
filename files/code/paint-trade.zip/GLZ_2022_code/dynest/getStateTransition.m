% This function provide the transition of the main state variables:
% omega, PM, PL.
% Note: the output of this function is the expectation of the state in the
% next period -- without the shocks.

% Input: column vector or a scaler
% wageRank_med, wageRank_high: should be dummies -- zero or one. Cannot
% both be ones. It indicates the firm type: high wage firm or median wage
% firm. The reference is low wage firm.

% est is a structure containing the offline estimate of the transition.

function [omega_next, log_PM_next, log_PL_next, log_K_next] = getStateTransition(omega, log_PM, log_PL,  log_K, exp_ind, imp_ind, wtoDum_lead, wageDum, exp_ind_lead, imp_ind_lead, est, temp_sigma)

if exist('temp_sigma') % if temp_sigma is provided, then calcualte the realized variables for the next period
    shock =  randn(length(omega),3)*temp_sigma;  % size: T by 3.

    omega_temp = [ones(length(omega),1 ),   wtoDum_lead, exp_ind, imp_ind, omega];

    omega_next = omega_temp * est.omegaPara +  shock(:,1);  % updated productivity, PM, and PL;

    PM_temp = [ones(length(omega),1 ),  wtoDum_lead ,  (1-wtoDum_lead).*imp_ind_lead, wtoDum_lead.*imp_ind_lead, log_PM]; %  A bug fixed: should use tariff_use_lead rather than tariff_use
    PL_temp = [ones(length(omega),1 ), log_PL];

    log_PM_next =  PM_temp * est.pmPara + shock(:,2);

    log_PL_next =  PL_temp * est.wagePara + shock(:,3);

else % if temp_sigma is not provided, then calculate the mean for the next period
    omega_temp = [ones(length(omega),1 ),  wtoDum_lead, exp_ind, imp_ind, omega];
    omega_next = omega_temp * est.omegaPara;  % updated productivity, PM, and PL;

    PM_temp = [ones(length(omega),1 ),  wtoDum_lead ,  (1-wtoDum_lead).*imp_ind_lead, wtoDum_lead.*imp_ind_lead,  log_PM]; %  A bug fixed: should use tariff_use_lead rather than tariff_use
    PL_temp = [ones(length(omega),1 ),  log_PL];

    log_PM_next =  PM_temp * est.pmPara;

    log_PL_next =  PL_temp * est.wagePara;

end

% For capital transition
log_K_idx = 1*(abs(log_K-est.Kgd(1))<1e-1) + 2*(abs(log_K-est.Kgd(2))<1e-1) + 3*(abs(log_K-est.Kgd(3))<1e-1) + 4*(abs(log_K-est.Kgd(4))<1e-1) + 5*(abs(log_K-est.Kgd(5))<1e-1);
shock_K =  rand(length(log_K),1);

log_K_tranProb = (1-wtoDum_lead).*est.tran_preWTO(log_K_idx,:) +  wtoDum_lead.*est.tran_postWTO(log_K_idx,:);
log_K_tranProbCum = cumsum(log_K_tranProb,2);

log_K_next_idx = 1*(shock_K<=log_K_tranProbCum(:,1)) + ...
    2*(shock_K>log_K_tranProbCum(:,1) & shock_K<=log_K_tranProbCum(:,2)) + ...
    3*(shock_K>log_K_tranProbCum(:,2) & shock_K<=log_K_tranProbCum(:,3)) + ...
    4*(shock_K>log_K_tranProbCum(:,3) & shock_K<=log_K_tranProbCum(:,4)) + ...
    5*(shock_K>log_K_tranProbCum(:,4));

log_K_next = est.Kgd(1)*(log_K_next_idx==1) + est.Kgd(2)*(log_K_next_idx==2) + est.Kgd(3)*(log_K_next_idx==3) + est.Kgd(4)*(log_K_next_idx==4) + est.Kgd(5)*(log_K_next_idx==5);


return
