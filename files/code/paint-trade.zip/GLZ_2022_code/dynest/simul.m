
function [outsim, state_pool] = simul(dynData, est, mu, temp_sigma, tariff_schedule, Tsim, Nsim, delta, purpose,Approx, pct)
% profit unit -- re-scale the profit to make the absolute difference
% between profits across different types sensible. (Otherwise the value function is too large.)
% We only need to do this in purpose == 1 (for estimation purpose)
if purpose == 1
    profit_unit = dynData.profit_unit;
else
    profit_unit = [];
    pct = [];
end

MARS_ind = isfield(Approx,'model_profit'); % depending on if we have MARS model
if MARS_ind
    fprintf('We are using MARS to approximate profit. \n')
else
    fprintf('We are using Poly to approximate profit. \n')
end
%% Set up variables to simulate:
% CIE - Variables to calculated Fixed & Sunk Costs of importing and exporting net of shocks.
%       When simulating we will be collecting the paths of cost type incurred to be used as indendent variables in the
%       minimum distance estimator.

% Define holders for the three components to compute V(sjt, iejt+1): for N simulations
%  Pi-N is discounted variable profits over all (four) possible choices of
%  this-period decison for Nsim simulations.
Ndata = size(dynData.omega,1);

%% Judge what we want to do
% purpose=1 means we do the samulation for estimation purpose. outsim is the output, and state_pool=[]
% purpose=0 means we do the samulation for generating state_pool. outsim=[], and state_pool is the output
state_pool_cell = cell(Nsim,1);
if purpose == 1
    pi_N     = zeros(Ndata,4,Nsim); %(each observation, four possible choices, Nsim simulations)
    pi_mean_sum = zeros(1,Nsim); % this is used to temporarily save sum of all four mean profit, which will be used later to decide if the nsim th simulation is badly approximated or not.
    %The components of fixed and cost shocks whose effects on profits we will
    %be estimating
    CIE_N    = zeros(Ndata,12,4,Nsim); %(each observation, vector of fixed cost variables, four possible choices, Nsim simulations)
    % Conditional expectation of the cost shocks
    Exicon_N = zeros(Ndata,4,Nsim); %(each observation, four possible choices, Nsim simulations)
end


parfor nsim=1:Nsim
    % keep the seed
    rng(nsim)
    if purpose==1
        % Define holders for the three components to compute V(sjt, iejt+1),
        % given one simulation n
        pi     = zeros(Ndata,4);
        CIE    = zeros(Ndata,12,4);
        Exicon = zeros(Ndata,4);
    end
    %LOOP OVER CHOICES OF IMPORT/EXPORT STATUS for the initial year.
    for ie = 1:4  % loop over ie types to compute V(sjt, ie) for all four ie type ie = (0,0), (0,1), (1,0), (1,1)

        %Define whether each choice involves importing or exporting
        imp_ind_lead = (ie==3 | ie ==4);
        imp_ind_lead = repmat(imp_ind_lead,Ndata,1);
        exp_ind_lead = (ie==2 | ie ==4);
        exp_ind_lead = repmat(exp_ind_lead,Ndata,1);

        if purpose ==1
            % Data year profit: compute the profit and cost components for the first period, given
            % sjt in the data and one ie, these are the same across all choices
            % because choices effect only next period values.
            pi(:,ie)     = dynData.profit./profit_unit;

            CIE(:,:,ie)  = [
                (1-dynData.imp_ind).*(1-dynData.exp_ind).*(1-imp_ind_lead).*(exp_ind_lead), ...
                (1-dynData.imp_ind).*(1-dynData.exp_ind).*(imp_ind_lead).*(1-exp_ind_lead) ,...
                (1-dynData.imp_ind).*(1-dynData.exp_ind).*(imp_ind_lead).*(exp_ind_lead), ...
                ...
                (dynData.imp_ind).*(1-dynData.exp_ind).*(1-imp_ind_lead).*(exp_ind_lead) ,...
                (dynData.imp_ind).*(1-dynData.exp_ind).*(imp_ind_lead).*(1-exp_ind_lead) ,...
                (dynData.imp_ind).*(1-dynData.exp_ind).*(imp_ind_lead).*(exp_ind_lead), ...
                ...
                (1-dynData.imp_ind).*(dynData.exp_ind).*(1-imp_ind_lead).*(exp_ind_lead) ,...
                (1-dynData.imp_ind).*(dynData.exp_ind).*(imp_ind_lead).*(1-exp_ind_lead), ...
                (1-dynData.imp_ind).*(dynData.exp_ind).*(imp_ind_lead).*(exp_ind_lead), ...
                ...
                (dynData.imp_ind).*(dynData.exp_ind).*(1-imp_ind_lead).*(exp_ind_lead) ,...
                (dynData.imp_ind).*(dynData.exp_ind).*(imp_ind_lead).*(1-exp_ind_lead) ...
                (dynData.imp_ind).*(dynData.exp_ind).*(imp_ind_lead).*(exp_ind_lead) ...
                ];

            Exicon(:,ie) = zeros(Ndata,1);
        end

        % Holder to replace old value by new ones when iterating over tsim
        omega = dynData.omega;
        log_PM = dynData.log_PM;
        log_PL = dynData.log_PL;
        exp_ind = dynData.exp_ind;
        imp_ind = dynData.imp_ind;
        log_K = dynData.log_K;

        %LOOP OVER TIME FOR A SINGLE PATH FOR EACH OBSERVATION.

        for tsim = 1:Tsim
            % Get the right wto Dummy
            wtoDum_lead = (dynData.year +  tsim >2001);

            % Update to sjt+1, given state sjt observed in the data, and any ie (may not be optimal).
            [omega, log_PM, log_PL, log_K] = getStateTransition(omega, log_PM, log_PL,  log_K, exp_ind, imp_ind, ...
                wtoDum_lead,dynData.wageDum, exp_ind_lead, imp_ind_lead, est, temp_sigma);  % getStateTransition only compute the deterministic part of the Markov process

            exp_ind = exp_ind_lead;
            imp_ind = imp_ind_lead;
            % NOTES: all changing state variables are updated here.

            [P1, P2, P3, P4] = getCCP(exp_ind, imp_ind, omega, log_PM,  log_PL, log_K,  dynData.wageDum, est,[],wtoDum_lead); % the last two []'s are here getCCP is reused in getSimulationPath
            %Choose which acually occurs...
            temp = rand(Ndata,1);
            index1 = temp <=P1;
            index2 = temp<=P1+P2 & temp>P1;
            index3 = temp<=P1+P2+P3 & temp>P1+P2;
            index4 = temp>P1+P2+P3;
            ie_update = index1 + index2*2 +index3*3 + index4*4; % iejt+2 in equation (8) in dynmodel.pdf

            imp_ind_lead = (ie_update==3 | ie_update ==4);
            exp_ind_lead = (ie_update==2 | ie_update ==4);

            mystate = [omega, log_K ,log_PM ,log_PL, exp_ind];

            if purpose ==1
                if MARS_ind == 1
                    profit_approx = appProfit_MARS(mystate,Approx.model_profit,    dynData.pullback_ind, pct) ./ profit_unit;
                else
                    profit_approx = appProfit_poly(mystate,Approx.order_poly, Approx.profit_poly_para,Approx.log_ind,Approx.standard_ind, Approx.mynorm) ./ profit_unit;
                end
                if tsim<Tsim
                    pi(:,ie)= pi(:,ie) + delta^tsim*profit_approx; % call subroutine: profit.m. size: Ndata by 1
                    %Compute the cost compents the MIDDLE dimension is the cost

                    CIE(:,:,ie)  = CIE(:,:,ie) + delta^tsim*...
                        [
                        (1-imp_ind).*(1-exp_ind).*(1-imp_ind_lead).*(exp_ind_lead) ,...
                        (1-imp_ind).*(1-exp_ind).*(imp_ind_lead).*(1-exp_ind_lead) ,...
                        (1-imp_ind).*(1-exp_ind).*(imp_ind_lead).*(exp_ind_lead), ...
                        ...
                        (imp_ind).*(1-exp_ind).*(1-imp_ind_lead).*(exp_ind_lead) ,...
                        (imp_ind).*(1-exp_ind).*(imp_ind_lead).*(1-exp_ind_lead) ,...
                        (imp_ind).*(1-exp_ind).*(imp_ind_lead).*(exp_ind_lead), ...
                        ...
                        (1-imp_ind).*(exp_ind).*(1-imp_ind_lead).*(exp_ind_lead) ,...
                        (1-imp_ind).*(exp_ind).*(imp_ind_lead).*(1-exp_ind_lead) ,...
                        (1-imp_ind).*(exp_ind).*(imp_ind_lead).*(exp_ind_lead) ,...
                        ...
                        (imp_ind).*(exp_ind).*(1-imp_ind_lead).*(exp_ind_lead) ,...
                        (imp_ind).*(exp_ind).*(imp_ind_lead).*(1-exp_ind_lead) ,...
                        (imp_ind).*(exp_ind).*(imp_ind_lead).*(exp_ind_lead) ,...
                        ];



                end
                %Calculate the conditional expectation in two steps, first select the choice probabilty associted with the chice we drew...
                CCP_ie_update = P1.*(ie_update==1) + P2.*(ie_update==2) + P3.*(ie_update==3) + P4.*(ie_update==4); % state updated as above. call function: ccp.m
                %Then add it to the running tally of conditional expectations
                %using Hotz-Miller converstion.
                Exicon(:,ie) = Exicon(:,ie) + delta^tsim*(0.5772156649-log(CCP_ie_update));  % 0.5772156649 is the Euler constant. size: Ndata by 1.
            else
                if 1 % take all points
                    state_pool_cell(nsim) = {[cell2mat(state_pool_cell(nsim)); mystate]}; % order is not important, so just stack mystate (Ndata by 5), to form a long vector.
                end
            end
        end
    end

    if purpose==1
        % record output for each simulation
        fprintf ('[%g], mean profit for four trade types: %g, %g, %g, %g \n', nsim, mean(pi))
        pi_mean_sum(nsim) = sum(mean(pi)); % this is saved and will be used to drop badly approximated simulations.

        pi_N(:,:,nsim)     =  pi;
        CIE_N(:,:,:,nsim)  =  CIE;
        Exicon_N(:,:,nsim) =  Exicon;

    end


end

if purpose==1
    myfilename_simul= ['..'  filesep 'Data' filesep 'painting_Simulated_haveway'];
    save(myfilename_simul,'Ndata','pi_N','CIE_N','Exicon_N','pi_mean_sum')

    keep_ind = (pi_mean_sum > quantile(pi_mean_sum, 0)) & (pi_mean_sum < quantile(pi_mean_sum,1)); % was 0.925

    outsim.pi = mean(pi_N(:,:,keep_ind),3);
    outsim.CIE = mean(CIE_N(:,:,:,keep_ind),4);   % variable costs
    outsim.Exicon = mean(Exicon_N(:,:,keep_ind),3); % expected fixed costs conditional on discrete choice ie

    state_pool = [];

else
    % construct final state_pool
    state_pool = [];
    for nsim = 1:Nsim
        state_pool = [state_pool; cell2mat(state_pool_cell(nsim))];
    end

    outsim=[];
end
end
