% this function calculate the negative of the profit in order to solve the
% firm's problem

% The input here should be L and M, and QD if export_ind == 1
% Prices should be normalized.

function [negProfit, gradient] = NegProfitFun(x,omega, capital, P0, PL,  export_ind, est)

[profit] = ProfitFun(x,omega, capital, P0, PL,  export_ind, est); % the input x include log_q rather than q

negProfit = - profit;

%%%%%
gamma = (est.sigma-1)/est.sigma;
L  = x(1);
M0 = x(2);
log_q = x(3);
q = exp(log_q);
M = q.*M0;
PM0 = P0*q^est.phi;
h = (est.beta*exp(est.theta*omega) + (1-est.beta)*q.^est.theta).^(est.kappa/est.theta);
K = capital;

F_partial_L = est.aL .* L.^(gamma-1) .* h .* est.Q_avg .* (est.aL*L.^gamma + est.aM*M.^gamma + est.aK*K.^gamma).^(1/gamma -1 );
F_partial_M0 = est.aM .* M.^(gamma-1) .* h .* est.Q_avg .* (est.aL*L.^gamma + est.aM*M.^gamma + est.aK*K.^gamma).^(1/gamma -1 ) .* q;
temp_h_partial_q = est.kappa * (1-est.beta) * q.^(est.theta - 1) .* (est.beta*exp(est.theta*omega) + (1-est.beta)*q.^est.theta).^(est.kappa/est.theta-1);
F_partial_q = est.aM .* M.^(gamma-1) .* h .* est.Q_avg .* (est.aL*L.^gamma + est.aM*M.^gamma + est.aK*K.^gamma).^(1/gamma -1 ) .* M0 + ...
                       temp_h_partial_q .* est.Q_avg.* (est.aL*L.^gamma + est.aM*M.^gamma + est.aK*K.^gamma).^(1/gamma);

if export_ind == 0
    QD = getProduction(h, L,M,capital,est);
    FOC_L = est.p_idx_D .* (1+1/est.etaD) .* QD.^(1/est.etaD) .* F_partial_L  - PL;
    FOC_M0 = est.p_idx_D .* (1+1/est.etaD) .* QD.^(1/est.etaD) .* F_partial_M0   - PM0;
    FOC_q = est.p_idx_D .* (1+1/est.etaD) .* QD.^(1/est.etaD) .* F_partial_q   - P0*M0*est.phi*q.^(est.phi-1);
    FOC_log_q = FOC_q .* q; % if log_q is used 
    gradient(1) = FOC_L;
    gradient(2) = FOC_M0;
    gradient(3) = FOC_log_q; % if log_q is used 
else  
    QD = x(4);
    QX = getProduction(h, L,M,capital,est) - QD;
    FOC_L = est.ka .* est.p_idx_X .* (1+1/est.etaX) .* QX.^(1/est.etaX) .* F_partial_L  - PL;
    FOC_M0 = est.ka .* est.p_idx_X .* (1+1/est.etaX) .* QX.^(1/est.etaX) .* F_partial_M0  - PM0;
    FOC_q = est.ka .* est.p_idx_X .* (1+1/est.etaX) .* QX.^(1/est.etaX) .* F_partial_q   - P0*M0*est.phi*q.^(est.phi-1);
    FOC_log_q = FOC_q .* q; % if log_q is used 
    FOC_QD = est.p_idx_D .* (1+1/est.etaD) .* QD.^(1/est.etaD)   - est.ka .* est.p_idx_X .* (1+1/est.etaX) .* QX.^(1/est.etaX);
    gradient(1) = FOC_L;
    gradient(2) = FOC_M0;
    gradient(3) = FOC_log_q; % if log_q is used 
    gradient(4) = FOC_QD;
end

gradient = - gradient;

return