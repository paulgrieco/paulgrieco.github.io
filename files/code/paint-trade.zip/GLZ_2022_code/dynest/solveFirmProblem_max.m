% This function calculate the max of profit given the state variables
% Note that the input of the L and M and the output should all be
% normalized. Thus, the associated price should also be adjusted
% accordingly.

% x is the initial guess

function [profit, L, M, QD, QX, EL, EM, exitflag, q, constrviolation, revenue] = solveFirmProblem_max(x, omega, log_capital, log_P0, log_PL,  export_ind,est)
%% solve for the firm's problem to get the optimal input and output 
% recover variables in level from log
capital = exp(log_capital);
P0 = exp(log_P0);
PL = exp(log_PL);

% prepare for auxiliary data:
exog_var.omega = omega;
exog_var.capital = capital;
exog_var.P0 = P0;
exog_var.PL = PL;
exog_var.est = est;

% the first one is simple: if the firm does not export today -- export_ind is zero
if export_ind == 0
    guess = [x(1); x(2); x(3)];
    lb = [0;0;-30];
    ub = [Inf;Inf;30];
    ktropts = optimset('DerivativeCheck', 'on', 'TolFun',1e-6,'TolX',1e-10,'MaxIter',1e+3,'GradObj','on', 'GradConstr', 'on', 'Display','off', 'Hessian','user-supplied', 'HessFcn', @(x, lambda) NegProfitFun_0_Hes(x, exog_var, lambda) );
    [result,Negprofit,exitflag,myoutput] = knitromatlab(@(x) NegProfitFun_0_Grd(x,exog_var),guess,[],[],[],[],lb,ub, [],[],ktropts);%,'knitro_9_default.opt');
constrviolation = myoutput.constrviolation;
else % the second one is bit different-- the firm has more variables to choose: how much to export
    guess = [x(1); x(2); x(3); x(4)];
    lb = [0;0;-30;0];% need a lower bound on logqm, other wise, if logqm is -1e+20 for example, then q is actually zero.
    ub = [Inf;Inf;30;Inf];
    ktropts = optimset('DerivativeCheck', 'on', 'TolFun',1e-6,'TolX',1e-10,'MaxIter',1e+3,'GradObj','on', 'GradConstr', 'on', 'Display','off', 'Hessian','user-supplied', 'HessFcn', @(x, lambda) NegProfitFun_1_Hes(x, exog_var, lambda) );
    [result,Negprofit,exitflag,myoutput] = knitromatlab(@(x) NegProfitFun_1_Grd(x,exog_var),guess,[],[],[],[],lb,ub, @(x) getProduction_constraint_Grd(x,exog_var),[],ktropts);%,'knitro_9_default.opt');
    constrviolation = myoutput.constrviolation;
end

% Now call KNITRO to solve for the firm's problem
    profit = - Negprofit; % since knitro minimize the objective, we need to take the negative of that
    L  = result(1);
    M = result(2);
    log_q = result(3);
    q = exp(log_q); % the output of result is log(q) rather than q
    PM = P0*q^(est.phi-1);
    h = (est.beta*exp(est.theta*omega) + (1-est.beta)*q^est.theta).^(est.kappa/est.theta);
    
if export_ind == 0
    QD = getProduction(h, L,M,capital,est);
    QX = 0;
else % the second one is bit different-- the firm has more variables to choose: how much to export
    QD = result(4);
    QX = getProduction(h, L,M,capital,est) - QD;
end
    
EL = L*PL;
EM  = M*PM;

revenue = profit + EL + EM;

return
    
    
    
    
