function [state_eds,pct] = getSimEDS(state_pool, epsilon, rDrop)
%% we do Principal component transformation (after or before the normalization are equivalent)
V= pca(state_pool(:,1:4)); % this change is because princomp is removed.
pc = state_pool(:,1:4) * V; % now pc is the transformed state

%% Then we need to standardize the state space
pc_min = min(pc) - 1e-5 * range(pc);
pc_max = max(pc) + 1e-5 * range(pc);

for i = 1:size(pc,2)
    pc_norm(:,i) = ( pc(:,i) - pc_min(i) ) ./(max(pc(:,i)) - pc_min(i)); % each state variable now has mean zero and std = 1.
end

%% Next, we drop the point that too far away
pc_mean = mean(pc_norm); % the center of the transformed state
dist_pc = sum(bsxfun(@minus, pc_norm, pc_mean).^2,2).^.5;
r = quantile(dist_pc,rDrop);% radius of the ball
keep_ind = (dist_pc < r);
pc_norm = [pc_norm(keep_ind, :), state_pool(keep_ind, 5)]; % now pc_norm has 5 dim

%% Now do EDS:
[pc_eds] = getEDS(pc_norm, epsilon);

%% First we normalize X to [0,1] and standardize Y
state_eds_norm = bsxfun(@plus, bsxfun(@times, pc_eds(:,1:4), pc_max  - pc_min), pc_min);

%% We must use Principal component transformation first,
state_eds = state_eds_norm(:,1:4)*inv(V);

%% add the last binary variable on
state_eds = [state_eds, pc_eds(:,end)];

%% record the max and min in pct to be used in the MARS and approximation.
pct.V= V;
pct.min = min(state_eds_norm) - 1e-5 * range(state_eds_norm);
pct.max = max(state_eds_norm) + 1e-5 * range(state_eds_norm);
 
