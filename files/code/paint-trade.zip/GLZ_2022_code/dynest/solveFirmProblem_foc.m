% This function calculate the max of profit given the state variables
% Note that the input of the L and M and the output should all be
% normalized. Thus, the associated price should also be adjusted
% accordingly.

function [profit, L, M, QD, QX, EL, EM, exitflag, qm, constrviolation, revenue] = solveFirmProblem_foc(guess, omega, log_capital, log_PM, log_PL, export_ind, est)

capital = exp(log_capital);
PM = exp(log_PM);
PL = exp(log_PL);

gamma = (est.sigma-1)/est.sigma;
exog_var.omega = omega;
exog_var.K = capital;
exog_var.P0 = PM;
exog_var.PL = PL;
exog_var.export_ind = export_ind;
exog_var.est = est;

% % use knitro: use gradient and Hessian
ktropts = optimset('TolFun',1e-6,'TolX',1e-10,'MaxIter',1e+3,'GradObj','on', 'GradConstr','on', 'Display','off', 'Hessian','user-supplied', 'HessFcn', @(x, lambda) dummy_objective_Hes(x,exog_var,lambda) );
[solution,~,exitflag, myoutput] = knitrolink(@(x) dummy_objective_Grd(x,exog_var),guess,[],[],[],[],[],[], @(x) qmFOC_Grd(x,exog_var),ktropts);
constrviolation = myoutput.constrviolation;

[~,M, PM_hat, QD, qm] = qmFOC_base(solution, omega, capital, PM, PL, export_ind, est); % calculate material quantity
L = (est.aM.*PL./est.aL./PM_hat).^(1/(gamma-1)) .* M;

EL = L.*PL;
EM  = M.*PM_hat;

z = export_ind.*(est.etaX*(1+est.etaD)/(1+est.etaX)/est.etaD/est.ka)^est.etaX;
QX = z.*QD.^(est.etaX/est.etaD);

revenue = est.p_idx_D .* QD.^(1+1/est.etaD) + export_ind .* est.p_idx_X .* QX.^(1+1/est.etaX);
profit = revenue - PL.*L - PM_hat.*M;


if exitflag <= 0
   % fprintf('Warning: QD is not well-solved! \n')
end

return
    
    
    
    
