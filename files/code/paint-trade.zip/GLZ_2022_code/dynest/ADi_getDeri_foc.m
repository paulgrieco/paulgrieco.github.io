% this script gets the derivative functions for profit maximization problem
% with foc

clear all
clc

path_name = ['..' filesep 'Data' ];
addpath(genpath(path_name))
path_name = ['..' filesep 'dynest' ];
addpath(genpath(path_name))

% load file
myfilein = ['..' filesep 'Data' filesep 'quality_out'];
load(myfilein);

exog_var.omega = 1;
exog_var.K = 1;
exog_var.P0 = 1;
exog_var.PL = 1;
exog_var.export_ind = 1;
exog_var.est = est;

% --------------------- Call adigatorGenFiles4Fminunc for no export case ------------------- %
setup.order = 2;
setup.numvar = 2; %  
setup.objective  = 'dummy_objective';
setup.constraint = 'qmFOC';
setup.auxdata = exog_var;

adifuncs = adigatorGenFiles4Fmincon(setup);
 