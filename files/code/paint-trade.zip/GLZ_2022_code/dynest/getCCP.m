% This function produces the conditional choice probability estimated
% offline.

function [imp0_exp0, imp0_exp1, imp1_exp0, imp1_exp1, V_excludeProfit, grid_idx] = getCCP(exp_ind, imp_ind, omega, log_PM,  log_PL, log_K, wageDum, est, dynRes, wtoDum_lead)
% est: structure containing all parameters

if isempty(dynRes) == 1 % if V_para is not supplied, then use the offline CCP

    %% use MNL:
    % est: structure containing all parameters
    X_ie = [exp_ind, imp_ind, omega, log_PM,  log_K, wageDum, exp_ind.*imp_ind]; % note: do not include a constant in X since mnrval.m will include it automatically

    %% Use biprobit
    X_exp = [ones(size(X_ie,1),1), X_ie, wtoDum_lead]; % add a wto dummy
    X_imp = [ones(size(X_ie,1),1), X_ie, wtoDum_lead]; % add a wto dummy
    Para_temp = est.beta_biprobit;
    Y_exp = ones(size(X_ie,1),1);
    Y_imp = ones(size(X_ie,1),1);

    [~, imp1_exp0] = LLF_biprobit(Para_temp, 0*Y_exp, 1*Y_imp, X_exp,X_imp);
    [~, imp0_exp1] = LLF_biprobit(Para_temp, 1*Y_exp, 0*Y_imp, X_exp,X_imp);
    [~, imp1_exp1] = LLF_biprobit(Para_temp, 1*Y_exp, 1*Y_imp, X_exp,X_imp);
    imp0_exp0 = 1-imp1_exp0- imp0_exp1 -imp1_exp1 ;

    grid_idx = [];

else % if V_para is supplied, then use it to calculate CCP
    state = [ omega, log_K, log_PM,  log_PL, exp_ind, imp_ind]; % state should be ordered in this way
    nObs = size(state,1);
    % get the determinstic part of the trade cost, given the trade status
    TC_est = dynRes.tradeCost(1:end-1); % the first part is the determinstic part, and the last one is the sigma for EV1 distribution

    TC(:,1) = getTC(exp_ind, imp_ind, 0, 0, TC_est);
    TC(:,2) = getTC(exp_ind, imp_ind, 1, 0, TC_est); % if only export
    TC(:,3) = getTC(exp_ind, imp_ind, 0, 1, TC_est); % if only import
    TC(:,4) = getTC(exp_ind, imp_ind, 1, 1, TC_est);

    % get the new MEAN state in the next period: in all four cases
    [omega_mu(:,1), log_PM_mu(:,1), log_PL_mu(:,1)] = getStateTransition(omega, log_PM, log_PL, log_K, exp_ind, imp_ind, ...
        wtoDum_lead,[], 0*ones(nObs,1), 0*ones(nObs,1), est); % (0,0) means (exp_ind_lead, imp_ind_lead) = (0,0)
    [omega_mu(:,2), log_PM_mu(:,2), log_PL_mu(:,2)] = getStateTransition(omega, log_PM, log_PL, log_K, exp_ind, imp_ind, ...
        wtoDum_lead,[], 1*ones(nObs,1), 0*ones(nObs,1), est); % (1,0) means (exp_ind_lead, imp_ind_lead) = (1,0)
    [omega_mu(:,3), log_PM_mu(:,3), log_PL_mu(:,3)] = getStateTransition(omega, log_PM, log_PL, log_K, exp_ind, imp_ind, ...
        wtoDum_lead,[], 0*ones(nObs,1), 1*ones(nObs,1), est);
    [omega_mu(:,4), log_PM_mu(:,4), log_PL_mu(:,4)] = getStateTransition(omega, log_PM, log_PL, log_K, exp_ind, imp_ind, ...
        wtoDum_lead,[], 1*ones(nObs,1), 1*ones(nObs,1), est);

    %get the new state with GQ shocks
    state_full = cell(nObs,4); % 4 means we have four cases of export and import

    if dynRes.MARS_ind == 3
        all_idx = 1:length(dynRes.V_data(:,1));
    end

    for i = 1:nObs
        for ie = 1:4 % 4 means we have four trade cases
            mu = [omega_mu(i,ie), log_PM_mu(i,ie), log_PL_mu(i,ie)];
            state_key = repmat(mu, size(dynRes.shocks,1),1) + dynRes.shocks;
            state_full{i,ie} = [state_key(:,1), repmat(log_K(i),size(state_key,1),1),state_key(:,2), state_key(:,3), (ie==2|ie==4)*ones(size(state_key,1),1), (ie==3|ie==4)*ones(size(state_key,1),1)];
            if dynRes.MARS_ind == 3 % Keep the weight and grid updating as it is not data any more

                temp_K = state_full{i,ie}(1,2); % this is log_K for this firm -- there was a bug: temp_K = state_full{i,ie}(2) -- it takes the second element!!!!
                K_grid = unique(dynRes.mynorm(:,2)); % This is the grid of log_K
                temp_K_ind = abs(temp_K  - K_grid) - min(abs(temp_K  - K_grid));
                K_on_grid = K_grid(temp_K_ind == 0);

                temp_ind = (dynRes.mynorm(:,2) == K_on_grid) & (dynRes.mynorm(:,5) == (ie==2|ie==4)) &  (dynRes.mynorm(:,6) == (ie==3|ie==4));
                temp_idx = all_idx(temp_ind);
                [idx_sub] = getidx(dynRes.mynorm(temp_ind,:),state_full{i,ie});
                grid_idx{i,ie} = temp_idx(idx_sub);
            end
        end


        if dynRes.MARS_ind == 1 % Note here dynRes.V_poly_para is the MARS model; dynRes.mynorm is the data set (or eds set)
            RHSpart_1  = - TC(i,1) + dynRes.delta *dynRes.weight' * approxV_MARS(state_full{i,1},dynRes.V_poly_para, dynRes.mynorm, dynRes.V_data, dynRes.log_ind,dynRes.standard_ind) ;
            RHSpart_2  = - TC(i,2) + dynRes.delta *dynRes.weight' * approxV_MARS(state_full{i,2},dynRes.V_poly_para,dynRes.mynorm, dynRes.V_data, dynRes.log_ind,dynRes.standard_ind) ;
            RHSpart_3  = - TC(i,3) + dynRes.delta *dynRes.weight' * approxV_MARS(state_full{i,3},dynRes.V_poly_para,dynRes.mynorm, dynRes.V_data, dynRes.log_ind,dynRes.standard_ind) ;
            RHSpart_4  = - TC(i,4) + dynRes.delta *dynRes.weight' * approxV_MARS(state_full{i,4},dynRes.V_poly_para,dynRes.mynorm, dynRes.V_data, dynRes.log_ind,dynRes.standard_ind) ;
        elseif dynRes.MARS_ind == 0 % use poly
            RHSpart_1  = - TC(i,1) + dynRes.delta *dynRes.weight' * appV_poly(state_full{i,1},dynRes.order_poly, dynRes.V_poly_para, dynRes.log_ind,dynRes.standard_ind,dynRes.mynorm);
            RHSpart_2  = - TC(i,2) + dynRes.delta *dynRes.weight' * appV_poly(state_full{i,2},dynRes.order_poly, dynRes.V_poly_para, dynRes.log_ind,dynRes.standard_ind,dynRes.mynorm);
            RHSpart_3  = - TC(i,3) + dynRes.delta *dynRes.weight' * appV_poly(state_full{i,3},dynRes.order_poly, dynRes.V_poly_para, dynRes.log_ind,dynRes.standard_ind,dynRes.mynorm);
            RHSpart_4  = - TC(i,4) + dynRes.delta *dynRes.weight' * appV_poly(state_full{i,4},dynRes.order_poly, dynRes.V_poly_para, dynRes.log_ind,dynRes.standard_ind,dynRes.mynorm);
        elseif dynRes.MARS_ind == 2 % use grid approximation Note here V_poly_para is grid_weight;
            RHSpart_1  = - TC(i,1) + dynRes.delta *dynRes.weight' * (dynRes.grid_weight{i,1} * dynRes.V_data(grid_idx{i,1}));
            RHSpart_2  = - TC(i,2) + dynRes.delta *dynRes.weight' * (dynRes.grid_weight{i,2} * dynRes.V_data(grid_idx{i,2}));
            RHSpart_3  = - TC(i,3) + dynRes.delta *dynRes.weight' * (dynRes.grid_weight{i,3} * dynRes.V_data(grid_idx{i,3}));
            RHSpart_4  = - TC(i,4) + dynRes.delta *dynRes.weight' * (dynRes.grid_weight{i,4} * dynRes.V_data(grid_idx{i,4}));
        elseif dynRes.MARS_ind == 3 % 3 means to use standard regtangle grid approximation
            RHSpart_1  = - TC(i,1) + dynRes.delta *dynRes.weight' * dynRes.V_data(grid_idx{i,1});
            RHSpart_2  = - TC(i,2) + dynRes.delta *dynRes.weight' * dynRes.V_data(grid_idx{i,2});
            RHSpart_3  = - TC(i,3) + dynRes.delta *dynRes.weight' * dynRes.V_data(grid_idx{i,3});
            RHSpart_4  = - TC(i,4) + dynRes.delta *dynRes.weight' * dynRes.V_data(grid_idx{i,4});
        end

        H = [RHSpart_1, RHSpart_2, RHSpart_3, RHSpart_4] ; % See Paul's note for details: the CCP is affected by the dispersion parameter. (Note, solving value function also need to be changed as well.)
        CCP_ie(i,:) = exp(H/ dynRes.tradeCost(end) - max(H/ dynRes.tradeCost(end)))./sum(exp(H/ dynRes.tradeCost(end) - max(H/ dynRes.tradeCost(end)))); % minus max(H) to make sure we do not have Inf as we are using exponential


        if dynRes.MARS_ind == 3 % if we use standard grid point method, then we can also return the value exclude current profit.
            V_excludeProfit(i) = sum( CCP_ie(i,:) .* ( H + dynRes.tradeCost(end)*(0.5772156649 - log(CCP_ie(i,:))) ) );
        else
            V_excludeProfit(i) = 0;
        end

    end

    imp0_exp0 = CCP_ie(:,1);
    imp0_exp1 = CCP_ie(:,2);
    imp1_exp0 = CCP_ie(:,3);
    imp1_exp1 = CCP_ie(:,4);

end
