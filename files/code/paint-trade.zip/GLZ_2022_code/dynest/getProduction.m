% This function calculate the output quantity produced from the production
% function

% The input should be normalized input (around 1), since the prices are
% normalized input prices.

function [quantity] = getProduction(h, L,M,K, est)
gamma = (est.sigma-1)/est.sigma;

quantity = est.Q_avg .* h.*(est.aL*L.^gamma + est.aM*M.^gamma + est.aK*K.^gamma).^(1/gamma);


