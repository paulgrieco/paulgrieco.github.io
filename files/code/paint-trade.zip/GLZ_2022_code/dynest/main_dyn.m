clear
clc

path_name = ['..' filesep 'ARESLab' ];
addpath(genpath(path_name))
path_name = ['..' filesep 'Data' ];
addpath(genpath(path_name))
path_name = ['..' filesep 'counterfactuals' ];
addpath(genpath(path_name))
path_name = ['..' filesep 'qualityest' ];
addpath(genpath(path_name))

IndustryName = 'painting';
myfilename_in = ['..'  filesep 'Data' filesep IndustryName '_res_forDyn'];
load(myfilename_in)

MARS_ind = 1; % whether or not use MARS to approximate profit function.

%% Simulation out of the parameter iteration
dynData.profit_unit = 6*1e4;
dynData.pullback_ind = 1;
Nsim= 3000;    % simulate Nsim paths
Tsim = 30;  % number of periods in each simulation path.
delta = 0.95;
Ndata = size(dynData.omega,1);

% Prepare for drawing shocks to productivity and material price
mu =     [0 0 0];
sigma2 = est.Sigma;
temp_sigma = chol(sigma2);  % To be used when drawing shocks in "simul"

tariff_schedule = []; % we now are using wto dummy, so set this as empty

% This is the approximation of profit using MARS
if MARS_ind == 1
    MARS.model_profit = profitApp_model;
    MARS.model_revenue= revenueApp_model;
else
    % This is the approximation of profit using Poly
    Poly = profitApp_model;
end

% purpose = 1: do the simulation for estimation purpose and only
% produce outsim and state_pool = [];
% purpose = 0: generate state_pool for eds.
purpose = 1;
if MARS_ind == 1
    [outsim, state_pool]  =  simul(dynData,est, mu, temp_sigma, tariff_schedule, Tsim, Nsim,  delta, purpose, MARS, pct);  % simulation out of the dynamic estimation to save time---a nice property of linear-in-parameter setup
else
    [outsim, state_pool]  =  simul(dynData,est, mu, temp_sigma, tariff_schedule, Tsim, Nsim,  delta, purpose, Poly);  % simulation out of the dynamic estimation to save time---a nice property of linear-in-parameter setup
end
%record CCP estimated the data, in order to form objective function in the estimator (for estimator1ccp.m)
[P1, P2, P3, P4] = getCCP(dynData.exp_ind, dynData.imp_ind, dynData.omega, dynData.log_PM,  dynData.log_PL, dynData.log_K, dynData.wageDum, est, [], dynData.year>=2002);
outsim.ccpdata = [P1, P2, P3, P4];
outsim.log_K = dynData.log_K;
outsim.year = dynData.year;
outsim.profit_data = dynData.profit;

IndustryName = 'painting';
myfilename_simul= ['..'  filesep 'Data' filesep IndustryName '_DynSimulated'];
save(myfilename_simul)

%% Estimator: iterate over model parameters
% starting value of model parameter
lambda0 = ones(13,1);
global check;
options=optimset('TolX',1e-15,'TolFun',1e-6,'MaxIter',100000,'MaxFunEvals',1000000, 'LargeScale', 'on','Display','off','Gradobj', 'on', 'Hessian','on'); %, 'Display','iter'

% use multi-start to look for the lowest obj value
N_multi = 30;
obj_value_multi = 1e+100*ones(N_multi,1);
lambda_multi = 1e+100*ones(N_multi,length(lambda0));
adjustment_multi = linspace(0.01,1,N_multi);

lb = -Inf*ones(size(lambda0));
ub = Inf*ones(size(lambda0));

parfor i = 1:N_multi
    rng(i)
    opt_ktr = optimset('TolFun',1e-10,'TolX',1e-6,'MaxIter',2000,'GradObj','on',  'Display','off', 'Hessian','user-supplied', 'HessFcn', @(x, lambda_h) hessian_ccp(x,lambda_h, outsim,[], []) );
    [lambda_temp, obj_value_multi(i)] = knitrolink(@(x) estimator1ccp(x,outsim ,[],[]),adjustment_multi(i)*lambda0 .* rand(size(lambda0)) * 2 ,[],[],[],[],lb,ub,[],opt_ktr);

    lambda_multi(i,:) = lambda_temp';
end
[~,idx] = min(obj_value_multi);
lambda_chosen = lambda_multi(idx,:);
lambda_chosen = lambda_chosen';
lambda = lambda_chosen;
[~, ~, hessian] = estimator1ccp(lambda, outsim ,[],[]);
lambda_SSE = abs(diag(inv(hessian)))*sqrt(3*length(dynData.omega));

lambda = lambda*1;
lambda_SSE = lambda_SSE*1;
%%%%%%%%%%%%%%%%%%%%%%%%%
disp('----lambda----lambda_SSE----');
disp([lambda, lambda_SSE]);

IndustryName = 'painting';
myfilename_out = ['..'  filesep 'Data' filesep IndustryName '_DynEst'];
save(myfilename_out)
    