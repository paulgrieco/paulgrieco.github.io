% This is the dummy objective function
function [f] = dummy_objective(x0,exog_var)
   %This is a dummy objective function which is used to let ktrlink serve
   %as an equation solver rather than an optimization routine.  We simply
   %supply the contraints and use this function as the "objective"...
   
   f = sum(x0) - sum(x0); % simply make sure it is not literally zero, otherwise ADigator does not work.
 
end
