% Input gridmesh should have variables in the correct order:
% omega, log_capital, log_PM, log_PL,  export_ind
% This function utilize both Max and FOC methods, and multi-start to find
% out the profit maximization problem possible.
% It comes with two options: all_MS==1 -- multi-start using Max, for all points;
%                                             all_MS==0 -- only multi-start
%                                             for points that Max and FOC do not agree with each other.

function [profit_grid, exitflag_grid,  verified_flag, M_grid, QD_grid, EM_grid, revenue_grid] = getProfit_grid_MS(gridmesh,est, n_MS,myseed)
%% Prepare
% for final result:
N_grid = length(gridmesh(:,1));

% for single solution:
myguess_foc = est.guess_foc;
myguess_max = est.guess_max;

profit_grid_foc = ones(N_grid,1);
QD_grid_foc = ones(N_grid,1);
M_grid_foc = ones(N_grid,1);
EM_grid_foc = ones(N_grid,1);
exitflag_grid_foc = ones(N_grid,1);
constrviolation_grid_foc = ones(N_grid,1);
revenue_grid_foc = ones(N_grid,1);

profit_grid_max = ones(N_grid,1);
QD_grid_max = ones(N_grid,1);
M_grid_max = ones(N_grid,1);
EM_grid_max = ones(N_grid,1);
exitflag_grid_max = ones(N_grid,1);
constrviolation_grid_max =  ones(N_grid,1);
revenue_grid_max = ones(N_grid,1);

% for multi-starts (for Max only)
rng(myseed);

for i = 1:N_grid
    guess_part1 = 2*repmat(est.guess_max, n_MS/2, 1)  .* rand(n_MS/2, length(est.guess_max)); % initial points based on the best guess
    guess_part2 =  rand(n_MS/2, length(est.guess_max)) .* repmat(est.guess_range_max - est.guess_range_min, n_MS/2, 1) + repmat(est.guess_range_min, n_MS/2, 1); % initial points based on the range of data
    myguess_ms{i} = [guess_part1; guess_part2];
end

profit_grid_ms_max = ones(N_grid,n_MS);
QD_grid_ms_max = ones(N_grid,n_MS);
M_grid_ms_max = ones(N_grid,n_MS);
EM_grid_ms_max = ones(N_grid,n_MS);
exitflag_grid_ms_max = ones(N_grid,n_MS);
constrviolation_grid_ms_max = ones(N_grid,n_MS);
revenue_grid_ms_max = ones(N_grid,n_MS);

%% start to run ...
% for a single run using both method:
parfor i = 1:N_grid
    [profit_grid_foc(i), ~, M_grid_foc(i), QD_grid_foc(i), ~, ~, EM_grid_foc(i), exitflag_grid_foc(i), ~, constrviolation_grid_foc(i), revenue_grid_foc(i)] = solveFirmProblem_foc(myguess_foc,  gridmesh(i,1), gridmesh(i,2), gridmesh(i,3),  gridmesh(i,4), gridmesh(i,5), est);
    [profit_grid_max(i), ~ , M_grid_max(i), QD_grid_max(i), ~, ~, EM_grid_max(i), exitflag_grid_max(i), ~, constrviolation_grid_max(i), revenue_grid_max(i)] = solveFirmProblem_max(myguess_max,  gridmesh(i,1), gridmesh(i,2), gridmesh(i,3),  gridmesh(i,4), gridmesh(i,5), est);
end

% for mult-starts using MAX method only:
parfor i = 1:N_grid
    thisguess = myguess_ms{i};
    for ms = 1:n_MS % corrected a bug: it was EM_grid_ms_max(i), but should be EM_grid_ms_max(i,ms) -- this bug lead to potentially wrong selection/dropping of point because the dropping is based on if EM is too small.
        [profit_grid_ms_max(i,ms), ~ , M_grid_ms_max(i,ms), QD_grid_ms_max(i,ms), ~, ~, EM_grid_ms_max(i,ms), exitflag_grid_ms_max(i,ms), ~, constrviolation_grid_ms_max(i,ms), revenue_grid_ms_max(i,ms)] = solveFirmProblem_max(thisguess(ms,:),  gridmesh(i,1), gridmesh(i,2), gridmesh(i,3),  gridmesh(i,4), gridmesh(i,5), est);
    end
end

% take the best possibility:
for i = 1:N_grid
    profit_all = [profit_grid_foc(i), profit_grid_max(i), profit_grid_ms_max(i,:)];
    revenue_all = [revenue_grid_foc(i), revenue_grid_max(i), revenue_grid_ms_max(i,:)];
    exitflag_all = [exitflag_grid_foc(i), exitflag_grid_max(i), exitflag_grid_ms_max(i,:)];
    constrviolation_all = [constrviolation_grid_foc(i),  constrviolation_grid_max(i), constrviolation_grid_ms_max(i,:)];
    profit_all = (constrviolation_all<1e-6).*profit_all + (constrviolation_all>=1e-6).*(-1e+100); % make the profit negative if it is not solved
    revenue_all = (constrviolation_all<1e-6).*revenue_all + (constrviolation_all>=1e-6).*(-1e+100); % make the sales negative if it is not solved

    profit_all = (profit_all<1e+20).*profit_all + (profit_all>=1e+20).*(-1e+100); % make the profit negative if it is not solved
    revenue_all = (revenue_all<1e+20).*revenue_all + (revenue_all>=1e+20).*(-1e+100); % make the sales negative if it is not solved

    M_all = [M_grid_foc(i), M_grid_max(i), M_grid_ms_max(i,:)]; % both MAX and FOC report M, rather than M0
    EM_all = [EM_grid_foc(i), EM_grid_max(i), EM_grid_ms_max(i,:)]; %
    QD_all = [QD_grid_foc(i), QD_grid_max(i), QD_grid_ms_max(i,:)];

    [~, idx] = sort(profit_all);
    profit_take(i) =profit_all(idx(end));
    revenue_take(i) =revenue_all(idx(end));
    M_take(i) =M_all(idx(end));
    EM_take(i) =EM_all(idx(end));
    QD_take(i) =QD_all(idx(end));
    exitflag_take(i) = exitflag_all(idx(end));
    verified_flag(i) = (1 - profit_all(idx(end-1))./profit_all(idx(end))) < 1e-2; % if the largest one and second largest profit differ only in 1%, then we say it is verified.
    verified_flag(i) = (profit_take(i) > 0) & verified_flag(i); % and must be positive
end

% report:
n_notsolved = sum(exitflag_take~=0); % in knitro, 0 means solved
n_negativeprofit = sum(profit_take<=0);
n_smallEM = sum((EM_take<=1e-5)|(isnan(EM_take))|(EM_take>1e+99)); % number of very small EM (added: or is NaN, or very large) -- very likely to be unsolved.
%fprintf('Total grid points attempted: %g \n', N_grid);
%fprintf('There are %g grids reported as not solved! \n', n_notsolved);
%fprintf('There are %g grids solved as negative or zero profit! \n', n_negativeprofit);
%fprintf('There are %g grids verified and the two largest profits of multi-starts are the same! \n', sum(verified_flag));
%fprintf('But there are still %g grids have very small EM! \n', n_smallEM);

% these need re-maximization:
unsolved_ind = (profit_take<=0) | (EM_take<=1e-5) | (isnan(EM_take)) | (EM_take>1e+99) | (profit_take>1e+20); % adjusted accordingly b/o n_smallEM above; and if profit it too large.

% filling the results:
profit_grid = profit_take';
revenue_grid = revenue_take';
exitflag_grid = (unsolved_ind  == 0); % 1 in exitflag_grid means solved
M_grid = M_take;
QD_grid = QD_take;
EM_grid = EM_take;

return
