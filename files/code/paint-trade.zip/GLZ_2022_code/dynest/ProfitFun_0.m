% This function calcuate the profit at given input
% note that x contain input as well the domestic output if the firm is
% exporting
% Input x = (L, M0, q, QD)
% 0 means no export
function [profit] = ProfitFun_0(x,omega, capital, P0, PL, est)
%% specify the variables
    L  = x(1);
    M = x(2);
    log_q = x(3);
    q = exp(log_q);
    PM = P0*q^(est.phi-1);
    h = (est.beta*exp(est.theta*omega) + (1-est.beta)*q^est.theta).^(est.kappa/est.theta);
    QD = getProduction(h, L,M,capital,est);

%% calculate the profit
profit = est.p_idx_D .* QD.^(1+1/est.etaD) - PL.*L - PM.*M;