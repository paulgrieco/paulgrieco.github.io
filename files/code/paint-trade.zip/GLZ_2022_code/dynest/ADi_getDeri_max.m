% this script gets the derivative functions for profit maximization problem
% with max

clear all
path_name = ['..' filesep 'Data' ];
addpath(genpath(path_name))
path_name = ['..' filesep 'dynest' ];
addpath(genpath(path_name))

% load file
myfilein = ['..' filesep 'Data' filesep 'quality_out'];
load(myfilein);

exog_var.omega = 1;
exog_var.capital = 1;
exog_var.P0 = 1;
exog_var.PL = 1;
exog_var.est = est;

% --------------------- Call adigatorGenFiles4Fminunc for no export case ------------------- %
setup.order = 2;
setup.numvar = 3; %  
setup.objective  = 'NegProfitFun_0';
setup.auxdata = exog_var;

adifuncs = adigatorGenFiles4Fmincon(setup);

% --------------------- Call adigatorGenFiles4Fminunc for export case ------------------- %

setup.order = 2;
setup.numvar = 4; %  
setup.objective  = 'NegProfitFun_1';
setup.constraint = 'getProduction_constraint';
setup.auxdata = exog_var;

adifuncs = adigatorGenFiles4Fmincon(setup);
