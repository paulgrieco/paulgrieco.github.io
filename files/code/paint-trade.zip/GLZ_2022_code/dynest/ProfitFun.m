% This function calcuate the profit at given input
% note that x contain input as well the domestic output if the firm is
% exporting
% Input x = (L, M0, q, QD)
function [profit] = ProfitFun(x,omega, capital, P0, PL,  export_ind, est)
%% specify the variables
    L  = x(1);
    M0 = x(2);
    log_q = x(3);
    q = exp(log_q);
    PM0 = P0*q^est.phi;
    M = q*M0;
    h = (est.beta*exp(est.theta*omega) + (1-est.beta)*q^est.theta).^(est.kappa/est.theta);

if export_ind == 0
    QD = getProduction(h, L,M,capital,est);
    QX = 0;
else  
    QD = x(4);
    QX = getProduction(h, L,M,capital,est) - QD;
end

%% calculate the profit
profit = est.p_idx_D .* QD.^(1+1/est.etaD) + est.ka .* export_ind .* est.p_idx_X .* QX.^(1+1/est.etaX) - PL.*L - PM0.*M0;

