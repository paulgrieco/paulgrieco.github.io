% This function produce a EDS given the raw data set and the criteria

% Input: State is the matrix of state variables, each column is a state;
% epsilon is the minimum distance between point in this set;
% sigmaDrop is the criteria to drop the remote point. Usually take
% sigmaDrop  = 5, which means drop the point that are 5 sigma away from the
% mean.

% pc has 5 dim, but only use first 4 for distance
% pc must have been standardized and pinciple componented analyzed.
% pc_eds need to be recoved in another function using V and pct.min and max
function [pc_eds] = getEDS(pc_norm,epsilon)
N_max = 1e+99; 
n_parallel = 12; 
if size(pc_norm,1) > N_max
   block_parallel = floor(linspace(1,size(pc_norm,1),n_parallel)); % use floor to make it integer
state_eds_block = cell(length(block_parallel)-1,1);
   for i = 1:length(block_parallel)-1
       block_part = block_parallel(i) : block_parallel(i+1) - 1*(i~=(length(block_parallel)-1));
       [state_eds_block{i}] = getEDS(pc_norm(block_part,:),epsilon);
   end
   pc_norm = [];
   for i = 1:length(block_parallel)-1
       pc_norm = [pc_norm; state_eds_block{i}]; 
   end
end

%% Now we construct the EDS
pc_eds = pc_norm(1,:); % take the first point as the initial point in EDS
for i = 1:size(pc_norm,1) 
    diff = bsxfun(@minus, pc_eds, pc_norm(i,:)); % difference to each of the eds point
    dist_min = min((sum(diff.^2,2))); % minimum distance to eds set
    if dist_min>epsilon
        pc_eds = [pc_eds; pc_norm(i,:)];
    end
    

end
