function [m,e] = momt_hs(beta,infoz,stat,Y,X,Z)

global out_op10

lnx1 = X(:,1);
x2 = X(:,2);
x3 = X(:,3);

b = beta(1);
A = beta(2);
%A=1 ;

Y_pred = out_op10.b(1)*lnx1 + out_op10.b(2)*(1/b)*log(x2.^b + (A*x3).^b);

e = Y - Y_pred;

m = Z'*e/size(Y,1);

end