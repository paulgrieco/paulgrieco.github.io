function obj = gmmhscode(b)
% PURPOSE:  Provide moment conditions and error term for 
%             linear GMM estimation
%-------------------------------------------------------------------------
% USAGE:  [m,e] = lingmmm(b,infoz,stat,y,x,z,w)
%  b      model parameters
%  infoz   MINZ infoz structure
%  stat   MINZ status structure
%  y,x,z  Data: dependent, independent, and instruments
%  w      GMM weighting matrix
%-------------------------------------------------------------------------
% RETURNS:
%  m      vector of moment conditions
%  e      Model errors  (Nobs x Neq)
%-------------------------------------------------------------------------
% VERSION: 1.1.2

% written by:
% Mike Cliff,  Purdue Finance  mcliff@mgmt.purdue.edu
% Created: 12/10/98
% Modified 9/26/00 (1.1.1 Does system of Eqs)
%          11//13/00 (1.1.2 No W as input argument)
  
global data

b1 = b(1);
b2 = b(2);
b3 = b(3);
b4 = b(4);
b5 = b(5);
b6 = b(6);

x1=data.X(:,1);
x2=data.X(:,2);
x3=data.X(:,3);

e1 = data.Y(:,1) - b1*(x1.^b2 + x2.^b2);
e2 = data.Y(:,2) - b3 - b4*x1 - b5*x2 - b6*x3;

% e = [e1 e2];
 z1 = [ones(data.Nobs,1) x1 x2 x3];
 z2 = [ones(data.Nobs,1) x1 x2 x3];

m1 = z1'*e1/rows(e1);
m2 = z2'*e2/rows(e2);
m = [m1; m2];

obj = m'*data.W*m;

% m = vec(z'*e/rows(e));

