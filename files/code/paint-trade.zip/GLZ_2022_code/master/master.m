%%% this script does bootstrapping for the entire estimation procedure 
clear 
clc

p = gcp('nocreate');
if isempty(p)
   parpool
end
   
path_name = ['..' filesep 'ARESLab' ];
addpath(genpath(path_name))
 path_name = ['..' filesep 'GMMpackage' ];
addpath(genpath(path_name))
 path_name = ['..' filesep 'adigator' ];
addpath(genpath(path_name))
path_name = ['..' filesep 'Data' ];
addpath(genpath(path_name))
path_name = ['..' filesep 'staticest' ];
addpath(genpath(path_name))
path_name = ['..' filesep 'qualityest' ];
addpath(genpath(path_name))
 path_name = ['..' filesep 'dynest' ];
addpath(genpath(path_name))
 path_name = ['..' filesep 'master' ];
addpath(genpath(path_name))
path_name = ['..' filesep 'counterfactuals' ];
addpath(genpath(path_name))

% 1.	Static Estimation Stage 1: follow GLZ to estimate quality-inclusive H and P_M. 
%       Main code: staticest\main_static.m
%       Output file: painting_res.mat 
main_static

% 2.	Static Estimation Stage 2: estimate quality-adjusted omega and p.
%       Main code: qualityest\main_quality.m
%       Output file: quality_out.mat
main_quality

% 3.    Produce (or update) the gridents and hessian using auto differentiation
ADi_getDeri_foc
ADi_getDeri_max

% 4.	Prepare for Dynamic Estimation (1): compute offline CCP, collect evaluation processes (including that of wage rate), and save relevant data for dynamic estimation.
%       Main code: qualityest\getDataForDyn.m
%       Output file: painting_res_forDyn_prepare.mat
getDataForDyn

% 5.	Prepare for Dynamic Estimation (2): generate EDS by simulation, solve profit on EDS, and approximate profit and revenue by MARS;
%       Main code: dynest\EDSprofitSolve.m
%       Output file: painting_res_forDyn.mat
EDSprofitSolve

% 6.	Dynamic Estimation: estimate trade distribution parameters by forward simulation.
%       Main code: dynest\main_dyn.m
%       Output file: painting_DynEst.mat
main_dyn
 
% 7.	Preprare for Counterfactual: setup grid of state and profit for value function iteration. 
%       Main code: counterfactual\computeGridProfit.m
%       Output file: painting_regGrid_k_6s_2006.mat (it will be load in the value function iteration.)
computeGridProfit

% 8.	Counterfactual: conduct various counterfactuals.
%       Main code: counterfactual\mian_counterfactual.m
%       Output file: painting_CFDynOut.mat
main_counterfactuals

% 9.   Print results: print tables
%      Main code: master\print_result.m
print_result
 
%Shut down parallel pool
p = gcp;
delete(p)



