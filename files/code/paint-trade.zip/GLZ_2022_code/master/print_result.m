% Print all tables
path_name = ['..' filesep 'Data' ];
addpath(genpath(path_name))
path_name = ['..' filesep 'dynest' ];
addpath(genpath(path_name))
path_name = ['..' filesep 'counterfactuals' ];
addpath(genpath(path_name))

clear all

load(['..' filesep 'Data' filesep 'quality_out.mat']) % use matlab result
table_firstline = {'Parameter', 'Import', 'Export'};
table_para = {'$\psi_0$', '$\psi_e$', '$\psi_i$', '$\psi_\omega$', '$\psi_m$','$\psi_k$', '$\psi_{low}$', '$\psi_{high}$', '$\psi_{ie}$', '\text{Post-WTO}'  };
table_est = [est.beta_biprobit((length(est.beta_biprobit)-1)/2+1:end-1),est.beta_biprobit(1:(length(est.beta_biprobit)-1)/2)];
load(['..' filesep 'Data' filesep 'BS_job_collected.mat']); % the bootstrapping file
table_se = [se.beta_biprobit((length(se.beta_biprobit)-1)/2+1:end-1), se.beta_biprobit(1:(length(se.beta_biprobit)-1)/2)];
fid = fopen(['..' filesep 'Table_output' filesep 'offlineCCP.txt'], 'w');
caption = 'Conditional choice of export and import probability estimates';
printTable_gen(fid,table_firstline, table_para, table_est,table_se,caption); % add 0 to caption to suppress se

%% production function estimate
clear all
load(['..' filesep 'Data' filesep 'painting_res.mat'])
table_firstline = {'Parameter', 'Estimate'};
table_para = {'$\eta^D$', '$\eta^X$',  '$\sigma$' , '$\kappa$', '$\alpha_L$',  '$\alpha_M$' , '$\alpha_K$'};
table_est = [itaD, itaX, theta, ka, M_norm_sh, L_norm_sh, K_norm_sh]';
load(['..' filesep 'Data' filesep 'BS_job_collected.mat']);  % the bootstrapping file
table_se = [se.etaD, se.etaX, se.theta/theta^2,se.ka, se.aL,se.aM,se.aK]';

fid = fopen(['..' filesep 'Table_output'  filesep 'productionFunEst.txt'], 'w');
caption = 'Production function parameter estimates';
printTable_gen(fid,table_firstline, table_para, table_est,table_se,caption);

%% make comparsion of offline ccp, model predicted ccp, and data
clear all
path_name = ['..' filesep 'dynest' ];
addpath(genpath(path_name))
load(['..' filesep 'Data' filesep 'painting_DynEst.mat'])
imp0_exp0_ccp = mean(outsim.ccpdata(:,1));
imp0_exp1_ccp = mean(outsim.ccpdata(:,2));
imp1_exp0_ccp = mean(outsim.ccpdata(:,3));
imp1_exp1_ccp = mean(outsim.ccpdata(:,4));

% % use all years
imp0_exp0_data = mean((dynData.exp_ind == 0) & (dynData.imp_ind == 0));
imp0_exp1_data = mean((dynData.exp_ind == 1) & (dynData.imp_ind == 0));
imp1_exp0_data = mean((dynData.exp_ind == 0) & (dynData.imp_ind == 1));
imp1_exp1_data = mean((dynData.exp_ind == 1) & (dynData.imp_ind == 1));

load(['..' filesep 'Data' filesep 'painting_DynEst.mat'])
[~, ~, ~, CCP_model] = estimator1ccp(lambda_chosen, outsim,[],[]); 
imp0_exp0_model = mean(CCP_model(:,1));
imp0_exp1_model = mean(CCP_model(:,2));
imp1_exp0_model = mean(CCP_model(:,3));
imp1_exp1_model = mean(CCP_model(:,4));

table_firstline = {' ', 'Neither', 'Import', 'Export', 'Both'};
table_para = {'Data', 'Offline CCP predicted ',  'Dynamic model predicted '};
table_est = [imp0_exp0_data, imp1_exp0_data, imp0_exp1_data, imp1_exp1_data;
    imp0_exp0_ccp, imp1_exp0_ccp, imp0_exp1_ccp, imp1_exp1_ccp;
    imp0_exp0_model, imp1_exp0_model, imp0_exp1_model, imp1_exp1_model;];
table_se = table_est;
fid = fopen(['..' filesep 'Table_output' filesep 'tradeProbability_cmp.txt'], 'w');
caption = 'Comparison of shares of exporting and importing firms: data and model predicted';
printTable_gen(fid,table_firstline, table_para, table_est,table_se,caption);

%% print the offline CCP predicted transition and forward CCP predicted transiction.
clear all
load(['..' filesep 'Data'  filesep 'painting_DynEst.mat'])

ind = (dynData.imp_ind == 0) & (dynData.exp_ind == 0);
trans_prob_00 = mean(outsim.ccpdata(ind,:));
trans_prob_model_00 = mean(check.CCP_model(ind,:));
% from data directly:
ind = (dynData.imp_ind == 0) & (dynData.exp_ind == 0) & (dynData.imp_ind_lead > -1) & (dynData.exp_ind_lead > -1) ;
ind_00 = (dynData.imp_ind == 0) & (dynData.exp_ind == 0) & (dynData.imp_ind_lead == 0) & (dynData.exp_ind_lead == 0) ;
ind_01 = (dynData.imp_ind == 0) & (dynData.exp_ind == 0) & (dynData.imp_ind_lead == 0) & (dynData.exp_ind_lead == 1) ;
ind_10 = (dynData.imp_ind == 0) & (dynData.exp_ind == 0) & (dynData.imp_ind_lead == 1) & (dynData.exp_ind_lead == 0) ;
ind_11 = (dynData.imp_ind == 0) & (dynData.exp_ind == 0) & (dynData.imp_ind_lead == 1) & (dynData.exp_ind_lead == 1) ;
trans_prob_data_00 = sum([ind_00, ind_01, ind_10, ind_11])/sum(ind);

ind = (dynData.imp_ind == 0) & (dynData.exp_ind == 1);
trans_prob_01 = mean(outsim.ccpdata(ind,:));
trans_prob_model_01 = mean(check.CCP_model(ind,:));
% from data directly:
ind = (dynData.imp_ind == 0) & (dynData.exp_ind == 1) & (dynData.imp_ind_lead > -1) & (dynData.exp_ind_lead > -1) ;
ind_00 = (dynData.imp_ind == 0) & (dynData.exp_ind == 1) & (dynData.imp_ind_lead == 0) & (dynData.exp_ind_lead == 0) ;
ind_01 = (dynData.imp_ind == 0) & (dynData.exp_ind == 1) & (dynData.imp_ind_lead == 0) & (dynData.exp_ind_lead == 1) ;
ind_10 = (dynData.imp_ind == 0) & (dynData.exp_ind == 1) & (dynData.imp_ind_lead == 1) & (dynData.exp_ind_lead == 0) ;
ind_11 = (dynData.imp_ind == 0) & (dynData.exp_ind == 1) & (dynData.imp_ind_lead == 1) & (dynData.exp_ind_lead == 1) ;
trans_prob_data_01 = sum([ind_00, ind_01, ind_10, ind_11])/sum(ind);

ind = (dynData.imp_ind == 1) & (dynData.exp_ind == 0);
trans_prob_10 = mean(outsim.ccpdata(ind,:));
trans_prob_model_10 = mean(check.CCP_model(ind,:));
% from data directly:
ind = (dynData.imp_ind == 1) & (dynData.exp_ind == 0) & (dynData.imp_ind_lead > -1) & (dynData.exp_ind_lead > -1) ;
ind_00 = (dynData.imp_ind == 1) & (dynData.exp_ind == 0) & (dynData.imp_ind_lead == 0) & (dynData.exp_ind_lead == 0) ;
ind_01 = (dynData.imp_ind == 1) & (dynData.exp_ind == 0) & (dynData.imp_ind_lead == 0) & (dynData.exp_ind_lead == 1) ;
ind_10 = (dynData.imp_ind == 1) & (dynData.exp_ind == 0) & (dynData.imp_ind_lead == 1) & (dynData.exp_ind_lead == 0) ;
ind_11 = (dynData.imp_ind == 1) & (dynData.exp_ind == 0) & (dynData.imp_ind_lead == 1) & (dynData.exp_ind_lead == 1) ;
trans_prob_data_10 = sum([ind_00, ind_01, ind_10, ind_11])/sum(ind);

ind = (dynData.imp_ind == 1) & (dynData.exp_ind == 1);
trans_prob_11 = mean(outsim.ccpdata(ind,:));
trans_prob_model_11 = mean(check.CCP_model(ind,:));
% from data directly:
ind = (dynData.imp_ind == 1) & (dynData.exp_ind == 0) & (dynData.imp_ind_lead > -1) & (dynData.exp_ind_lead > -1) ;
ind_00 = (dynData.imp_ind == 1) & (dynData.exp_ind == 1) & (dynData.imp_ind_lead == 0) & (dynData.exp_ind_lead == 0) ;
ind_01 = (dynData.imp_ind == 1) & (dynData.exp_ind == 1) & (dynData.imp_ind_lead == 0) & (dynData.exp_ind_lead == 1) ;
ind_10 = (dynData.imp_ind == 1) & (dynData.exp_ind == 1) & (dynData.imp_ind_lead == 1) & (dynData.exp_ind_lead == 0) ;
ind_11 = (dynData.imp_ind == 1) & (dynData.exp_ind == 1) & (dynData.imp_ind_lead == 1) & (dynData.exp_ind_lead == 1) ;
trans_prob_data_11 = sum([ind_00, ind_01, ind_10, ind_11])/sum(ind);

trans_prob_offline = [trans_prob_00; trans_prob_01; trans_prob_10;trans_prob_11];
trans_prob_model = [trans_prob_model_00; trans_prob_model_01; trans_prob_model_10;trans_prob_model_11];
trans_prob_data = [trans_prob_data_00; trans_prob_data_01; trans_prob_data_10;trans_prob_data_11];

table_firstline = {' ', 'Neither', 'Export Only', 'Import Only', 'Both'};
table_para =  {'Neither', 'Export Only', 'Import Only', 'Both'};
table_est = trans_prob_data;
table_se = table_est;
fid = fopen(['..' filesep 'Table_output' filesep 'transitionProbability_data.txt'], 'w');
caption = 'Transition probabilities: data';
printTable_gen(fid,table_firstline, table_para, table_est,table_se,caption, 0);

table_est = trans_prob_offline;
fid = fopen(['..' filesep 'Table_output' filesep 'transitionProbability_offline.txt'], 'w');
caption = 'Transition probabilities: offline CCP predicted';
printTable_gen(fid,table_firstline, table_para, table_est,table_se,caption, 0);

table_est = trans_prob_model;
fid = fopen(['..' filesep 'Table_output' filesep 'transitionProbability_model.txt'], 'w');
caption = 'Transition probabilities: model predicted';
printTable_gen(fid,table_firstline, table_para, table_est,table_se,caption, 0);

%% print the trade cost parameters
clear all
load(['..' filesep 'Data' filesep 'painting_DynEst.mat'])

table_firstline = {'Parameter', 'Estimate'};
table_para =  {'$1/\lambda_\xi$','$\lambda_{00,01}$', '$\lambda_{00,10}$','$\lambda_{00,11}$','$\lambda_{10,01}$', '$\lambda_{10,10}$','$\lambda_{10,11}$','$\lambda_{01,01}$', '$\lambda_{01,10}$','$\lambda_{01,11}$', '$\lambda_{11,01}$', '$\lambda_{11,10}$','$\lambda_{11,11}$'}';
table_est = lambda;
load(['..' filesep 'Data' filesep 'BS_job_collected']); % the bootstrapping file
table_se = se.lambda;
fid = fopen(['..' filesep 'Table_output' filesep 'tradecost_est.txt'], 'w');
caption = 'Estimate of trade cost distribution parameters';
printTable_gen(fid,table_firstline, table_para, table_est,table_se,caption, 1);

%% Print a table of capital transition matrix
clear all
load(['..' filesep 'Data' filesep 'painting_DynEst.mat'])
table_para = {'$k_1$', '$k_2$','$k_3$','$k_4$','$k_5$'}';
table_para = [table_para; table_para];
table_firstline =  {'', '$k_1$', '$k_2$','$k_3$','$k_4$','$k_5$'};

table_est = [est.tran_preWTO; est.tran_postWTO];

load(['..' filesep 'Data' filesep 'BS_job_collected']); % the bootstrapping file
table_se = [se.tran_preWTO; se.tran_postWTO];

fid = fopen(['..' filesep 'Table_output' filesep 'capital_transition.txt'], 'w');
caption = 'Estimate of transition matrix of capital ';
printTable_gen(fid,table_firstline, table_para, table_est,table_se,caption, 1);

% The part is to compute the numbers of counterfactuals to report in the
% paper. 

clear all
load('painting_CFDynOut.mat')

CF_res_name = ['..' filesep 'Data' filesep 'painting_CFDynOut.mat'];
[CF_tab] = printTable_CF(CF_res_name);

% This CF_tab will be used in the following tables for counterfactuals:

% Table 1: A table to summarize the difference between the baseline and
% counterfactuals
table_firstline =  {'Year', '2','5','10','15'};
table_para = {'Aggregate productivity', 'Aggregate input price', 'Exporters Point', 'Exporters Percent', 'Importers Point', 'Importers Percent'}';
table_para = [table_para; table_para];

table_est = CF_tab.omega_p_keyVar;

load(['..' filesep 'Data' filesep 'BS_CF_job_collected']); % the bootstrapping file
table_se = se_CF.omega_p_keyVar;

fid = fopen(['..' filesep 'Table_output' filesep 'counterfactual_omega_p.txt'], 'w');
caption = 'Effect of Trade Participation on Productivity and Input Prices';
printTable_gen(fid,table_firstline, table_para, table_est,table_se,caption, 1);

% Table 2: A table to summarize the difference between the full model and WTO counterfactual, the baseline is no WTO price effect
% prepare the table content
table_firstline =  {'Year', '2','5','10','15'};
table_para = {'Aggregate productivity', 'Aggregate input price', 'Exporters Point', 'Exporters Percent', 'Importers Point', 'Importers Percent'}';
table_para = [table_para; table_para];

table_est = CF_tab.wto_incentive_keyVar;

load(['..' filesep 'Data' filesep 'BS_CF_job_collected']); % the bootstrapping file
table_se = se_CF.wto_incentive_keyVar;

fid = fopen(['..' filesep 'Table_output' filesep 'counterfactual_wto_incentive.txt'], 'w');
caption = 'Effect of WTO Price-Incentive to Import';
printTable_gen(fid,table_firstline, table_para, table_est,table_se,caption, 1);

% Table 3: print a table for OP decomposition to summarize WTO counterfactual -- it uses removed tariff case as the baseline
table_para = {'Productivity', 'Input Price'}';
table_firstline =  {' ', 'Weighted','Un-weighted','Cov'};

table_est = CF_tab.OP_5;
table_se = se_CF.wto_OP_5;
fid = fopen(['..' filesep 'Table_output' filesep 'OP_decomposition_cf_5yrs.txt'], 'w');
caption = 'Decomposition of Change of Productivity and Input Price Level (5 years)';
printTable_gen(fid,table_firstline, table_para, table_est,table_se,caption, 1);

% Table 4: print a table for OP decomposition to summarize WTO counterfactual -- it uses removed tariff case as the baseline
table_para = {'Productivity', 'Input Price'}';
table_firstline =  {' ', 'Weighted','Un-weighted','Cov'};

table_est = CF_tab.OP_15;
table_se = se_CF.wto_OP_15;
fid = fopen(['..' filesep 'Table_output' filesep 'OP_decomposition_cf_15yrs.txt'], 'w');
caption = 'Decomposition of Change of Productivity and Input Price Level (15 years)';
printTable_gen(fid,table_firstline, table_para, table_est,table_se,caption, 1);

%% Print a table to summarize who benefit more from WTO (using no-WTO-price effect as the baseline) -- 5 years case
clear all
load('painting_CFDynOut.mat')
% prepare the table content
CF_res_name = ['..' filesep 'Data' filesep 'painting_CFDynOut.mat'];
[CF_tab] = printTable_CF(CF_res_name);

table_firstline =  {'','Overall', 'Low $\omega$','High $\omega$', 'Low $p_{M}$', 'High $p_{M}$', 'Neither','Export','Import', 'Both'};
table_para = {'Productivity','Input Price','Exporters Point', 'Exporters Percent', 'Importers Point', 'Importers Percent'}';
table_est = CF_tab.wto_firmtype_keyVar_5;

load(['..' filesep 'Data' filesep 'BS_CF_job_collected']); % the bootstrapping file
table_se = se_CF.wto_firmtype_keyVar_5;

fid = fopen(['..' filesep 'Table_output' filesep 'WTO_whoBenefit_5yrs.txt'], 'w');
caption = 'Gains from WTO Tariff Reduction by Groups (5 years)';
printTable_gen(fid,table_firstline, table_para, table_est,table_se,caption, 1);


%% Print a table to summarize the baseline: no-WTO-price case (5 years)
% This table has a similar to the table above -- but it show the "pre"
% numbers (the base numbers before taking the difference)
clear all
load('painting_CFDynOut.mat')
% prepare the table content
baseline_case = 7;
cf_case = [2]; %  % the case of counterfactual: the full model
end_year = [6]; % take a number of years

diff_omega = [];
diff_P0 = [];
diff_exp = [];
diff_imp = [];

% prepare for the baseline case: normalize its productivity and price to
% 100 so we can compare both across groups and before/after.
omega_base = agg_revenue_weighted_overall.omega_agg_avg(baseline_case,end_year);
P0_base = agg_revenue_weighted_overall.log_PM_agg_avg(baseline_case,end_year);

% Overall
diff_omega(1) = 1;
diff_P0(1)  = 1;
diff_exp(1) = agg_revenue_weighted_overall.exp_ind_agg_avg(baseline_case,end_year);
diff_imp(1) = agg_revenue_weighted_overall.imp_ind_agg_avg(baseline_case,end_year);
% For low omega
diff_omega(2) =  agg_revenue_weighted_lowOmega.omega_agg_avg(baseline_case,end_year) ./ omega_base;
diff_P0(2)  = agg_revenue_weighted_lowOmega.log_PM_agg_avg(baseline_case,end_year) ./ P0_base;
diff_exp(2) = agg_revenue_weighted_lowOmega.exp_ind_agg_avg(baseline_case,end_year);
diff_imp(2) = agg_revenue_weighted_lowOmega.imp_ind_agg_avg(baseline_case,end_year);
% For high omega
diff_omega(3) =   agg_revenue_weighted_hiOmega.omega_agg_avg(baseline_case,end_year) ./ omega_base;
diff_P0(3)  =  agg_revenue_weighted_hiOmega.log_PM_agg_avg(baseline_case,end_year) ./ P0_base;
diff_exp(3) =  agg_revenue_weighted_hiOmega.exp_ind_agg_avg(baseline_case,end_year);
diff_imp(3) =  agg_revenue_weighted_hiOmega.imp_ind_agg_avg(baseline_case,end_year);

% For low price
diff_omega(4) =  agg_revenue_weighted_lowPrice.omega_agg_avg(baseline_case,end_year) ./ omega_base;
diff_P0(4)  =  agg_revenue_weighted_lowPrice.log_PM_agg_avg(baseline_case,end_year) ./ P0_base;
diff_exp(4) =  agg_revenue_weighted_lowPrice.exp_ind_agg_avg(baseline_case,end_year);
diff_imp(4) =  agg_revenue_weighted_lowPrice.imp_ind_agg_avg(baseline_case,end_year);
% For high price
diff_omega(5) = agg_revenue_weighted_hiPrice.omega_agg_avg(baseline_case,end_year) ./ omega_base;
diff_P0(5)  =  agg_revenue_weighted_hiPrice.log_PM_agg_avg(baseline_case,end_year) ./ P0_base;
diff_exp(5) = agg_revenue_weighted_hiPrice.exp_ind_agg_avg(baseline_case,end_year);
diff_imp(5) =  agg_revenue_weighted_hiPrice.imp_ind_agg_avg(baseline_case,end_year);

% for None traders
diff_omega(6) =  agg_revenue_weighted_none.omega_agg_avg(baseline_case,end_year) ./ omega_base;
diff_P0(6)  =  agg_revenue_weighted_none.log_PM_agg_avg(baseline_case,end_year) ./ P0_base;
diff_exp(6) =  agg_revenue_weighted_none.exp_ind_agg_avg(baseline_case,end_year);
diff_imp(6) =  agg_revenue_weighted_none.imp_ind_agg_avg(baseline_case,end_year);
% For exporters
diff_omega(7)=  agg_revenue_weighted_exp.omega_agg_avg(baseline_case,end_year) ./ omega_base;
diff_P0(7)  =  agg_revenue_weighted_exp.log_PM_agg_avg(baseline_case,end_year) ./ P0_base;
diff_exp(7) =  agg_revenue_weighted_exp.exp_ind_agg_avg(baseline_case,end_year);
diff_imp(7) =  agg_revenue_weighted_exp.imp_ind_agg_avg(baseline_case,end_year);
% For importers
diff_omega(8) =   agg_revenue_weighted_imp.omega_agg_avg(baseline_case,end_year) ./ omega_base;
diff_P0(8)  =   agg_revenue_weighted_imp.log_PM_agg_avg(baseline_case,end_year) ./ P0_base;
diff_exp(8)  =  agg_revenue_weighted_imp.exp_ind_agg_avg(baseline_case,end_year);
diff_imp(8)  = agg_revenue_weighted_imp.imp_ind_agg_avg(baseline_case,end_year);
% For both
diff_omega(9) =  agg_revenue_weighted_both.omega_agg_avg(baseline_case,end_year) ./ omega_base;
diff_P0(9) =  agg_revenue_weighted_both.log_PM_agg_avg(baseline_case,end_year) ./ P0_base;
diff_exp(9) = agg_revenue_weighted_both.exp_ind_agg_avg(baseline_case,end_year);
diff_imp(9) =  agg_revenue_weighted_both.imp_ind_agg_avg(baseline_case,end_year);

table_firstline =  {'','Overall', 'Low $\omega$','High $\omega$', 'Low $p_{M}$', 'High $p_{M}$', 'Neither','Export','Import', 'Both'};
table_para = {'Productivity','Input Price','Exporting','Importing'}';
table_est = [ diff_omega;  diff_P0;diff_exp;  diff_imp] ; % convert into percentage

table_est = table_est*100;
table_se = table_est;
fid = fopen(['..' filesep 'Table_output' filesep 'WTO_whoBenefit_baseline_5yrs.txt'], 'w');
caption = 'Counterfactual: No WTO Tariff Reduction, by Groups (5 years)';
printTable_gen(fid,table_firstline, table_para, table_est,table_se,caption, 0);

%% Print a table to summarize who benefit more from WTO (using no-WTO-price effect as the baseline) -- 15 years case
clear all
load('painting_CFDynOut.mat')
% prepare the table content
CF_res_name = ['..' filesep 'Data' filesep 'painting_CFDynOut.mat'];
[CF_tab] = printTable_CF(CF_res_name);

table_firstline =  {'','Overall', 'Low $\omega$','High $\omega$', 'Low $p_{M}$', 'High $p_{M}$', 'Neither','Export','Import', 'Both'};
table_para = {'Productivity','Input Price','Exporters Point', 'Exporters Percent', 'Importers Point', 'Importers Percent'}';
table_est = CF_tab.wto_firmtype_keyVar_15;

load(['..' filesep 'Data' filesep 'BS_CF_job_collected']); % the bootstrapping file
table_se = se_CF.wto_firmtype_keyVar_15;

fid = fopen(['..' filesep 'Table_output' filesep 'WTO_whoBenefit_15yrs.txt'], 'w');
caption = 'Gains from WTO Tariff Reduction by Groups (15 years)';
printTable_gen(fid,table_firstline, table_para, table_est,table_se,caption, 1);


%% Print a table to summarize the baseline: no-WTO-price case (15 years)
% This table has a similar to the table above -- but it show the "pre"
% numbers (the base numbers before taking the difference)
clear all
load('painting_CFDynOut.mat')
% prepare the table content
baseline_case = 7;
cf_case = [2]; %  % the case of counterfactual: the full model
end_year = [16]; % take a number of years

diff_omega = [];
diff_P0 = [];
diff_exp = [];
diff_imp = [];

% prepare for the baseline case: normalize its productivity and price to
% 100 so we can compare both across groups and before/after.
omega_base = agg_revenue_weighted_overall.omega_agg_avg(baseline_case,end_year);
P0_base = agg_revenue_weighted_overall.log_PM_agg_avg(baseline_case,end_year);

% Overall
diff_omega(1) = 1;
diff_P0(1)  = 1;
diff_exp(1) = agg_revenue_weighted_overall.exp_ind_agg_avg(baseline_case,end_year);
diff_imp(1) = agg_revenue_weighted_overall.imp_ind_agg_avg(baseline_case,end_year);
% For low omega
diff_omega(2) =  agg_revenue_weighted_lowOmega.omega_agg_avg(baseline_case,end_year) ./ omega_base;
diff_P0(2)  = agg_revenue_weighted_lowOmega.log_PM_agg_avg(baseline_case,end_year) ./ P0_base;
diff_exp(2) = agg_revenue_weighted_lowOmega.exp_ind_agg_avg(baseline_case,end_year);
diff_imp(2) = agg_revenue_weighted_lowOmega.imp_ind_agg_avg(baseline_case,end_year);
% For high omega
diff_omega(3) =   agg_revenue_weighted_hiOmega.omega_agg_avg(baseline_case,end_year) ./ omega_base;
diff_P0(3)  =  agg_revenue_weighted_hiOmega.log_PM_agg_avg(baseline_case,end_year) ./ P0_base;
diff_exp(3) =  agg_revenue_weighted_hiOmega.exp_ind_agg_avg(baseline_case,end_year);
diff_imp(3) =  agg_revenue_weighted_hiOmega.imp_ind_agg_avg(baseline_case,end_year);

% For low price
diff_omega(4) =  agg_revenue_weighted_lowPrice.omega_agg_avg(baseline_case,end_year) ./ omega_base;
diff_P0(4)  =  agg_revenue_weighted_lowPrice.log_PM_agg_avg(baseline_case,end_year) ./ P0_base;
diff_exp(4) =  agg_revenue_weighted_lowPrice.exp_ind_agg_avg(baseline_case,end_year);
diff_imp(4) =  agg_revenue_weighted_lowPrice.imp_ind_agg_avg(baseline_case,end_year);
% For high price
diff_omega(5) = agg_revenue_weighted_hiPrice.omega_agg_avg(baseline_case,end_year) ./ omega_base;
diff_P0(5)  =  agg_revenue_weighted_hiPrice.log_PM_agg_avg(baseline_case,end_year) ./ P0_base;
diff_exp(5) = agg_revenue_weighted_hiPrice.exp_ind_agg_avg(baseline_case,end_year);
diff_imp(5) =  agg_revenue_weighted_hiPrice.imp_ind_agg_avg(baseline_case,end_year);

% for None traders
diff_omega(6) =  agg_revenue_weighted_none.omega_agg_avg(baseline_case,end_year) ./ omega_base;
diff_P0(6)  =  agg_revenue_weighted_none.log_PM_agg_avg(baseline_case,end_year) ./ P0_base;
diff_exp(6) =  agg_revenue_weighted_none.exp_ind_agg_avg(baseline_case,end_year);
diff_imp(6) =  agg_revenue_weighted_none.imp_ind_agg_avg(baseline_case,end_year);
% For exporters
diff_omega(7)=  agg_revenue_weighted_exp.omega_agg_avg(baseline_case,end_year) ./ omega_base;
diff_P0(7)  =  agg_revenue_weighted_exp.log_PM_agg_avg(baseline_case,end_year) ./ P0_base;
diff_exp(7) =  agg_revenue_weighted_exp.exp_ind_agg_avg(baseline_case,end_year);
diff_imp(7) =  agg_revenue_weighted_exp.imp_ind_agg_avg(baseline_case,end_year);
% For importers
diff_omega(8) =   agg_revenue_weighted_imp.omega_agg_avg(baseline_case,end_year) ./ omega_base;
diff_P0(8)  =   agg_revenue_weighted_imp.log_PM_agg_avg(baseline_case,end_year) ./ P0_base;
diff_exp(8)  =  agg_revenue_weighted_imp.exp_ind_agg_avg(baseline_case,end_year);
diff_imp(8)  = agg_revenue_weighted_imp.imp_ind_agg_avg(baseline_case,end_year);
% For both
diff_omega(9) =  agg_revenue_weighted_both.omega_agg_avg(baseline_case,end_year) ./ omega_base;
diff_P0(9) =  agg_revenue_weighted_both.log_PM_agg_avg(baseline_case,end_year) ./ P0_base;
diff_exp(9) = agg_revenue_weighted_both.exp_ind_agg_avg(baseline_case,end_year);
diff_imp(9) =  agg_revenue_weighted_both.imp_ind_agg_avg(baseline_case,end_year);

table_firstline =  {'','Overall', 'Low $\omega$','High $\omega$', 'Low $p_{M}$', 'High $p_{M}$', 'Neither','Export','Import', 'Both'};
table_para = {'Productivity','Input Price','Exporting','Importing'}';
table_est = [ diff_omega;  diff_P0;diff_exp;  diff_imp] ; % convert into percentage

table_est = table_est*100;
table_se = table_est;
fid = fopen(['..' filesep 'Table_output' filesep 'WTO_whoBenefit_baseline_15yrs.txt'], 'w');
caption = 'Counterfactual: No WTO Tariff Reduction, by Groups (15 years)';
printTable_gen(fid,table_firstline, table_para, table_est,table_se,caption, 0);

%% print a table for OP decomposition for Omega and price (in level), from data
clear all
load(['..' filesep 'Data' filesep 'quality_out.mat'])
table_firstline =  {'Year', 'Weighted','Un-weighted','Cov','Weighted','Un-weighted','Cov'};
revenue = exp(log_R);
table_est = [];
table_para = {'2000', '2001','2002','2003','2004', '2005','2006'}';

for yr=2000:2006
    show_ind = (year==yr);
    n_show = sum(show_ind);
    Omega_uwmean = mean(exp(phyOmega(show_ind)), 1); % unweighted average
    P0_uwmean= mean(exp(log_P0(show_ind)), 1); % unweighted average

    Omega_uwmean_show(yr-1999) = mean(exp(phyOmega(show_ind)), 1); % unweighted average
    P0_uwmean_show(yr-1999) = mean(exp(log_P0(show_ind)), 1); % unweighted average

    delta_Omega = exp(phyOmega(show_ind)) - repmat(Omega_uwmean, n_show, 1);
    delta_P0 = exp(log_P0(show_ind)) - repmat(P0_uwmean, n_show, 1);
    share = revenue(show_ind)./ repmat(sum(revenue(show_ind)), n_show, 1);
    delta_share = share    -   1/n_show * ones(n_show, size(delta_Omega,2));

    Omega_weighted(yr-1999) = sum(exp(phyOmega(show_ind))  .* share);
    P0_weighted(yr-1999) = sum(exp(log_P0(show_ind))  .* share);

    corr_Omega_share(yr-1999)  = sum(delta_Omega .* delta_share);
    corr_P0_share(yr-1999)  = sum(delta_P0 .* delta_share);
end

temp1 = [Omega_weighted', Omega_uwmean_show', corr_Omega_share']./Omega_weighted(1);
temp2 = [P0_weighted', P0_uwmean_show', corr_P0_share']./P0_weighted(1);
table_est = [temp1, temp2];
table_est = table_est*1;

load(['..' filesep 'Data' filesep 'BS_CF_job_collected']); % the bootstrapping file
table_se = se_CF.wto_OP_15;

fid = fopen(['..'  filesep 'Table_output'  filesep 'OP_decomposition_data.txt'], 'w');
caption = 'OP decomposition for Omega and price (in level) from data ';
printTable_gen(fid,table_firstline, table_para, table_est,table_se,caption, 0);


%% Summary Statistics at the industrial level: show the growth

clear all
load(['..' filesep 'Data' filesep 'painting_res.mat'])
table_firstline = {' ',  'Overall', 'Pre-WTO','Post-WTO'};
table_para = {'Total Sales'
    'Wage Expenditure'
    'Material Expenditure'
    'Capital Stock'
    'Export Revenue'
    'Import Value'
    'Number of Firms'
    };


show_ind_set = [year>0, year<2002, year>=2002];
nYr = [7, 2,5];
table_est = [];
for i=1:3
    show_ind = show_ind_set(:,i);
    output = sum(outputpv_gy(show_ind))/1000/8/nYr(i);
    nFirms = sum((show_ind))/nYr(i);
    EL  = sum(labor_cost(show_ind))/1000/8/nYr(i);
    EM  = sum(material_cost(show_ind))/1000/8/nYr(i);
    K = sum(capital_pv(show_ind))/1000/8/nYr(i);
    exp_value  =  sum(exp_gy(exp_gy>0 & show_ind))/1000/8/nYr(i);
    imp_value =  sum(value_fy_imp(value_fy_imp>0 & show_ind))/1000/8/nYr(i);

    table_est(:,i) = [ output ;
        EL;
        EM;
        K;
        exp_value ;
        imp_value;
        nFirms;
        ];
end

table_se = table_est;
fid = fopen(['..' filesep 'Table_output' filesep  'summary-industrial level.txt'], 'w');
caption = 'Summary Statistics of at the Industrial level';
printTable_gen(fid,table_firstline, table_para, table_est,table_se,caption, 0);

% print a figure for the growth of import and export
for yr = 2000:2006
    show_ind = (year==yr);
    exp_value_yr(yr-1999)  =  sum(exp_gy(exp_gy>0 & show_ind))/1000/8;
    imp_value_yr(yr-1999) =  sum(value_fy_imp(value_fy_imp>0 & show_ind))/1000/8;
end
plot([2000:2006],exp_value_yr,'--b','LineWidth',2)
hold on
plot([2000:2006],imp_value_yr,'-r','LineWidth',2)
legend('Export','Import');
ylabel('Aggregate Value (Million USD)')
xlabel('Year')

%% Summary Statistics  focusing on the trade liberalization before and after WTO
clear all
load(['..' filesep 'Data' filesep 'painting_res.mat'])
table_firstline = {' ',  'Pre-WTO','Post-WTO'};
table_para = {
    'IndustryExport Share'
    'Firm-level Export Share (\%)'
    'Export Participation (\%)'
    'Weighted Export Participation (\%)'
    'Industry Import Share'
    'Firm-level Import Share (\%)'
    'Import Participation (\%)'
    'Weighted Import Participation (\%)'
    };

show_ind_set = [ year<2002, year>=2002];
table_est = [];
nYr = [2,5];
for i=1:2
    show_ind = show_ind_set(:,i);
    output_med = mean(outputpv_gy(show_ind))/1000/8;
    nWorker_med = mean(labor_gy(show_ind));
    EL_med = mean(labor_cost(show_ind))/1000/8;
    EM_med = mean(material_cost(show_ind))/1000/8;
    K_med = mean(capital_pv(show_ind))/1000/8;
    M_sh = material_cost./(material_cost + labor_cost);
    M_sh_med = mean(M_sh(show_ind));
    exp_prob = sum(exp_gy>0 & show_ind)/sum(show_ind);
    imp_prob = sum(value_fy_imp>0 & show_ind)/sum(show_ind);
    exp_sh = exp_gy./outputpv_gy; % at the firm level
    imp_sh = value_fy_imp./inter; % at the firm level
    exp_sh_med =  mean(exp_sh(exp_sh>0 & show_ind));
    imp_sh_med =  mean(imp_sh(imp_sh>0 & show_ind));
    exp_value_med =  mean(exp_gy(exp_gy>0 & show_ind))/1000/8;
    imp_value_med =  mean(value_fy_imp(value_fy_imp>0 & show_ind))/1000/8;

    output_share = outputpv_gy(show_ind)./sum(outputpv_gy(show_ind));
    exp_prob_weighted = (exp_gy(show_ind)>0)'*output_share;
    imp_prob_weighted = (value_fy_imp(show_ind)>0)'*output_share;

    M_share = material_cost(show_ind)./sum(material_cost(show_ind));
    exp_prob_M_weighted = (exp_gy(show_ind)>0)'*M_share;
    imp_prob_M_weighted = (value_fy_imp(show_ind)>0)'*M_share;

    output = sum(outputpv_gy(show_ind))/1000/8/nYr(i);
    EM  = sum(material_cost(show_ind))/1000/8/nYr(i);
    exp_value  =  sum(exp_gy(exp_gy>0 & show_ind))/1000/8/nYr(i);
    imp_value =  sum(value_fy_imp(value_fy_imp>0 & show_ind))/1000/8/nYr(i);
    Exp_share_industrial = exp_value/output;
    Imp_share_industrial = imp_value/EM;

    table_est(:,i) = [
        Exp_share_industrial*100 ;
        exp_sh_med*100 ;
        exp_prob*100 ;
        exp_prob_weighted*100 ;
        Imp_share_industrial*100 ;
        imp_sh_med*100 ;
        imp_prob*100 ;
        imp_prob_weighted*100 ;
        ];
end

table_se = table_est;
fid = fopen(['..' filesep 'Table_output' filesep 'summary-firm-level.txt'], 'w');
caption = 'Importing and Exporting Before and After WTO';
printTable_gen(fid,table_firstline, table_para, table_est,table_se,caption,0);

%% Summary Statistics

clear all
load(['..' filesep 'Data' filesep 'painting_summary.mat'])
table_firstline = {'Statistics', 'Value'};
table_para = {'Median Total Sales'
    'Median Export Revenue (conditional)'
    'Median Import Value (conditional)'
    'Median Number of Workers'
    'Median Wage Expenditure'
    'Median Material Expenditure'
    'Median Capital Stock'
    'Exporting Obs (\%)'
    'Importing Obs (\%)'
    'Industrial-level Export-Revenue Share (\%, all firms)'
    'Industrial-level Import-material Expenditure Share (\%, all firms)'
    'Industrial-level Export-Revenue Share (\%, exporting firms)'
    'Industrial-level Import-material Expenditure Share (\%, importing firms)'
    'Number of Obs'
    };

table_est = [output_total /1000/8;
    export_cond /1000/8;
    import_cond /1000/8;
    nWorker;
    wagebill /1000/8;
    EM /1000/8;
    K /1000/8;
    12.9;
    12.4;
    10.4;  
    11.8; 
    34.8;
    42.2;
    nObs;
    ];
table_se = table_est;
fid = fopen(['..'  filesep 'Table_output' filesep 'summary.txt'], 'w');
caption = 'Summary Statistics of Paint Industry';
printTable_gen(fid,table_firstline, table_para, table_est,table_se,caption);

%% Correlation of key variables
clear all
load(['..' filesep 'Data' filesep 'quality_out.mat'])
table_firstline = {'Correlation', 'Value'};
table_para = {'corr$(\omega,\log(q_m))$';
    'corr$(\omega,\log(h))$'
    'corr$(\omega,\log(P_0))$'
    'corr$(\omega,\log(P_m))$'
    'corr$(\log(P_0),\log(q_m))$'
    'corr$(\log(L),\omega)$'
    'corr$(\log(L),\log(P0))$'
    'corr$(\log(L),\log(P_m))$'
    'corr$(\log(L),\log(q_m))$'
    'corr$(\log(L),\log(h))$'
    };
table_est = [corr(phyOmega, log_qm);
    corr(phyOmega, log_h);
    corr(phyOmega, log_P0);
    corr(phyOmega, log(PM_imputed));
    corr(log_P0, log_qm);
    corr(log_worker, phyOmega);
    corr(log_worker, log_P0);
    corr(log_worker, log(PM_imputed));
    corr(log_worker, log_qm);
    corr(log_worker, log_h);
    ];
table_se = table_est;
fid = fopen(['..'  filesep 'Table_output' filesep 'correlations.txt'], 'w');
caption = 'Correlation Coefficients of Key Variables';
printTable_gen(fid,table_firstline, table_para, table_est,table_se,caption);

