% This function solve the productivity (and domestic sale quantity) from a
% nonlinear equation system

function [omega_imputed, Q_D, exitflag] = recoverOmega(guess, data, ka, itaD, itaX, L_norm_sh, M_norm_sh, K_norm_sh,  gamma, Q_bar,market_p,market_Q)

option = optimset('Display','off');
[Q_D,fval,exitflag] = fsolve(@(x) QDFun(data, x, ka, itaD, itaX, L_norm_sh, M_norm_sh, K_norm_sh,  gamma,  Q_bar,market_p,market_Q),guess,option);

[~,omega_imputed] = QDFun(data, Q_D,ka, itaD, itaX, L_norm_sh, M_norm_sh, K_norm_sh,   gamma, Q_bar,market_p,market_Q);

if exitflag <= 0
    fprintf('Warning: omega is not well-solved!')
end
