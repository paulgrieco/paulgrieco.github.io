% Process the data: rename and define new variables
%% rename variables
pid_0 = id;
R = sales; 
log_R =log(R); 
log_L = log(labor_gy);
labor = labor_gy;
labor_cost = wage + benefit + ins_unemp;
material_cost = inter;
capital = capital_pv;
log_capital = log(capital);
value_ratio=(labor_cost+material_cost)./labor_cost;
quan_ratio=capital./labor;
export = exp_gy;
export_sh = export./R;
R_D = R - exp_gy;
lage = log(max(0,year-openyear)+1);

paidup_tot =  paidup_state + paidup_col + paidup_legal + paidup_person + paidup_hmt + paidup_fdi;
p_capstate = paidup_state./paidup_tot;
p_capcorporate = paidup_legal./paidup_tot;
p_capcoll = paidup_col./paidup_tot;
p_capindividual = paidup_person./paidup_tot;
p_caphkmactai = paidup_hmt./paidup_tot;
p_capforeign = paidup_fdi./paidup_tot;

no_exporter = (abs(exp_gy) <= 1e-4);
lr_export = exp_gy./(1e+6); 

imp_ind = (abs(impValue_share)>1e-4);
import_sh = impValue_share;

zipcode2 = floor(zipcode/10000) + 1;
zipcodeDum = dummyvar(zipcode2);
zipcodeDum = zipcodeDum(:,sum(zipcodeDum,1) > 10);

no_intang = (abs(intangible)<1e-4); 
lr_intangcap = intangible./(1e+6);

lliquid = asset_liquid./(1e+6);
neg_liquid = debt./(1e+6);

%% load into structure data
data.log_R = log_R;
data.log_L = log_L;
data.labor = labor;
data.capital = capital;
data.labor_cost = labor_cost;
data.material_cost = material_cost;
data.value_ratio = value_ratio;
data.quan_ratio = quan_ratio;
data.log_value_ratio = log(value_ratio);
data.log_labor_cost = log(labor_cost);
data.log_capital = log(capital);
data.pid_0 = pid_0;

data.export = export;
data.R_D = R_D;

%% Normalized data
data.log_R_norm = data.log_R - mean(log_R);
data.labor_norm = exp(log_L - mean(log_L));
data.labor_cost_norm = exp(log(labor_cost) - mean(log(labor_cost)));
data.material_cost_norm = exp(log(material_cost) - mean(log(material_cost)));
data.capital_norm = exp(log_capital - mean(log_capital));
data.log_capital_norm = data.log_capital - mean(log_capital);
data.log_material_cost_norm = log(material_cost) - mean(log(material_cost));
data.log_labor_cost_norm = log(labor_cost) - mean(log(labor_cost));
data.log_labor_norm = log(labor) - mean(log(labor));
data.ratio = data.labor_norm./data.capital_norm;

%% esimate shares: using normalization point to calculate
data.material_cost_avg = exp(mean(log(material_cost)));
data.labor_cost_avg = exp(mean(log(labor_cost)));
data.capital_avg = exp(mean(log(capital)));

