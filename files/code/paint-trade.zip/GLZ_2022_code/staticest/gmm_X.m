% Compute the standard error, which is used to do maximization in the main
function [m,e] = gmm_X(ita_ka,infoz,stat,Y,X,Z)
global data
itaX = ita_ka(1);
ka = ita_ka(2);
%% construct the error terms of the evolution process
estD = data.estD;
itaD =  estD.itaD;
e = log(data.export) + itaX*log(ka) - (1+itaX)*log((itaD+1)/itaD) - (1+itaX)*log(itaX/(itaX+1)) - (itaX+1)/(itaD+1)*log(data.R_D) ;

e = e(data.tag_X==1); % only use the exporters

m = vec(Z'*e)/size(e,1);
end