% This is the function/equation about omega. We use it to solve for omega

% here x =  exp(omega)
function [diff,grad] = omegaFun(data, x,itaD, itaX, L_norm_sh, M_norm_sh, K_norm_sh,   gamma, Q_bar,market_p,market_Q)
grad = [];

%% solve for Q_D as a function of exp(omega)
long_part = (L_norm_sh*data.value_ratio.*(data.labor_norm.^gamma) + K_norm_sh*(data.capital_norm.^gamma)).^( 1/gamma - 1);

LHS_temp = (1+itaD)/itaD * market_p * L_norm_sh * (data.labor_norm.^gamma) .* x .* Q_bar .* long_part;

RHS_temp = data.labor_cost;

Q_D = (LHS_temp./RHS_temp).^(-itaD);

%% take the difference of the production function (to solve exp(omega))
 z = (itaX*(1+itaD)/(1+itaX)/itaD)^itaX; 

LHS = z*Q_D.^(itaX/itaD) + Q_D;

RHS = x .* Q_bar .* (L_norm_sh*data.value_ratio.*(data.labor_norm.^gamma) + K_norm_sh*(data.capital_norm.^gamma)).^( 1/gamma);

diff = RHS - LHS;
