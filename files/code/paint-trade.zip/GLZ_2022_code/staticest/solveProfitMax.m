% This function solve for the firm's profit maximization

function [Q_D, Q_X, M, L, E_M, E_L, myexitflag] = solveProfitMax(s) 
%% Setup true parameters
aL0 = s.L_norm_sh; % distribution parameters, non-normalized (original).
aM0 = s.M_norm_sh;
aK0 = s.K_norm_sh;
gamma0 = s.gamma; % as a function of simga
itaD = s.itaD; % demand elasticity
itaX = s.itaX; % demand elasticity

PL = s.PL; % Input prices 
PM = s.PM;

prod = s.Q_bar*exp(s.omega); % exp of omega (productivity)
K = s.capital_norm; % normalized capital stock

%% solve for firm's optimal input and output choices

L_0 = 1;
M_0 = 1;
K_0 = 1;
prod_0 = 1;
Q_0 = 1;
aL0_bar = aL0;
aM0_bar = aM0;
aK0_bar = aK0;

allA = ((itaD + 1)/itaD);
allS = (L_0/M_0)*PL.*((PL*L_0*aM0_bar./(PM*M_0*aL0_bar)).^(1/(gamma0 - 1))) + PM;
allB = (aM0_bar + aL0_bar*(PL*L_0*aM0_bar./(PM*M_0*aL0_bar)).^(gamma0/(gamma0 - 1))).^(1/gamma0);
allC = aK0_bar*((K/K_0).^gamma0);

m.allD = (allA.*allB.*prod*Q_0)./allS;
m.allE = allC.*((prod*Q_0).^gamma0);
m.itaD = itaD;
m.itaX = itaX;
m.z = ( (1+itaX)./(1+itaD) )^itaX;
m.gamma0 = gamma0;
m.exporter = s.exporter;

temp = ( allC.^(1/s.gamma) ) .* prod;
Q_guess = s.Q_D_guess;
lb = [];
ub = [];

options = optimset('TolFun',1e-10,'TolX',1e-10,'MaxIter',200,'Display','off','MaxFunEvals',10000000); % was 20000
[Q_D,funval, exitflag] = fsolve(@(x) Q_opt_lin(x,m),Q_guess,options); 

options = optimset('Display','off','MaxIter',500);
Q_lsq = (exitflag == 1) .* real(Q_D) + (exitflag ~= 1) .* Q_guess;
[Q_D,resnorm,residual,exitflag] = lsqnonlin(@(x) Q_opt_lin(x,m),Q_lsq,lb,ub,options);

if (max(abs(imag(Q_D)./real(Q_D))) > 1e-2) | (sum(exitflag<=0) > 0)
    fprintf('Warning: the firm profit max problem is not well solved for some firms ... \n')
end

myexitflag = (abs(imag(Q_D)./real(Q_D)) < 1e-2) & (abs(residual)<1e-3);

Q_D = real(Q_D);
Q_X = s.exporter .* m.z .* Q_D.^(itaX/itaD);
Q  = Q_D + Q_X; % total output quantity

M = (((Q./(prod*Q_0)).^gamma0 - allC).^(1/gamma0))./allB; % optimal material quantity choice
L = ((PL*L_0*aM0_bar./(PM*M_0*aL0_bar)).^(1/(gamma0 - 1))).*(M*L_0/M_0); % optimal labor quantity choice

E_M = M.* PM;
E_L = L .* PL;



