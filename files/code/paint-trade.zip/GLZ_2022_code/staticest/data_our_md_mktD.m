% this function is to use GLZ but with domestic market only.
% data.tag_D indicates which ones are domestic market only observations.
function [obj, grad] = data_our_md_mktD(g)
grad = [];

global data

itaD = g(1);
gamma = (g(2) - 1)/g(2);
temp = log(data.R_D) -log(itaD/(itaD+1)) - log(data.material_cost+ data.labor_cost.*(1 + g(3).*(data.capital_norm./data.labor_norm).^gamma));

obj = [];

for i = 1:length(data.tag_D)
  if data.tag_D(i) == 1
      obj = [obj, temp(i)];
  end
end