% This script export matlab data to Stata for futher analysis

filename = 'ForStatadata.xlsx';
varName = {'omega_imputed','PM_imputed', 'asset_liquid' 'exp_ind' 'imp_ind' 'lage' 'lliquid' 'log_capital_norm' 'log_wagerate' 'p_capcoll'  'p_capcorporate', 'p_capforeign', 'p_caphkmactai', 'p_capindividual', 'p_capstate' 'year' 'zipcode2' 'pid' 'tariff_avg'};
xlswrite(filename,varName)
A = [omega_imputed, PM_imputed, asset_liquid exp_ind+0 imp_ind+0 lage lliquid log_capital_norm log_wagerate p_capcoll p_capcorporate p_capforeign p_caphkmactai p_capindividual p_capstate year zipcode2 data.pid_0 tariff_avg];
xlswrite(filename,A,1, 'A2')

 %% The following part is for moving Matlab data after quality estimation to Stata. It need to match with the original data: painting.csv
clear
load('quality_out.mat')

filename = 'ForStatadata_quality_out.xlsx';
varName = {'id',  'year', 'phyOmega', 'log_P0', 'log_qm',  'PM_imputed', 'omega_imputed', 'R_check'};
xlswrite(filename,varName)
A = [data.pid_0,  year, phyOmega, log_P0, log_qm,  data.PM_imputed, data.omega_imputed, exp(data.log_R)];
xlswrite(filename,A,1, 'A2')
 