 % e is the matrix of errors of the evolution processes, which is used to
 % construct the var-cov of the two errors.
function [gmm_out, e] = gmmest_X(ita_ka)
global data 

Y  = data.log_capital_norm(data.tag_X==1);
Z = [data.log_capital_norm(data.tag_X==1), data.log_labor_norm(data.tag_X==1),  data.log_labor_cost_norm(data.tag_X==1),  data.log_material_cost_norm(data.tag_X==1), data.log_capital_norm(data.tag_X==1).^2];
 
X = Z;

gmmopt.plot = 0; % 0 is to have some plot, 1 is not.
gmmopt.infoz.momt='gmm_X';
gmmopt.gmmit = 2;
gmmopt.W0 = 'I';
gmm_out = gmm(ita_ka,gmmopt,Y,X,Z);

[~,e] = gmm_X(gmm_out.b,[],[],Y,X,Z); % this produces the errors of the evolution processes after the estimation.