% This function gets the lag of the variable/vector, and also return the
% valid indicator (have both current and lag term)

function [x_lag, valid_ind] = getLag(x,id)
x_lag = NaN*zeros(size(x)); % make it NaN
x_lag(2:end) = x(1:end-1);

id_lag = NaN*zeros(size(id));
id_lag(2:end) = id(1:end-1);
valid_ind = (id == id_lag);
