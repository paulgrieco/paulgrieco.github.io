% This is the function/equation about omega. We use it to solve for omega
% This is the production function divided by FOC (labor) to produce an
% equation of QD only.
% here x =  exp(omega)
function [diff,omega] = QDFun(data, x,ka, itaD, itaX, L_norm_sh, M_norm_sh, K_norm_sh,   gamma, Q_bar,market_p,market_Q)


%% solve for Q_D as a function of exp(omega)
% this is the part in the bracket in the note
long_part = L_norm_sh*data.value_ratio.*(data.labor_norm.^gamma) + K_norm_sh*(data.capital_norm.^gamma);

z = (itaX*(1+itaD)/(1+itaX)/itaD/ka)^itaX; 

LHS = (1+itaD)/itaD * market_p .* L_norm_sh .* (data.labor_norm.^gamma) .* (data.exporter .* z .* x.^((itaX+1)/itaD) + x.^((itaD+1)/itaD) );

RHS = data.labor_cost .* long_part;

diff = RHS - LHS;

%% take the difference of the production function (to solve exp(omega))
LHS_temp = data.exporter .* z.*x.^(itaX/itaD) + x;

RHS_temp =  Q_bar .* (L_norm_sh*data.value_ratio.*(data.labor_norm.^gamma) + K_norm_sh*(data.capital_norm.^gamma)).^( 1/gamma);

omega = log(LHS_temp) - log(RHS_temp);