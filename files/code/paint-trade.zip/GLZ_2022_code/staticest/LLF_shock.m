% This function calculate the log likelihood function of the joint shock of (omega, pm, pl)

function LLF = LLF_shock(omega_shock,log_PM_shock,log_PL_shock,Cov)

pdf_shock = mvnpdf([omega_shock,log_PM_shock,log_PL_shock],0,Cov);

LLF = sum(log(pdf_shock));
