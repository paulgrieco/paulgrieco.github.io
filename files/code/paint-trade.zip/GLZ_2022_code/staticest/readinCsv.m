%% Import data from text file.

%% Initialize variables.
delimiter = ',';
startRow = 2;

%% Format string for each line of text:
%   column1: double (%f)
%	column2: double (%f)
%   column3: double (%f)
%	column4: double (%f)
%   column5: double (%f)
%	column6: double (%f)
%   column7: double (%f)
%	column8: double (%f)
%   column9: double (%f)
%	column10: double (%f)
%   column11: double (%f)
%	column12: double (%f)
%   column13: double (%f)
%	column14: double (%f)
%   column15: double (%f)
%	column16: double (%f)
%   column17: double (%f)
%	column18: double (%f)
%   column19: double (%f)
%	column20: double (%f)
%   column21: double (%f)
%	column22: double (%f)
%   column23: double (%f)
%	column24: double (%f)
%   column25: double (%f)
%	column26: double (%f)
%   column27: double (%f)
%	column28: double (%f)
%   column29: double (%f)
%	column30: double (%f)
%   column31: double (%f)
%	column32: double (%f)
%   column33: double (%f)
%	column34: double (%f)
%   column35: double (%f)
%	column36: double (%f)
%   column37: double (%f)
%	column38: double (%f)
%   column39: double (%f)
%	column40: double (%f)
% For more information, see the TEXTSCAN documentation.
formatSpec = '%f%f%f%f%f%f%f%f%f%f%f%f%f%f%f%f%f%f%f%f%f%f%f%f%f%f%f%f%f%f%f%f%f%f%f%f%f%f%f%f%f%[^\n\r]';

%% Open the text file.
fileID = fopen(filename,'r');

%% Read columns of data according to format string.
% This call is based on the structure of the file used to generate this
% code. If an error occurs for a different file, try regenerating the code
% from the Import Tool.
%dataArray = textscan(fileID, formatSpec, 'Delimiter', delimiter, 'HeaderLines' ,startRow-1, 'ReturnOnError', false);
dataArray = textscan(fileID, formatSpec, 'Delimiter', delimiter, 'EmptyValue' ,NaN,'HeaderLines' ,startRow-1, 'ReturnOnError', false);
%% Close the text file.
fclose(fileID);

%% Post processing for unimportable data.
% No unimportable data rules were applied during the import, so no post
% processing code is included. To generate code which works for
% unimportable data, select unimportable cells in a file and regenerate the
% script.

%% Allocate imported array to column variable names
year = dataArray{:, 1};
zipcode = dataArray{:, 2};
sic = dataArray{:, 3};
openyear = dataArray{:, 4};
labor_gy = dataArray{:, 5};
outputpv_gy = dataArray{:, 6};
sales_gy = dataArray{:, 7};
exp_gy = dataArray{:, 8};
asset_liquid = dataArray{:, 9};
inventory = dataArray{:, 10};
inventory_finish = dataArray{:, 11};
asset_liq_avg = dataArray{:, 12};
capital_pv = dataArray{:, 13};
capital4prod = dataArray{:, 14};
intangible = dataArray{:, 15};
debt_long = dataArray{:, 16};
debt_short = dataArray{:, 17};
debt = dataArray{:, 18};
rights = dataArray{:, 19};
paidup = dataArray{:, 20};
paidup_state = dataArray{:, 21};
paidup_col = dataArray{:, 22};
paidup_legal = dataArray{:, 23};
paidup_person = dataArray{:, 24};
paidup_hmt = dataArray{:, 25};
paidup_fdi = dataArray{:, 26};
sales_prime = dataArray{:, 27};
wage = dataArray{:, 28};
benefit = dataArray{:, 29};
inter = dataArray{:, 30};
ins_unemp = dataArray{:, 31};
index = dataArray{:, 32};
id = dataArray{:, 33};
value_fy_exp = dataArray{:, 34};
price_fy_exp = dataArray{:, 35};
value_fy_imp = dataArray{:, 36};
price_fy_imp = dataArray{:, 37};
exchange_rate = dataArray{:, 38};
impValue_share = dataArray{:, 39};
sales = dataArray{:, 40};
tariff_avg = dataArray{:, 41};


%% Clear temporary variables
clearvars filename delimiter startRow formatSpec fileID dataArray ans;