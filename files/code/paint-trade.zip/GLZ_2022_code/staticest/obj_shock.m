

function [obj_shock] = obj_shock(para,m)
% unpack parameters
[Cov,omegaPara, PMPara, PLPara] = unpack_ar_para(para,m);

% calculate the three shocks given the parameters and data
omega_shock = m.omega - m.X_omega * omegaPara;
log_PM_shock = m.log_PM - m.X_PM * PMPara;
log_PL_shock = m.log_PL - m.X_PL * PLPara;

obj_shock = - LLF_shock(omega_shock,log_PM_shock,log_PL_shock,Cov);