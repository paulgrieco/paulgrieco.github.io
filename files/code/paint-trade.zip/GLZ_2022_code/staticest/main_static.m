clear all
clc

path_name = ['..' filesep 'GMMpackage' ];
addpath(genpath(path_name))

path_name = ['..' filesep 'adigator' ];
addpath(genpath(path_name))

%read data from csv file
industry_name = 'painting';
filename = ['..' filesep 'Data' filesep industry_name '.csv'];

readinCsv
save([ industry_name])
clearvars -except industry_name
clc

load([industry_name])

resFile = sprintf('%s_res',industry_name);
resFile = ['..' filesep 'Data' filesep resFile];

data_process_static

global data

% initial guess
para_0 = 1*[-8, 2, .3];

quan = .00;
perc = .95;
tr_pm = .1;
tr_prod = 0.05;
trim = 0.025;

% load data
data.log_R = log_R;
data.log_L = log_L;
data.labor = labor;
data.capital = capital;
data.labor_cost = labor_cost;
data.material_cost = material_cost;
data.value_ratio = value_ratio;
data.quan_ratio = quan_ratio;
data.log_value_ratio = log(value_ratio);
data.log_labor_cost = log(labor_cost);
data.log_capital = log(capital);
data.pid_0 = pid_0;

% Add with market level data
data.log_Q_avg = mean(log_R); % use average R to approximate average Q
Q_avg = exp(data.log_Q_avg);
Q_bar = Q_avg;
market_p = 1*ones(size(pid_0));
market_Q = 1;

% Normalized data
data.log_R_norm = data.log_R - mean(log_R);
data.labor_norm = exp(log_L - mean(log_L));
data.labor_cost_norm = exp(log(labor_cost) - mean(log(labor_cost)));
data.material_cost_norm = exp(log(material_cost) - mean(log(material_cost)));
data.capital_norm = exp(log_capital - mean(log_capital));
data.log_capital_norm = data.log_capital - mean(log_capital);

data.log_material_cost_norm = log(material_cost) - mean(log(material_cost));
data.log_labor_cost_norm = log(labor_cost) - mean(log(labor_cost));
data.log_labor_norm = log(labor) - mean(log(labor));

data.ratio = data.labor_norm./data.capital_norm;

% esimate shares: using normalization point to calculate
data.material_cost_avg = exp(mean(log(material_cost)));
data.labor_cost_avg = exp(mean(log(labor_cost)));
data.capital_avg = exp(mean(log(capital)));

% tag observations for inital year of each firm
data.tag = zeros(length(data.pid_0),1);

TC = data.labor_cost + data.material_cost;

data.tag = (data.R_D>0)&(data.log_R>quantile(data.log_R,quan)).*(data.log_R<quantile(data.log_R,1- quan)) ...
    .*(labor_cost>quantile(labor_cost,quan)).*(labor_cost<quantile(labor_cost,1- quan)) ...
    .*(material_cost>quantile(material_cost,quan)).*(material_cost<quantile(material_cost,1- quan)) ...
    .*(data.capital_norm./data.labor_norm>quantile(data.capital_norm./data.labor_norm,quan)).*(data.capital_norm./data.labor_norm<quantile(data.capital_norm./data.labor_norm,1- quan));

data.tag = data.tag.*(exp(data.log_R)*perc>TC);
data.tag_D = data.tag .* (no_exporter==1); % valid tag indicating domestic producer only
data.tag_X = data.tag .* (no_exporter==0); % valid tag indicating producer of both domestic and foreign market

% for domestic only observations:
[para_est,resnorm,residual,exitflag,output,lambda,jacobian] = lsqnonlin('data_our_md_mktD',para_0,[], [], optimset('Tolfun',1e-6, 'TolX',1e-15,'MaxIter',500,'Display','iter','MaxFunEvals',10000));
sigma([1,3,4]) = sqrt(resnorm*diag(full((jacobian'*jacobian)^-1))/length(residual));

% For results
itaD = para_est(1);
theta = para_est(2);
tau = para_est(3);
gamma = (theta-1)/theta;

% for exporters

% use lsq to estimate:
para_1 = -8;
estD.itaD = itaD;
estD.theta = theta;
estD.tau = tau;

% use GMM:
data.estD.itaD = itaD;
data.estD.theta = theta;
data.estD.tau = tau;
itaX0 = itaD;
ka = 1; % allow for relative size of exporting market to domestic market
ita_ka = [itaX0; ka];
[gmm_out, e] = gmmest_X(ita_ka);

% For results
itaX = gmm_out.b(1);
ka = gmm_out.b(2);
sigma(2) = gmm_out.se(1);
sigma(5) = gmm_out.se(2);

% % hours per labor
hours = 5000;
labor_avg = exp(mean(log(labor*hours)));
labor_cost_avg = exp(mean(log(labor_cost)));
labor_price_avg = labor_cost_avg/labor_avg;
material_cost_avg = exp(mean(log(material_cost)));
material_avg = exp(mean(log(material_cost./1))); % treat the material price as 1
capital_avg = exp(mean(log(capital)));

L_norm_sh = labor_cost_avg/(labor_cost_avg + material_cost_avg + tau*labor_cost_avg);
M_norm_sh = material_cost_avg/(labor_cost_avg + material_cost_avg + tau*labor_cost_avg);
K_norm_sh = tau*labor_cost_avg/(labor_cost_avg + material_cost_avg + tau*labor_cost_avg);

mu = tau*labor_cost_avg/(capital_avg^gamma*(labor_cost_avg/(labor_avg^gamma) + material_cost_avg/(material_avg^gamma)));
L_orig_sh = (1/(mu+1))*(labor_cost_avg/(labor_avg^gamma))/(labor_cost_avg/(labor_avg^gamma) + material_cost_avg/(material_avg^gamma));
M_orig_sh = (material_cost_avg/(material_avg^gamma))/(labor_cost_avg/(labor_avg^gamma))*L_orig_sh;
K_orig_sh = 1 - L_orig_sh - M_orig_sh;

% Impute material price;
M_imputed = ((L_norm_sh.*material_cost)./(M_norm_sh.*labor_cost)).^(1/gamma) .* (hours*labor) .* (material_avg/labor_avg);

PM_imputed = material_cost./(M_imputed./exp(mean(log(M_imputed)))); % This is the normalized material price
wagerate_norm = data.labor_cost./(data.labor./exp(mean(log(data.labor))));
log_wagerate = log(wagerate_norm); % This is the normalized wage rate.

% trimming
PM_imputed_trimmed = PM_imputed.*(PM_imputed>quantile(PM_imputed,tr_pm)).*(PM_imputed<quantile(PM_imputed,1 - 1*tr_pm));

PM_imputed_clear = [];
for m = 1:length(PM_imputed_trimmed)
    if PM_imputed_trimmed(m) > 0
        PM_imputed_clear = [PM_imputed_clear,PM_imputed_trimmed(m)];
    end
end

[f_pm,pm] = ksdensity(log(PM_imputed_clear));

data.PM_imputed = PM_imputed;

nObs = length(data.labor_norm);
stepsize = 500;
loc = 1;

i = 1;
while loc<nObs
    block = [loc : loc + stepsize - 1];
    if (loc + stepsize - 1)<=nObs
        data_block{i}.value_ratio = data.value_ratio(block,:);
        data_block{i}.labor_norm = data.labor_norm(block,:);
        data_block{i}.capital_norm = data.capital_norm(block,:);
        data_block{i}.labor_cost = data.labor_cost(block,:);
        data_block{i}.exporter  = (1-no_exporter(block,:));
        data_block{i}.market_p  = market_p(block,:);
    else
        data_block{i}.value_ratio = data.value_ratio(loc:end,:);
        data_block{i}.labor_norm = data.labor_norm(loc:end,:);
        data_block{i}.capital_norm = data.capital_norm(loc:end,:);
        data_block{i}.labor_cost = data.labor_cost(loc:end,:);
        data_block{i}.exporter  = (1-no_exporter(loc:end,:));
        data_block{i}.market_p  = market_p(loc:end,:);
    end

    loc = loc + stepsize;
    i  = i + 1;
end
fprintf('Now begin to solve for omega ...\n')
parfor i = 1: length(data_block)
    fprintf('Solving block %g ... \n', i)
    guess = (3e+4)*ones(length(data_block{i}.labor_norm),1);
    [omega_imputed_block{i}, Q_D_block{i}, exitflag(i)] = recoverOmega(guess, data_block{i}, ka, itaD, itaX, L_norm_sh, M_norm_sh, K_norm_sh, gamma, Q_bar,data_block{i}.market_p,market_Q);
end

assert(sum(exitflag<=0) == 0) % make sure the omega's are well-solved

omega_imputed = [];
for i = 1: length(data_block)
    omega_imputed = [omega_imputed; omega_imputed_block{i}];
end


assert(max(abs(imag(omega_imputed)))<1e-4); % in case we have imag part of omega because of the solution of the the above equation is not well-derived
omega_imputed = real(omega_imputed);
data.omega_imputed = omega_imputed;

% trimming
omega_imputed_trimmed = omega_imputed.*(omega_imputed>quantile(omega_imputed,tr_prod)).*(omega_imputed<quantile(omega_imputed,1 - 1*tr_prod));
omega_imputed_clear = [];
for m = 1:length(omega_imputed_trimmed)
    if omega_imputed_trimmed(m) ~= 0
        omega_imputed_clear = [omega_imputed_clear,omega_imputed_trimmed(m)];
    end
end

% demeaned imputed productivity
[f_omega,omega] = ksdensity(omega_imputed_clear-mean(omega_imputed_clear));

% calculate coefficient corr(omega,PL) and corr(omega,PM)
omega_imputed_co = omega_imputed.*(omega_imputed>quantile(omega_imputed,tr_prod)).*(omega_imputed<quantile(omega_imputed,1 - 1*tr_prod));
PM_imputed_co = PM_imputed.*(PM_imputed>quantile(PM_imputed,tr_pm)).*(PM_imputed<quantile(PM_imputed,1 - 1*tr_pm));
PL_co = labor_cost./labor;
omega_imputed_co_clear = [];
PM_imputed_co_clear = [];
PL_co_clear = [];
for m = 1:length(omega_imputed_co)
    if omega_imputed_co(m) ~= 0& PM_imputed_co(m)>0
        omega_imputed_co_clear = [omega_imputed_co_clear,omega_imputed_co(m)];
        PM_imputed_co_clear = [ PM_imputed_co_clear, PM_imputed_co(m)];
        PL_co_clear = [PL_co_clear,PL_co(m)];
    end
end

co_omega_PM = corr(omega_imputed_co_clear',log( PM_imputed_co_clear'));
co_omega_PL = corr(omega_imputed_co_clear',log( PL_co_clear'));

Nd = 1e+5;
draws = randn(Nd,1);
tau_draws = tau + draws*sigma(4);
L_norm_draws = labor_cost_avg./((1+tau_draws)*labor_cost_avg + material_cost_avg);
L_norm_sd = sqrt(var(L_norm_draws));
M_norm_draws = material_cost_avg./((1+tau_draws)*labor_cost_avg + material_cost_avg);
M_norm_sd = sqrt(var(M_norm_draws));
K_norm_draws = (tau_draws*labor_cost_avg)./((1+tau_draws)*labor_cost_avg + material_cost_avg);
K_norm_sd = sqrt(var(K_norm_draws));

draws1 = randn(Nd,1);
theta_draws = theta + draws1*sigma(3);
gamma_draws = (theta_draws - 1)./theta_draws;
L_orig_draws = (labor_cost_avg./(labor_avg.^gamma_draws))./ (labor_cost_avg./(labor_avg.^gamma_draws) + material_cost_avg./(material_avg.^gamma_draws) + tau_draws.*labor_cost_avg./(capital_avg.^gamma_draws));
L_orig_sd = sqrt(var(L_orig_draws));
M_orig_draws = (material_cost_avg./(material_avg.^gamma_draws))./ (labor_cost_avg./(labor_avg.^gamma_draws) + material_cost_avg./(material_avg.^gamma_draws) + tau_draws.*labor_cost_avg./(capital_avg.^gamma_draws));
M_orig_sd = sqrt(var(M_orig_draws));
K_orig_draws = (tau_draws.*labor_cost_avg./(capital_avg.^gamma_draws))./ (labor_cost_avg./(labor_avg.^gamma_draws) + material_cost_avg./(material_avg.^gamma_draws) + tau_draws.*labor_cost_avg./(capital_avg.^gamma_draws));
K_orig_sd = sqrt(var(K_orig_draws));

disp_est = [itaD; itaX;theta;L_norm_sh; M_norm_sh; K_norm_sh; tau;L_orig_sh; M_orig_sh; K_orig_sh];
disp_sd = [sigma(1);sigma(2);sigma(3); L_norm_sd;M_norm_sd;K_norm_sd;sigma(4);L_orig_sd;M_orig_sd;K_orig_sd];
disp_results=[disp_est,disp_sd];

% Display

disp('M_sh_orig|L_sh_orig|K_sh_orig| M_sh_norm| L_sh_norm| K_sh_norm| tau ');
disp([M_orig_sh, L_orig_sh, K_orig_sh, M_norm_sh, L_norm_sh, K_norm_sh, tau]);

disp('d-elast |elast_sub  | relative market ratio ')
disp([itaD, itaX, theta, ka]);
disp([sigma(1), sigma(2), sigma(3), sigma(5)]);
%
% % Just for display
obs = sum(data.tag==1);

est.aL = L_norm_sh;
est.aM = M_norm_sh;
est.aK = K_norm_sh;

est.etaD = itaD;
est.etaX = itaX;
est.ka = ka;

est.sigma = theta;

save(resFile);

