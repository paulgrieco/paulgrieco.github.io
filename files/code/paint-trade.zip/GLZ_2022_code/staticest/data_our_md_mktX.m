% this function is to use GLZ but with observations of export only.

function [obj, grad] = data_our_md_mktX(itaX, estD)
grad = [];

global data

itaD = estD.itaD;
gamma = (estD.theta- 1)/estD.theta;
temp = log(data.R_D + (itaD/(itaD+1))*((itaX+1)/itaX) * data.export) -log(itaD/(itaD+1)) - log(data.material_cost+ data.labor_cost.*(1 + estD.tau.*(data.capital_norm./data.labor_norm).^gamma));

obj = [];

for i = 1:length(data.tag_X)
  if data.tag_X(i) == 1
      obj = [obj, temp(i)];
  end
end