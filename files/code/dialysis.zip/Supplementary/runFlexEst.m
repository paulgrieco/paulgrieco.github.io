
%This script runs the estimation of referee 1's suggested extension

setupDialysis;

%Run 1: Our Flexibile results: 
op.qual = 2;


[c_table1, c_xprodfx1] = mainEst(cols, s, [s.inspection_rate s.time_since_survey], [s.poshires s.for_profit s.compLevel s.davita s.fresenius],...
    [s.for_profit s.davita s.fresenius], op);


