function [M mu sig] = genBasis( X, order)
%
% This function receives a vector of coefficients and returns a 
% matrix of standardized polynomials with intereactions ready to be
% used in a linear regression

%Input: X matrix of variables for the 'nonparametric function
%       order, the order of the polynomial to approximate

    %Standardization of the variables makes thing more numerically
    %stable, but does not affect the result (since we aren't interested
    % in the nonparametric coefficients themselves).
    %The function zscore is a built in for standardizing variables
    [nobs dim] = size(X);
    [zX, mu, sig] = zscore(X);
    %zX = X;
    
    %This will generate terms, a vector with the powers to generate
    %all the monomials of order order
    %Each row is the powers for a different monomial.
    nterms = (order+1)^dim;
    terms = dec2bigbase(0:nterms-1, order+1);
    terms(sum(terms,2)>order,:) = [];
    [nterms foo] = size(terms);

    %Allocate memory for the design matrix
    M = zeros(nobs , nterms);

    %This loop evaluates each monomial in the expansion.  
    %We loop over terms...but should be using just-in-time compiling.
    for t = 1:length(terms)
        %Raise each dimension to the appropriate power (bsxvun)
        % and then multiply them together (prod) to produce column t
        % of the design matrix.
        M(:,t) = prod(bsxfun(@power, zX, terms(t,:)),2);
    end

end