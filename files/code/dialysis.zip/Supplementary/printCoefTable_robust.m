
%This file prints the robustness check table. 
%Table 5 in the manuscript. 
clear;
load bootRes;

fid = 1;

robTab = [ c_table2(:,1) c_table3(:,1) c_table4(:,1)  c_table6(:,1) ];
seTab  = [  se_table2(:,1) se_table3(:,1) se_table4(:,1)  se_table6(:,1)];
tabOrder = [1 2 3 4];

coefNames = {'Quality, $-\alpha_q$', 'Capital, $\beta_k$', 'Labor, $\beta_\ell$'};

%Opening...
fprintf(fid, '\\begin{table}[t] \n  \\begin{center} \n');
fprintf(fid, '\\begin{threeparttable} \n \n'); 
fprintf(fid, '\\caption{Robustness Checks.} \n');
fprintf(fid, '\\begin{tabular}{lcccc}\n \\hline \\hline \n');

%Headers...

fprintf(fid, ' & No Quality & No Patient  & No  &  Drop Low  \\\\ \n \\hline \n');
fprintf(fid, ' & Instrument & Char. Controls. & Competition &  Demand Markets \\\\ \n \\hline \n');

for v = 1:length(coefNames)
    fprintf(fid, '%s ', coefNames{v} );
    
    %Coefficients
    for c = 1:length(tabOrder)
        fprintf(fid, '& %.4f ', robTab(v,tabOrder(c)));
    end
    fprintf(fid, '\\\\ \n')
    
    %Standard Errors
    for c = 1:length(tabOrder)
        fprintf(fid, ' & \\footnotesize{(%.4f)}', seTab(v,tabOrder(c)));
    end
    fprintf(fid, '\\\\ \n')

end
fprintf(fid, '\\hline \n \\end{tabular} \n');
fprintf(fid, '\\begin{tablenotes} \n \\small \n');
fprintf(fid, '\\item Notes: Alternative specifications to the baseline results presented in Table 5, Column 1. Standard errors in parenthesis');
fprintf(fid, '\\end{tablenotes}');
fprintf(fid, '\\label{tab:Robust} \n')
fprintf(fid, ' \\end{threeparttable} \n \\end{center} \n \\end{table} \n');