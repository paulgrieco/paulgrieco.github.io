%This script will bootstrap our primary results and save them to a file

clear;
diary('runBoot.diary');

%Rely on runMainEst to set things up and do the main regression.
runMainEst;


tic;
%% Now the actual bootstrap

%This is the highest CMS code, used for drawing firms
topCMS = max(cols(:,s.cms_code));

%This is the number of firms in our estimation, all firms have a unique, 
%id, but some are skipped because of earlier screening
numFirms = length(unique(cols(:,s.cms_code)));

B = 200;
b_table1_list = [];
b_xprodfx1_list = [];

b_table2_list = [];
b_xprodfx2_list = [];
b_table3_list = [];
b_xprodfx3_list = [];
b_table4_list = [];
b_xprodfx4_list = [];
b_table5_list = [];
b_xprodfx5_list = [];
b_table6_list = [];
b_xprodfx6_list = [];

ktrflag_list = [];

RandStream.setGlobalStream(RandStream('mt19937ar','seed',8342341));

%Setup pool, recently updated:
% Old code that is now deprecated:
%if matlabpool('size') == 0
%   matlabpool open
%end
poolobj = gcp('nocreate');
if isempty(poolobj)
    poolobj = parpool;
    fprintf('Created pool with %d workers', poolobj.NumWorkers);
else
    fprintf('Using existing pool of %d workers', poolobj.NumWorkers);
end



parfor b = 1:B
    %Draw the bootstrap sample
    bFirms = 0
    boot_cols = [];
    while bFirms < numFirms
        addCMS = ceil(rand()*topCMS);
        addCols = cols( cols(:,s.cms_code) == addCMS,:);
        if ~isempty(addCols)
            boot_cols = [boot_cols; addCols];
            bFirms = bFirms+1;
        end
    end
    
    
    %Evaluate
    [b_table1, b_xprodfx1] = mainEst(boot_cols, s, [s.inspection_rate s.time_since_survey], [s.poshires s.for_profit s.compLevel s.davita s.fresenius],...
        [s.for_profit s.davita s.fresenius], op1);

    [b_table2, b_xprodfx2] = mainEst(boot_cols, s, [s.inspection_rate s.time_since_survey], [s.poshires s.for_profit s.compLevel s.davita s.fresenius],...
        [s.for_profit s.davita s.fresenius], op2);

    [b_table3, b_xprodfx3] = mainEst(boot_cols, s, [s.inspection_rate s.time_since_survey], [s.poshires s.for_profit s.compLevel s.davita s.fresenius],...
        [s.for_profit s.davita s.fresenius], op3);
    
    [b_table4, b_xprodfx4] = mainEst(boot_cols, s, [s.inspection_rate s.time_since_survey], [s.poshires s.for_profit], ...
        [s.for_profit s.davita s.fresenius], op4);
    
    boot_cols_tight = boot_cols(boot_cols(:,s.tight_market)==1, :);
    [b_table5, b_xprodfx5] = mainEst(boot_cols_tight, s, [s.inspection_rate s.time_since_survey], [s.poshires s.for_profit s.compLevel s.davita s.fresenius],...
        [s.for_profit s.davita s.fresenius], op1);

    boot_cols_tight90 = boot_cols(boot_cols(:,s.tight_market_90)==1, :);
    [b_table6, b_xprodfx6] = mainEst(boot_cols_tight90, s, [s.inspection_rate s.time_since_survey], [s.poshires s.for_profit s.compLevel s.davita s.fresenius],...
        [s.for_profit s.davita s.fresenius], op1);
    
    
    %Add to list
    b_table1_list = [ b_table1_list b_table1(:)];
    b_xprodfx1_list = [ b_xprodfx1_list b_xprodfx1(:) ];
    b_table2_list = [ b_table2_list b_table2(:)];
    b_xprodfx2_list = [ b_xprodfx2_list b_xprodfx2(:) ];
    b_table3_list = [ b_table3_list b_table3(:)];
    b_xprodfx3_list = [ b_xprodfx3_list b_xprodfx3(:) ];
    b_table4_list = [ b_table4_list b_table4(:)];
    b_xprodfx4_list = [ b_xprodfx4_list b_xprodfx4(:) ];
    b_table5_list = [ b_table5_list b_table5(:)];
    b_xprodfx5_list = [ b_xprodfx5_list b_xprodfx5(:) ];
    b_table6_list = [ b_table6_list b_table6(:)];
    b_xprodfx6_list = [ b_xprodfx6_list b_xprodfx6(:) ];
  
end

%matlabpool close
delete(poolobj);
toc;

se_table1 = mean(bsxfun(@minus, b_table1_list, c_table1(:)).^2,2).^(1/2);
se_table1 = reshape(se_table1, size(c_table1));

se_xprodfx1 = mean(bsxfun(@minus, b_xprodfx1_list, c_xprodfx1(:)).^2,2).^(1/2);
se_xprodfx1 = reshape(se_xprodfx1, size(c_xprodfx1));

se_table2 = mean(bsxfun(@minus, b_table2_list, c_table2(:)).^2,2).^(1/2);
se_table2 = reshape(se_table2, size(c_table2));

se_xprodfx2 = mean(bsxfun(@minus, b_xprodfx2_list, c_xprodfx2(:)).^2,2).^(1/2);
se_xprodfx2 = reshape(se_xprodfx2, size(c_xprodfx2));

se_table3 = mean(bsxfun(@minus, b_table3_list, c_table3(:)).^2,2).^(1/2);
se_table3 = reshape(se_table3, size(c_table3));

se_xprodfx3 = mean(bsxfun(@minus, b_xprodfx3_list, c_xprodfx3(:)).^2,2).^(1/2);
se_xprodfx3 = reshape(se_xprodfx3, size(c_xprodfx3));

se_table4 = mean(bsxfun(@minus, b_table4_list, c_table4(:)).^2,2).^(1/2);
se_table4 = reshape(se_table4, size(c_table4));

se_xprodfx4 = mean(bsxfun(@minus, b_xprodfx4_list, c_xprodfx4(:)).^2,2).^(1/2);
se_xprodfx4 = reshape(se_xprodfx4, size(c_xprodfx4));

se_table5 = mean(bsxfun(@minus, b_table5_list, c_table5(:)).^2,2).^(1/2);
se_table5 = reshape(se_table5, size(c_table5));

se_xprodfx5 = mean(bsxfun(@minus, b_xprodfx5_list, c_xprodfx5(:)).^2,2).^(1/2);
se_xprodfx5 = reshape(se_xprodfx5, size(c_xprodfx5));

se_table6 = mean(bsxfun(@minus, b_table6_list, c_table6(:)).^2,2).^(1/2);
se_table6 = reshape(se_table6, size(c_table6));

se_xprodfx6 = mean(bsxfun(@minus, b_xprodfx6_list, c_xprodfx6(:)).^2,2).^(1/2);
se_xprodfx6 = reshape(se_xprodfx6, size(c_xprodfx6));

save bootRes

diary('off');