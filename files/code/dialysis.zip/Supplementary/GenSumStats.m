%This script runs the quality regression using the latest results.

clear;
%data = importdata('prodEstData_wdeath.csv');
data = importdata('prodEstData.csv');

% Order of polynomials for nonparametric functins:
op.order = 5;

%% Step 1: Read In Data

%First, grab the columns we need for this estimation
grab_cols = [1:size(data.data,2)];
col_names = data.colheaders(grab_cols); 
cols = data.data(:, grab_cols);
[nTotObs nCols] = size(cols);

for v = 1:nCols
    eval(sprintf('s.%s = %d;', col_names{v}, v));
end


%% Set arguments

%Use instrument for quality,
op.iv =1;

%Use charachteristics for infection rate,
op.inf_char = 1;

%Include competition, for profit dummy in policy
op.comp = 1;
op.fp = 1;

%Include quality in first stage
op.qual = 1;

%Include the inspection rate:
op.inspect = 1;


%% Now run the data clean, once for all the bootstrapped runs, and get coeffiicients

%Generate the data set where all needed variable are recorded.
cols = cleanCols(cols, s, op.iv, op.inf_char);



%% First, the competition table...
fid = 1;
%Opening...
fprintf(fid, '\\begin{table}[htbp] \n \\begin{center} \n'); 
fprintf(fid, '\\caption{Distribution of Competitors in HSA.} \n');
fprintf(fid, '\\begin{tabular}{cccc}\n \\hline \\hline \n');

fprintf(fid, ' Num Comp. & N & Freq. & Cum. \\\\ \n \\hline \n');

for c = 0:3
    fprintf(fid, '%d & %d & %.4f & %.4f \\\\ \n', c, sum(cols(:, s.compLevel)==c), mean(cols(:,s.compLevel) == c), mean(cols(:,s.compLevel) <=c));
end

fprintf(fid, '\\hline \n \\end{tabular} \n');
fprintf(fid, '\\label{tab:competitors} \n')
fprintf(fid, '\\end{center} \n \\end{table} \n\n');


%% Now the full blown Summary Stat's table. 

%We need to calculate a few things we only have in logs:
foo = [exp(cols(:,[s.lpatient_years s.lstations s.lstaff])) (cols(:,s.hires)==0) (cols(:,s.invest)==0)];
s.patients = size(cols,2)+1;
s.stations = size(cols,2)+2;
s.staff = size(cols,2)+3;
s.zhires = size(cols,2)+4;
s.zinvest = size(cols,2)+5;
cols = [cols foo];

pretty_titles = { 'Patient Years', 'FTE Staff', 'Net Hiring', 'Zero Net Hiring', 'Stations', 'Zero Net Investment', 'Septic Infection Rate', 'Deaths', 'CMS Expected Deaths', 'Death Rate Ratio', 'State Inspection Rate', 'Years Since Survey', 'Neph Ref?' };
varnames = {'patients', 'staff', 'hires', 'zhires', 'stations','zinvest','infect_rate', 'deaths_', 'expdeaths_', 'death_ratio', 'inspection_rate', 'time_since_survey', 'neph_ref'};

pretty_titles = { 'Patient Years', 'FTE Staff', 'Net Hiring', 'Zero Net Hiring', 'Stations', 'Zero Net Investment', 'Septic Infection Rate', 'Excess Mortality' };
varnames = {'patients', 'staff', 'hires', 'zhires', 'stations','zinvest','infect_rate', 'death_ratio', };

fprintf(fid, '\\begin{table}[htbp] \n \\begin{center} \n'); 
fprintf(fid, '\\caption{Summary Statistics.} \n');
fprintf(fid, '\\begin{tabular}{lrr}\n \\hline \\hline \n');

fprintf(fid, ' Variable & \\multicolumn{1}{c}{Mean} & \\multicolumn{1}{c}{St. Dev.}  \\\\ \n \\hline \n');


for f = 1:length(varnames)
    fprintf(fid, '%s & %.3f & %.3f \\\\ \n', pretty_titles{f}, eval(sprintf('mean(cols(:,s.%s))', varnames{f})), eval(sprintf('std(cols(:,s.%s))', varnames{f})));
end

fprintf(fid, '\\hline \n Number of Firms & \\multicolumn{2}{c}{%d}  \\\\ Number of Firm-Years & \\multicolumn{2}{c}{%d} \\\\ \n', length(unique(cols(:,s.cms_code))), size(cols,1));

fprintf(fid, '\\hline \n \\end{tabular} \n');
fprintf(fid, '\\label{tab:sumstats} \n')
fprintf(fid, '\\end{center} \n \\end{table} \n\n');

%% Added this table, which is essentially the summary stats table but analyzing sample selection:

fprintf(fid, '\\begin{table}[htbp] \n \\begin{center} \n'); 
fprintf(fid, '\\caption{First Stage Selection.} \n');
fprintf(fid, '\\begin{tabular}{lrrrr}\n \\hline \\hline \n');

fprintf(fid, ' Variable & \\multicolumn{1}{c}{All Observations} & \\multicolumn{1}{c}{In First Stage}  & \\multicolumn{1}{c}{Dropped} & T-Score  \\\\ \n \\hline \n');


for f = 1:length(varnames)
    tomean = cols(:,s.(varnames{f}));
    tomean_ah= tomean(~isnan(tomean));
    tomean_nzh= tomean(~isnan(tomean)&~cols(:,s.zhires)&cols(:,s.zinvest));
    tomean_zh = tomean(~isnan(tomean)&(cols(:,s.zhires)|~cols(:,s.zinvest)));
    tscore = (mean(tomean_nzh) - mean(tomean_zh)) / sqrt((var(tomean_nzh)/length(tomean_nzh)) + (var(tomean_zh)/length(tomean_zh)));
    fprintf(fid, '%s & %.3f & %.3f & %.3f & %.3f \\\\ \n', pretty_titles{f}, mean(tomean_ah), mean(tomean_nzh), mean(tomean_zh), tscore);
    fprintf(fid, '\t & (%.3f) & (%.3f) & (%.3f) \\\\ \n',  std(tomean_ah), std(tomean_nzh) ,std(tomean_zh));
end

fprintf(fid, '\\hline \n Number of Observations & %d & %d & %d \\\\ \n', size(cols,1), sum( (cols(:,s.zhires) ==0) &(cols(:,s.zinvest)==1)), size(cols,1)- sum( (cols(:,s.zhires) ==0) &(cols(:,s.zinvest)==1))  );

fprintf(fid, '\\hline \n \\end{tabular} \n');
fprintf(fid, '\\label{tab:selection} \n')
fprintf(fid, '\\end{center} \n \\end{table} \n\n');


%% Now the Patient Charachtaristic Summary Stat's table. 

pretty_titles = {'Avg. Patient Age', 'Pct. Female', 'Pct. AV Fistula', 'Avg. Comorbid Conditions', 'Avg. Duration of ESRD', 'Avg. Hemoglobin Level'};
varnames = {'avg_age_', 'female_all_pct_', 'vat_cat1_', 'avg_comb_cond_', 'avg_dur_esrd_', 'avg_hemog_pct_'};

fprintf(fid, '\\begin{table}[htbp] \n \\begin{center} \n'); 
fprintf(fid, '\\caption{Patient Charachteristics Summary Statistics.} \n');
fprintf(fid, '\\begin{tabular}{lrr}\n \\hline \\hline \n');

fprintf(fid, ' Variable & \\multicolumn{1}{c}{Mean} & \\multicolumn{1}{c}{St. Dev.}  \\\\ \n \\hline \n');


for f = 1:length(varnames)
    fprintf(fid, '%s & %.3f & %.3f \\\\ \n', pretty_titles{f}, eval(sprintf('mean(cols(:,s.%s))', varnames{f})), eval(sprintf('std(cols(:,s.%s))', varnames{f})));
end

fprintf(fid, '\\hline \n \\end{tabular} \n');
fprintf(fid, '\\label{tab:patchas} \n')
fprintf(fid, '\\end{center} \n \\end{table} \n\n');




%% Finally run Ryan's Fixed Effects Regressions on Quality...

cols(isnan(cols(:,s.time_since_survey)),:) = [];
[b1 se1] = fe_reg(cols(:,s.infect_rate), cols(:,[s.time_since_survey]), cols(:,s.cms_code));
[b2 se2] = fe_reg(cols(:,s.infect_rate), cols(:,[s.inspection_rate]), cols(:,s.cms_code));
[b3 se3] = fe_reg(cols(:,s.infect_rate), cols(:,[s.inspection_rate s.time_since_survey]), cols(:,s.cms_code));


[b4 se4] = fe_reg(cols(:,s.infect_rate), cols(:,[s.time_since_survey ...
    s.avg_age_ s.female_all_pct_ s.vat_cat1_ s.avg_comb_cond_ s.avg_dur_esrd_ s.avg_hemog_pct_]), cols(:,s.cms_code));
[b5 se5] = fe_reg(cols(:,s.infect_rate), cols(:,[s.inspection_rate ...
    s.avg_age_ s.female_all_pct_ s.vat_cat1_ s.avg_comb_cond_ s.avg_dur_esrd_ s.avg_hemog_pct_]), cols(:,s.cms_code));

[b6 se6] = fe_reg(cols(:,s.infect_rate), cols(:,[s.inspection_rate s.time_since_survey...
    s.avg_age_ s.female_all_pct_ s.vat_cat1_ s.avg_comb_cond_ s.avg_dur_esrd_ s.avg_hemog_pct_]), cols(:,s.cms_code));

%% Output sample for Ryan...

filename = 'finalSample.csv';
fid = fopen(filename, 'w');

for c = 1:size(data.colheaders,2)
    fprintf(fid,'%s,', data.colheaders{c});
end
fprintf(fid,'patients, stations, staff, zhires, zinvest\n');

fclose(fid); 
dlmwrite(filename,cols,'-append','precision', '%.6f', 'delimiter', ',');



