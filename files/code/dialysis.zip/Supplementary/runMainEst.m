
%This script sets up and runs the main estimation only.  We call it in
%runBoot for consistency but it's primary purpose is to be able to get
%coefficients without running the full bootstrap.

setupDialysis;

%Run 1: Our baseline results: 
op1 = op;

%Run 2: No IV:
op2 = op;
op2.iv = 0;

%Run 3: No patient charachtersitics:
op3 = op;
op3.inf_char = 0;

%Run 4: No competition, since the editors are worried it may be endogenous.
op4 = op;
op4.statefe = 0; %Actually, this flag is always off anyway.


[c_table1, c_xprodfx1] = mainEst(cols, s, [s.inspection_rate s.time_since_survey], [s.poshires s.for_profit s.compLevel s.davita s.fresenius],...
    [s.for_profit s.davita s.fresenius], op1);

[c_table2, c_xprodfx2] = mainEst(cols, s, [s.inspection_rate s.time_since_survey], [s.poshires s.for_profit s.compLevel s.davita s.fresenius],...
    [s.for_profit s.davita s.fresenius], op2);

[c_table3, c_xprodfx3] = mainEst(cols, s, [s.inspection_rate s.time_since_survey], [s.poshires s.for_profit s.compLevel s.davita s.fresenius],...
    [s.for_profit s.davita s.fresenius], op3);

 
% Newest for robustness check table.
[c_table4, c_xprodfx4] = mainEst(cols, s, [s.inspection_rate s.time_since_survey], [s.poshires s.for_profit], ...
    [s.for_profit s.davita s.fresenius], op4);

%New robustness check, drop centers which ryan says aren't in a
%"tight_market" 
tight_cols = cols(cols(:,s.tight_market)==1, :);
[c_table5, c_xprodfx5] = mainEst(tight_cols, s, [s.inspection_rate s.time_since_survey], [s.poshires s.for_profit s.compLevel s.davita s.fresenius],...
    [s.for_profit s.davita s.fresenius], op1);

tight_cols_90 = cols(cols(:,s.tight_market_90)==1, :);
[c_table6, c_xprodfx6] = mainEst(tight_cols_90, s, [s.inspection_rate s.time_since_survey], [s.poshires s.for_profit s.compLevel s.davita s.fresenius],...
    [s.for_profit s.davita s.fresenius], op1);


%Run 4: No comp-level or profit-status, used to be in robustness checks but replaced by the above c_table4:
%[c_table4, c_xprodfx4] = mainEst(cols, s, [s.inspection_rate s.time_since_survey], [s.poshires], [], op4);

% TODAY's BIG CHECK:
%[c_poshirechk] = mainEst(cols, s, [s.inspection_rate s.time_since_survey], [s.for_profit s.compLevel s.davita s.fresenius s.poshires], [s.for_profit s.davita s.fresenius], op);


% Trying to add state codes...
%[c_table1, c_xprodfx1] = mainEst(cols, s, [s.inspection_rate s.time_since_survey], [s.poshires s.for_profit s.compLevel s.davita s.fresenius], [s.for_profit s.davita s.fresenius], op1);