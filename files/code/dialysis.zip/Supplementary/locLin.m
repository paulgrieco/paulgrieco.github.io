
function [yhat badObs] = locLin(y, X, discX)
% locLin peforms a local linear regression of each column of y on X at
% every observation point, and returns the yhat at each point. The optional
% discX is a vector of discrete types. If it is empty we assume all
% observations are of the same type. 

  %We are explicilty dealing with near-singular matricies throught badObs, 
  %so we can turn the warning off, make sure it's turned on at the bottom
  warning('off', 'MATLAB:nearlySingularMatrix');
  warning('off', 'MATLAB:singularMatrix');
  
  [nObs, dim] = size(X);
  %[zX, zMu, zSigma] = zscore(X);

  
  %We drop observations from there regression if they drop below this
  %threshold, saves a LOT of time. 
  numNeigh = 1500;
  
  badObs = [];
  yhat = zeros(size(y));
  badObs = false(nObs,1);
  %tic;
  
  %We're going to do the regression category by category.
  types = unique(discX, 'rows');
  numTypes = size(types, 1);
  W = zeros(numNeigh);
  for t = 1:numTypes
      typematch = all( bsxfun(@eq, discX, types(t,:)), 2);
      t_nObs = sum(typematch);
      [tX, tMu, tSig] = zscore(X(typematch, :));
      tY = y(typematch, :);
      
      %Set bandwith for number of observations in this type...
      %Assign bandwidth according to Scott's generalization of Silverman's
      %Rule-of-thumb.  Oversmoothing to deal with non-normality and
      %skewness of the data. 
      % Note: we zscore all the X variables by type, so in this formula
      % sigma_hat = 1.
      h = 1.5*t_nObs^(-1/(dim+4));
      t_numNeigh = min(t_nObs, numNeigh);

      t_yhat = zeros(size(tY));
      t_badObs = false(t_nObs,1);
      for j = 1:sum(typematch)

          Dx = bsxfun(@minus, tX, tX(j,:));
          w = prod(normpdf(Dx./h),2);

          %Sort weights in order to choose nearest neighboors
          sW = sort(w);
          eps = sW(end-t_numNeigh+1);

          XX = [ones(sum(w>eps),1) tX(w>eps,:)];
          ww = w(w>eps)./sW(end);
          W = diag(ww); 

          %Check for singularity issues, if we have them, maybe do something
          %But for now just save observation numbers...
          if rcond((XX'*W*XX)) < 1e-18
             %fprintf('Gonna get a warning\n');
             t_badObs(j)=1;
          end

          %Run the estimations...
          t_yhat(j,:) = [1 tX(j,:)]*((XX'*W*XX)\(XX'*W*tY(w>eps,:)));
          %if mod(j, 1000)==0
          %    fprintf('%d Complete\n', j);
          %end
      end
      
      %Now populate the main array
      yhat(typematch,:) = t_yhat;
      badObs(typematch,:) = t_badObs;
      
      %fprintf('Finished type %d, h = %f, n = %d\n', t, h, t_nObs);
  end
  
  warning('on', 'MATLAB:nearlySingularMatrix');
  warning('on', 'MATLAB:singularMatrix');
  %toc;
end