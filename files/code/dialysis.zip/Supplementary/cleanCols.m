
function [cols, n] = cleanCols(cols, s, iv, inf_chars) 
    cols(isnan(cols(:,s.lhires)), :) = [];
    %Also drop non-reported qualities...
    cols(isnan(cols(:,s.infect_rate)),:) = [];
    %And missing numbers of patients...
    cols(isnan(cols(:,s.lpatient_years)), :) = [];
    
    %And missing inspection rate information
    cols(isnan(cols(:,s.inspection_rate)), :) = [];
%    cols(isnan(cols(:,s.time_since_survey)),:) = [];

    if (inf_chars == 1)
        %..and missing vascular access data...
         cols(isnan(cols(:,s.vat_cat1_)), :) = [];
         cols(isnan(cols(:,s.avg_age_)), :) = [];
         cols(isnan(cols(:,s.avg_comb_cond_)), :) = [];
         cols(isnan(cols(:,s.avg_dur_esrd_)), :) = [];
         cols(isnan(cols(:,s.avg_hemog_pct_)), :) = [];
         cols(isnan(cols(:,s.female_all_pct_)), :) = [];
    end
    
    %Only need to drop missing death ratios if we are instrumenting...
    if (iv == 1)
        cols(isnan(cols(:,s.death_ratio)), :) = [];        
    end

    
    n = size(cols,1);
