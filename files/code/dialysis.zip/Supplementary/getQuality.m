function [Q, QIV] = getQuality(cols, s, inf_char)

    if (inf_char == 0)
        Q =  -cols(:,s.infect_rate);
        
        %Right now using death ratio as instrument, eventually will want to use
        %The residual of deaths on expected deaths
        QIV =  -cols(:,s.death_ratio) ;
        
    else
        %Here we regress patient charachteristics on infection rate and
        % use residual as a quality measure
        PCX = cols(:, [s.vat_cat1_ s.avg_age_ s.avg_comb_cond_ s.avg_dur_esrd_ s.avg_hemog_pct_ s.female_all_pct_]);
        PCX = [ ones(size(PCX,1),1) PCX ];
        PCY = cols(:, s.infect_rate);
        PCB = (PCX'*PCX)\(PCX'*PCY);
        Q = -(PCY - PCX*PCB);
        
        %Log attempt 1: Should do regression in log since this predicts
        %negative numbers...
        %Q = -(log(PCY) - log(PCX*PCB));
        
        %Question 1: what if we regress the death ratio this way?
        Y = cols(:,s.death_ratio);
        BDR = (PCX'*PCX)\(PCX'*Y);
        QIV = -(Y - PCX*BDR);
        
        
%         if 0 %This segment is for using lagged-quality as an instrument.  
%             %It doesn't work well because we loose too many observations.
%             %We need both a lag (for the quality instrument) and a forward
%             %(to calculate hiring) in order for this to work. The
%             %non-parametrics get really really noisy.
%             
%             full_Q = nan( max(cols(:,s.for_id)) , 1 );
%             full_Q(cols(:,s.row_id)) = Q;
% 
%             %One might think this loop is inefficient, but it runs very fast, due
%             %to JIC, it just constructs a vector with lagged omega, this vector has
%             %a nan where the lag is not available. 
%             Q_lag = nan(size(Q));
%             for r = 1:length(Q_lag)
%                 if ~isnan(cols(r,s.lag_id))
%                 Q_lag(r) = full_Q(cols(r,s.lag_id));
%                 end
%             end
%             QIV = Q_lag;
%         end
    end
    
    
    
   

    
    %If we want to produce a table of these results, let's put the output
    %script here and turn it on with a flag.  Don't need it for now.
    
end