

% This file prints out Table 8, estimates when we allow a flexible frontier
% based on observables.

clear;
load bootFlexRes;

fid = 1;

%% 
%These are the order of the results from 'name' that we want to use in the
%table.
tabOrder = [ 1 4 5 ];

coefNames = {'Quality, $-\alpha_q$', 'Quality x Capital, $\alpha_{qk}$', 'Quality x Labor, , $\alpha_{q\ell}$', 'Capital, $\beta_k$', 'Labor, $\beta_\ell$'};

%Opening...
fprintf(fid, '\\begin{table}[htbp] \n \\begin{center} \n'); 
fprintf(fid, '\\caption{Flexible Production Frontier.} \n');
fprintf(fid, '\\begin{tabular}{lccc}\n \\hline \\hline \n');

%Headers...
%fprintf(fid, '& \\multicolumn{3}{c|}{OLS} & \\multicolumn{2}{c}{IV} \\\\ \n');
fprintf(fid, ' & Model & OLS & FE \\\\ \n \\hline \n');

for v = 1:length(coefNames)
    fprintf(fid, '%s ', coefNames{v} );
    
    %Coefficients
    for c = 1:length(tabOrder)
        fprintf(fid, '& %.4f ', c_table1(v,tabOrder(c)));
    end
    fprintf(fid, '\\\\ \n')
    
    %Standard Errors
    for c = 1:length(tabOrder)
        fprintf(fid, ' & \\footnotesize{(%.4f)}', se_table1(v,tabOrder(c)));
    end
    fprintf(fid, '\\\\ \n')

end

fprintf(fid, '\\hline \n \\end{tabular} \n');
fprintf(fid, '\\label{tab:Coeffs_flex} \n')
fprintf(fid, '\\end{center} \n \\end{table} \n\n');


%% Here we do the test for whether the labor and quality coefficients cancel
diff = c_table1(2,1) + c_table1(3,1);
chk = b_table1_list(2,:) + b_table1_list(3,:);
chk_center = chk - mean(chk);
pval = mean((chk_center > abs(diff)) + (chk_center < -abs(diff)));

fprintf(fid, '\n\nThe p-value for the test of labor and capital coefficients canceling is %.3f.\n', pval);


