
%This file produces Table 4 based on saved estimation and bootstrap
%results. 
clear;
load bootRes;

fid = 1;

%% 
%These are the order of the results from 'name' that we want to use in the
%table.
tabOrder = [ 1 4 5 6 9 10];

coefNames = {'Quality, $-\alpha_q$', 'Capital, $\beta_k$', 'Labor, $\beta_\ell$'};

%Opening...
fprintf(fid, '\\begin{table}[htbp] \n \\begin{center} \n'); 
fprintf(fid, '\\caption{Transformation and Production Estimates.} \n');
fprintf(fid, '\\begin{tabular}{lcccccc}\n \\hline \\hline \n');

%Headers...
fprintf(fid, '& \\multicolumn{3}{c}{With Quality} & \\multicolumn{3}{c}{Without Quality} \\\\ \n');
fprintf(fid, ' & Model & OLS & FE & Model & OLS & FE \\\\ \n \\hline \n');

for v = 1:length(coefNames)
    fprintf(fid, '%s ', coefNames{v} );
    
    %Coefficients
    for c = 1:length(tabOrder)
        fprintf(fid, '& %.4f ', c_table1(v,tabOrder(c)));
    end
    fprintf(fid, '\\\\ \n')
    
    %Standard Errors
    for c = 1:length(tabOrder)
        fprintf(fid, ' & \\footnotesize{(%.4f)}', se_table1(v,tabOrder(c)));
    end
    fprintf(fid, '\\\\ \n')

end




fprintf(fid, '\\hline \n \\end{tabular} \n');
fprintf(fid, '\\label{tab:Coeffs} \n')
fprintf(fid, '\\end{center} \n \\end{table} \n\n');



