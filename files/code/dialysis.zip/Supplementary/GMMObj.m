function [obj,g] = GMMObj(beta, yq_cur, KL_cur, Phi_lag, KL_lag, discTypes, W, order)

%Back out omega + epsioln in time t and omega in time t-1:
    omep_cur = yq_cur - KL_cur*beta;
    om_lag = Phi_lag - KL_lag*beta;
    
    %Regress to find productivity process and innovation, allow the
    %coefficients of g to vary by type. If the omDisc is not given, 
    %Assume that all types are the same. 
    if isempty(discTypes)
        discTypes = ones(size(omep_cur));
    end
    numTypes = max(discTypes);
    xi = zeros(size(omep_cur));
    g = zeros(order+1,numTypes);
    for t = 1:numTypes
       typematch = (discTypes == t);
       G = genBasis(om_lag(typematch), order); 
       g(:,t) = (G'*G)\(G'*omep_cur(typematch));
       xi(typematch) = omep_cur(typematch) - G*g(:,t);
    end
       
    %Form the moments:
    %gm = [ones(1, size(xi)); KL_lag'; KL_cur']*xi;
    gm = [KL_cur']*xi;
    
    %Calculate the objective:
    obj = gm'*W*gm;

end