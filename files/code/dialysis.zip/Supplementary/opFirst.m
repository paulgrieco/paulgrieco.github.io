function [alphaq Phi] = opFirst(cols, s, order, qual, iv, comp, fp, inspect)

%disp(sprintf('The length of the data set passed to opFirst is %d', size(cols,1)));

%First, eliminate zero hiring observations.
cnz = cols(cols(:,s.lhires) ~= 0 & cols(:,s.invest) == 0, : );
%cnz = cols(cols(:,s.lhires) ~= 0, : );
cnz(isnan(cnz(:,s.for_id)), : ) = [];

%We also need to eliminate non-zero investment observations
%cnz(cnz(:,s.invest) ~= 0, :) = [];

%Here we wanted to make sure we were not using data to estimate Phi
%which would not be used in the second stage, take out for now...
%full_cols = nan( max(cols(:,s.for_id)) , size(cols, 2) );
%full_cols(cols(:,s.row_id),:) = cols;
%cnz( isnan(full_cols(cnz(:, s.for_id), s.qual)), :) = [];

%disp(sprintf('The length of the data set with non-zero hires is %d', size(cnz,1)));


%% Build Basis for first stage estimation    
%This constructs the design matrix for the series approximation..

    if (inspect == 1)
       M = genBasis( cnz(:, [s.lhires s.lstations s.lstaff s.inspection_rate ]), order);
    else
       M = genBasis( cnz(:, [s.lhires s.lstations s.lstaff ]), order);
    end
    
    if (comp == 1)
        tM = [];
        for lev = min(cnz(:,s.compLevel)):max(cnz(:,s.compLevel))
          tM = [tM bsxfun(@times, M, cnz(:,s.compLevel) == lev) ];
        end
        M = tM;
    end
    
    if (fp == 1)
        tM = [bsxfun(@times, M, cnz(:,s.for_profit)) bsxfun(@times, M, 1-cnz(:,s.for_profit))];
        M = tM;
    end
    
%% Run the First stage regression.
   y = cnz(:,s.lpatient_years);
   if (qual == 1) && (iv ==1)
       X = [ cnz(:,s.qual) M];
       Z = [ cnz(:,s.qualiv) M];
       b_qphi = (Z'*X)\(Z'*y);
   
   elseif (qual == 1) && (iv ==0)
       X = [ cnz(:,s.qual) M];
       b_qphi = (X'*X)\(X'*y);
       
       ep = y - X*b_qphi;
       [cnz(1:30,s.row_id) cnz(1:30,s.for_id) y(1:30) ep(1:30)];
   else %No quality
       b_qphi = (M'*M)\(M'*y);
   end
       
%% Record Phi in the original (with zeros) cols
   if (qual == 1)
       alphaq = b_qphi(1);
       Phi_nz = M*b_qphi(2:end);
   else
       alphaq = nan;
       Phi_nz = M*b_qphi;
   end
   
   Phi_t = nan( max(cols(:,s.row_id)) , 1 );
   Phi_t( cnz(:,s.row_id) ) = Phi_nz;
   Phi = Phi_t(cols(:,s.row_id));
   %Phi = Phi';
       
       
end
