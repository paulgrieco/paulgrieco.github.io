function [ Phi ] = convertToFull(Phi_cnz, cols, cnz, s )
%Expands the vector of estimates $\hat{\Phi}$ from the length of observations 
%included in the nonparametric estimation (i.e., those with non-zero hiring) 
%to the full set of observations, using NaN to pad the dropped variables.
    Phi_t = nan( max(cols(:,s.row_id)) , 1 );
    Phi_t( cnz(:,s.row_id) ) = Phi_cnz;
    Phi = Phi_t(cols(:,s.row_id));
end

