
%This file produces two tables. 
%
%The first is the production funciton parameter estimates based on
%different specifications of the productivity process. It is Table 7 in the
%manuscript.
%
%The second presents average productivity by center type across the same
%specifications, it does not appear in the manuscript. 

clear;
load bootRes;

fid = 1;

%% 
%These are the order of the results from 'name' that we want to use in the
%table.
tabOrder = [ 1 2 3 ];

coefNames = {'Quality, $-\alpha_q$', 'Capital, $\beta_k$', 'Labor, $\beta_\ell$'};

%Opening...
fprintf(fid, '\\begin{table}[htbp] \n \\begin{center} \n'); 
fprintf(fid, '\\caption{Transformation and Production Estimates.} \n');
fprintf(fid, '\\begin{tabular}{lccc}\n \\hline \\hline \n');

%Headers...
%fprintf(fid, '& \\multicolumn{3}{c|}{OLS} & \\multicolumn{2}{c}{IV} \\\\ \n');
fprintf(fid, ' & Baseline & Linear & Non-parametric \\\\ \n \\hline \n');

for v = 1:length(coefNames)
    fprintf(fid, '%s ', coefNames{v} );
    
    %Coefficients
    for c = 1:length(tabOrder)
        fprintf(fid, '& %.4f ', c_table1(v,c));
    end
    fprintf(fid, '\\\\ \n')
    
    %Standard Errors
    for c = 1:length(tabOrder)
        fprintf(fid, ' & \\footnotesize{(%.4f)}', se_table1(v,c));
    end
    fprintf(fid, '\\\\ \n')

end




fprintf(fid, '\\hline \n \\end{tabular} \n');
fprintf(fid, '\\label{tab:Coeffs_prod} \n')
fprintf(fid, '\\end{center} \n \\end{table} \n\n');

%% Now the table on the g specificaiton itself...

coefNames = {'For-Profit', 'Frenesius', 'DaVita'};
tabOrder = [ 1 2 ];

%Opening...
fprintf(fid, '\\begin{table}[htbp] \n \\begin{center} \n'); 
fprintf(fid, '\\caption{Average Productivity Difference by Center Type.} \n');
fprintf(fid, '\\begin{tabular}{lcc}\n \\hline \\hline \n');
fprintf(fid, ' & Linear & Non-parametric \\\\ \n \\hline \n');
for v = 1:length(coefNames)
    fprintf(fid, '%s ', coefNames{v} );
    
    %Coefficients
    for c = 1:length(tabOrder)
        fprintf(fid, '& %.4f ', c_xprodfx1(v,c));
    end
    fprintf(fid, '\\\\ \n')
    
    %Standard Errors
    for c = 1:length(tabOrder)
        fprintf(fid, ' & \\footnotesize{(%.4f)}', se_xprodfx1(v,c));
    end
    fprintf(fid, '\\\\ \n')

end

fprintf(fid, '\\hline \n \\end{tabular} \n');
fprintf(fid, '\\label{tab:ProdCoeffs} \n')
fprintf(fid, '\\end{center} \n \\end{table} \n\n');

