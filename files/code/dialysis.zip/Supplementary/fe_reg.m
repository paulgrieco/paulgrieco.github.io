function [b_fe, se] = fe_reg(Y, X, id)

%This conducts fixed effects regression where id is the vector of centre
%ids

%We assume id's are numbered 1 to num_centers.

%Note: Tried implementing with bsxfun, but its actually a little slower in
%this case (probably due to the loops). 

YX = [Y X];
YXbar = zeros(size(YX));
single_yr = zeros(size(YX,1),1);
for c = 1:max(id)
    ctrrows = (id ==c);
    numyears = sum(ctrrows);
   YXbar(ctrrows,:) = repmat(mean(YX(ctrrows, :)), numyears, 1);  
%    YXdemean(ctrrows,:) = bsxfun(@minus, YX(ctrrows,:), mean(YX(ctrrows, :)));
    if (numyears == 1)
        single_yr(ctrrows) = 1;
    end
end

YX(single_yr>0, :) = [];
YXbar(single_yr>0,:) = [];
YY = YX(:,1) - YXbar(:,1);
XX = YX(:,2:end) - YXbar(:,2:end);

%YXdemean(single_yr>0, :) = [];
%YY = YXdemean(:,1);
%XX = YXdemean(:,2:end);

b_fe = (XX'*XX)\(XX'*YY);

if nargout>1
    %Heteroskasticity Robust Standard Errors...
    u = YY - XX*b_fe;
    V = XX'*diag(u.^2)*XX;
    se = diag((XX'*XX)\V/(XX'*XX)).^.5;
end