function [ coeff_table, xprod_fx] = mainEst( cols, s, xCts, xDisc, omDisc, op )
%Main estimation function for the dialysis production frontier
%   Also return coefficients for ols and fe regression with 
%   the same data set.

    [q qiv] = getQuality(cols, s, op.inf_char);
    cols = [cols q qiv];
    s.qual = size(cols,2)-1;
    s.qualiv = size(cols, 2);
   
   
    %There are five different ways to treat quality determined by op.qual:
    switch op.qual
        case 0 
            qualCols = [];
            qualIvCols = [];
        case 1
            qualCols = s.qual;
            qualIvCols = s.qualiv;
        case 2
            cols = [cols cols(:,s.qual).*cols(:,s.lstations) cols(:,s.qual).*cols(:,s.lstaff) ...
              cols(:,s.qualiv).*cols(:,s.lstations) cols(:,s.qualiv).*cols(:,s.lstaff)   ];
            s.qualxK = size(cols,2)-3;
            s.qualxL = size(cols,2)-2;
            s.qualivxK = size(cols,2)-1;
            s.qualivxL = size(cols,2);
            qualCols = [ s.qual s.qualxK s.qualxL];
            qualIvCols = [ s.qualiv s.qualivxK s.qualivxL];
        case 3
            cols = [cols cols(:,s.qual).*(cols(:,s.lstations)-cols(:,s.lstaff)) ...
            cols(:,s.qualiv).*(cols(:,s.lstations)-cols(:,s.lstaff))   ];
            s.qualxKL = size(cols,2)-1;
            s.qualivxKL = size(cols,2);
            qualCols = [ s.qual s.qualxKL ];
            qualIvCols = [ s.qualiv s.qualivxKL ];
        case 4
            cols = [cols cols(:,s.qual).*(cols(:,s.lstations)-cols(:,s.lstaff)) cols(:,s.qual).*(cols(:,s.lstations)-cols(:,s.lstaff)).^2 ...
            cols(:,s.qualiv).*(cols(:,s.lstations)-cols(:,s.lstaff)) cols(:,s.qualiv).*(cols(:,s.lstations)-cols(:,s.lstaff)).^2   ];
            s.qualxKL = size(cols,2)-3;
            s.qualxKL2 = size(cols,2)-2;
            s.qualivxKL = size(cols,2)-1;
            s.qualivxKL2 = size(cols,2);
            qualCols = [ s.qual s.qualxKL s.qualxKL2 ];
            qualIvCols = [ s.qualiv s.qualivxKL s.qualivxKL2];
        case 5
            cols = [cols cols(:,s.qual).*cols(:,s.for_profit) cols(:,s.qual).*cols(:,s.davita) cols(:,s.qual).*cols(:,s.fresenius)];
            cols = [cols cols(:,s.qualiv).*(cols(:,s.for_profit)) cols(:,s.qualiv).*(cols(:,s.davita)) cols(:,s.qualiv).*(cols(:,s.fresenius))];
            s.qualxfp = size(cols,2) -5;
            s.qualxdavita = size(cols,2)-4;
            s.qualxfres = size(cols,2)-3;
            s.qualivxfp = size(cols,2) -2;
            s.qualivxdavita = size(cols,2)-1;
            s.qualivxfres = size(cols,2);
            qualCols = [ s.qual s.qualxfp s.qualxdavita s.qualxfres];
            qualIvCols = [s.qualiv s.qualivxfp s.qualivxdavita s.qualivxfres];
            
        otherwise
            fprintf('mainEst: unrecognized op.qual flag.\n');
            return;
    end 
    
    %Not the best way to not instrument for speed reasons but it works. 
    if op.iv == 0
        qualIvCols = qualCols;
    end
    
    %Now cull observations for the first stage, 
    %We will eliminate observations that we can't handle for any of three
    %reasons
    % 1. Hiring is zero, so hiring is not invertiable. 
    % 2. Investment is non-zero, we have to use fixed investment level
    % 3. We are missing data from the "x" variable for this observation.
    cnz = cols(cols(:,s.lhires) ~= 0 & cols(:,s.invest) == 0 & all(~isnan(cols(:,[xCts xDisc qualCols qualIvCols])),2), :);
 
    %% First stage Estimation - recover alpha
    if op.statefe == 1
        [alpha_q, Phi_cnz, nqPhi_cnz] = opFirstLL(cnz, s.lpatient_years, [s.lhires s.lstations s.lstaff xCts], xDisc, qualCols, qualIvCols, s.state_code);
    else  
        [alpha_q, Phi_cnz, nqPhi_cnz] = opFirstLL(cnz, s.lpatient_years, [s.lhires s.lstations s.lstaff xCts], xDisc, qualCols, qualIvCols);
    end
    
    %These 3 lines convert Phi from the cnz size to cols size, then add Phi to cols. 
    Phi = convertToFull(Phi_cnz, cols, cnz, s);
    cols = [cols Phi];
    s.Phi = size(cols,2);
    
%    save('stateforopsecond');
    
    %% Second Stage Estimation - recover beta and g
    %Now do the second stage...also preps for ols and fe regressions.
    [b_us, xprod_fx  X, y, ids, mainFlag] = opSecond(cols, s, op.order, alpha_q, qualCols, omDisc, [], 0);
    %Note, first column of X is a constant..
    b_ols = (X'*X)\(X'*y);
    b_fe = fe_reg(y, X(:,2:end), ids);
     
    coeff_table = [ b_us b_ols(2:end) b_fe  ];
    
    %We can also do the no-quality production function easily:
    nqPhi = convertToFull(nqPhi_cnz, cols, cnz, s);
    cols(:,s.Phi) = nqPhi;
    [b_usnq, xprod_fx_usnq, X, y, ids, mainFlag] = opSecond(cols, s, op.order, [], [], omDisc,[],0);
    %Note, first column of X is a constant..
    b_ols = (X'*X)\(X'*y);
    b_fe = fe_reg(y, X(:,2:end), ids);
    coeff_table = [coeff_table  [nan(size(alpha_q,1),size(b_usnq,2)); b_usnq(2:end,:)] [nan(size(alpha_q,1),1); b_ols(2:end)] [nan(size(alpha_q,1),1); b_fe]];
    xprod_fx = [xprod_fx xprod_fx_usnq];
    
%    save('stateforqual');
    
    %% Final stage compute quality correlations
    %omega_hat = cols(:,s.lpatient_years) - alphaq*cols(:,s.qual) - betak*cols(:,s.lstations) - betal*cols(:,s.lstaff);
    %omega_lag = cols(s.for_id, omega_hat);
    
   

end

