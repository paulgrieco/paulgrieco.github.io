
%Setup script for dialysis estimation. 
clear;

% CSV import broke with upgrade to MATLAB 2012b
%data = importdata('prodEstData.csv');

%Adding state codes and other variables... 
data = importdata('prodEstData.csv');

%data = importdata('prodEstData_full.csv');

%Check ryan's new tight markets dummy doest mess up the file format...
%data = importdata('prodEstData_t.csv');

%
% XLSX import works but takes a long time...
%data = importdata('prodEstData.xlsx');
%
% So now I just have the data stored in a mat file...
%load prodEstData

% Order of polynomials for nonparametric functins:
op.order = 4;

%% Step 1: Read In Data

%First, grab the columns we need for this estimation
%grab_cols = [1:5 7 9 11 13 14 15 17 18 20:25 30];
%Just grab all columns, we use names anyway.
grab_cols = [1:length(data.colheaders)];
col_names = data.colheaders(grab_cols); 
cols = data.data(:, grab_cols);
[nTotObs nCols] = size(cols);

for v = 1:nCols
    %disp(sprintf('s.%s = %d;', col_names{v}, v));
    eval(sprintf('s.%s = %d;', col_names{v}, v));
end



%Cheat to check time since survey (31) or neph per capita (32), 
%as utility shifters by substituting them for inspection_rate:
%cols(:, s.inspection_rate) = data.data(:,32);

%% Set arguments

%Use instrument for quality,
op.iv =1;

%Use charachteristics for infection rate,
op.inf_char = 1;

%Include competition, for profit dummy in policy
op.comp = 1;
op.fp = 1;


%Quality in the first stage
% 0 - don't inlcude quality
% 1 - include quality as a level
% 2 - include quality with interactions ql and qk (colinearity, doesn't work well
% 3 - inculude quality with interaction q*(k-l) (works nice, more capital
%     intensive good. 
op.qual = 1;


%Include inspection rate in first stage:
op.inspect = 1;

%Include state fixed effects:
%Robustness check, very agresssive in terms of non-parameric estimator
%since it assumes state fes are not interacted with other variables,
%doesn't seem to affect results.
op.statefe = 0;


%% Now run the data clean, once for all the bootstrapped runs, and get coeffiicients

%Generate the data set where all needed variable are recorded.
cols = cleanCols(cols, s, op.iv, op.inf_char);

%Finally, let's create a dummy for positive hiring, we use this as a
%discrete type which makes sure that only positive hiring obsevatins
%estimate a postivie Phi and negative hiring observations are used to
%estimate a negative Phi:
%
%Note that since zeros are dropped anyway poshires=0 means negative hiring
cols = [cols cols(:,s.lhires)>0];
s.poshires = size(cols,2);
