function [coeffs, xprod_fx, X, y, ids, flag ] = opSecond(cols, s, order, alphaq, alphaCols, omDisc, pfCols, plotG)

   narginchk(8,8)
  
   


   %First let's get the sample right. 
   %want all observations whose lag productivity was estimated.
   lagcols = cols(~isnan(cols(:,s.Phi)), :);
   
   full_cols = nan( max(cols(:,s.for_id)) , size(cols, 2) );
   full_cols(cols(:,s.row_id),:) = cols;
   curcols = full_cols(lagcols(:,s.for_id),:);
   
   %disp(sprintf('The length of the data set before opSecond quality check is %d', size(curcols,1)));
   
   if isempty(pfCols);
       %If production function isn't specified, use Cobb-Douglass
       pfCols = [s.lstations s.lstaff];
   end
   
   %However, sometimes we don't have the quality measure in the forward
   %period, need to take out those observations.
   if ~isempty(alphaq)
      %First make sure quality coefficients match quality matrix...
      assert(size(alphaq,1) == size(alphaCols,2), 'opSecond: Dimension of alphaq inconsistent with alphaCols');
      %Take out observations that we can't compute quality index...
      % but didn't we already do this?  Yes, but then we re-expanded above
      % to get the forward lags correct. So this is redoing the same cut.
      lagcols(isnan(curcols(:,s.qual)), :) = [];
      curcols(isnan(curcols(:,s.qual)), :) = [];
      
      %
      %Alternative that requires observing Phi in current period.
      %yq_cur = curcols(:,s.Phi);
      yq_cur  = curcols(:, s.lpatient_years) - curcols(:, alphaCols)*alphaq;
   
      %Data set to spit for ols and fe...
      X = [ ones(size(curcols,1),1)  curcols(:,[ alphaCols pfCols]) ];
   
   else %No quality case:
      lagcols(isnan(curcols(:,s.lpatient_years)), :) = [];
      curcols(isnan(curcols(:,s.lpatient_years)), :) = [];
      yq_cur  = curcols(:, s.lpatient_years);
      X = [ ones(size(curcols,1),1) curcols(:, pfCols ) ];
      alphaq = []; %This is just so the coeff-table is constructed easily.
   end
   %Final assignments to return for ols and fixed effects...
   y = curcols(:,s.lpatient_years);
   ids = curcols(:,s.cms_code);

   %Items we need to evaluate objective funciton...
   KL_cur = curcols(:, pfCols );
   Phi_lag = lagcols(:, s.Phi);
   KL_lag  = lagcols(:, pfCols );
   
   dimPF = length(pfCols);
   
   beta = .2*ones(dimPF,1);
   %lb_beta = [0 0]';
   %ub_beta = [inf inf]';
   %disp(sprintf('The length of the data set after prep for GMM is is %d', size(yq_cur,1)));
   
    %Here we use the moments to estimate b_kl
    ktropts = optimset('Display','off');

% Used to use KNITRO but found that Nelder-Mead converges a bit more often,
% when both converge they agree.
%    [b_kl, fval, flag] = ktrlink(@(b) GMMObj(b, yq_cur, KL_cur, Phi_lag, KL_lag, eye(4), order), beta, ...
%        [],[],[],[],lb_beta,ub_beta,[],ktropts);

   %This portion of the code identifies types for the g function given
   %omDisc.  Generates typeID which is just an index number for each "type"
    discX = lagcols(:, omDisc);
    types = unique(discX, 'rows');
    numTypes = size(types, 1);
    typeID = zeros(size(lagcols,1),1);
    for t = 1:numTypes
      typematch = all( bsxfun(@eq, discX, types(t,:)), 2);
      typeID(typematch) = t;
    end
   
   %order = 6; 
    
   % g estimation no x controls:
   [b_kl_nogx, fval, flag] = fminsearch(@(b) GMMObj(b, yq_cur, KL_cur, Phi_lag, KL_lag, [], eye(2), order), beta, ktropts);
    
   %Nonparametric g estimation with discrete types:
   [b_kl_np, fval, flag] = fminsearch(@(b) GMMObj(b, yq_cur, KL_cur, Phi_lag, KL_lag, typeID, eye(2), order), beta, ktropts);
   [~, g_np] = GMMObj(b_kl_np, yq_cur, KL_cur, Phi_lag, KL_lag, typeID, eye(2), order);
   [G omega_mu omega_sig] = genBasis(Phi_lag - KL_lag*b_kl_np, order);
   omega_hats = G*g_np;
   
   if (size(omega_hats,2) ==4)
       xprod_fx_np = mean([omega_hats(:,2) - omega_hats(:,1) omega_hats(:,3) - omega_hats(:,1) omega_hats(:,4) - omega_hats(:,1)] )';
       xprod_fx_npstd = std([omega_hats(:,2) - omega_hats(:,1) omega_hats(:,3) - omega_hats(:,1) omega_hats(:,4) - omega_hats(:,1)] )';
   
       %Parametric version with dummy variables 
       typeX = [(typeID==2) (typeID==3) (typeID==4)];
       [b_kl_par, fval, flag] = fminsearch(@(b) GMMObjPara(b, yq_cur, KL_cur, Phi_lag, KL_lag, typeX, eye(2), order), beta, ktropts);
           
       [~, g_para] = GMMObjPara(b_kl_par, yq_cur, KL_cur, Phi_lag, KL_lag, typeX, eye(2), order);
       xprod_fx = [g_para(1:size(typeX,2)) xprod_fx_np xprod_fx_npstd];
   else
       %Unneeded when we aren't controling for firm type...
       %xprod_fx_np = [];
       %xprod_fx_npstd = [];
       %g_para = [];
       b_kl_par = [nan; nan];
       xprod_fx = [];
   end
   

   
   %Set to nan for the no-quality case.
   if isempty(alphaq)
       alphaq = nan;
   end
   
   
   coeffs = [ alphaq*ones(1,3) ; b_kl_nogx b_kl_par b_kl_np];
   

%%   
   if plotG
       std_axis = [-2.5:.1:2.5]';
       true_axis = std_axis*omega_sig + omega_mu;
       points = bsxfun(@power, std_axis, [0:order]);
       type_titles = {'Non-Profit', 'For-Profit', 'Fresenius', 'DaVita'};
       
       for t = 1:size(g_np,2)
           h(t) = plot(true_axis, points*g_np(:,t));
           hold all;
       end
       legend(h, type_titles, 0);
       axis([1 2.7 1 2.7]);
       xlabel('\omega_{t-1}');
       ylabel('g(.)');
   end
   
   %dlmwrite('statacheck.csv', curcols, 'delimiter', ',', 'precision', 6)
end