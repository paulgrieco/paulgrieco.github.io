%This script will bootstrap our primary results and save them to a file

clear;
diary('runFlexBoot.diary');

%Rely on runMainEst to set things up and do the main regression.
runFlexEst;


tic;
%% Now the actual bootstrap

%This is the highest CMS code, used for drawing firms
topCMS = max(cols(:,s.cms_code));

%This is the number of firms in our estimation, all firms have a unique, 
%id, but some are skipped because of earlier screening
numFirms = length(unique(cols(:,s.cms_code)));

B = 200;
b_table1_list = [];
b_xprodfx1_list = [];

ktrflag_list = [];

RandStream.setGlobalStream(RandStream('mt19937ar','seed',8342341));
%Setup pool, recently updated:
% Old code that is now deprecated:
%if matlabpool('size') == 0
%   matlabpool open
%end
poolobj = gcp('nocreate');
if isempty(poolobj)
    poolobj = parpool;
    fprintf('Created pool with %d workers', poolobj.NumWorkers);
else
    fprintf('Using existing pool of %d workers', poolobj.NumWorkers);
end



parfor b = 1:B
    %Draw the bootstrap sample
    bFirms = 0
    boot_cols = [];
    while bFirms < numFirms
        addCMS = ceil(rand()*topCMS);
        addCols = cols( cols(:,s.cms_code) == addCMS,:);
        if ~isempty(addCols)
            boot_cols = [boot_cols; addCols];
            bFirms = bFirms+1;
        end
    end
    
    
    %Evaluate
    [b_table1, b_xprodfx1] = mainEst(boot_cols, s, [s.inspection_rate s.time_since_survey], [s.poshires s.for_profit s.compLevel s.davita s.fresenius],...
    [s.for_profit s.davita s.fresenius], op);

    
    %Add to list
    b_table1_list = [ b_table1_list b_table1(:)];
    b_xprodfx1_list = [ b_xprodfx1_list b_xprodfx1(:) ];

end

%Shut down parallel pool:
%matlabpool close
delete(poolobj);

toc;

se_table1 = mean(bsxfun(@minus, b_table1_list, c_table1(:)).^2,2).^(1/2);
se_table1 = reshape(se_table1, size(c_table1));

se_xprodfx1 = mean(bsxfun(@minus, b_xprodfx1_list, c_xprodfx1(:)).^2,2).^(1/2);
se_xprodfx1 = reshape(se_xprodfx1, size(c_xprodfx1));


save bootFlexRes

diary('off');