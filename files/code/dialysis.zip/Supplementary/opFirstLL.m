function [alpha_q, Phi, nqPhi] = opFirstLL(cols, outputCol, ctsCols, discCols, linCols, ivCols, stateCol)
 
    %We need 4 to 6 arguments...
    narginchk(4, 7);
    
    
    %4 arguments: No quality data.
    %This handles the no-quality case. 
    if nargin==4
       [Phi badObs] = locLin(cols(:,outputCol), cols(:,ctsCols), cols(:, discCols));
       if sum(badObs)> 0
        Phi(badObs)=nan;
        nqPhi = Phi;
       end
       alpha_q = [];
       return;
    end
    
    %5 arguments: Quality without instrument.
    %This is NOT the fastest way to not instrument for quality but it is
    %accurate.
    if nargin==5
        ivCols = linCols;
    end
    
    %Dimention of alpha, make sure both linCols and ivCols are this lenght.
    dimA = numel(linCols);
    assert(dimA == numel(ivCols));
    
    yCols = [outputCol linCols ivCols];
    
    if nargin < 7
        [yxz_hat, badObs] = locLin(cols(:,yCols), cols(:,ctsCols), cols(:, discCols));
    else
        [yxz_hat, badObs] = locLin_state(cols(:,yCols), cols(:,ctsCols), cols(:, discCols), cols(:, stateCol));
    end
    
    %Unpack yxz_hat
    Ey_hat = yxz_hat(:,1);
    Ex_hat = yxz_hat(:,2:dimA+1);
    Ez_hat = yxz_hat(:,dimA+2:end);
    
    %Save the no-quality Phi, which is just the nonparametric regression...
    nqPhi = Ey_hat;
    nqPhi(badObs) = nan;
    
    useObs = ~badObs;
    nObs = sum(useObs);
    if (nObs < size(cols,1))
        fprintf('opFirstLL: Dropping %d observations due to failed rank condition.\n', sum(badObs));
    end
    
    %Recover alpha with an IV regresion. 
    y = cols(useObs,outputCol) - Ey_hat(useObs); 
    X = [ ones(nObs,1) cols(useObs,linCols) - Ex_hat(useObs,:) ];
    Z = [ ones(nObs,1) cols(useObs,ivCols) - Ez_hat(useObs,:) ];
    alpha = (Z'*X)\(Z'*y);
    alpha_q = alpha(2:end);
    
    if (nargout > 1)
        depPhi = cols(:,outputCol) - cols(:,linCols)*alpha_q;
        [Phi, badObs] = locLin(depPhi, cols(:,ctsCols), cols(:, discCols));

        if sum(badObs)> 0
            Phi(badObs)=nan;
        end
    end
end
