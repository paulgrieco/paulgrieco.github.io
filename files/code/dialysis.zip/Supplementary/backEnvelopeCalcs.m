
% This script does some back of the envelope post-estimation calculations,
% a subset of these calculations appear in the text of the manuscript. 

load bootRes
theta_hat = c_table1(:,1)

    [q qiv] = getQuality(cols, s, 1);
    cols = [cols q qiv];
    s.qual = size(cols,2)-1;
    s.qualiv = size(cols, 2);


%% These are the back of the envelope calculations for the conclusion. 

lab_prod = cols(:,s.patient_years)./exp(cols(:,s.lstaff));

X = [cols(:,[s.lhires]) lab_prod];
X_pos = X(X(:,1)>0,:);
X_neg = X(X(:,1)<0,:);

corr(X)

corr(X_pos)

corr(X_neg)

pos_v_neg = (mean(lab_prod(cols(:,s.hires)>0)) - mean(lab_prod(cols(:,s.hires)<0)))/ mean(lab_prod(cols(:,s.hires)<0));

%Now I want to think about the cost of saving one patient in terms of
%labor.

patients_infected = cols(:,s.patient_years).*(cols(:,s.infect_rate)/100);

delta_rate = ((100*(patients_infected-1))./cols(:,s.patient_years)) - cols(:,s.infect_rate); 

constraint_units = delta_rate*theta_hat(1);

lost_patient_years = -(exp(cols(:,s.lpatient_years)-constraint_units) - exp(cols(:,s.lpatient_years)));

labor_pct = constraint_units ./ theta_hat(3);

%additional_nurses = exp(cols(:,s.lstaff)).*labor_pct;

additional_nurses = exp(cols(:,s.lstaff)+labor_pct) - exp(cols(:,s.lstaff));

disp('* * * * * COST OF INFECTION CALCS * * * * * *');

cost_of_infection_patients = median(lost_patient_years)*[45 55]
cost_of_infection_nurse = median(additional_nurses)*[35 50]


%% Here we answer Ryan's question about productivity. 
disp('* * * * * PRODUCTIVITY DIFFERENCES FOR/NON PROFIT * * * * * *');
prod_model = cols(:,s.lpatient_years) - theta_hat(1)*cols(:,s.qual) - theta_hat(2)*cols(:,s.lstaff) - theta_hat(3)*cols(:,s.lstations);
lscov(prod_model, [ones(size(cols,1),1) cols(:,s.for_profit)])

theta_nq = [0 c_table1(2,6) c_table1(3,6)]
prod_nq = cols(:,s.lpatient_years) - theta_nq(1)*cols(:,s.qual) - theta_nq(2)*cols(:,s.lstaff) - theta_nq(3)*cols(:,s.lstations);
lscov(prod_nq, [ones(size(cols,1),1) cols(:,s.for_profit)])

%In summary, we find that the "bias" in productivity measurement is quite
%small. This is mostly because the correlation between productivity and
%quality is very small to begin with. Probably best not to make a big deal
%of it I guess. We still find that for-profits are much more productive
%thatn non-profits, even after controlling for quality.

%% Here I calculate elasticities of quality.

% We want the percent change in the number of patients for a percent change
% in quality (in terms of infections) 

disp('* * * * * ELASTICITY CALCS * * * * * *');

disp('Baseline: percentiles and average:');
pct_change_infections = .01*cols(:,s.infect_rate);
implied_change_y = theta_hat(1)*pct_change_infections;
elasticity = 100*implied_change_y;
prctile(elasticity, [10 25 50 75 90])
mean(elasticity)

disp('Flexible: percentiles and average:');
clear
load bootFlexRes
theta_hat = c_table1(:,1);
pct_change_infections = .01*cols(:,s.infect_rate);
implied_change_y = (theta_hat(1) + theta_hat(2)*cols(:,s.lstations) + theta_hat(3)*cols(:,s.lstaff)).*pct_change_infections;
elasticity = 100*implied_change_y;
prctile(elasticity, [10 25 50 75 90])
mean(elasticity)
