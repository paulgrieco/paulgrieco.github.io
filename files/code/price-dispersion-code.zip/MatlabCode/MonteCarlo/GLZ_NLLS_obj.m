% Compute the distance between the left and right hand sides of the
% estimation equation.

function GLZ_NLLS_obj = GLZ_NLLS_obj(g, data)

ita = g(1);
gamma = (g(2) - 1)/g(2);

constant = (ita/(1 + ita));
TC = data.labor_cost + data.material_cost; % total variable cost

% GLZ_NLLS_obj = exp(data.log_R)./TC - constant*( 1+ g(3).*((data.capital_norm./data.labor_norm).^gamma)./data.value_ratio);

GLZ_NLLS_obj = data.log_R - log(TC) - log(constant) - log( 1+ g(3).*((data.capital_norm./data.labor_norm).^gamma)./data.value_ratio);

