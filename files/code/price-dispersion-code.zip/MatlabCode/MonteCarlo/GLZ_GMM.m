% Main function of GLZ's method used in Monte Carlo experiments;
% This demonstration uses GMM.
% Specification: CES.


function GLZ_GMM_res = GLZ_GMM(sigma0,newData) % do not need input, output is a set of estimates and standard errors.
%% generate new data or use the old one
if newData == 1 % if it is 1 then generate new data, otherwise use old one
    data = getData(sigma0);
else
    load data_ready_mc.mat
end

%% Employ GLZ method using GMM:
% inital guess (in principle it can be arbitrary), here we use the one not
% far awary from the true value.
para_guess = .9*[log(data.ita0/(1 + data.ita0)), data.aL0, data.aM0, data.aK0, (data.sigma0-1)/data.sigma0]; % initial guess
data.W = 1*eye(length(para_guess)); % this is the weight matrix. It also appears in check_deriv.m

% use Gauss-Newton method to find a better starting value
GaussNewt_res = GaussNewt(para_guess, data);

% use fminsearch to find the min of the objective function as the estimate.
myoptions = optimset('TolFun',1e-15,'TolX',1e-15,'MaxIter',10000,'Display','off','MaxFunEvals',10000);
para_bar_search = fminsearch(@(x) GLZ_GMM_obj(x, data),GaussNewt_res,myoptions); 

% this is the estimate of the normalized distribution parameters 
% and re-defined parameters (i.e., cons = log(ita/(ita+1)) and gamma = (sigma-1)/sigma)
para_bar_est = para_bar_search; 

%% use estimated normalized parameters to recover the parameters of interest;
% and Compute standard error of parameters of interest using "delta method"
[para_rec, se, ~] = getEst(para_bar_est,data);

ita = para_rec(1);
aL = para_rec(2);
aM = para_rec(3);
aK = para_rec(4);
sigma = para_rec(5);

ita_se = se(1);
aL_se = se(2);
aM_se = se(3);
aK_se = se(4);
sigma_se = se(5);

%% Display the results
GMM_est = [ita; aL; aM; aK; sigma]';
GMM_sd = [ita_se;  aL_se; aM_se; aK_se; sigma_se]';

% disp('   d-elast |    aL    |   aM    |   aK    |   elast_sub');
% disp([ita, aL, aM, aK, sigma]);
% disp([ita_se, aL_se, aM_se, aK_se, sigma_se]);

GLZ_GMM_res = [GMM_est,GMM_sd];