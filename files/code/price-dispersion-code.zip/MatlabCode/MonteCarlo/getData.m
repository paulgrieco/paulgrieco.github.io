% this function generate data and save the useful observations in the structure called data.
% the structure data will be pass around.

% This is to simulate the data set for the Monte Carlo experiment
% Main function of DGP

% Function form: CES. Specifications: sigma0 = .8, 1.5, or 2.5, passed as
% input.
% Other parameters keep the same.
% Input prices are simulated exogenously with dispersion
% Evolution of productivity is AR(1)
% Investment is a function of productivity and capital stock
% Firm-level input is the optimal choice given prices, productivity, and captial stock


function data = getData(sigma0) 
%% simulate data set for estimation

% Data panel: 100 frims, 10 years
J = 100;
T = 10;

%% Setup true parameters
aL0 = .4; % distribution parameters, non-normalized (original).
aM0 = .4;
aK0 = .2;
%sigma0 = 1.5; % elasticity of substitution, use the parameter of the function input
gamma0 = (sigma0 - 1)/sigma0; % as a function of simga
ita0 = -4; % demand elasticity

g00 = .2; % parameters for markov process of productivity
g10 = .95;

h0 = .2; % parameter for investment decision

sigmaPL = .2; % dispersion of input price: wage rate
sigmaPM = .2; % dispersion of input price: material price

%% generate input prices: to make sure prices are postive, generate in log form then take exp.
rng('default');
rng(1);
logPL = randn(T,J)*sigmaPL;
rng(2);
logPM = randn(T,J)*sigmaPM;

PL = exp(reshape(logPL,[],1))/10; % Input prices 
PM = exp(reshape(logPM,[],1))/10;

%% generate productivity
sigmaW = 0.01; % dispersion of unexpected productivity shock
rng('shuffle')
epsW = randn(T,J)*sigmaW; % unexpected productivity shock

rng('shuffle')
W0 = randn(1,J)*.05 + .5; % initial productivity for all J firms

W = zeros(T,J); % productivity: omega
W(1,:) = W0;
for i = 2:T
    W(i,:) = g00 + g10*W(i-1,:) + epsW(i,:); % evolution of productivity
end
prod = exp(reshape(W,[],1)); % exp of omega (productivity)

%% generate investment and capital stock
logI = zeros(T,J); 

rng('shuffle')
logK0 = randn(1,J)*.05 + 6;  % initial log capital for all J firms
K = zeros(T,J);
K(1,:) = exp(logK0);

logI(1,:) = ( h0*W(1,:) + (1-h0)*log(K(1,:)) )/2; % investment decision

for i = 2:T
    K(i,:) = exp(logI(i-1,:)) + K(i-1,:);
    logI(i,:) = ( h0*W(i,:) + (1-h0)*log(K(i,:)) )/2;
end
I = exp(reshape(logI,[],1)); % investment is defined as exponential of logI
K = (reshape(K,[],1)); % exponential of logK

%% generate firm's optimal input and output choices
% In terms of optimal choices, there is no difference in using normalized
% or non-normalized production function.
% Here we use non-normalized production function. That is, normalization point can be viewed as (1,1,1,1)
% in this case, normalized distribution parameters, e.g. aL_bar, are equal to
% the original parameters.
L_0 = 1;
M_0 = 1;
K_0 = 1;
prod_0 = 1;
Q_0 = 1;
aL0_bar = aL0;
aM0_bar = aM0;
aK0_bar = aK0;

allA = ((ita0 + 1)/ita0);
allS = (L_0/M_0)*PL.*((PL*L_0*aM0_bar./(PM*M_0*aL0_bar)).^(1/(gamma0 - 1))) + PM;
allB = (aM0_bar + aL0_bar*(PL*L_0*aM0_bar./(PM*M_0*aL0_bar)).^(gamma0/(gamma0 - 1))).^(1/gamma0);
allC = aK0_bar*((K/K_0).^gamma0);

m.allD = (allA.*allB.*prod*Q_0)./allS;
m.allE = allC.*((prod*Q_0).^gamma0);
m.ita0 = ita0;
m.gamma0 = gamma0;

Q_guess = 10000*ones(T*J,1);

options = optimset('TolFun',1e-10,'TolX',1e-10,'MaxIter',200,'Display','off','MaxFunEvals',10000000);
[Q,funval, exitflag] = fsolve(@(x) Q_opt(x,m),Q_guess,options); 
Q = real(Q);

M = (((Q./(prod*Q_0)).^gamma0 - allC).^(1/gamma0))./allB; % optimal material quantity choice
L = ((PL*L_0*aM0_bar./(PM*M_0*aL0_bar)).^(1/(gamma0 - 1))).*(M*L_0/M_0); % optimal labor quantity choice

%% generate output price and quantity
% true output quantity and price:
Q_true = Q; % Quantity without measurement error
P = Q.^(1/ita0); % output price is determined by demand function
P_true = P; % record the true output price
R_true = P_true.*Q_true; % record the true revenue (without any measurement error)

% Output quantity with measurement error -- used to contruct revenue with
% measurement error.
rng('shuffle')
epsQ = reshape(randn(T,J)*.01,[],1); 
Q = exp(epsQ).*Q; % with unexpected shock or measurement error

%% Construct commonly available firm-level data set (as defined in the paper)
prod_value = P.*Q;
labor_cost = L.*PL;
material_cost = M.*PM;
profit = prod_value - labor_cost - material_cost; % just check if > 0 or not

% Change names and save
pid = ones(T,1); % define plant/firm id. Same firm with the same id is ordered from period 1 to T.
pid_0 = pid;
for i = 2:J
    pid_0 = [pid_0;i*pid];
end
labor = L;
capital = K;
log_invest = log(I);
log_capital = log(K);

log_R=log(prod_value);
log_L=log(labor);
value_ratio=(labor_cost+material_cost)./labor_cost;
quan_ratio=capital./labor;

%% save the useful observations in the structure called data
% true parameters
data.ita0 = ita0;
data.aL0 = aL0;
data.aM0 = aM0;
data.aK0 = aK0;
data.sigma0 = sigma0;

data.nObs = T*J; % number of observations
data.log_R = log_R;
data.log_L = log_L;
data.labor = labor;
data.capital = capital;
data.labor_cost = labor_cost;
data.material_cost = material_cost;
data.value_ratio = value_ratio;
data.quan_ratio = quan_ratio;
data.log_value_ratio = log(value_ratio);
data.log_labor_cost = log(labor_cost);
data.log_capital = log(capital);
data.pid_0 = pid_0; % plant/firm id

%% Construct normalized data
data.log_R_norm = data.log_R - mean(log_R);
data.labor_norm = exp(log_L - mean(log_L));
data.labor_cost_norm = exp(log(labor_cost) - mean(log(labor_cost)));
data.capital_norm = exp(log_capital - mean(log_capital));
data.log_capital_norm = data.log_capital - mean(log_capital);
data.log_invest_norm = log_invest - mean(log_invest);
data.log_material_cost_norm = log(material_cost) - mean(log(material_cost));
data.log_labor_cost_norm = log(labor_cost) - mean(log(labor_cost));
data.log_labor_norm = log(labor) - mean(log(labor));
data.ratio = data.labor_norm./data.capital_norm;

% Normalization point: geometric means
data.material_cost_avg = exp(mean(log(material_cost)));
data.labor_cost_avg = exp(mean(log(labor_cost)));
data.labor_avg = exp(mean(log(labor)));
data.capital_avg = exp(mean(log(capital)));
data.material_avg = exp(mean(log(M))); 

save data_ready_mc



