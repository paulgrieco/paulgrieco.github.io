% this function computes the standard errors 
% as well as the variance matrix of the GMM estimator


function [se_bar var_bar_mat] = getSe_bar(g,data)

[~, ~, ~, Devi, mom_matrix]= GLZ_GMM_obj(g,data); 
% note that Devi is timed by nObs in GLZ_GMM_obj
% but mom_matrix is not.
D = Devi/data.nObs;
V = mom_matrix*mom_matrix'/data.nObs; 

var_bar_mat = (D'*D)^(-1) * (D'*V*D) * (D'*D)^(-1) / data.nObs;

se_bar = diag(var_bar_mat).^.5;



