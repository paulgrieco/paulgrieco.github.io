% This is the master script for the Monte Carlo experiment.

%% Monte Carlo experiment to check the performance of GLZ's method using GMM estimate
clear all
clc
sigma0 = 0.8; % sigma0 is the true elasticity of substitution. It takes three value: .8, 1.5, 2.5 in the paper.

MM = 1000; % # of replications
results.our = []; % store results

% Replications
for i = 1:MM
    fprintf('Conducting replication %u of %u ... \n', i, MM)
    GLZ_GMM_res = GLZ_GMM(sigma0,1); % the second input is to indicate "generate new data", set it to 0 if need to use the old saved data. 
    results.our = [results.our; GLZ_GMM_res]; % GLZ_mc does not require an input of parameter
    save results
end

% take avarage (or median)
results.our_avg = mean(real(results.our)); 
results.our_var = std(real(results.our));

% Present result by our_show
our_show = [];
for i = 1: 10
   our_show =  [our_show; results.our_avg(i); results.our_var(i)];
end

save results

