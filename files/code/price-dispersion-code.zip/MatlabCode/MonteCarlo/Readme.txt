This is the readme file of Monte Carlo experiment code using GLZ's method 
for CES specification.  This code serves three purposes. First, it is a 
demonstration of how GLZ's method is implemented in CES specification via a
GMM-based estimation. Second, it also shows how GLZ's method can be implemented
via a nonlinear least square estimation with constraints, and verifies that 
the two implementations are equivalent. Third, it conducts Monte Carlo experiment
to check the performance of GLZ's method via the GMM-based estimation. We briefly 
explain the files in this folder as follows.

1. main_mc: it is the master function of Monte Carlo.

2. GLZ_GMM.m: it is the main function of GLZ's method used in Monte Carlo experiments.
This is the demonstration of GLZ using GMM.

3. GLZ_GMM_obj.m: objective function of GLZ_GMM.m.

4. GaussNewt.m: it uses Gauss-Newton method (iteration) to find a solution of 
the GMM problem. Theoretically, iterations lead to the solution but it can be 
fairly slow. So we use it to find a starting point for fminsearch that is close
to the solution (the GMM estimate).

5. getEst.m: it a) uses estimated normalized parameters to recover the 
parameters of interest; b) uses the delta method to compute the standard error 
of parameters of interest.

6. getSe_bar.m: it computes the standard errors as well as the variance 
matrix of the GMM estimator that is used in the delta method.

7. GLZ_NLLS.m: it is the demonstration of GLZ using nonlinear least square estimation.

8. GLZ_NLLS_obj.m: objective function of GLZ_NLLS.m.

9. GMM_NLLS_cmp.m: It verifies the equivalence of the two implementations, 
GMM and NLLS, by a number of simulations.

10. getData.m: generates data that is used for estimation, including solving 
the firm's problem of choosing labor and material quantity. 

11. Q_opt.m: objective function of the firm's optimization problem.

12. check_deriv.m: it checks the analitical derivatives of the objective function
with respective to all parameters. This is not a part of the Monte Carlo experiment
but just to check our user-supplied derivatives are correct.