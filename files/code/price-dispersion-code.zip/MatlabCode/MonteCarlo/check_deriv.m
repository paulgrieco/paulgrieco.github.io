% this function conducts Derivative Check
% partial derivative check added: Devi, numDevi
% bug fixed at m1_constant

function [max_diff, diff_grad, grad, numgrad, Devi, numDevi] = check_deriv(para_bar,data)

    data.W = 1*eye(length(para_bar)); %  the weight matrix may be not constructed in data structure, so add it here.
    [GMM_obj, grad, mom, Devi, ~] = GLZ_GMM_obj(para_bar, data);
   
    eps=1e-10;    
    numgrad = zeros(1,length(para_bar));

    for i=1:length(para_bar)

        para_bar_new = para_bar;
        para_bar_new(i) = para_bar(i)+eps;

        [GMM_obj_new, ~, mom_new, ~, ~] = GLZ_GMM_obj(para_bar_new, data);
        numgrad(i) = (GMM_obj_new- GMM_obj)/eps;
        numDevi(:,i) = data.nObs*(mom_new- mom)/eps;
        

    end
     
    diff_grad = abs((grad  - numgrad)./numgrad);
    max_diff = max(max(diff_grad));
    if max_diff > 1e-4

        fprintf('Error: Derivative Check did not pass');

        return

    end
    
end