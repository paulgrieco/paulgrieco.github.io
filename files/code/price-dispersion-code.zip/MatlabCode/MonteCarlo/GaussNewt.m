% This function uses the Guass-Newton method to find a better starting value of
% the estimation.
% In principle, this method can find the min of the objective function of
% GMM but it takes long time. So we only use it to find a good starting
% value which is used as inital guess in fminsearch.

% Some debug features still remain, in purpose.

function GaussNewt_res = GaussNewt(para_guess, data)
%% Now start the Gauss-Newton method
max_iter = 100000; 
n_report = 50; % report the status n_report times, used in n_status
n_status = ceil(max_iter/n_report); 

para = [];
para(1,:) = para_guess;

W = data.W;
tol = 1e-10; % set it to a lower value for more accuracy if fminsearch does not converage, but this step takes longer time.
adj_count = 0; % pinv may not handle the convergency well. So add this to count how many times the matrix (G'*W*G) is badly conditioned and pinv is used.
adj_count_max = 30; % this is the max of using pinv.

% Gauss-Newton iteration
for t=2:max_iter
    
    [~, ~, mom, Devi] = GLZ_GMM_obj(para(t-1,:),data);
    G = - Devi;
    v = mom' + G*para(t-1,:)';
    
    if rcond((G'*W*G)) < 1e-20
        para(t,:) = rand(5,1); % if the matrix is really badly conditioned, start over
        % fprintf('Warning: matrix is badly conditioned, iteration has started over! \n')
        
    elseif rcond((G'*W*G)) < 1e-15 & rcond((G'*W*G)) >= 1e-20
        if adj_count <= adj_count_max
            para(t,:) = real( pinv(G'*W*G)*G'*W*v )'; % if the matrix is badly conditioned, use pinv 
            % fprintf('Warning: matrix is badly conditioned, pinv used! \n')
            adj_count = adj_count + 1;
        else
            para(t,:) = rand(5,1); % if the matrix is badly conditioned in too many interations, start over
            % fprintf('Warning: matrix is badly conditioned in too many interations, iteration has started over! \n')
            adj_count = 0; % reset the counter if it starts over.
        end

    else
        para(t,:) = real( (G'*W*G)\G'*W*v )';
        
        % If we just do the above, parameters become negative and then we
        % take the log of them.  
        % So We need to set a bound for the parameters.
        % since the last parameter gamma can be negative, so we focus on
        % the other 4 parameters.
        % In particular, the following statement is a kludge to enforce
        % that the parameters must be positive. It works reasonably well,
        % but could probably be improved.
        if min(para(t,1:4)) <= 0.01 | min(para(t,2:4)) >= 1 
            lambda = .2; % the weight to put on the "starting over" guess. This value can be adjusted. 
            ita_adj = para(t,1) .* (para(t,1) > 0.01) + rand(1,1) .* (para(t,1) <= 0.01);
            alpha_adj = para(t,2:4) .* (para(t,2:4) > 0.01).*(para(t,2:4) < 1) + rand(1,3) .* (para(t,2:4) > 1) + rand(1,3) .* (para(t,2:4) <= 0.01);
            para(t,:) = (1-lambda)*para(t-1,:) + lambda*[ita_adj, alpha_adj, para(t,5)];
        end
    end
    
    % if para (t,:) still has imag part then start over from a random new point.
        if isreal(para(t,:)) == 0
            para(t,:) = rand(5,1);
            % fprintf('Warning: parameters still have imag part, iteration has started over! \n')
        end

    D_max = max(abs(para(t,:) - para(t-1,:)));
    if  D_max < tol
        % fprintf('Gauss-Newton Iteration stopped because targeted accuracy achieved: %e \n', tol)
        break
    end
    
    % this is just for debug, check the convergency
    if mod(t,n_status) == 0
         para(t,:); 
    end
        
end

if  D_max > tol
        fprintf('Warning: Targeted accuracy not achieved! Current: %e. Increase max #iterations! \n', D_max)
end

GaussNewt_res = para(end,:);