% This is the objective function of the GMM. It returns gradients wrt to
% all parameters as well.

% In addition, moment_all is the analog of the moment conditions (i.e., expectation);
% mom_matrix is a 5 by T*J matrix consists of the moment conditions 
% evaluated at every individual data point. It is used to compute standard
% errors of the estimates.

function [GMM_obj, GMM_grad, moment_all, Devi, mom_matrix]= GLZ_GMM_obj(para_bar, data)

constant = para_bar(1); % Note: constant = log(ita/(1 + ita));
aL = para_bar(2);
aM = para_bar(3);
aK = para_bar(4);
gamma = para_bar(5); % Note: gamma = (sigma - 1)/sigma;

%% compute objective function
inValue  =  data.material_cost + data.labor_cost.*(1+aK/aL * (data.capital_norm./data.labor_norm).^gamma);
diff = data.log_R - constant - log(inValue);

deriv_constant= 1;
moment_constant = sum(deriv_constant.*diff)/data.nObs;
mom_matrix(1,:) = (deriv_constant.*diff)';

deriv_aK = 1/aL * data.labor_cost .* (data.capital_norm./data.labor_norm).^gamma ./inValue;
moment_aK = sum(deriv_aK.*diff)/data.nObs;
mom_matrix(2,:) = (deriv_aK.*diff)';

deriv_gamma = aK/aL * data.labor_cost .* (data.capital_norm./data.labor_norm).^gamma .* log(data.capital_norm./data.labor_norm)./inValue;
moment_gamma = sum(deriv_gamma.*diff)/data.nObs;
mom_matrix(3,:) = (deriv_gamma.*diff)';

moment_restr_1 = aL * data.material_cost_avg - aM * data.labor_cost_avg;
mom_matrix(4,:) = moment_restr_1 * ones(1,data.nObs);

moment_restr_2 = aL + aM + aK - 1;
mom_matrix(5,:) = moment_restr_2 * ones(1,data.nObs);

moment_all = [moment_constant, moment_aK, moment_gamma, moment_restr_1, moment_restr_2];

GMM_obj = moment_all * data.W * moment_all'*data.nObs;

%% compute gradient of GMM
% define some value that is commonly used.
ratio_power = (data.capital_norm./data.labor_norm).^gamma;
log_ratio = log(data.capital_norm./data.labor_norm);
deriv_aL = - aK/(aL^2) * data.labor_cost .* (data.capital_norm./data.labor_norm).^gamma ./inValue;
inValue_deriv_aL = - aK/(aL^2) * data.labor_cost .* (data.capital_norm./data.labor_norm).^gamma;
inValue_deriv_aK = 1/aL * data.labor_cost .* (data.capital_norm./data.labor_norm).^gamma;
inValue_deriv_gamma = aK/aL * data.labor_cost .* ratio_power .* log_ratio;

% partial derivative wrt constand
m1_constant_inSum =  - deriv_constant;
m1_constant= (m1_constant_inSum); % note that since deriv_constant is a constant (1), so not need to summed or divided 

m2_constant_inSum = data.labor_cost/aL .* ratio_power .* (-1./inValue) .* deriv_constant;
m2_constant = sum(m2_constant_inSum)/data.nObs;

m3_constant_inSum = data.labor_cost .* aK/aL .* log_ratio .* ratio_power .* (-1./inValue) .* deriv_constant;
m3_constant = sum(m3_constant_inSum)/data.nObs;

m4_constant = 0;
m5_constant = 0;

% partial derivative wrt aL
m1_aL_inSum = - deriv_aL;
m1_aL = sum(m1_aL_inSum)/data.nObs;

m2_aL_inSum_part = -1/(aL^2) .* 1./inValue .* diff - 1/aL .* inValue_deriv_aL ./inValue.^2 .* diff - 1/aL .* 1./inValue .* deriv_aL;
m2_aL_inSum = data.labor_cost .* ratio_power .* m2_aL_inSum_part;
m2_aL = sum(m2_aL_inSum)/data.nObs;

m3_aL_inSum = aK * data.labor_cost .* log_ratio .* ratio_power .* m2_aL_inSum_part;
m3_aL = sum(m3_aL_inSum)/data.nObs;

m4_aL = data.material_cost_avg;
m5_aL = 1;

% partial derivative wrt aM
m1_aM = 0;
m2_aM = 0;
m3_aM = 0;
m4_aM = - data.labor_cost_avg;
m5_aM = 1;

% partial derivative wrt aK
m1_aK_inSum = - deriv_aK;
m1_aK = sum(m1_aK_inSum)/data.nObs;

m2_aK_inSum_part = - inValue_deriv_aK .* 1./inValue.^2 .* diff - deriv_aK ./ inValue;
m2_aK_inSum = data.labor_cost ./ aL .* ratio_power .* m2_aK_inSum_part;
m2_aK = sum(m2_aK_inSum)/data.nObs;

m3_aK_inSum_part = 1./inValue .* diff - aK * inValue_deriv_aK .* 1./inValue.^2 .* diff - aK * deriv_aK ./ inValue;
m3_aK_inSum = data.labor_cost ./ aL .* log_ratio .* ratio_power .* m3_aK_inSum_part;
m3_aK = sum(m3_aK_inSum)/data.nObs;

m4_aK = 0;
m5_aK = 1;

% partial derivative wrt sigma
m1_gamma_inSum = - deriv_gamma;
m1_gamma = sum(m1_gamma_inSum)/data.nObs;

m2_gamma_inSum_part = log_ratio .*  ratio_power ./ inValue .* diff - ratio_power .* inValue_deriv_gamma ./ inValue.^2 .* diff - ratio_power ./ inValue .* deriv_gamma;
m2_gamma_inSum = data.labor_cost ./ aL .* m2_gamma_inSum_part;
m2_gamma = sum(m2_gamma_inSum)/data.nObs;

m3_gamma_inSum_part = log_ratio .*  ratio_power ./ inValue .* diff ...
    - ratio_power ./ inValue.^2 .* inValue_deriv_gamma .* diff ...
    - ratio_power ./ inValue .* deriv_gamma;
m3_gamma_inSum = aK ./ aL .* data.labor_cost .* log_ratio.* m3_gamma_inSum_part;
m3_gamma = sum(m3_gamma_inSum)/data.nObs;

m4_gamma = 0;
m5_gamma = 0;

% Now construct the Devi matrix to be used in gradient
Devi = data.nObs*[m1_constant m1_aL m1_aM m1_aK m1_gamma;
        m2_constant m2_aL m2_aM m2_aK m2_gamma;
        m3_constant m3_aL m3_aM m3_aK m3_gamma;
        m4_constant m4_aL m4_aM m4_aK m4_gamma;
        m5_constant m5_aL m5_aM m5_aK m5_gamma;
        ];
    
GMM_grad = 2 * moment_all * data.W * Devi;   

