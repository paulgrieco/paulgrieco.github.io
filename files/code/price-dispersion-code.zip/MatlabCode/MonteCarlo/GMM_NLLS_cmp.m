% This script tests the consistency of GMM and NLLS, via Monte Carlo method

clc
clear

NN = 100;
n_cons = 0;
sigma0 = .8; % sigma0 is the true elasticity of substitution. It takes three value: .8, 1.5, 2.5 in the paper.

% Replications
for i = 1:NN
    [GLZ_NLLS_res, cons_ind, max_diff] = GLZ_NLLS(sigma0,1); % the second input indicates whether to compare the NLLS estimate with GMM estimate
    n_cons = n_cons + cons_ind;
    fprintf('%u out of %u is consistent. \n', n_cons, i)     
end

save GMM_NLLS_compare_result