% used to solve for the optimal input choices (which are written as
% functions of output quantity).
% q stands for quantity of output.

function Q_opt = Q_opt(q,m)

% global m

Q_opt = m.allD.*(q.^(1/m.ita0)) - (1 - m.allE.*(q.^(-m.gamma0))).^(1/m.gamma0 - 1);