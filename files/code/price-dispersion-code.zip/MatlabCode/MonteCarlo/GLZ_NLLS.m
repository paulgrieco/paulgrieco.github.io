% Main function of GLZ's method, implemented in NLLS.
% Added feature: compare the result using NLLS with GMM.
% Specification: CES.


function [GLZ_NLLS_res, cons_ind, max_diff] = GLZ_NLLS(sigma0,compGMM) % do not need input, output is a set of estimates and standard errors.
%% Employ GLZ method using NLLS:
% inital guess (in principle it can be arbitrary), here we use the one not
% far awary from the true value.
if  compGMM == 1% if it is 1, then first estimate via GMM and then compare it with NLLS estimate.
    GMM_est = GLZ_GMM(sigma0,1); 
    load data_ready_mc.mat
    para_guess = 1.5*[GMM_est(1), GMM_est(5), GMM_est(4)/GMM_est(2)];
else  % if it is 0 then use another (or arbitary) starting value
    data = getData(sigma0); % generate new data
    para_guess = 1.5*[data.ita0, sigma0, data.aK0/data.aL0]; % initial guess, the last parameter is tau = aK_bar/aL_bar
end

myoptions = optimset('Tolfun',1e-15, 'TolX',1e-15,'MaxIter',1000,'Display','off','MaxFunEvals',10000);
[para_est,resnorm,residual,exitflag,output,lambda,jacobian] = lsqnonlin(@(x) GLZ_NLLS_obj(x,data),para_guess,[], [], myoptions);
% Compute standard errors
se = sqrt(resnorm*diag(full((jacobian'*jacobian)^-1))/length(residual));

% estimate and se
ita = para_est(1);
sigma = para_est(2);
tau = para_est(3);
gamma = (sigma-1)/sigma;

%% Recover all relevant parameters 
% Recover normalized (CES function) form, using normalization point to
% calculate:
material_cost_avg = data.material_cost_avg;
labor_cost_avg = data.labor_cost_avg;
labor_avg = data.labor_avg;
capital_avg = data.capital_avg;
material_avg = data.material_avg;

% Recover parameters for original (CES function) form:
mu = tau*labor_cost_avg/(capital_avg^gamma*(labor_cost_avg/(labor_avg^gamma) + material_cost_avg/(material_avg^gamma)));

aL = (1/(mu+1))*(labor_cost_avg/(labor_avg^gamma))/(labor_cost_avg/(labor_avg^gamma) + material_cost_avg/(material_avg^gamma));
aM = (material_cost_avg/(material_avg^gamma))/(labor_cost_avg/(labor_avg^gamma))*aL;
aK = 1 - aL - aM;

%% Display the results
NLLS_est = [ita; aL; aM; aK; sigma]';

% disp('   d-elast |    aL    |   aM    |   aK    |   elast_sub');
% disp([ita, aL, aM, aK, sigma]);

%% Compare with GMM
if  compGMM == 1% if it is 1, then first estimate via GMM and then compare it with NLLS estimate.
    max_diff = max( abs( (GMM_est(1:5) - NLLS_est)./GMM_est(1:5) ) );
    if max_diff < 1e-4
        fprintf('Consistent, max_diff = %e. \n', max_diff)
        cons_ind = 1; % consistency indicator
    else
        fprintf('Warning: Two estimates are NOT consistent, max_diff = %e. \n', max_diff)
        cons_ind = 0;
    end
end

GLZ_NLLS_res = NLLS_est;
