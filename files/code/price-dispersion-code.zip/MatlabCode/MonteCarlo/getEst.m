% This function:
% 1) use estimated normalized parameters to recover the parameters of interest;
% 2) use "delta method" to compute the standard error of parameters of
% interest.

function [para_est, se, var_mat] = getEst(para_bar,data)

%% load input of the function
cons = para_bar(1); % cons = log(ita/(ita+1))
aL_bar = para_bar(2);
aM_bar = para_bar(3);
aK_bar = para_bar(4);
gamma = para_bar(5);
 
%% recover the parameters of interest
material_cost_avg = data.material_cost_avg;
labor_cost_avg = data.labor_cost_avg;
labor_avg = data.labor_avg;
capital_avg = data.capital_avg;
material_avg = data.material_avg; 

tau = aK_bar/aL_bar;
ita = exp(cons)./(1-exp(cons));
aL = (labor_cost_avg/(labor_avg^gamma))/(labor_cost_avg/(labor_avg^gamma) + material_cost_avg/(material_avg^gamma) + tau*labor_cost_avg/(capital_avg^gamma));
aM = (material_cost_avg/(material_avg^gamma))/(labor_cost_avg/(labor_avg^gamma) + material_cost_avg/(material_avg^gamma) + tau*labor_cost_avg/(capital_avg^gamma));
aK = 1 - aL - aM;
sigma = 1/(1-gamma);

para_est = [ita, aL, aM, aK, sigma];

%% use "delta method" to compute the standard error of parameters of interest
% first get the standard errors for the estimates of normalized parameters.
[~, var_mat_bar] = getSe_bar(para_bar,data);

% now use var_mat_bar to compute the standard error of parameters of interest
denorm = labor_cost_avg/(labor_avg^gamma) + material_cost_avg/(material_avg^gamma) + tau*labor_cost_avg/(capital_avg^gamma);
denorm_aL_bar = - (aK_bar/aL_bar^2)*labor_cost_avg/(capital_avg^gamma);
denorm_aK_bar = 1/aL_bar*labor_cost_avg/(capital_avg^gamma);
denorm_gamma = - log(labor_avg)*labor_cost_avg/(labor_avg^gamma) - log(material_avg)* material_cost_avg/(material_avg^gamma) - log(capital_avg)*tau*labor_cost_avg/(capital_avg^gamma);

D1_cons = - exp(cons)/(1-exp(cons))^2;
D1_aL_bar = 0; 
D1_aM_bar = 0;
D1_aK_bar = 0;
D1_gamma = 0;

D2_cons = 0;
D2_aL_bar = - denorm_aL_bar*labor_cost_avg/(labor_avg^gamma)/denorm^2; 
D2_aM_bar = 0; 
D2_aK_bar = - denorm_aK_bar*labor_cost_avg/(labor_avg^gamma)/denorm^2; 
D2_gamma = - ( labor_cost_avg/(labor_avg^gamma) ) * (log(labor_avg)*denorm + denorm_gamma )/denorm^2;

D3_cons = 0;
D3_aL_bar = - denorm_aL_bar*material_cost_avg/(material_avg^gamma)/denorm^2; 
D3_aM_bar = 0; 
D3_aK_bar = - denorm_aK_bar*material_cost_avg/(material_avg^gamma)/denorm^2; 
D3_gamma = - ( material_cost_avg/(material_avg^gamma) ) * (log(material_avg)*denorm + denorm_gamma )/denorm^2;

D4_cons = 0;
D4_aL_bar = - ( aK_bar/aL_bar * labor_cost_avg/(capital_avg^gamma) )*( 1/aL_bar*denorm + denorm_aL_bar )/denorm^2; 
D4_aM_bar = 0; 
D4_aK_bar = - ( 1/aL_bar * labor_cost_avg/(capital_avg^gamma) )*( denorm + aK_bar*denorm_aK_bar )/denorm^2;
D4_gamma = - tau*( labor_cost_avg/(capital_avg^gamma) ) * (log(capital_avg)*denorm + denorm_gamma )/denorm^2;

D5_cons = 0;
D5_aL_bar = 0; 
D5_aM_bar = 0;
D5_aK_bar = 0;
D5_gamma = 1/(1-gamma)^2;

D_devi = [D1_cons, D1_aL_bar, D1_aM_bar, D1_aK_bar, D1_gamma;
          D2_cons, D2_aL_bar, D2_aM_bar, D2_aK_bar, D2_gamma;
          D3_cons, D3_aL_bar, D3_aM_bar, D3_aK_bar, D3_gamma;
          D4_cons, D4_aL_bar, D4_aM_bar, D4_aK_bar, D4_gamma;
          D5_cons, D5_aL_bar, D5_aM_bar, D5_aK_bar, D5_gamma];

var_mat = D_devi*var_mat_bar*D_devi';
se = diag(var_mat).^.5;
