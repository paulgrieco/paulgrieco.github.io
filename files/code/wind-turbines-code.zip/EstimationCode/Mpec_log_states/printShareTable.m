
clear

%set file identifier to standard out;
fid = 1;

%First we need to import the appropriate data
load counter_boot

%ALERT: We've added this code to counter_boot, so it will be redundant for
%future runs, however, it shouldn't cause any errors.  Should still be
%removed eventually
for var = 1: length(name_vec)
   eval(sprintf('%s_se = reshape(%s_se, size(e_%s));', name_vec{var}, name_vec{var}, name_vec{var}));
   eval(sprintf('clear %s', name_vec{var}));
end


% Calulate market shares from the data

% ordering is the same as for the market shares from the model
% DNK, GER, Fringe firms
d_natShare =  100*[ sum(sum(m.y_matrix_ger(:,2:m.num_for_ger+1))) ./ m.num_pro_ger ,  sum(sum(m.y_matrix_ger(:,2+m.num_for_ger:end))) ./ m.num_pro_ger, sum(m.y_matrix_ger(:,1)) ./ m.num_pro_ger; ...
         sum(sum(m.y_matrix_dnk(:,2:end-m.num_for_dnk))) ./ m.num_pro_dnk ,  sum(sum(m.y_matrix_dnk(:,end-m.num_for_dnk+1,end))) ./ m.num_pro_dnk, sum(m.y_matrix_dnk(:,1)) ./ m.num_pro_dnk];
           


country = {'Denmark', 'Germany'};
c_order = [ 2 1 ];
rowname = {'Danish Firms', 'German Firms'};
r_order = [ 1 2 ];

shares = {'natShare'  ,  'natShareNF'  ,  'natShareNB'};
for s=1:length(shares)
   eval(sprintf('e_%s = 100*e_%s;', shares{s}, shares{s}));
   eval(sprintf('%s_se = 100*%s_se;', shares{s}, shares{s}));
end

%Market Shares...
%%
fprintf(fid, '\\begin{table}[htbp] \n \\begin{center} \n'); 
fprintf(fid, '\\caption{Counterfactual Market Shares of Major Firms.} \n');
fprintf(fid, '\\begin{tabular}{llcccc}\n \\hline \\hline \n');

%The Headers...
fprintf(fid, ' & & Data & Estimates & No Fixed  & No Border  \\\\\n');
fprintf(fid, ' & &  &  & Costs & Costs \\\\\n \\hline \\\\\n');


%The Guts...
for c=1:length(country)
   for r = 1:length(rowname)
       if (r==1)
          fprintf(fid, '\\multirow{3}{*}{%s} & ', country{c});
       else
         fprintf(fid, ' & '); 
       end
       fprintf(fid, '%s & %.2f & %.2f & %.2f & %.2f \\\\\n', rowname{r}, d_natShare(c_order(c), r_order(r)), e_natShare(c_order(c), r_order(r)), e_natShareNF(c_order(c), r_order(r)), e_natShareNB(c_order(c), r_order(r)));
       fprintf(fid, '\t & \t & \t & { \\footnotesize (%.2f) } & { \\footnotesize (%.2f) } & { \\footnotesize (%.2f) } \\\\\n', natShare_se(c_order(c), r_order(r)), natShareNF_se(c_order(c), r_order(r)), natShareNB_se(c_order(c), r_order(r)));
   end
   if (c < length(country))
      fprintf(fid, '\\\\\n');
   end
end
fprintf(fid, '\\hline \n \\multicolumn{6}{l}{Note: Market share measured in projects won. } \\\\ \n \\end{tabular} \n');
fprintf(fid, '\\label{tab:counterfact} \n')
fprintf(fid, '\\end{center} \n \\end{table} \n\n');