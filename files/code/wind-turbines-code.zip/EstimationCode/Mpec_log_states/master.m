


clc;
clear;
close all

%MASTER file which runs code in order of dependencies..


tic;
%Setup data structures 
setup;

%Estimate the model and find standard errors
Main_mpec;
toc;
%%
%Use point estimate to solve conterfactuals and produce other relevant
%statistics:
%  1) Remove country fixed costs...all firms compete 
%  2) Remove all border costs, set country dummy coefficient to zero
%  3) Calculate National market shars for 3 scenarios (baseline, no fixed
%     border, no border costs)
%  4) Calculate markups, profits, consumer Surplus under 3 scenarios
%  5) Calculate Distance elasticity under baseline scenario
%  6) Calculate upper and lower bounds for fixed cost of entry 
%    ...(this step involves "Add one firm" counterfactuals"). 
[rho_nF rho_nB natShare natShareNF natShareNB markups markupsNF markupsNB ...
    profits profitsNF profitsNB conSurp conSurpNF conSurpNB ...
    delasticity_ger delasticity_dnk fc_bounds ] = postEstStats(m, m_nFC, thetahat, rhohat);

%copy the statistics into the est_point file...
for var = 1:length(name_vec)
  eval(sprintf('e_%s = %s;', name_vec{var}, name_vec{var}));
  eval(sprintf('save(''est_point'', ''e_%s'', ''-append'');', name_vec{var})); 
end

save('est_point', 'name_vec', '-append');

%Draw the figure of market share by border using conterfacutals and model
border_pic;

%Calculate the McFadden pseudo-R2 (but its not a binary model so we aren't
%sure its right anyway...
%pseudoR2;

%Generate distribution of win probabilites for model and two counterfactual
%scnarios
%bootCounter;
