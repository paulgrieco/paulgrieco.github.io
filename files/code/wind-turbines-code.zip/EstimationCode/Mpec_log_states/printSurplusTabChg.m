

clear;

load counter_boot;
 
%% First get the point estimates
e_levels = surplus_table_func(m,m_nFC,e_rhohat,e_rho_nF,e_rho_nB,thetahat);
%Compute percentage changes...
e_chg = [ (e_levels(:,2) - e_levels(:,1)) (e_levels(:,3) - e_levels(:,1))  (e_levels(:,6) - e_levels(:,4)) ];
e_chg = 100*e_chg./[ e_levels(:,1) e_levels(:,1) e_levels(:,4)];

mat_chg = [];
mat_levels = [];
for bb = 1:B
     b_levels = surplus_table_func(m,m_nFC,rhohat_mat(:,bb),rho_nF_mat(:,bb),rho_nB_mat(:,bb),thetahat_mat(:,bb));
     b_chg = [ (b_levels(:,2) - b_levels(:,1)) (b_levels(:,3) - b_levels(:,1))  (b_levels(:,6) - b_levels(:,4)) ];
     b_chg = 100*b_chg./[ b_levels(:,1) b_levels(:,1) b_levels(:,4)];
     mat_chg = [ mat_chg b_chg(:) ]; 
     mat_levels = [mat_levels b_levels(:)];
end

%These are using "basic" normalization, i.e, by variance of epsilon.
se_levels = ((1/B)*sum((repmat(e_levels(:), 1, B) - mat_levels).^2,2)).^(1/2);
se_levels = reshape(se_levels, size(e_levels));

%%
%Now re-scale levels according to total surplus by country...
se_levels(:,1:3) = 100*se_levels(:,1:3)./e_levels(end,1);
se_levels(:,4:6) = 100*se_levels(:,4:6)./e_levels(end,4);
e_levels(:,1:3) = 100*e_levels(:,1:3)./e_levels(end,1);
e_levels(:,4:6) = 100*e_levels(:,4:6)./e_levels(end,4);

%These are % changes, scale free
se_chg = ((1/B)*sum((repmat(e_chg(:), 1, B) - mat_chg).^2,2)).^(1/2);
se_chg = reshape(se_chg, size(e_chg));


%Now I want to build the table to print...
rownames = {'(A) Consumer Surplus',  '(B) Danish Firm Profits', '(C) German Firm Profits', 'Domestic Surplus (A+x)', 'Total Surplus (A+B+C)'};
country = {'Denmark', 'Germany'};
cty_base = [1 4];

fid = 1;

%% First Print the table supressing the level columns...

% fprintf(fid, '\\begin{table}[htbp] \n \\begin{center} \n'); 
% fprintf(fid, '\\caption{Counterfactual Consumer Surplus} \n');
% fprintf(fid, '\\begin{tabular}{llccc}\n \\hline \\hline \n');
% 
% %Column Headers
% fprintf(fid, '\t & \t & Baseline  & No Fixed Costs & No Border   \\\\ \n ');
% fprintf(fid, '\t & \t &  (Levels) &  (pct Change)   &  (pct Change)  \\\\ \n \\hline \n');
% 
% 
% for cty=1:length(country)
%     fprintf(fid, '\\\\ \n');
%     for r=1:length(rownames)
%         if (r==1)
%             fprintf(fid, '\\multirow{%d}{*}{%s} & ', 2*length(rownames), country{cty});
%         else
%             fprintf(fid, ' & '); 
%         end
%         if (cty == 1)
%             fprintf(fid, '%s & %.2f & %.2f & %.2f \\\\\n', rownames{r}, e_levels(r,1), e_chg(r, 1), e_chg(r,2));
%             fprintf(fid, ' \t & \t & (%.2f) & (%.2f) & (%.2f) \\\\\n', se_levels(r,1), se_chg(r,1), se_chg(r,2));
%         else
%             fprintf(fid, '%s & %.2f & \t & %.2f \\\\\n', rownames{r}, e_levels(r,4), e_chg(r, 3));
%             fprintf(fid, '\t & \t & (%.2f) & \t & (%.2f) \\\\\n', se_levels(r,1), se_chg(r,3));           
%         end
%     end
%     if (cty < length(cty))
%         fprintf(fid, '\\\\ \n \\hline \n');
%     end
% end
% 
% fprintf(fid, '\\hline \n \\multicolumn{5}{l}{Note: ...} \\\\ \n \\end{tabular} \n');
% fprintf(fid, '\\label{tab:Surplus} \n')
% fprintf(fid, '\\end{center} \n \\end{table} \n\n');


%% Now try with the counterfactual level columns...


fprintf(fid, '\\begin{table}[htbp] \n \\begin{center} \n'); 
fprintf(fid, '\\caption{Counterfactual Welfare Analysis by Country.} \n');
fprintf(fid, '\\begin{tabular}{llccccc}\n \\hline \\hline \n');

%Column Headers
fprintf(fid, '\t & \t & Baseline  & \\multicolumn{2}{c}{No Fixed Costs} & \\multicolumn{2}{c}{No Border}   \\\\ \n ');
fprintf(fid, '\t & \t &  (Levels) & (Levels) &(\\%% Chg)   &  (Levels) &(\\%% Chg)  \\\\ \n \\hline \n');


for cty=1:length(country)
    fprintf(fid, '\\\\ \n');
    for r=1:length(rownames)
        if (r==1)
            fprintf(fid, '\\multirow{%d}{*}{%s} & ', 2*length(rownames), country{cty});
        else
            fprintf(fid, ' & '); 
        end
        if (cty == 1)
            fprintf(fid, '%s & %.2f & %.2f & %.2f & %.2f & %.2f \\\\\n', rownames{r}, e_levels(r,1), e_levels(r,2), e_chg(r, 1), e_levels(r,3), e_chg(r,2));
            fprintf(fid, ' \t & \t & {\\footnotesize (%.2f)} & {\\footnotesize (%.2f)} & {\\footnotesize (%.2f)} & {\\footnotesize (%.2f)} & {\\footnotesize (%.2f)} \\\\  \n', se_levels(r,1), se_levels(r,2), se_chg(r,1), se_levels(r,3), se_chg(r,2));
        else
            fprintf(fid, '%s & %.2f & \t & \t & %.2f & %.2f \\\\\n', rownames{r}, e_levels(r,4), e_levels(r,6), e_chg(r, 3));
            fprintf(fid, '\t & \t & {\\footnotesize (%.2f)} & \t & \t & {\\footnotesize (%.2f)} & {\\footnotesize (%.2f)} \\\\\n', se_levels(r,4), se_levels(r,6), se_chg(r,3));           
        end
    end
    if (cty < length(cty))
        fprintf(fid, '\\\\ \n \\hline \n');
    end
end

fprintf(fid, '\\hline \n \\multicolumn{7}{l}{Note: Levels are scaled such that baseline total surplus from projects within a country} \\\\ \n');
fprintf(fid, '\\multicolumn{7}{l}{ is 100. \\%% Change is percent change from baseline level.} \\\\ \n \\end{tabular} \n');
fprintf(fid, '\\label{tab:Surplus} \n');
fprintf(fid, '\\end{center} \n \\end{table} \n\n');




