
clear

%set file identifier to standard out;
fid = 1;

%First we need to import the appropriate data
load counter_boot

%ALERT: We've added this code to counter_boot, so it will be redundant for
%future runs, however, it shouldn't cause any errors.  Should still be
%removed eventually
for var = 1: length(name_vec)
   eval(sprintf('%s_se = reshape(%s_se, size(e_%s));', name_vec{var}, name_vec{var}, name_vec{var}));
   eval(sprintf('clear %s', name_vec{var}));
end

%%

country = {'Denmark', 'Germany'};
c_order = [ 2 1 ];


shares = {'natShare'  ,  'natShareNF'  ,  'natShareNB'};
for s=1:length(shares)
   eval(sprintf('e_%s = 100*e_%s;', shares{s}, shares{s}));
   eval(sprintf('%s_se = 100*%s_se;', shares{s}, shares{s}));
end

%Consumer surplus...
%%
fprintf(fid, '\\begin{table}[htbp] \n \\begin{center} \n'); 
fprintf(fid, '\\caption{Counterfactual Consumer Surplus} \n');
fprintf(fid, '\\begin{tabular}{lccc}\n \\hline \\hline \n');

%The Headers...
fprintf(fid, '  & Estimates & No Fixed  & No Border  \\\\\n');
fprintf(fid, '  &  & Costs & Costs \\\\\n \\hline  \n');


%The Guts...
for c=1:length(country)
       fprintf(fid, '%s & %.2f & %.2f & %.2f \\\\\n', country{c},  e_conSurp(c_order(c)), e_conSurpNF(c_order(c)), e_conSurpNB(c_order(c)) ) ;
       fprintf(fid, '\t & (%.2f) & (%.2f) & (%.2f) \\\\\n',  conSurp_se(c_order(c)), conSurpNF_se(c_order(c)), conSurpNB_se(c_order(c)) );
   if (c < length(country))
      fprintf(fid, '\\\\\n');
   end
end

fprintf(fid, '\\hline \n \\multicolumn{4}{l}{Note: This is the consumer surplus for the} \\\\ \n');
fprintf(fid, ' \\multicolumn{4}{l}{average project in each country. The scale } \\\\  \n');
fprintf(fid, ' \\multicolumn{4}{l}{is normalized by the variance of $\\epsilon$. } \\\\ \n \\end{tabular} \n');
fprintf(fid, '\\label{tab:ConSurp} \n')
fprintf(fid, '\\end{center} \n \\end{table} \n\n');