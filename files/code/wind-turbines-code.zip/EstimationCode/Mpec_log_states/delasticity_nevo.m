%Compute distance elasticidies "Nevo Style", i.e., the effect of your plant
%being located one mile further away holding everyone else's plant location
%constant.

%This elasticity is computed for every (active) firm at every project

%% Either run these scripts or load their output files
%setup; 
% load data_structures;
% %Main_mpec
% load est_point;

function [firm_elast_ger , firm_elast_dnk] = delasticity_nevo(m,thetahat, rhohat)

%Usual reshape of rho into project by firm matricies
rho_matrix_ger    = reshape(rhohat(1:(m.num_firms_ger+1)*m.num_pro_ger)',m.num_firms_ger+1,m.num_pro_ger)' ;
rho_matrix_dnk    = reshape(rhohat((m.num_firms_ger+1)*m.num_pro_ger+1:end)',m.num_firms_dnk+1,m.num_pro_dnk)' ;

%Calculation of distance elasticities for each project-firm
% UPDATED 10.14.2013...This directory uses log distance so we have update
% this formula...still the distance elasticity.
own_dist_elast_ger = thetahat(11) * (1-rho_matrix_ger(:,2:end)); 
own_dist_elast_dnk = thetahat(11) * (1-rho_matrix_dnk(:,2:end)); 


% For all active firms and projects in Germany and Denmark we print the 25 percentile, median,
% and 75 percentile of distance elasticities
%full_elast_quart = [prctile([own_dist_elast_ger(:) ; own_dist_elast_dnk(:)],25) ...
%median([own_dist_elast_ger(:) ; own_dist_elast_dnk(:)]) ...
%prctile([own_dist_elast_ger(:) ; own_dist_elast_dnk(:)],75)];

%fprintf(' Mean distance elasticity in Germany and DNK combined')
%mean([own_dist_elast_ger(:) ; own_dist_elast_dnk(:)])
% Frims have the usual ordering: first row Bonus, ....
firm_elast_ger = [ prctile(own_dist_elast_ger, 25)' prctile(own_dist_elast_ger, 50)' prctile(own_dist_elast_ger, 75)'];
firm_elast_dnk =  [ prctile(own_dist_elast_dnk, 25)' prctile(own_dist_elast_dnk, 50)' prctile(own_dist_elast_dnk, 75)'];
% Distance elasticities are generally higher for foreign markets

