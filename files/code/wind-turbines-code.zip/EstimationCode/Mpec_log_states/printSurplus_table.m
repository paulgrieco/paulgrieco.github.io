% 
clear
load counter_boot

fid = 1;
%% Estimation points

e_surplus_tab_unscaled = surplus_table_func(m,m_nFC,e_rhohat,e_rho_nF,e_rho_nB,thetahat);
e_surplus_tab_unscaled(:,5) = [];   % If fixed costs are removed nobody enters in Germany

% Rescale surplus accumulated in DK by total Surplus in DK in Benchmark model 

e_surplus_tab(:,1:3) = 100 * e_surplus_tab_unscaled(:,1:3)./ e_surplus_tab_unscaled(5,1);

% Rescale similarly for Germany

e_surplus_tab(:,4:5) = 100 * e_surplus_tab_unscaled(:,4:5)./ e_surplus_tab_unscaled(5,4);


%% Standard error

surplus_tab_Boot = [];

for bb = 1:B
    surplus_tab_bb = surplus_table_func(m,m_nFC,rhohat_mat(:,bb),rho_nF_mat(:,bb),rho_nB_mat(:,bb),thetahat_mat(:,bb));   % read in bootsstrap draws here
    surplus_tab_Boot = [surplus_tab_Boot , surplus_tab_bb(:)];
end


surplus_tab_se = reshape(std(surplus_tab_Boot,0,2),size(surplus_tab_bb));
surplus_tab_se(:,5) = [];


% Rescale
surplus_tab_se(:,1:3) = 100 * surplus_tab_se(:,1:3) ./ e_surplus_tab_unscaled(5,1);
surplus_tab_se(:,4:5) = 100 * surplus_tab_se(:,4:5) ./ e_surplus_tab_unscaled(5,4);


%Surplus table ...
%%

rownames = {'Consumer Surplus',  'Top 5 Danish firms', 'Top 5 German firms', 'Domestic Surplus', 'Total Surplus'};


fprintf(fid, '\\begin{table}[htbp] \n \\begin{center} \n'); 
fprintf(fid, '\\caption{Counterfactual Consumer Surplus} \n');
fprintf(fid, '\\begin{tabular}{lccc|ccc}\n \\hline \\hline \n');

%Headers...
fprintf(fid, ' & \\multicolumn{3}{c|}{Denmark} & \\multicolumn{3}{c}{Germany} \\\\ \n');
fprintf(fid, ' & Estimates & No Fixed & No Border & Estimates & \\hspace{.5in} & No Border \\\\ \n ');
fprintf(fid, ' &           &  Costs   &  Costs    &           &                &  Costs  \\\\ \n \\hline \n');

%Guts...
for f = 1:length(rownames)
    fprintf(fid, '%s & %.2f & %.2f & %.2f & %.2f & \t & %.2f  \\\\ \n', rownames{f}, e_surplus_tab(f,:));
    fprintf(fid, '\t & (%.2f) & (%.2f) & (%.2f) & (%.2f) & \t & (%.2f)  \\\\ \n', surplus_tab_se(f,:));
end

fprintf(fid, '\\hline \n \\multicolumn{7}{l}{Note: Scale is normalized in both Germany and Denmark such that Total Surplus in the benchmark model = 100.} \\\\ \n \\end{tabular} \n');
fprintf(fid, '\\label{tab:Surplus} \n')
fprintf(fid, '\\end{center} \n \\end{table} \n\n');