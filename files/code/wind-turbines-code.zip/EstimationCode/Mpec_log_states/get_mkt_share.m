% This function uses rhos as input as well as the number of active firms in
% every market and calculates expected market shares by country for German
% and Danish firms

function fval = get_mkt_share(m,rho)

rho_matrix_ger    = reshape(rho(1:(m.num_firms_ger+1)*m.num_pro_ger)',m.num_firms_ger+1,m.num_pro_ger)' ;
rho_matrix_dnk    = reshape(rho((m.num_firms_ger+1)*m.num_pro_ger+1:end)',m.num_firms_dnk+1,m.num_pro_dnk)' ;

sim_mkt_share_ger = sum(rho_matrix_ger,1) ./ m.num_pro_ger;
sim_mkt_share_dnk = sum(rho_matrix_dnk,1) ./ m.num_pro_dnk;

sim_mkt_share_dnk_in_ger = sum(sim_mkt_share_ger(2:m.num_for_ger+1));
sim_mkt_share_gerlarge_in_ger = sum(sim_mkt_share_ger(m.num_for_ger+2:end));
sim_mkt_share_fringe_in_ger = sim_mkt_share_ger(1,1);

sim_mkt_share_ger_in_dnk = sum(sim_mkt_share_dnk(end-m.num_for_dnk+1:end));
sim_mkt_share_dnklarge_in_dnk = sum(sim_mkt_share_dnk(2:end-m.num_for_dnk));
sim_mkt_share_fringe_in_dnk = sum(sim_mkt_share_dnk(1));

fval = [sim_mkt_share_dnk_in_ger , sim_mkt_share_gerlarge_in_ger , sim_mkt_share_fringe_in_ger ; ...
        sim_mkt_share_dnklarge_in_dnk , sim_mkt_share_ger_in_dnk , sim_mkt_share_fringe_in_dnk];
    % first row DNK , 2nd row GER, first colum: Danish firms, second: German, third: Fringe
