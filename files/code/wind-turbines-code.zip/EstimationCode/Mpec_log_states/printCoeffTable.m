

clear;

%set file identifier to standard out;
fid = 1;

spacer = .05;

typenames = {'Border Effect', 'Internal Border' , 'Log Distance', 'Firm Effect'};
firmnames = {'Bonus (DK)',  'Nordtank (DK)', 'Micon (DK)', 'Vestas (DK)', ...
    'WindWorld (DK)', 'Enercon (DE)', 'Fuhrlaender (DE)', 'Nordex (DE)', ...
    'Suedwind (DE)', 'Tacke (DE)'};

firmorder = [ 1 2 3 4 5 7 8 6 9 10];

numFirms = length(firmnames);

%% Load the data...
load data_structures;

% Zeroth, the no-state border specification...
load ../Mpec_log/est_point
noSt_th = thetahat;
noSt_se = se; 
noSt_ll = ll;
noSt_n  = m.num_pro_ger + m.num_pro_dnk;;

% First, the baseline specification...

load est_point;
hom_th = thetahat;
hom_se = se;
hom_ll = ll;
hom_n  = m.num_pro_ger + m.num_pro_dnk;

% Second, load the heterogeneous distance specificaton
load ../Mpec_log_states_het/est_point
het_th = thetahat;
het_se = se;
het_ll = ll;
%Actually the same number by default since m comes from data_structures.
het_n  = m.num_pro_ger + m.num_pro_dnk;

% Finally, load the size specificaton
load ../Mpec_log_states_size/est_point
size_th = thetahat;
size_se = se;
size_ll = ll;
%Actually the same number by default since m comes from data_structures.
size_n = m.num_pro_ger + m.num_pro_dnk;


%% Now let's Get Printing

%First row is the Border Effects...
outMat = [ hom_th(end) het_th(end); ...
           hom_th(end-1) -999];

fprintf(fid, '\\begin{table}[htbp] \n \\begin{center} \n'); 
fprintf(fid, '\\caption{Maximum Likelihood Estimates.} \n');
fprintf(fid, '\\begin{tabular}{lcccc}\n \\hline \\hline \n');
fprintf(fid, ' & \\hspace{%.3f in} Natonal Border Only \\hspace{%.3f in} & \\hspace{%.3f in} National and Internal \\hspace{%.3f in} ', spacer, spacer, spacer, spacer)
fprintf(fid, ' & \\hspace{%.3f in}Heterogeneous \\hspace{%.3f in} & \\hspace{%.3f in}Scale \\hspace{%.3f in} \\\\\n \\hline \n', spacer, spacer, spacer, spacer);     
       
%First print out the border effects:
fprintf(fid, 'National Border Variable Cost, $\\beta_b$ & %4.3f & %4.3f & %4.3f & %4.3f \\\\\n', noSt_th(end), hom_th(end-1), het_th(end-1), size_th(end-3));
fprintf(fid, '\t& { \\footnotesize (%4.3f) } & { \\footnotesize (%4.3f) } & { \\footnotesize (%4.3f) } & { \\footnotesize (%4.3f) } \\\\\n', noSt_se(end), hom_se(end-1), het_se(end-1), size_se(end-3));

fprintf(fid, 'Internal Border Variable Cost, $\\beta_i$ & \t & %4.3f & %4.3f & %4.3f \\\\\n', hom_th(end), het_th(end), size_th(end-2));
fprintf(fid, '\t&                           & { \\footnotesize (%4.3f) } & { \\footnotesize (%4.3f) } & { \\footnotesize (%4.3f) } \\\\\n', hom_se(end), het_se(end), size_se(end-2));



%Now the Distance Coeffs
fprintf(fid, 'Log Distance Cost (100km), $\\beta_d$ & %4.3f & %4.3f &   & %4.3f \\\\ \n', noSt_th(end-1), hom_th(end-2), size_th(end-4));
fprintf(fid, '\t& { \\footnotesize (%4.3f) } & { \\footnotesize (%4.3f) } &  & { \\footnotesize (%4.3f) } \\\\ \n', noSt_se(end-1), hom_se(end-2), size_se(end-4));

for f = 1:numFirms
    fprintf(fid, '\\hspace{.12in} \\it{ %s } & \t  & \t & %4.3f \\\\\n', firmnames{f}, het_th(numFirms + firmorder(f)));
    fprintf(fid, ' \t\t\t & \t & \t &  { \\footnotesize (%4.3f) } \\\\\n', het_se(numFirms + firmorder(f)));
end


%Now the Size Coefficients: 
fprintf(fid, 'Project Size, $\\beta_s$ & \t  & \t & \t & %4.3f \\\\\n', size_th(end-1));
fprintf(fid, ' \t & \t & \t & \t &  { \\footnotesize (%4.3f) } \\\\\n', size_se(end-1));

fprintf(fid, 'Project Size x Border, $\\beta_{sb}$ & \t & \t & \t & %4.3f \\\\\n', size_th(end));
fprintf(fid, ' \t & \t & \t & \t &  { \\footnotesize (%4.3f) } \\\\\n', size_se(end));


%Now the Firm Fixed Effect Coeffs
%NOTE: We report firm fixed effects such that higher is more productive,
%-1*the code results...
fprintf(fid, 'Firm Fixed Effects, $\\xi_j$ &  &  \\\\\n \\\\\n');

for f = 1:numFirms
    fprintf(fid, '\\hspace{.12in} \\it{ %s } & %4.3f  & %4.3f & %4.3f & %4.3f \\\\\n', firmnames{f}, -1*noSt_th(firmorder(f)), -1*hom_th(firmorder(f)), -1*het_th(firmorder(f)), -1*size_th(firmorder(f)));
    fprintf(fid, ' \t\t\t &  { \\footnotesize (%4.3f) } &  { \\footnotesize (%4.3f) } &  { \\footnotesize (%4.3f) } &  { \\footnotesize (%4.3f) } \\\\\n', noSt_se(firmorder(f)), hom_se(firmorder(f)), het_se(firmorder(f)), size_se(firmorder(f)));
end

%Now the log likelihood and number of observations...
fprintf(fid, '\\\\\n');
fprintf(fid, 'Log-Likelihood & %.2f & %.2f & %.2f & %.2f \\\\\n', -noSt_ll, -hom_ll, -het_ll, -size_ll);
fprintf(fid, 'N & %d & %d & %d & %d \\\\\n', noSt_n, hom_n, het_n, size_n);

fprintf(fid, '\\hline \n\\end{tabular} \n');
fprintf(fid, '\\label{tab:CoeffEst} \n')
fprintf(fid, '\\end{center} \n \\end{table} \n\n');