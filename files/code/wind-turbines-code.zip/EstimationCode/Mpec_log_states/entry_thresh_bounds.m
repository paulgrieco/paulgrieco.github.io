%% This file generates the Bounds on fixed costs implied by observed entry decisions:

% For firms that DID enter:
%  Fixed cost are < profits, which are computed in margin_table.m
% For firms that DID NOT enter:
%  We here resolve the model assuming they had entered, their fixed cost
%  must be at least as high as profits they receive in this scenario...


%% Either run these scripts or load their output files
%setup; 
% load data_structures;
%% Main_mpec
% load est_point;

function lb_vec = entry_thresh_bounds(m, m_nFC,thetahat)

%% Set up the model structure for adding a single firm...
%We only need to consider German firms entering Denmark, non-fringe firms
%7-10, so firms 8-11 in the rho matrx, where fringe is 1.

m_Add1 = m;
m_Add1.num_firms_dnk = m.num_firms_dnk + 1;
m_Add1.num_for_dnk = 2;
m_Add1.foreign_mat_dnk = [zeros(m_Add1.num_pro_dnk,5),ones(m_Add1.num_pro_dnk,2)];
m_Add1.state_mat_dnk = zeros(m_Add1.num_pro_dnk, m_Add1.num_firms_dnk);

%% Set up Jacobean Pattern and initial guess (stolen from counterfactualSolve)


%Now set up Jacobian pattern for the countefactual structure...
%These are the sparsity templates for each project the first row, is the 
%fringe share and the final column is theadding up constraint
J_m_ger = [[ones(1,m_Add1.num_firms_ger);eye(m_Add1.num_firms_ger)],ones(m_Add1.num_firms_ger+1,1)];
J_m_dnk = [[ones(1,m_Add1.num_firms_dnk);eye(m_Add1.num_firms_dnk)],ones(m_Add1.num_firms_dnk+1,1)];

%This is the Jacobian of the Constraints by the market share parameters
%(rhos)
JJ = [kron(eye(m_Add1.num_pro_ger),J_m_ger), zeros((m_Add1.num_firms_ger+1)*m_Add1.num_pro_ger, (m_Add1.num_firms_dnk+1)*m_Add1.num_pro_dnk) ; %These are the german market constraints
    zeros((m_Add1.num_firms_dnk+1)*m_Add1.num_pro_dnk, (m_Add1.num_firms_ger+1)*m_Add1.num_pro_ger), kron(eye(m_Add1.num_pro_dnk), J_m_dnk) ]; 



rho_ger = ones(m_Add1.num_pro_ger * (m_Add1.num_firms_ger + 1) ,1) ./ (m_Add1.num_firms_ger + 1);    
rho_dnk = ones(m_Add1.num_pro_dnk * (m_Add1.num_firms_dnk + 1) ,1) ./ (m_Add1.num_firms_dnk + 1);    
r0 = [rho_ger; rho_dnk];
Jac_Pattern_rho = JJ';
LB = [zeros(size(rho_ger,1)+size(rho_dnk,1),1)];
UB = [ones(size(rho_ger,1)+size(rho_dnk,1),1)];
ktropts = optimset('DerivativeCheck','on','Display','iter',...
           'GradConstr','on','GradObj','on','TolCon',1E-6,'TolFun',1E-6,'TolX',1E-6,'JacobPattern',Jac_Pattern_rho);


Add1_res = cell(4,1);

%We need to ``swap'' the fixed effect for the firm we are adding into the
%seventh slot so that it is included in the danish market correctly.
th_Add1 = thetahat;

lb_vec  = zeros(4,1);

for toAdd = 7:10
   %Update distance matrix and Add1_th;
   %This code copies the column "toAdd" firm into column 7 and move its
   %fixed effect to slot 7 (the "added" firm in Denmark).  The german side
   %of this counterfactual is nonsense since we do not update german side
   %distances and all firms are active in Germany anyway.
   m_Add1.dist_mat_dnk(:,m_Add1.num_firms_dnk) = m_nFC.dist_mat_dnk(:,toAdd); 
   th_Add1(7) = thetahat(toAdd);
   
   %Solve the model (only care about the danish side, but we do germany as
   %well)
   [rho_A, FVAL_A, EXITFLAG_A, OUTPUT_A] = ktrlink(@(x_0) dummy_objective(x_0), r0, [],[],[],[],LB,UB,@(x_0) model_constraints(x_0, th_Add1,m_Add1),ktropts,'knitro.opt');
   Add1_res{toAdd-6}.rho = rho_A;
   Add1_res{toAdd-6}.flag = EXITFLAG_A;
 
   [foo Add1_res{toAdd-6}.pro] = avgMarkups(m_Add1, rho_A);
%    
%    fprintf('The lower bound of fixed cost for firm %d is %f\n', toAdd,...
%         Add1_res{toAdd-6}.pro.dnk(7));
   %ALERT:
   %(2,7) grab's the seventh (added) firm in denmark..
   lb_vec(toAdd - 6) = Add1_res{toAdd-6}.pro(2,7);
   
   %Update starting value, hopefully this will speed up solving for later
   %counterfactuals...
   r0 = rho_A;
end

