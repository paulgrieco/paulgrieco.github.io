% Calculate average margins and consumer surplus in Germany and Denmark under model and
% counterfactuals, produce table.
%clear; 

%% Either run scripts or load their output files
%setup; 
load data_structures;
%Main_mpec
load est_point;
%counterfactualSolve
load counterFact_out


%Calculate "percent correct" measure of r2
% We stopped computing this because by the "maximum probability"
% deffinition of prediction we always predict the same firm in each country
% (Enercon in germany and Vestas in Denmark) so it doesn't seem like a
% useful measure.  Train argues against its use for essentially this
% reason, p. 69.

% rho_ger = rhohat(1:m.num_pro_ger * (m.num_firms_ger + 1) ,1);    
% rho_ger_mat    = (reshape(rho_ger,m.num_firms_ger + 1,m.num_pro_ger))';
% 
% rho_dnk = rhohat(m.num_pro_ger * (m.num_firms_ger + 1)+1 : m.num_pro_ger * (m.num_firms_ger + 1) + m.num_pro_dnk * (m.num_firms_dnk + 1) ,1) ;    
% rho_dnk_mat    = (reshape(rho_dnk,m.num_firms_dnk + 1,m.num_pro_dnk))';
% 
% pred_ger = (rho_ger_mat - repmat(max(rho_ger_mat,[],2), 1, m.num_firms_ger+1) > -1e-15);

%This is "McFadden's pseudo r2 measure, see C&T p 474 or http://www.ats.ucla.edu/stat/mult_pkg/faq/general/psuedo_rsquareds.htm
%  not that this is really for binary data not categorical data and we are
%  just computing it for reference.
pseduor2 = 1 - (-ll/ (m.num_pro_ger * log(1/(m.num_firms_ger+1)) + m.num_pro_dnk * log(1/(m.num_firms_dnk+1))) );