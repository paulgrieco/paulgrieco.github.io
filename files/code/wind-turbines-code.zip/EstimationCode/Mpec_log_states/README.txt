
CODE README FILE:  MPEC_LOG_STATES (Baseline Results)

This file provides information about the the code release which accompanies "BORDERS, GEOGRAPHY AND OLIGOPOLY: EVIDENCE FROM THE WIND TURBINE INDUSTRY" by Kerem Cosar, Paul Grieco, and Felix Tintelnot.

The primary code was run uses MATLAB version 2012b and KNITRO 8.1.1 and 8.2. It has been run successfully on a Mac Pro OSX version 8.10.5 and on the Lion-XF cluster at Pennsylvania State University (https://rcc.its.psu.edu/resources/hpc/lionxf/#specs).  The bootstrap computation is parallelized and makes use of the PBS batch system on the Lion-XF cluster. 

To produce the directory results, simply run the "master" script in MATLAB (with KNITRO properly installed).

What follows is a description of the files in this directory: 

CODE FILES: 
Code files are listed in order in which they are called: 

master.m - Master file which runs code in order of dependencies. Running this file will run the entire estimation and counterfactual analysis. It would also run the the bootstrap of the counterfactuals.

setup.m - This file reads in the the data files and constructs the structures which will be used in estimation.  All model structures are saved in the output file "data_structures.mat" 

Main_mpec.m - Constructs sparsity pattern, calls optimization, and computes standard errors for the primary estimation. Saves results in 'est_point.mat'

dummy_objective.m - A dummy function which returns zero.  Used when we want to simply
solve for equilibrium instead of optimize the likelihood.  It is used as an objective
function input to KNITRO where the equilibrium constraints are supplied as constraints. 

model_constraints.m - Contains a function to compute the equilibrium constraints of the model. Used by KNITRO in optimization and also in solving for equilibrium. Also supplies
the gradient of the constraints. 

eqm_constraints.m - Contains a function to compute the equilibrium constraints of the model. Used by KNITRO in optimization and also in solving for equilibrium. Also supplies
the gradient of the constraints. The only difference between model_constraints and eqm_constraints is the whether or not the parameters are included in the input vector.

likelihood_func.m - Contains a function to compute the model likelihood. Used as objective function by KNITRO in estimation. 

postEstStats.m - Makes calls to several functions which compute post-estimation statistics and counterfactual analysis. All statistics returned via output arguments.

counterfactualSolve.m - Computes equilibrium for "No Fixed Cost" and 
"No National Borders" counterfactuals. Returns win probabilities for each project under
these counterfactuals. 

get_mkt_share.m - Computes national market shares by firm given the model structures and win probabilities at the project level. 

avgMarkups.m - Computes average markups and profits given the model structure and win probabilities. 

conSurplus.m - Computes national consumer surplus given the model structure and win probabilities. 

delasticity.m - Computes the distance elasticity by project following Nevo (1999). 

entry_thresh_bouns.m - Computes the fixed cost bounds presented in Table 4. 

border_pic.m - Draws a MATLAB version of Figure 4. 

psuedoR2 (not used) - Constructs a pseudo-R2 statistic for model fit. 

bootCounter.m - Parametric bootstrap for standard errors on counterfactuals. Draws 200
points from the asymptotic distribution of theta-hat, solves for equilibrium, and computes the statistics via postEstStats.  Then finds standards errors based on these bootstrap draws. Saves results in counter_boot. NOTE: Parllel version of this code available from the authors. This version will run as part of master but will take several days (maybe weeks) to complete. However, parallel uses PBS Scripts.

moranTest.m - Computes moran test statistic provided in appendix. 

stateFixedCostTest.m - Computes the test statistics for the test for state-level 
fixed costs discussed in the text of Section 4.2.

print*.m - Uses output files to print LaTeX code for the tables in the draft. Format of tables in draft may be slightly altered as part of editing for the journal, but all numbers match. Note that some print files load data from other directories since they
print data from alternative specifications.

knitro.opt - KNITRO options file. 

INPUT FILES:
german_data_for_matlab_new.out (PROPRIETARY) - Csv containing all the information on each project in Germany, including distances to assembly.  Each line is a single project.
 
danish_data_for_matlab_new.out - Csv containing all the information on each project in Germany, including distances to assembly.  Each line is a single project.

stateDumSorted.csv (PROPRIETARY) - Contains state of origin information for each project. 

dist_matrix_data.mat (PROPRIETARY) - Inter-project distance matrixes for use in the moran test. 

OUTPUT FILES: 

data_structures.mat (PROPRIETARY) - Contains the structures used as inputs to the estimation. 

est_point.mat - Results from the estimation and counterfactuals at the estimated point. Including optimized point and standard errors. 

counter_boot.mat - Results of model including inference for counterfactual analysis. cat

stateFixedCostTestResult.mat - Results of test for state level fixed costs discussed in Section 4.2. 


