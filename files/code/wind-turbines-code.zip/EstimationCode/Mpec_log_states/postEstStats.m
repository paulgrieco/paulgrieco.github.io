
function [rho_nF rho_nB natShare natShareNF natShareNB markups markupsNF markupsNB ...
    profits profitsNF profitsNB conSurp conSurpNF conSurpNB ...
    delasticity_ger delasticity_dnk fc_bounds ] = postEstStats(m, m_nFC, theta, rho)
%
%This function will take our parameter estimates and calculate ALL
%The statistics we wish to put into the paper, it is largely a 
%wrapper from previously used code...
%

%First solve our primary counterfactuals....
[rho_nF rho_nB flag] = counterfactualSolve(m_nFC, theta, 0);


if (flag)
    disp(sprintf('WARNING: counterfactualSolve Returned Status: %d', flag));
end


%Next, let's calculate national market share tables. 
 % first row GER , 2nd row DNK, first colum: Danish firms, second: German, third: Fringe
natShare = get_mkt_share(m, rho);
natShareNF = get_mkt_share(m_nFC, rho_nF);
natShareNB = get_mkt_share(m_nFC, rho_nB);


%Now let's get markups and profits...
[markups profits] = avgMarkups(m, rho);
[markupsNF profitsNF] = avgMarkups(m_nFC, rho_nF);
[markupsNB profitsNB] = avgMarkups(m_nFC, rho_nB);

%Next Consumer Surplus...
conSurp = conSurplus(m, rho, theta);
conSurpNF = conSurplus(m_nFC, rho_nF, theta);
conSurpNB = conSurplus(m_nFC, rho_nB, [theta(1:end-1); 0]);

% Distance ealsticiy Nevo style

% % Frims have the usual ordering: first row Bonus, ....
% delasticity_ger = [ prctile(own_dist_elast_ger, 25)' prctile(own_dist_elast_ger, 50)' prctile(own_dist_elast_ger, 75)']
% delasticity_dnk =  [ prctile(own_dist_elast_dnk, 25)' prctile(own_dist_elast_dnk, 50)' prctile(own_dist_elast_dnk, 75)']
% % Distance elasticities are generally higher for foreign markets
% We only do this for the model estimates, not for the counter-factual
% estimates (although it would be trivial to do so...)

[delasticity_ger , delasticity_dnk] = delasticity_nevo(m, theta, rho);

% Fixed costs bounds

% First we get the lower bounds of fixed costs for firms that did not enter
lb_vec = entry_thresh_bounds(m, m_nFC, theta);
% then we combine them with the upper bounds from the profits expression

fc_bounds  = nan(max(m.num_firms_ger, m.num_firms_dnk), 2);
fc_bounds(end - 3:end, 1) = lb_vec;
%Expected profits of foreign firms that did enter
%Germany is row 1, Denmark row 2, first columns are danish firms, 
%  late columns are german firms
fc_bounds(1:6 ,2) = [ profits(1,1:5) profits(2,6)]';