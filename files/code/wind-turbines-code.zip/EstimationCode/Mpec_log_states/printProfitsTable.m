

clear

%set file identifier to standard out;
fid = 1;


%First we need to import the appropriate data
load counter_boot
%ALERT: We've added this code to counter_boot, so it will be redundant for
%future runs, however, it shouldn't cause any errors.  Should still be
%removed eventually
for var = 1: length(name_vec)
   eval(sprintf('%s_se = reshape(%s_se, size(e_%s));', name_vec{var}, name_vec{var}, name_vec{var}));
   eval(sprintf('clear %s', name_vec{var}));
end


firmnames = {'Bonus (DK)',  'Nordtank (DK)', 'Micon (DK)', 'Vestas (DK)', ...
    'WindWorld (DK)', 'Enercon (DE)', 'Fuhrlaender (DE)', 'Nordex (DE)', ...
    'Suedwind (DE)', 'Tacke (DE)'};
f_order = [ 1 2 3 4 5 7 8 6 9 10];

%%
% 
% %Opening...
% fprintf(fid, '\\begin{table}[htbp] \n \\begin{center} \n'); 
% fprintf(fid, '\\caption{Baseline and Counterfactual Profit Estimates.} \n');
% fprintf(fid, '\\begin{tabular}{lccc|ccc}\n \\hline \\hline \n');
% 
% %Headers...
% fprintf(fid, ' & \\multicolumn{3}{c|}{Denmark} & \\multicolumn{3}{c}{Germany} \\\\ \n');
% fprintf(fid, ' & Estimates & No Fixed & No Border & Estimates & No Fixed & No Border \\\\ \n ');
% fprintf(fid, ' &           &  Costs   &  Costs    &           &  Costs   &  Costs  \\\\ \n \\hline \n');
% 
% %Guts...
% for f = 1:length(firmnames)
%     fprintf(fid, '%s & %.2f & %.2f & %.2f & %.2f & %.2f & %.2f \\\\ \n', firmnames{f}, ...
%         e_profits(2, f_order(f)), e_profitsNF(2, f_order(f)), e_profitsNB(2, f_order(f)), ...
%         e_profits(1, f_order(f)), e_profitsNF(1, f_order(f)), e_profitsNB(1, f_order(f)));
%     fprintf(fid, '\t & { \\footnotesize (%.2f) } & { \\footnotesize (%.2f) } & { \\footnotesize (%.2f) } & { \\footnotesize (%.2f) } & { \\footnotesize (%.2f) } & { \\footnotesize (%.2f) } \\\\ \n', ...
%         profits_se(2, f_order(f)), profitsNF_se(2, f_order(f)), profitsNB_se(2, f_order(f)), ...
%         profits_se(1, f_order(f)), profitsNF_se(1, f_order(f)), profitsNB_se(1, f_order(f)));
% end
% 
% fprintf(fid, '\\hline \n \\multicolumn{7}{l}{Note: Scale is normalized by variance of $\\epsilon$. } \\\\ \n \\end{tabular} \n');
% fprintf(fid, '\\end{center} \n \\end{table} \n\n');
% 
% %% Option 2:
% %Opening...
% fprintf(fid, '\\begin{table}[htbp] \n \\begin{center} \n'); 
% fprintf(fid, '\\caption{Baseline and Counterfactual Profit Estimates.} \n');
% fprintf(fid, '\\begin{tabular}{lccccc}\n \\hline \\hline \n');
% 
% %Headers...
% fprintf(fid, ' & \\multicolumn{3}{c}{Denmark} & \\multicolumn{2}{c}{Germany} \\\\ \n');
% fprintf(fid, ' & Estimates & No Fixed & No Border & Estimates &  No Border \\\\ \n ');
% fprintf(fid, ' &           &  Costs   &  Costs    &           &   Costs    \\\\ \n \\hline \n');
% 
% %Guts...
% for f = 1:length(firmnames)
%     fprintf(fid, '%s & %.2f & %.2f & %.2f & %.2f & %.2f   \\\\ \n', firmnames{f}, ...
%         e_profits(2, f_order(f)), e_profitsNF(2, f_order(f)), e_profitsNB(2, f_order(f)), ...
%         e_profits(1, f_order(f)),  e_profitsNB(1, f_order(f)));
%     fprintf(fid, '\t & { \\footnotesize (%.2f) } & { \\footnotesize (%.2f) } & { \\footnotesize (%.2f) } & { \\footnotesize (%.2f) } & { \\footnotesize (%.2f) } \\\\ \n', ...
%         profits_se(2, f_order(f)), profitsNF_se(2, f_order(f)), profitsNB_se(2, f_order(f)), ...
%         profits_se(1, f_order(f)),  profitsNB_se(1, f_order(f)));
% end
% 
% fprintf(fid, '\\hline \n \\multicolumn{6}{l}{Note: Scale is normalized by variance of $\\epsilon$. } \\\\ \n \\end{tabular} \n');
% fprintf(fid, '\\end{center} \n \\end{table} \n\n');



%% Option 3: Which we are presently using...

%Opening...
fprintf(fid, '\\begin{table}[htbp] \n \\begin{center} \n'); 
fprintf(fid, '\\caption{Baseline and Counterfactual Profit Estimates.} \n');
fprintf(fid, '\\begin{tabular}{lccc|ccc}\n \\hline \\hline \n');

%Headers...
fprintf(fid, ' & \\multicolumn{3}{c|}{Denmark} & \\multicolumn{3}{c}{Germany} \\\\ \n');
fprintf(fid, ' & Estimates & No Fixed & No Border & Estimates & \\hspace{.5in} & No Border \\\\ \n ');
fprintf(fid, ' &           &  Costs   &  Costs    &           &                &  Costs  \\\\ \n \\hline \n');

%Guts...
for f = 1:length(firmnames)
    fprintf(fid, '%s & %.2f & %.2f & %.2f & %.2f & \t & %.2f  \\\\ \n', firmnames{f}, ...
        e_profits(2, f_order(f)), e_profitsNF(2, f_order(f)), e_profitsNB(2, f_order(f)), ...
        e_profits(1, f_order(f)),  e_profitsNB(1, f_order(f)));
    fprintf(fid, '\t & { \\footnotesize (%.2f) } & { \\footnotesize (%.2f) } & { \\footnotesize (%.2f) } & { \\footnotesize (%.2f) } & \t & { \\footnotesize (%.2f) }  \\\\ \n', ...
        profits_se(2, f_order(f)), profitsNF_se(2, f_order(f)), profitsNB_se(2, f_order(f)), ...
        profits_se(1, f_order(f)), profitsNB_se(1, f_order(f)));
end

fprintf(fid, '\\hline \n \\multicolumn{7}{l}{Note: Scale is normalized by variance of $\\epsilon$. } \\\\ \n \\end{tabular} \n');
fprintf(fid, '\\label{tab:Profits} \n')
fprintf(fid, '\\end{center} \n \\end{table} \n\n');




%% Now the Fixed Cost table

%Opening...
fprintf(fid, '\\begin{table}[htbp] \n \\begin{center} \n'); 
fprintf(fid, '\\caption{Export Fixed Cost Bounds.} \n');
fprintf(fid, '\\begin{tabular}{lcc}\n \\hline \\hline \n');

%Headers...
fprintf(fid, ' & Lower & Upper \\\\ \n \\hline \n ');

%Guts...
for f = 1:length(firmnames)
    if (~isnan(e_fc_bounds(f_order(f), 1)))
        fprintf(fid, '%s & %.2f &   \\\\ \n', firmnames{f}, e_fc_bounds(f_order(f), 1));
        fprintf(fid, ' & { \\footnotesize (%.2f) } &  \\\\ \n', fc_bounds_se(f_order(f), 1));
    else
        fprintf(fid, '%s &  & %.2f  \\\\ \n', firmnames{f}, e_fc_bounds(f_order(f), 2));
        fprintf(fid, ' &  & { \\footnotesize (%.2f) }  \\\\ \n', fc_bounds_se(f_order(f), 2));
    end
end

fprintf(fid, '\\hline \n \\multicolumn{3}{l}{Note: Scale is normalized by variance of $\\epsilon$. } \\\\ \n \\end{tabular} \n');
fprintf(fid, '\\label{tab:Bounds} \n')
fprintf(fid, '\\end{center} \n \\end{table} \n\n');


