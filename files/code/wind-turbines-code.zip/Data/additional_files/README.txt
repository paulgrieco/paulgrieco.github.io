
README - RoadDistance Calc



This directory contains the code used to query road distances between manufacturer locations and projects. The code for this portion of the project is written in python and makes use of the Google API. The input and output files for the Danish projects are provided. The German files are proprietary. 

To run the code, make sure that distmat.py is executable and that you have a working internet connection. Then run

$ ./distmat.py python_danishprojects.csv python_producers.csv distances.out

This will take several days to run, as google only allows a fixed number of queries per day.  After the query limit is used, the program "sleeps" for 24 hours before submitting additional queries. 

If you just want to test the code, the file smallproj.csv contains only the first 9 projects, run

$ ./distmat.py smallproj.csv python_producers.csv distances.out

Which will complete in a few seconds.  

The dataset in the paper was constructed with calculated distances as of 2011, some distances may have changed due to updates to the German/Danish road network and Google's algorithm for road distances, however these changes should be small.