Production files for "Strategic Patient Discharge: The Case of Long-Term Care Hospitals"
by Paul Eliason, Paul Grieco, Ryan McDevitt, and James Roberts

I. Data cleaning and formatting files.  These must be run in the following order:

    1.  claim_count.do - Uses the MEDPAR data co identify the CMS provider numbers that have positive Medicare claims.  This will be used in POS_datawork.do to drop LTCHs without any claims.
    
    2. POS_datawork.do.  This code extracts long-term care hospitals from the Medicare Provider of Service Files and cleans the data for analysis. It also merges in data collected (by hand) from AHA surveys (found in auxiliary/AHA_tomerge2.dta) and from the LTCHPPS historic Impact Files (found in auxiliary/LTCHPPS_Impact_File_ALL.dta)
    
    3. drg_data.do.  This combines the DRG data (from CMS) and save as dta.
    
    4. LTHC_MEDPAR_datawork.do.  This takes the MEDPAR claims (not included in production files due to DUA restrictions), cleans them, merges in the hospital data and formats it into a flat file for analysis in Stata.
    
    5. data2matlab.do---This uses the resulting flat file from LTCH_MEDPAR_datawork_v5.do (a stata file) and reformats it for estimation of the dynamic model in Matlab.
    
 
    
    
II. Summary Statistics Tables

    tables_summary_statistics_I.do---This generates the following summary statistics tables: Table 1, Table 2, Table A1, and Table A2.
    
    tables_summary_statistics_II.do---This generates table A4, table A5, and table A6.
    
III. Reduced Form Tables    
    
    table3.do---Estimates probit models displayed in table 3, table A8, and table A9.
    
    table4.do---Estimates probit models displayed in table 4 and table A10.
    
    tableA3.do---Generates table A3.    
    
IV. Structural Model
    A.  Estimation    
        1.  LTCH_dynamic_model1.m estimates the dynamic structural model of patient discharge displayed in column (1) of table 5 (No patient types or DOW dummies).
        2.  LTCH_dynamic_model2.m estimates the dynamic structural model of patient discharge displayed in column (2) of table 5 (Patient types and DOW dummies).
    B.  Tables and Figures
        1. LTCH_dynamic_model2_analysis.m takes the estimaets from LTCH_dynamic_model2.m and simulates the counterfactual results shown in Table 6, Figure 8, and Figure A3.
        
V.  Other figures
    figure1_A2.do creates figure 1 and panels a, c, and e from figure A2.
    
    figures_histograms.do creates figure 2, figure 3, figure 4, figure 5, figure 6, figure 7, figure A1, and panels b, d, f from figure A2.
    