function [ stats ] = cfac_stats2( discharges,sso,baseline,payoff, ...
                                       costs,basepay,basecost,cbsa_ltch,drg )
%  This generates stats for the counterfactual table.  The output is a 
%   vector with the following elements:
%
%  1.  Share of patients discharged before magic day
%  2.  Share of patients discharged on or after magic day
%  3.  Share of patients discharged after day 45
%  4.  Share of patients with longer stay compared to baseline
%  5.  Share of patients with shorter stay compared to baseline
%  5.5 Percent change in LOS relative to baseline
%  6.  Mean length of stay relevative to magic day
%  7.  St. dev length of stay relative to magic day
%  8.  Median day of discharge, relative to magic day
%  8.1 Mean LOS
%  8.2 STD LOS
%  8.3 Average Pct change in LOS
%  8.5 Of patients in LTCH three days before magic day, how many are held
%        until the magic day
%  8.75Of patients in LTCH three days before magic day, how many are
%        discharged in the three days after the magic day
%  9.  Mean Payments
% 10.  St. dev. payments
% 11.  Median payments
% 12.  Mean costs
% 13.  St. dev. costs
% 14.  Median costs
% 15.  Mean cost monopolist
% 16.  Mean cost 2-3 LTCHs
% 17.  Mean cost 4+ LTCHs
% 18.  Average pct change in cost in monopolist
% 19.  Average pct change in cost in 2-3 LTCH CBSA
% 20.  Average pct change in cost in 4+ LTCH CBSA
%  ALL IN THAT ORDER

%% Shares before and after magic day
I_disch = truncmax(discharges);
sbmd = mean(I_disch<sso);
samd = mean(I_disch>=sso);
sa45 = mean(I_disch==46);

%% Comparisons to baseline
I_base = truncmax(baseline);
slb = mean(I_disch>I_base);
ssb = mean(I_disch<I_base);

%% Percent change in LOS relative to baseline
pcrb = mean((I_disch - I_base)./I_base);

%% Mean, std, median length of stay

LOS_rmd = I_disch-ceil(sso);
LOS_rmd = LOS_rmd(I_disch<46);
mndod = mean(LOS_rmd);
sddod = std(LOS_rmd);
mddod = median(LOS_rmd);
mnlos = mean(I_disch);
sdlos = std(I_disch);


%For purposes of summing up payoffs and costs, I add up only the first 45
   % days for observations staying longer than 45
   
%Number of patients in hospital at day rmd -3
nprmdn3 = sum(I_disch>=floor(sso)-3);
%conditioning on being in the hospital at day rmd -3, how many are in the
%hospital at rmd 0
nprmdn0 = sum( (I_disch>floor(sso)));
%conditioning on being in the hospital at day rmd -3, how many are
%discharged in rmd 0 - 3
nprmdn03 = sum((I_disch>=ceil(sso) & I_disch<=ceil(sso)+3));

sphmd = nprmdn0/nprmdn3;
spdm03 = nprmdn03/nprmdn3;
   
I_disch(I_disch==46)=45;
I_base(I_base==46)=45;
%% Payments
for i = 1:size(payoff,1);
    totpay(i) = sum(payoff(i,1:I_disch(i)),2)/1000;
    totcosts(i) = sum(costs(i,1:I_disch(i)),2)/1000;
    btotpay(i) = sum(basepay(i,1:I_base(i)),2)/1000;
    btotcost(i)= sum(basecost(i,1:I_base(i)),2)/1000;
end

mnpay = mean(totpay(totpay~=0));
sdpay = std(totpay(totpay~=0));
mdpay = median(totpay(totpay~=0));
pcprb = ((totpay - btotpay)./btotpay);
pcprb = mean(pcprb(btotpay~=0 & totpay~=0));

%% Costs
mncost = mean(totcosts);
sdcost = std(totcosts);
mdcost = median(totcosts);
pccrb = ((totcosts - btotcost)./btotcost);
pccrb = mean(pccrb(btotcost~=0 & totcosts~=0));

%%Payments by market structure
monop = cbsa_ltch'==1;
comp1 = cbsa_ltch'==2 | cbsa_ltch'==3;
comp2  = cbsa_ltch'>=4;

pmt_monop = mean(totpay(monop==1));
pmt_comp1 = mean(totpay(comp1==1));
pmt_comp2 = mean(totpay(comp2==1 & cbsa_ltch'~=9999));

pcprb_ms = ((totpay - btotpay)./btotpay);
pcprb_monop = mean(pcprb_ms(monop==1 & btotpay~=0));
pcprb_comp1 = mean(pcprb_ms(comp1==1 & btotpay~=0));
pcprb_comp2 = mean(pcprb_ms(comp2==1 & cbsa_ltch'~=9999 & btotpay~=0));

%% Costs by market structure

cost_monop = mean(totcosts(monop==1));
cost_comp1 = mean(totcosts(comp1==1));
cost_comp2 = mean(totcosts(comp2==1 & cbsa_ltch'~=9999));

pccrb_ms = ((totcosts - btotcost)./btotcost);
pccrb_monop = mean(pccrb_ms(monop==1 & btotcost~=0));
pccrb_comp1 = mean(pccrb_ms(comp1==1 & btotcost~=0));
pccrb_comp2 = mean(pccrb_ms(comp2==1 & cbsa_ltch'~=9999 & btotcost~=0));

stats = [sbmd, samd, sa45, slb, ssb, pcrb, mndod,sddod,mddod,mnlos,...
         sdlos,sphmd,spdm03,mnpay,sdpay,mdpay,pcprb,mncost,sdcost,...
         mdcost,pccrb,pmt_monop,pmt_comp1,pmt_comp2,pcprb_monop, ...
         pcprb_comp1,pcprb_comp2,cost_monop,cost_comp1,cost_comp2, ...
         pccrb_monop,pccrb_comp1,pccrb_comp2]';


end

