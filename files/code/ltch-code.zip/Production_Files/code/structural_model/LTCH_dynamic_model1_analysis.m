%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% LTCHdyn_v11_cubic_uflow_analysis.m
% Paul Eliason, 9/5/2017
% paul.eliason@duke.edu
%
% Analysis with estimates from v11 with cubic time trends
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all
setDropboxPath
cd 'Projects/LTCH';
addpath 'work/matlab/dynamic';

load('parameters_1.mat');
cbsa_ltch1 = csvread('data/matlab/cbsa_ltch2Matlab_v2.csv');
cbsa_ltch = cbsa_ltch1;

disp('Likelihood');
ll
disp('Exit Flag');
ef

%%%%%%%%%%%%Tests and simulation%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if ef==1,
    est = est1; 
    se  = se1;
end
if ef~=1,
    est = est2;
    se  = est2;
end

est(end-drg_count+1:end) = est(end-drg_count+1:end)*100;
se(end-drg_count+1:end)  = se(end-drg_count+1:end)*100;

X=[permute(payoffs2,[1 3 2]).*permute(repmat(ownership(:,1),1,T+1),[1 3 2]), ...
   permute(payoffs2,[1 3 2]).*permute(repmat(ownership(:,2),1,T+1),[1 3 2]), ...
   permute(payoffs2,[1 3 2]).*permute(repmat(ownership(:,3),1,T+1),[1 3 2]), ...
   permute(payoffs2,[1 3 2]).*permute(repmat(ownership(:,4),1,T+1),[1 3 2]), ...
   permute(costs2,[1 3 2]).*permute(repmat(ownership(:,1),1,T+1),[1 3 2]), ...
   permute(costs2,[1 3 2]).*permute(repmat(ownership(:,2),1,T+1),[1 3 2]), ...
   permute(costs2,[1 3 2]).*permute(repmat(ownership(:,3),1,T+1),[1 3 2]), ...
   permute(costs2,[1 3 2]).*permute(repmat(ownership(:,4),1,T+1),[1 3 2]), ...
   permute(ts2,[3 2 1]).*[repmat(drg==1,1,3,T+1)], ... %lambda 1
   permute(ts2,[3 2 1]).*[repmat(drg==2,1,3,T+1)], ... %lambda 2
   permute(ts2,[3 2 1]).*[repmat(drg==3,1,3,T+1)], ... %lambda 3
   permute(ts2,[3 2 1]).*[repmat(drg==4,1,3,T+1)], ... %lambda 4
   permute(ts2,[3 2 1]).*[repmat(drg==5,1,3,T+1)], ... %lambda 5
   permute(ts2,[3 2 1]).*[repmat(drg==6,1,3,T+1)], ... %lambda 6
   permute(ts2,[3 2 1]).*[repmat(drg==7,1,3,T+1)], ... %lambda 7
   permute(ts2,[3 2 1]).*[repmat(drg==8,1,3,T+1)], ... %lambda 8
   permute(ts2,[3 2 1]).*[repmat(drg==9,1,3,T+1)], ... %lambda 9
   permute(repmat([zeros(N,T),drg==1],1,1,1),[1 3 2]), ... %Omega 1
   permute(repmat([zeros(N,T),drg==2],1,1,1),[1 3 2]), ... %Omega 2
   permute(repmat([zeros(N,T),drg==3],1,1,1),[1 3 2]), ... %Omega 3
   permute(repmat([zeros(N,T),drg==4],1,1,1),[1 3 2]), ... %Omega 4
   permute(repmat([zeros(N,T),drg==5],1,1,1),[1 3 2]), ... %Omega 5
   permute(repmat([zeros(N,T),drg==6],1,1,1),[1 3 2]), ... %Omega 6
   permute(repmat([zeros(N,T),drg==7],1,1,1),[1 3 2]), ... %Omega 7
   permute(repmat([zeros(N,T),drg==8],1,1,1),[1 3 2]), ... %Omega 8
   permute(repmat([zeros(N,T),drg==9],1,1,1),[1 3 2])]; %Omega 9

X0=[permute(payoffs2,[1 3 2]).*permute(repmat(ownership(:,1),1,T+1),[1 3 2]), ...
   permute(payoffs2,[1 3 2]).*permute(repmat(ownership(:,2),1,T+1),[1 3 2]), ...
   permute(payoffs2,[1 3 2]).*permute(repmat(ownership(:,3),1,T+1),[1 3 2]), ...
   permute(payoffs2,[1 3 2]).*permute(repmat(ownership(:,4),1,T+1),[1 3 2]), ...
   permute(costs2,[1 3 2]).*permute(repmat(ownership(:,1),1,T+1),[1 3 2]), ...
   permute(costs2,[1 3 2]).*permute(repmat(ownership(:,2),1,T+1),[1 3 2]), ...
   permute(costs2,[1 3 2]).*permute(repmat(ownership(:,3),1,T+1),[1 3 2]), ...
   permute(costs2,[1 3 2]).*permute(repmat(ownership(:,4),1,T+1),[1 3 2]), ...
   permute(ts2,[3 2 1]).*[repmat(drg==1,1,4,T+1)], ... %lambda 1
   permute(ts2,[3 2 1]).*[repmat(drg==2,1,4,T+1)], ... %lambda 2
   permute(ts2,[3 2 1]).*[repmat(drg==3,1,4,T+1)], ... %lambda 3
   permute(ts2,[3 2 1]).*[repmat(drg==4,1,4,T+1)], ... %lambda 4
   permute(ts2,[3 2 1]).*[repmat(drg==5,1,4,T+1)], ... %lambda 5
   permute(ts2,[3 2 1]).*[repmat(drg==6,1,4,T+1)], ... %lambda 6
   permute(ts2,[3 2 1]).*[repmat(drg==7,1,4,T+1)], ... %lambda 7
   permute(ts2,[3 2 1]).*[repmat(drg==8,1,4,T+1)], ... %lambda 8
   permute(ts2,[3 2 1]).*[repmat(drg==9,1,4,T+1)], ... %lambda 9
   permute(repmat([zeros(N,T),drg==1],1,1,1),[1 3 2]), ... %Omega 1
   permute(repmat([zeros(N,T),drg==2],1,1,1),[1 3 2]), ... %Omega 2
   permute(repmat([zeros(N,T),drg==3],1,1,1),[1 3 2]), ... %Omega 3
   permute(repmat([zeros(N,T),drg==4],1,1,1),[1 3 2]), ... %Omega 4
   permute(repmat([zeros(N,T),drg==5],1,1,1),[1 3 2]), ... %Omega 5
   permute(repmat([zeros(N,T),drg==6],1,1,1),[1 3 2]), ... %Omega 6
   permute(repmat([zeros(N,T),drg==7],1,1,1),[1 3 2]), ... %Omega 7
   permute(repmat([zeros(N,T),drg==8],1,1,1),[1 3 2]), ... %Omega 8
   permute(repmat([zeros(N,T),drg==9],1,1,1),[1 3 2])]; 

%%Statistical test for equivalence of alphas and betas
alpha_hat = est(1:4);
alpha_se = se(1:4);
beta_hat  = est(5:8);
beta_se   = se(5:8);
%T-test for difference of alphas
disp('T-tests for differences among alphas');
t_alpha(1) = (alpha_hat(1)-alpha_hat(2))/sqrt(alpha_se(1)^2+alpha_se(2)^2);
t_alpha(2) = (alpha_hat(1)-alpha_hat(3))/sqrt(alpha_se(1)^2+alpha_se(3)^2);
t_alpha(3) = (alpha_hat(1)-alpha_hat(4))/sqrt(alpha_se(1)^2+alpha_se(4)^2);
t_alpha(4) = (alpha_hat(2)-alpha_hat(3))/sqrt(alpha_se(2)^2+alpha_se(3)^2);
t_alpha(5) = (alpha_hat(2)-alpha_hat(4))/sqrt(alpha_se(2)^2+alpha_se(4)^2);
t_alpha(6) = (alpha_hat(3)-alpha_hat(4))/sqrt(alpha_se(3)^2+alpha_se(4)^2);
disp(t_alpha');
%T-test for difference of betas
disp('T-tests for differences among betas');
t_beta(1) = (beta_hat(1) - beta_hat(2))/sqrt(beta_se(1)^2+beta_se(2)^2);
t_beta(2) = (beta_hat(1) - beta_hat(3))/sqrt(beta_se(1)^2+beta_se(3)^2);
t_beta(3) = (beta_hat(1) - beta_hat(4))/sqrt(beta_se(1)^2+beta_se(4)^2);
t_beta(4) = (beta_hat(2) - beta_hat(3))/sqrt(beta_se(2)^2+beta_se(3)^2);
t_beta(5) = (beta_hat(2) - beta_hat(4))/sqrt(beta_se(2)^2+beta_se(4)^2);
t_beta(6) = (beta_hat(3) - beta_hat(4))/sqrt(beta_se(3)^2+beta_se(4)^2);
disp(t_beta');

%% Genearting discharge distribution using the estimated lambdas
%%Random draws of patients for simulated and counterfactual discharge
%%distributions
N_s = 300000;
sig = 0;
sim_pats = randi(N,N_s,1);

sX = X(sim_pats,:,:);
sX0 = X0(sim_pats,:,:);
ssso_thresh = sso_thresh(sim_pats);
scDRG = cDRG(sim_pats);

scbsa_ltch = cbsa_ltch(sim_pats);

%Type I EV draws
%Seed
ek = evrnd(0,1,N_s,T)*(-1);
ed = evrnd(0,1,N_s,T)*(-1);

%Drawing random coefficient
phi = 0;



%%Predicting discharge dates and matrix indicating "still in hospital"
[basedisch,baserm,VK] = ...
LTCH_sim(est,sX,T,N_s,delta,drg_count,ek,ed,phi);


%Plotting value function, centered on magic day
[days_rmd,VK_rmd] = aux_stats_rmd2(VK,baserm,ssso_thresh);
figure('Color',[1 1 1]);
plot(days_rmd,VK_rmd);
xlabel('Days Relative to SSO Threshold');
ylabel('Mean Value Function');
export_fig 'output/dynamic_results/LTCHdyn_v11_cubic_uflow_VK.pdf';

%Plotting observed and model predicted discharge patterns
% Discharge probabilities relative to magic day

[real_pd_rmd,real_days_rmd,real_disch_rmd] = prob_disch_rmd_v2( ...
                    discharges,sso_thresh);

[base_pd_rmd,base_days_rmd,base_disch_rmd] = prob_disch_rmd_v2( ...
                    basedisch,ssso_thresh);
 
%Goodness of fit --- All
figure('Color',[1 1 1]);
h1 = plot(real_days_rmd,mean(real_disch_rmd,1),'-r');
hold on;
h2 = plot(base_days_rmd,mean(base_disch_rmd,1),'--b');
h3 = plot([0,0],[0,0.2],'-g');
legend([h1 h2],{'Observed Distribution of Discharges', ...
                'Predicted Distribution of Discharges'},'northwest');
xlabel('Days Relative to SSO Threshold');
ylabel('Pr(Discharge_t)');
export_fig 'output/dynamic_results/LTCHdyn_v11_cubic_uflow_g1_ALL.pdf';



%Goodness of fit --- 207
              
figure('Color',[1 1 1]);
h1 = plot(real_days_rmd,mean(real_disch_rmd(cDRG==207,:),1),'-r');
hold on;
h2 = plot(base_days_rmd,mean(base_disch_rmd(scDRG==207,:),1),'--b');
h3 = plot([0,0],[0,0.2],'-g');
legend([h1 h2],{'Observed Distribution of Discharges', ...
                'Predicted Distribution of Discharges'},'northwest');
xlabel('Days Relative to SSO Threshold');
ylabel('Pr(Discharge_t)');
export_fig 'output/dynamic_results/LTCHdyn_v11_cubic_uflow_g1_207.pdf';


%Plot of average value function

[basedisch_Temp,baserm_temp,Vk_temp] = ...
LTCH_sim(est(1:end),sX0,T,N_s,delta,drg_count,ek,ed,0);

%Evolution of health-types remaining in hospital
[days_rmd,Vk_rmd] = aux_stats_rmd2(Vk_temp,baserm_temp, ...
                                    ssso_thresh);

figure('Color',[1 1 1]);
h1 = plot(days_rmd,Vk_rmd);
hold on;
%h2 = plot([1:45],mean((1-baserm).*repmat(phi,1,T),1));
%h3 = plot([0,0],[0,0.2],'-g');
% legend([h1 ],{'Mean Expected Value Function'},'northwest');
xlabel('Days in Hospital');
ylabel('Mean Expected Value Function');
export_fig '../../../output/dynamic_results/LTCHdyn_v11_uflow_VF_ALL.pdf';

% counterfactual_table(

%%Counterfactual 1 -- alpha==0
c1est = est;
c1est(1:4) = 0;
[c1disch,c1rm] = LTCH_sim(c1est,sX,T,N_s,delta,drg_count, ...
                                    ek,ed,phi);

[c1_pd_rmd,c1_days_rmd,c1_disch_rmd] = prob_disch_rmd_v2( ...
                    c1disch,ssso_thresh);
                
%-Counterfactual 1 figures
%---All
figure('Color',[1 1 1]);
h2 = plot(c1_days_rmd,mean(c1_disch_rmd,1),'-^k');
hold on;
h1 = plot(base_days_rmd,mean(base_disch_rmd,1),'--b');
h3 = plot([0,0],[0,0.2],'-g');
legend([h1 h2],{'Predicted Distribution of Discharges', ...
                '\alpha = 0 Counterfactual'},'northwest');
xlabel('Days Relative to SSO Threshold');
ylabel('Pr(Discharge_t)');
export_fig 'output/dynamic_results/LTCHdyn_v11_cubic_uflow_c1_ALL_alpha.pdf';

%---207
figure('Color',[1 1 1]);
h2 = plot(c1_days_rmd,mean(c1_disch_rmd(scDRG==207,:),1),'-^k');
hold on;
h1 = plot(base_days_rmd,mean(base_disch_rmd(scDRG==207,:),1),'--b');
h3 = plot([0,0],[0,0.2],'-g');
legend([h1 h2],{'Predicted Distribution of Discharges', ...
                '\alpha = 0 Counterfactual'},'northwest');
xlabel('Days Relative to SSO Threshold');
ylabel('Pr(Discharge_t)');
export_fig 'output/dynamic_results/LTCHdyn_v11_cubic_uflow_c1_207_alpha.pdf';

%%Counterfactual 2

% Generating per-diem payoffs (c1payments)
geo_mean  = ceil(geo_mean);
c2pay = fullpayment./geo_mean;
c2payoffs = [];
c2payoffs(:,1) = 2*c2pay;
for t = 2:T,
   c2payoffs(:,t) = c2pay.*(t<geo_mean); 
end

c2payoffs = [c2payoffs,zeros(N,1)];

c2X = [permute(c2payoffs,[1 3 2]).*permute(repmat(ownership(:,1),1,T+1),[1 3 2]), ...
   permute(c2payoffs,[1 3 2]).*permute(repmat(ownership(:,2),1,T+1),[1 3 2]), ...
   permute(c2payoffs,[1 3 2]).*permute(repmat(ownership(:,3),1,T+1),[1 3 2]), ...
   permute(c2payoffs,[1 3 2]).*permute(repmat(ownership(:,4),1,T+1),[1 3 2]), ...
   permute(costs2,[1 3 2]).*permute(repmat(ownership(:,1),1,T+1),[1 3 2]), ...
   permute(costs2,[1 3 2]).*permute(repmat(ownership(:,2),1,T+1),[1 3 2]), ...
   permute(costs2,[1 3 2]).*permute(repmat(ownership(:,3),1,T+1),[1 3 2]), ...
   permute(costs2,[1 3 2]).*permute(repmat(ownership(:,4),1,T+1),[1 3 2]), ...
   permute(ts2,[3 2 1]).*[repmat(drg==1,1,4,T+1)], ... %lambda 1
   permute(ts2,[3 2 1]).*[repmat(drg==2,1,4,T+1)], ... %lambda 2
   permute(ts2,[3 2 1]).*[repmat(drg==3,1,4,T+1)], ... %lambda 3
   permute(ts2,[3 2 1]).*[repmat(drg==4,1,4,T+1)], ... %lambda 4
   permute(ts2,[3 2 1]).*[repmat(drg==5,1,4,T+1)], ... %lambda 5
   permute(ts2,[3 2 1]).*[repmat(drg==6,1,4,T+1)], ... %lambda 6
   permute(ts2,[3 2 1]).*[repmat(drg==7,1,4,T+1)], ... %lambda 7
   permute(ts2,[3 2 1]).*[repmat(drg==8,1,4,T+1)], ... %lambda 8
   permute(ts2,[3 2 1]).*[repmat(drg==9,1,4,T+1)], ... %lambda 9
   permute(repmat([zeros(N,T),drg==1],1,1,1),[1 3 2]), ... %Omega 1
   permute(repmat([zeros(N,T),drg==2],1,1,1),[1 3 2]), ... %Omega 2
   permute(repmat([zeros(N,T),drg==3],1,1,1),[1 3 2]), ... %Omega 3
   permute(repmat([zeros(N,T),drg==4],1,1,1),[1 3 2]), ... %Omega 4
   permute(repmat([zeros(N,T),drg==5],1,1,1),[1 3 2]), ... %Omega 5
   permute(repmat([zeros(N,T),drg==6],1,1,1),[1 3 2]), ... %Omega 6
   permute(repmat([zeros(N,T),drg==7],1,1,1),[1 3 2]), ... %Omega 7
   permute(repmat([zeros(N,T),drg==8],1,1,1),[1 3 2]), ... %Omega 8
   permute(repmat([zeros(N,T),drg==9],1,1,1),[1 3 2])]; 
   
   

c2X = c2X(sim_pats,:,:);
[c2disch,c2rm] = LTCH_sim(est,c2X,T,N_s,delta,drg_count,ek,ed,phi);

[c2_pd_rmd,c2_days_rmd,c2_disch_rmd] = prob_disch_rmd_v2( ...
                    c2disch,ssso_thresh);
                
%-Counterfactual 2 figures
%---All
figure('Color',[1 1 1]);
h2 = plot(c2_days_rmd,mean(c2_disch_rmd,1),'-dk');
hold on;
h1 = plot(base_days_rmd,mean(base_disch_rmd,1),'--b');
h3 = plot([0,0],[0,0.2],'-g');
legend([h1 h2],{'Predicted Distribution of Discharges', ...
                'Per Diem Counterfactual'},'northwest');
xlabel('Days Relative to SSO Threshold');
ylabel('Pr(Discharge_t)');
export_fig 'output/dynamic_results/LTCHdyn_v11_cubic_uflow_c2_ALL.pdf';

%---207
figure('Color',[1 1 1]);
h2 = plot(c2_days_rmd,mean(c2_disch_rmd(scDRG==207,:),1),'-dk');
hold on;
h1 = plot(base_days_rmd,mean(base_disch_rmd(scDRG==207,:),1),'--b');
h3 = plot([0,0],[0,0.2],'-g');
legend([h1 h2],{'Predicted Distribution of Discharges', ...
                'Per Diem Counterfactual'},'northwest');
xlabel('Days Relative to SSO Threshold');
ylabel('Pr(Discharge_t)');
export_fig 'output/dynamic_results/LTCHdyn_v11_cubic_uflow_c2_207.pdf';


%%Counterfactual 3
c3X = [permute(costs2*1.05,[1 3 2]).*permute(repmat(ownership(:,1),1,T+1),[1 3 2]), ...
   permute(costs2*1.05,[1 3 2]).*permute(repmat(ownership(:,2),1,T+1),[1 3 2]), ...
   permute(costs2*1.05,[1 3 2]).*permute(repmat(ownership(:,3),1,T+1),[1 3 2]), ...
   permute(costs2*1.05,[1 3 2]).*permute(repmat(ownership(:,4),1,T+1),[1 3 2]), ...
   permute(costs2,[1 3 2]).*permute(repmat(ownership(:,1),1,T+1),[1 3 2]), ...
   permute(costs2,[1 3 2]).*permute(repmat(ownership(:,2),1,T+1),[1 3 2]), ...
   permute(costs2,[1 3 2]).*permute(repmat(ownership(:,3),1,T+1),[1 3 2]), ...
   permute(costs2,[1 3 2]).*permute(repmat(ownership(:,4),1,T+1),[1 3 2]), ...
   permute(ts2,[3 2 1]).*[repmat(drg==1,1,4,T+1)], ... %lambda 1
   permute(ts2,[3 2 1]).*[repmat(drg==2,1,4,T+1)], ... %lambda 2
   permute(ts2,[3 2 1]).*[repmat(drg==3,1,4,T+1)], ... %lambda 3
   permute(ts2,[3 2 1]).*[repmat(drg==4,1,4,T+1)], ... %lambda 4
   permute(ts2,[3 2 1]).*[repmat(drg==5,1,4,T+1)], ... %lambda 5
   permute(ts2,[3 2 1]).*[repmat(drg==6,1,4,T+1)], ... %lambda 6
   permute(ts2,[3 2 1]).*[repmat(drg==7,1,4,T+1)], ... %lambda 7
   permute(ts2,[3 2 1]).*[repmat(drg==8,1,4,T+1)], ... %lambda 8
   permute(ts2,[3 2 1]).*[repmat(drg==9,1,4,T+1)], ... %lambda 9
   permute(repmat([zeros(N,T),drg==1],1,1,1),[1 3 2]), ... %Omega 1
   permute(repmat([zeros(N,T),drg==2],1,1,1),[1 3 2]), ... %Omega 2
   permute(repmat([zeros(N,T),drg==3],1,1,1),[1 3 2]), ... %Omega 3
   permute(repmat([zeros(N,T),drg==4],1,1,1),[1 3 2]), ... %Omega 4
   permute(repmat([zeros(N,T),drg==5],1,1,1),[1 3 2]), ... %Omega 5
   permute(repmat([zeros(N,T),drg==6],1,1,1),[1 3 2]), ... %Omega 6
   permute(repmat([zeros(N,T),drg==7],1,1,1),[1 3 2]), ... %Omega 7
   permute(repmat([zeros(N,T),drg==8],1,1,1),[1 3 2]), ... %Omega 8
   permute(repmat([zeros(N,T),drg==9],1,1,1),[1 3 2])]; 

c3X = c3X(sim_pats,:,:);

[c3disch,c3rm] = LTCH_sim(est,c3X,T,N_s,delta,drg_count,ek,ed,phi);

[c3_pd_rmd,c3_days_rmd,c3_disch_rmd] = prob_disch_rmd_v2( ...
                    c3disch,ssso_thresh);
                
%-Counterfactual 3 figures
%---All
figure('Color',[1 1 1]);
h2 = plot(c3_days_rmd,mean(c3_disch_rmd,1),'-ok');
hold on;
h1 = plot(base_days_rmd,mean(base_disch_rmd,1),'--b');
h3 = plot([0,0],[0,0.2],'-g');
legend([h1 h2],{'Predicted Distribution of Discharges', ...
                'Cost-Plus Counterfactual'},'northwest');
xlabel('Days Relative to SSO Threshold');
ylabel('Pr(Discharge_t)');
export_fig 'output/dynamic_results/LTCHdyn_v11_cubic_uflow_c3_ALL.pdf';

%---207
figure('Color',[1 1 1]);
h2 = plot(c3_days_rmd,mean(c3_disch_rmd(scDRG==207,:),1),'-ok');
hold on;
h1 = plot(base_days_rmd,mean(base_disch_rmd(scDRG==207,:),1),'--b');
h3 = plot([0,0],[0,0.2],'-g');
legend([h1 h2],{'Predicted Distribution of Discharges', ...
                'Cost-Plus Counterfactual'},'northwest');
xlabel('Days Relative to SSO Threshold');
ylabel('Pr(Discharge_t)');
export_fig 'output/dynamic_results/LTCHdyn_v11_cubic_uflow_c3_207.pdf';

%%Counterfactual tables

%Observed data
realtab = cfac_stats2(discharges,sso_thresh,discharges,payoffs,costs, ...
    payoffs,costs,cbsa_ltch);

%Baseline model
spayoffs = payoffs(sim_pats,:);
scosts = costs(sim_pats,:);
basetab = cfac_stats2(basedisch,ssso_thresh,basedisch,spayoffs,scosts, ...
    spayoffs,scosts,scbsa_ltch);

%C1
c1tab = cfac_stats2(c1disch,ssso_thresh,basedisch,spayoffs,scosts, ...
    spayoffs,scosts,scbsa_ltch,drg(sim_pats));

%C2
c2tab = cfac_stats2(c2disch,ssso_thresh,basedisch, ...
        c2payoffs(sim_pats,1:end-1),scosts,spayoffs,scosts,scbsa_ltch);
   
%C3
c3tab = cfac_stats2(c3disch,ssso_thresh,basedisch, ...
        1.05*scosts,scosts,spayoffs,scosts,scbsa_ltch);
    
collabels = {'Real';'Baseline';'Cost-Min';'Per-Diem';'Cost-Plus'};
stats = {'Share discharged b4 MD','Share disch. after MD', ...
         'Share disch after 45','Share longer stay', ...
         'Share shorter stay','Pct Change in LOS','Mean LOS RMD', ...
         'STD LOS RMD', ...
         'Med. DOD RMD','MEAN LOS','STD LOS','3Pat to MD', ...
         '3Pat dischMD+3','Mean Pmt','Std Pmt','Med Pmt', ...
         'Pct Change Pmt','Mean Costs','Std. Costs','Med. Costs', ...
         'Pct Change Cost','Mean Pmt Monop','Mean Pmt 2-3 LTCH', ...
         'Mean Pmt 4+ LTCH','Pct Change Pmt Monop', ...
         'Pct Change Pmt 2-3 LTCH','Pct Change Pmt 4+ LTCH', ...
         'Mean Cost Monop','Mean Cost 2-3 LTCH', ...
         'Mean Cost 4+ LTCH','Pct Change Cost Monop', ...
         'Pct Change Cost 2-3 LTCH','Pct Change Cost 4+ LTCH'}';
Tab = table(stats,realtab,basetab,c1tab,c2tab,c3tab);
Tab

%Plotting lambda for DRG 207
gamma = est(25)+est(26)*ts + est(27)*ts.^2 + est(28)*ts.^3;
plot(ts,gamma)
ylabel('\lambda');
xlabel('Days in hospital');
export_fig 'output/dynamic_results/LTCHdyn_v11_cubic_uflow_g2_207.pdf';

gamma2 = -0.011530448 -0.040012733*ts + 0.000698269*ts.^2
plot(ts,gamma2)
ylabel('\lambda');
xlabel('Days in hospital');
export_fig 'output/dynamic_results/LTCHdyn_v11_uflow_g2_207.pdf';

%Simulations for black patients
sblack = black(sim_pats);
spayoffs = payoffs(sim_pats,:);
scosts = costs(sim_pats,:);

blackbasetab = cfac_stats2(basedisch(sblack==1,:), ...
    ssso_thresh(sblack==1,:), ...
    basedisch(sblack==1,:), ...
    spayoffs(sblack==1,:), ...
    scosts(sblack==1,:), ...
    spayoffs(sblack==1,:), ...
    scosts(sblack==1,:), ...
    scbsa_ltch(sblack==1,:));

%C1
blackc1tab = cfac_stats2(c1disch(sblack==1,:), ...
    ssso_thresh(sblack==1,:), ...
    basedisch(sblack==1,:), ...
    spayoffs(sblack==1,:), ...
    scosts(sblack==1,:), ...
    spayoffs(sblack==1,:), ...
    scosts(sblack==1,:), ...
    scbsa_ltch(sblack==1,:));

%C2
blackc2tab = cfac_stats2(c2disch(sblack==1,:), ...
    ssso_thresh(sblack==1,:), ...
    basedisch(sblack==1,:), ...
    c2payoffs(sblack==1,:), ...
    scosts(sblack==1,:), ...
    spayoffs(sblack==1,:), ...
    scosts(sblack==1,:), ...
    scbsa_ltch(sblack==1,:));
%C3
blackc3tab = cfac_stats2(c3disch(sblack==1,:), ...
    ssso_thresh(sblack==1,:), ...
    basedisch(sblack==1,:), ...
    1.05*scosts(sblack==1,:), ...
    scosts(sblack==1,:), ...
    spayoffs(sblack==1,:), ...
    scosts(sblack==1,:), ...
    scbsa_ltch(sblack==1,:));

blackTab = table(stats,blackbasetab,blackc1tab,blackc2tab,blackc3tab);


whitebasetab = cfac_stats2(basedisch(sblack==0,:), ...
    ssso_thresh(sblack==0,:), ...
    basedisch(sblack==0,:), ...
    spayoffs(sblack==0,:), ...
    scosts(sblack==0,:), ...
    spayoffs(sblack==0,:), ...
    scosts(sblack==0,:), ...
    scbsa_ltch(sblack==0,:));

%C1
whitec1tab = cfac_stats2(c1disch(sblack==0,:), ...
    ssso_thresh(sblack==0,:), ...
    basedisch(sblack==0,:), ...
    spayoffs(sblack==0,:), ...
    scosts(sblack==0,:), ...
    spayoffs(sblack==0,:), ...
    scosts(sblack==0,:), ...
    scbsa_ltch(sblack==0,:));

%C2
whitec2tab = cfac_stats2(c2disch(sblack==0,:), ...
    ssso_thresh(sblack==0,:), ...
    basedisch(sblack==0,:), ...
    c2payoffs(sblack==0,:), ...
    scosts(sblack==0,:), ...
    spayoffs(sblack==0,:), ...
    scosts(sblack==0,:), ...
    scbsa_ltch(sblack==0,:));
%C3
whitec3tab = cfac_stats2(c3disch(sblack==0,:), ...
    ssso_thresh(sblack==0,:), ...
    basedisch(sblack==0,:), ...
    1.05*scosts(sblack==0,:), ...
    scosts(sblack==0,:), ...
    spayoffs(sblack==0,:), ...
    scosts(sblack==0,:), ...
    scbsa_ltch(sblack==0,:));

whiteTab = table(stats,whitebasetab,whitec1tab,whitec2tab,whitec3tab);