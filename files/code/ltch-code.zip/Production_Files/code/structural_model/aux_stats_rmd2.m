function [ days_rmd,Vk_rmd ] = aux_stats_rmd2( Vk,baserm, ...
                            sso_thresh )
N=size(Vk,1);
thresh = ceil(sso_thresh+0.0001);
Vk_rmd = nan(N,29);
rm_rmd = nan(N,29);


for i = 1:N,
    Vk_rmd(i,:) = Vk(i,thresh(i)-14:thresh(i)+14);
    rm_rmd(i,:) = baserm(i,thresh(i)-14:thresh(i)+14);
end

Vk_rmd = mean(Vk_rmd,1);

days_rmd = [-14:14];


end

