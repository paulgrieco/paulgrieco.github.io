function [ pd_rmd,days_rmd ,disch_rmd] = ...
                        prob_disch_rmd_v2( discharges,sso_thresh )
%prob_disch_rmd--computes the probability of discharge by day realtive to
%the magic day.  This does it for 25 days before and 16 days after the
%magic day.

[N,T] = size(discharges);

%Getting indeces of magic day
I = ceil(sso_thresh+0.0000001);

Tp = 14;
Ta = 14;
disch_post = nan(N,Tp);
disch_pre  = nan(N,Ta);

ub = I+Tp;
lb = I-Ta;
disch_rmd = nan(N,Tp+Ta+1);
for i = 1:N,
    disch_rmd(i,:) = discharges(i,lb(i):ub(i));
end

rmd  = zeros(N,21);
for i =1:Ta+Tp+1,
   rmd(:,i)  = max( disch_rmd(:,1:i),[],2);
end

rmd = sum(rmd,1);

pd_rmd(1) = rmd(1)/N;

for i = 2:Ta+Tp+1,
    pd_rmd(i) = (rmd(i) - rmd(i-1))/(N - rmd(i-1));
end

days_rmd = [-1*Ta:1:Tp];

end

