function [SLL,g] = LTCH_ll_v11_uflow(param,X,T,N,delta,discharges,rm, ...
                                 drg_count)

b = param(1:end);
o=100;
b(end-drg_count+1:end) = b(end-drg_count+1:end)*o;


% widedisch = repmat(discharges,1,1,J);
% widerm    = repmat(rm,1,1,J);

Vk = nan(N,T);
Vd = nan(N,T);
EV = nan(N,T+1);
Pd = nan(N,T);
lPd = nan(N,T);

dEV = nan(N,T+1,size(param,2));

%Euler's constant
ec = 0.5772156649;

%Vk for state T is just equal to lambda.  This gives it a zero expected
%value
EV(:,T+1) = squeeze(X(:,:,T+1))*b';
dEV(:,T+1,1:end) = zeros(N,1,size(param,2));
dEV(:,T+1,end-drg_count+1:end) = ...
    permute(X(:,end-drg_count+1:end,T+1),[1 3 2]);

%Value function, expected value function and discharge probabilities by
%backwards induction

for t = T:-1:1,
   %Value function 
   Vk(:,t) = X(:,:,t)*b' + delta*EV(:,t+1);
   Vd(:,t) = X(:,:,t)*b';
   
   %Expected Value Function
   B = max(Vk(:,t),Vd(:,t));
   EV(:,t) = B+log(exp(Vk(:,t)-B)+exp(Vd(:,t)-B)) + ec;
   
%    %Discharge probabilities
   lPd(:,t) = Vd(:,t) - B - log(exp(Vd(:,t)-B) + exp(Vk(:,t)-B));
   lPk(:,t) = Vk(:,t) - B - log(exp(Vd(:,t)-B) + exp(Vk(:,t)-B));
   Pd(:,t) = exp(lPd(:,t));
%    Pk(:,t,j) = exp(lPk(:,t,j));
     
   %For Gradient
   dEV(:,t,:) = permute(X(:,:,t),[1 3 2]) + ...
                        delta*repmat(1-Pd(:,t),1,1,size(param,2)).* ...
                        dEV(:,t+1,:);

end


% %Log Likelihood Function
% A = log(w) + widedisch.*lPd + cumsum(log(1-Pd).*(1-widedisch).*(1-widerm),2); 
% 
% % A = log(w) + widedisch.*lPd + cumsum(lPk.*(1-widedisch).*(1-widerm),2); 
% 
% B = max(A,[],3);
% 
% P = cumprod((Pd.^widedisch) .* ...
%             (1-Pd).^((1 - widedisch).*(1-widerm)),2); 
a = lPd;
b = max(a,[],3);

c = lPk;
d = max(c,[],3);

SLL = -sum(sum(discharges.*(lPd) + ...
          (1-rm).*(1-discharges).*(lPk)));        


% SLL = -sum(sum(discharges.*(b + log(exp(a - b))) + ...
%           (1-rm).*(1-discharges).*(d + log(sum(exp(c -repmat(d,1,1)),3)))));        
        
% SLL = -sum(sum(B.*discharges + log(discharges.*sum(exp(A-repmat(B,1,1,J)),3) + ...
%                 (1-discharges))));
        
% P2 = squeeze(prod((1-Pd),2));
% nd = 1-sum(discharges,2);
%         
% SLL = -sum(sum(B.*discharges + log(discharges.*sum(exp(A-repmat(B,1,1,J)),3) ...
%                 + 1-discharges ),2 )+ ...
%                 nd.*sum(repmat(weights',N,1).*P2,2) + (1-nd)); 
            
% disp(param');
% disp(SLL);

%Gradient
% P2 = cumprod((1-Pd).^((1 - widedisch).*(1-widerm)),2);


dPd = -repmat(delta.*Pd.*(1-Pd),1,1,size(param,2)).*dEV(:,2:T+1,:);


% % dP = -delta*dEV(:,2:T+1,:,:).*repmat(P,1,1,1,size(param,2)).* ...
% %       (1-repmat(Pd,1,1,1,size(param,2))) + ...
% %       delta*repmat(P(:,1:end,:),1,1,1,size(param,2)).* ...
% %       (cumsum(repmat(Pd,1,1,1,size(param,2)).*dEV(:,2:T+1,:,:),2) - ...
% %       repmat(Pd,1,1,1,size(param,2)).*dEV(:,2:T+1,:,:));
% % % dP2 = dP(repmat(discharges==1,1,1,J,size(param,2))); 
M1 = min(realmax,1./Pd);
M2 = min(realmax,1./(1-Pd));
g = -squeeze(sum(sum(repmat(discharges.*M1,1,1,size(param,2)).*dPd + ...
            repmat((1-discharges).*(1-rm).*M2,1,1,size(param,2)).* ...
            (-1*dPd),2),1));
g(end-drg_count+1:end) = g(end-drg_count+1:end)*o;      
if sum(isnan(g))>0
    g
end


end