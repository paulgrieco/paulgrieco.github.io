function [ pdischarges,prm,Vk] = LTCH_sim( param,X,T,N,delta, ...
                                                    drg_count,ek,ed,phi)

b = param(1:end);



        
%Euler's constant
ec = 0.5772156649;

%Initializing value and expected value functions
EV  = nan(N,T+1);
Vk  = nan(N,T);
Vd  = nan(N,T);

%Constructing value function and discharge probabilities
EV(:,T+1) = squeeze(X(:,:,T+1))*b';

for t = T:-1:1,
    
    %Value function
    v = X(:,:,t)*b' + phi;
    
    Vk(:,t) = v + delta*EV(:,t+1) + ek(:,t);
    Vd(:,t) = v + ed(:,t);
    
    %Expected value function
%     B = max(Vk(:,t),Vd(:,t));
%     EV(:,t) = B+log(exp(Vk(:,t)-B)+exp(Vd(:,t)-B)) + ec; 
    EV(:,t) = log(exp(v + delta*EV(:,t+1)) + exp(v)) + ec;
end



%Finding first day for which Vd>Vk and calling that the predicted discharge
%day
pdischarges = nan(N,T);
for t = 1:T,
    [M,I] = max([Vk(:,t) Vd(:,t)],[],2);
    pdischarges(:,t) = I-1;
end
for n = 1:N,
    out = 0;
    for t = 1:T,
        if out==1,
            pdischarges(n,t) = 0;
        end
        if (out==0)*(pdischarges(n,t)==1),
            out = 1;
        end
    end
end

%Indicators for remaining in the sample (set equal to one if ever one)
prm = zeros(N,T);
for i=1:T,
   prm(:,i) = max(pdischarges(:,1:i),[],2); 
end


end

