%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% LTCHdyn_v10.m
% Paul Eliason, 4/26/2016
% paul.eliason@duke.edu
%
%  Estimates model with random coefficient.  Uses entire sample.
%
%  Uses quadratic time trend
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all
cd '/net/storage-01/econ/research/jr139/LTCH/'
addpath 'work/dynamic';

% Beginning diary
diary('work/dynamic/LTCH_dyn_v10_uflow_diary.txt');

%Seed --need to fix.  This is legacy code now.
format long
% rng('seed',3456);
rand('seed',997990);
randn('seed',997990);

%% Loading Dataset and organizing Data
payoffs1 = csvread('data/matlab/payoffs2matlab_v2.csv');
discharges1 = csvread('data/matlab/discharges2matlab_v2.csv');
ownership1 = csvread('data/matlab/ownership2matlab_v2.csv');
costs1 = csvread('data/matlab/costs2matlab_v2.csv');
fullpayment = csvread('data/matlab/fullpayment2matlab_v2.csv');
geo_mean = csvread('data/matlab/geo_mean2matlab_v2.csv');
hwh = csvread('data/matlab/aha_hwh2matlab_v2.csv');
sso_thresh = csvread('data/matlab/sso_thresh2matlab_v2.csv');
cDRG = csvread('data/matlab/cDRG2matlab_v2.csv');
dow1 = csvread('data/matlab/day_of_week2matlab_v2.csv');
black1 = csvread('data/matlab/black2matlab_v2.csv');
age1   = csvread('data/matlab/age2matlab_v2.csv');
male1  = csvread('data/matlab/male2matlab_v2.csv');
%Number of periods and patients
T = 45;
discharges = discharges1(:,1:T);
[N,~] = size(discharges);

payoffs = payoffs1(:,1:T);
costs   = costs1(:,1:T);
discharges = discharges(:,1:T);

%Ownership
%Ownership
fp = sum(ownership1(:,2:end),2);
hwh = hwh(:,1);
ownership = [fp.*hwh, fp.*(1-hwh),(1-fp).*hwh,(1-fp).*(1-hwh)];

%Number of DRGs
drg_count = 9;

%DRG
cDRG = cDRG;

%black, age and male
black = black1;
age = age1;
u65 = age<4;
male = male1;

%Day of week
dow = dow1;
dowdum = nan(N,T+1,7);

for i = 1:7,
   dowdum(:,:,i) = [dow==i,zeros(N,1)];
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Discount factor
delta = 1;


%%  Optimization options
opts = optimoptions('fminunc','MaxFunEvals',200000,'MaxIter',200000, ...
                'TolX',10e-9,'Display','iter',...
                'Algorithm','quasi-newton','TolFun',10e-9);
            
%%  Creating running max to turn off all discharge probabilities after
%discharge is realized
rm = zeros(N,T);
for i=1:T,
   rm(:,i) = max(discharges(:,1:i),[],2); 
end

% transcribing nine DRG categories into consecutive integers 1-9 (for
% easier coding)
drg = [1*(cDRG==177) + 2*(cDRG==189) + 3*(cDRG==190) + 4*(cDRG==193) + ...
       5*(cDRG==207) + 6*(cDRG==539) + 7*(cDRG==592) + 8*(cDRG==871) + ...
       9*(cDRG==949)];
% % % drg = [1*(cDRG==177) + 2*(cDRG==189)];
% % % drg = [1*(cDRG==949)];
%% Estimating Model




%%Formatting data
ts = [[1:T]'];
ts2 = repmat([ones(T,1) ts ts.^2 ts.^3 ts.^4/1000;zeros(1,5)],1,1,N);
payoffs2 = [payoffs,zeros(N,1)];
costs2   = [costs,zeros(N,1)];

X=[permute(payoffs2,[1 3 2]).*permute(repmat(ownership(:,1),1,T+1),[1 3 2]), ...
   permute(payoffs2,[1 3 2]).*permute(repmat(ownership(:,2),1,T+1),[1 3 2]), ...
   permute(payoffs2,[1 3 2]).*permute(repmat(ownership(:,3),1,T+1),[1 3 2]), ...
   permute(payoffs2,[1 3 2]).*permute(repmat(ownership(:,4),1,T+1),[1 3 2]), ...
   permute(costs2,[1 3 2]).*permute(repmat(ownership(:,1),1,T+1),[1 3 2]), ...
   permute(costs2,[1 3 2]).*permute(repmat(ownership(:,2),1,T+1),[1 3 2]), ...
   permute(costs2,[1 3 2]).*permute(repmat(ownership(:,3),1,T+1),[1 3 2]), ...
   permute(costs2,[1 3 2]).*permute(repmat(ownership(:,4),1,T+1),[1 3 2]), ...
   permute(ts2,[3 2 1]).*[repmat(drg==1,1,5,T+1)], ... %lambda 1
   permute(ts2,[3 2 1]).*[repmat(drg==2,1,5,T+1)], ... %lambda 2
   permute(ts2,[3 2 1]).*[repmat(drg==3,1,5,T+1)], ... %lambda 3
   permute(ts2,[3 2 1]).*[repmat(drg==4,1,5,T+1)], ... %lambda 4
   permute(ts2,[3 2 1]).*[repmat(drg==5,1,5,T+1)], ... %lambda 5
   permute(ts2,[3 2 1]).*[repmat(drg==6,1,5,T+1)], ... %lambda 6
   permute(ts2,[3 2 1]).*[repmat(drg==7,1,5,T+1)], ... %lambda 7
   permute(ts2,[3 2 1]).*[repmat(drg==8,1,5,T+1)], ... %lambda 8
   permute(ts2,[3 2 1]).*[repmat(drg==9,1,5,T+1)], ... %lambda 9
   permute(repmat([zeros(N,T),drg==1],1,1,1),[1 3 2]), ... %Omega 1
   permute(repmat([zeros(N,T),drg==2],1,1,1),[1 3 2]), ... %Omega 2
   permute(repmat([zeros(N,T),drg==3],1,1,1),[1 3 2]), ... %Omega 3
   permute(repmat([zeros(N,T),drg==4],1,1,1),[1 3 2]), ... %Omega 4
   permute(repmat([zeros(N,T),drg==5],1,1,1),[1 3 2]), ... %Omega 5
   permute(repmat([zeros(N,T),drg==6],1,1,1),[1 3 2]), ... %Omega 6
   permute(repmat([zeros(N,T),drg==7],1,1,1),[1 3 2]), ... %Omega 7
   permute(repmat([zeros(N,T),drg==8],1,1,1),[1 3 2]), ... %Omega 8
   permute(repmat([zeros(N,T),drg==9],1,1,1),[1 3 2])]; %Omega 9
   


%starting values
x0 = rand(1,4+4+5*drg_count+drg_count)./100000;

x = LTCH_ll(x0,X,T,N,delta,discharges,rm,drg_count);

opts = optimoptions('fminunc','MaxFunEvals',200000,'MaxIter',200000, ...
                'TolX',10e-9,'Display','iter',...
                'Algorithm','quasi-newton','TolFun',10e-9, ...
                'GradObj','on','CheckGradients',false, ...
                'StepTolerance',1e-20);  
            
[est1,ll,ef,op,score,hess] = fminunc('LTCH_ll',x0,opts, ...
    X,T,N,delta,discharges,rm,drg_count);

se1 = 1./sqrt(diag(hess));
disp('Estimates and Standard Errors');
[est1',se1]
disp('Likelihood');
ll
disp('Exit Flag');
ef

if ef~=1,
    
    [est2,ll2,ef2,op,score,hess2] = fminunc('LTCH_ll',est1,opts, ...
    X,T,N,delta,discharges,rm,drg_count);

    se2 = 1./sqrt(diag(hess2));

    [est2',se2]
    disp('Likelihood');
    ll2
    disp('Exit Flag');
    ef2
    
if ef2~=2,

    [est3,ll3,ef3,op,score,hess3] = fminunc('LTCH_ll',est2,opts, ...
    X,T,N,delta,discharges,rm,drg_count);

    se3 = 1./sqrt(diag(hess3));

    [est3',se3]
    disp('Likelihood');
    ll3
    disp('Exit Flag');
    ef3    
    
end

end

X = [];

save('parameters_1.mat');
