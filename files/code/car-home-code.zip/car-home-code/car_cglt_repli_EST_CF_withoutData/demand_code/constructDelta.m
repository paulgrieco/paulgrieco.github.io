%This funciton computes delta from its primitives. It should not be
%confused with getDelta, which computes a delta by inverting the share
%equation. 

function delta = constructDelta(parlin, p, DShocks, m)
  %We first need to replace the data p (m.p) with the requested price in
  %linX, m.linP is a matrix of size linX with a one at all entries that are
  %prices and zeros otherwise.
  thisX = bsxfun(@times, m.linP, p) + (1-m.linP).*m.linX;
  
  %Now computing delta is simple... 
  delta = thisX*parlin + DShocks;

end