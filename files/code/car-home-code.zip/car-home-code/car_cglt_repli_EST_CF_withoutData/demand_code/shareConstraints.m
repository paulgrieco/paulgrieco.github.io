function [c, Diff_share, dc, full_Jac] = shareConstraints(delta, mu, m)
  %This function takes a vector delta of mean utilities and a matrix
  % mu of individual deviations (all constructed outside) and computes
  % the mkt shares of each product and then formulates the difference between shares and true shares. 
  c = [];
  dc = [];
  Nmkt = m.nMkts;
  
  
  [share, share_ij] = getShare(delta, mu,m);
  
  Diff_share = share - m.share;
  
  if nargout > 2
      %Allocate the jacobian...keep it sparse.
      full_Jac = sparse(m.nObs, m.nObs);
      
      %The self-derivatives are fairly straightforward, do them for all
      %markets at once:
      Self_ind = share_ij.*(1-share_ij);
      Self_Deriv = Self_ind*m.quadweight';
      
      full_Jac_temp = cell(Nmkt,1);
      
      parfor mk=1:Nmkt
          ind_mk = (m.mktCode==mk);
          n_mod = sum(ind_mk);
          %fprintf('Market %d: Number of models: %d\n', mk, n_mod);
          %fprintf('\tGetting Shares\n', mk, n_mod);
          %tic;
          
          %Grab the individual market shares for each consumer for all
          %models in this market:
          sh_mkt = share_ij(ind_mk,:);
          sh_mkt_trans = sh_mkt';
         
          %Cross_S = repmat((sh_mkt(:))',n_mod,1).*reshape((reshape(repmat...
          %  (sh_mkt_trans(:),1,n_mod), m.nNodes, n_mod*n_mod))',n_mod,n_mod*m.nNodes);
          %tic;
          %fprintf('\tGetting Cross_S_A:\n', mk, n_mod);
          Cross_S_A = repmat((sh_mkt(:))',n_mod,1);
          %toc;
          
          %tic;
          %fprintf('\tGetting Cross_S_B:\n', mk, n_mod);
           
          %Cross_S_B = reshape((reshape(repmat(sh_mkt_trans(:),1,n_mod), m.nNodes, n_mod*n_mod))',n_mod,n_mod*m.nNodes);
          
          Cross_S_B1 = reshape(repmat(sh_mkt_trans(:),1,n_mod), m.nNodes, n_mod*n_mod);
          
          Cross_S_B = reshape(Cross_S_B1', n_mod, n_mod*m.nNodes);
          
          
          %toc;
          %tic;
          %fprintf('\tDot Mult for Cross_S:\n', mk, n_mod);
          Cross_S = Cross_S_A.*Cross_S_B;
          %toc;
        
          Cross_S = reshape(Cross_S, n_mod, n_mod, m.nNodes);
          Cross_Deriv = -sum(bsxfun(@times, Cross_S, reshape(m.quadweight,1, 1, m.nNodes)),3);
          full_Jac_temp{mk} = (1-eye(n_mod)).*Cross_Deriv + diag(Self_Deriv(ind_mk));
          %full_Jac(ind_mk, ind_mk) = (1-eye(n_mod)).*Cross_Deriv + diag(Self_Deriv(ind_mk));
          
          
          
          
          %toc;
          %This snippet does the same thing but loops over consumers.
          %Jac = zeros(n_mod, n_mod, m.nNodes);
          %for my_cons = 1:m.nNodes
          %   deriv_self    = share_ij(ind_mk,my_cons) .* (1-share_ij(ind_mk,my_cons));
          %   deriv_offdiag = - share_ij(ind_mk,my_cons) * share_ij(ind_mk,my_cons)';
          %   Jac(:,:,my_cons)           = (1-eye(sum(ind_mk))) .* deriv_offdiag + diag(deriv_self);
          %end
          %full_Jac(ind_mk,ind_mk) = sum(bsxfun(@times, Jac, reshape(m.quadweight,1, 1, m.nNodes)),3);
          %fprintf('\tMarket %d: Done!\n', mk);
      end
      
       for mk=1:Nmkt
          ind_mk = (m.mktCode==mk);
          full_Jac(ind_mk, ind_mk) = full_Jac_temp{mk};
       end
      
  end
end
