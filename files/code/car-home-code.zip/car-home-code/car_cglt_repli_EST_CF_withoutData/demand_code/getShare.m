function [share, share_ij, outShare] = getShare(delta, mu, m)
  %This function takes a vector delta of mean utilities and a matrix
  % mu of individual deviations (all constructed outside) and computes
  % the mkt shares of each product. 

  
%  inExp_max = mean( max(bsxfun(@plus, delta, mu)) ); % take this max out in exponential

  u = bsxfun(@plus, delta, mu);
  
  share_ij = zeros(size(u));
  for mk = 1:m.nMkts
    ind_mk = (m.mktCode == mk);
    u_mk = u(ind_mk,:);
    shift = max(u_mk);
    adj_u = exp(bsxfun(@minus, u_mk, shift));
    sum_adj_u = exp(-shift) + sum(adj_u);
    
    %Utility_sum(ind_mk,:) = repmat(1*exp(-inExp_max)+sum(expu(ind_mk,:)),sum(ind_mk),1);
    share_ij(ind_mk,:) = bsxfun(@rdivide, adj_u, sum_adj_u);
  end
  %share_ij = expu ./Utility_sum; 
  
  share = share_ij*m.quadweight';
  
  %Can also return the outside share if desired...
  if nargout > 2
     outShare = 1-sum(repmat(share,1,m.nMkts).*dummyvar(m.mktCode));
  end

  if min(real(share)) < 0 | max(abs(imag(share))) > 1e-6
      fprintf('Warning: getShare.m generates negative/non-real shares!!! The min is %f; min of imag is %f \n', min(real(share)), max(abs(imag(share))));
  end


end