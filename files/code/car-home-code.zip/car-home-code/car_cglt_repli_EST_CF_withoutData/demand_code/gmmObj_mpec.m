function [ obj, grad ] = gmmObj_mpec(mpec_x, W, size_nl, size_g )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
   
   %First, we've got to unpack parameters.
    parnonlin = mpec_x(1:size_nl);
    disp(parnonlin')
    g = mpec_x(size_nl+1:size_nl+size_g);
    delta = mpec_x(size_nl+size_g+1:end);
   
   
   %Here let's review how we construct a projection for IV
        %W = eye(size(ZZ,2))/(ZZ'*ZZ);  %This is the initial weight matrix, for efficiency, 
                                       % For optimal second stage, replace with:
                                       % W = eye(size(XX,2))/(ZZ'*Dxi*Dxi'*ZZ);
        %invIV = eye(size(XX,2))/(XX'*ZZ*W*ZZ'*XX);
        %PZ = eye(size(XX,1)) - XX*invIV*XX'*ZZ*W*ZZ';
        %G = Z'*PZ
        %Then the objective is just
        % g = G*delta;
        % g'*W*g
%   g = G*delta;
   obj = g'*W*g;
   
   if nargout > 1
      grad = [ zeros(length(parnonlin),1); (2*W*g) ; zeros(size(delta)) ];
   end
  
   
end

