clear;

%% Load the demand result file
load(['..' filesep 'demand_output' filesep 'demandresult.mat']);

parnonlin = mainout.parnonlin_hat;
parlin = mainout.beta_hat;

cost = mainout.cost;
%[hp_no, hp_yr, hp_deal, hp_both, hpc_no, hpc_both] = print_HomePreferences(mainout,0,0); 
%objVal = mainout.objVal_2nd;
%seNonlin = mainout.seNonlin;


rList = dir([ '..' filesep 'demand_output' filesep 'secondMulti_*mat']); 
nB = numel(rList);

%These are going to hold the outcomes of each bootstrap draw
m_parnonlin = nan(numel(parnonlin) , nB);
m_parnonlin_guess = nan(numel(parnonlin) , nB);
m_parlin = nan(numel(parlin) , nB);
m_cost = nan(numel(cost), nB);
% m_hp_no = nan(numel(hp_no), nB);
% m_hp_yr = nan(numel(hp_yr), nB);
% m_hp_deal = nan(numel(hp_deal), nB);
% m_hp_both = nan(numel(hp_both), nB);
% m_hpc_no = nan(numel(hpc_no), nB);
% m_hpc_both = nan(numel(hpc_both), nB);

m_objVal = nan(1, nB);
m_seNonlin = nan(numel(parnonlin), nB);

%Collect Data
for i = 1:nB
    Load_File = sprintf('../demand_output/%s', rList(i).name);
    if exist(Load_File, 'file') %check wither file exists
        fprintf('loading %s\n', Load_File)
	    load(Load_File)
    	
        m_parnonlin(:,i) = mainout.parnonlin_hat;
        m_parnonlin_guess(:,i) = mainout.m.parnonlin_guess;
        m_parlin(:,i) = mainout.beta_hat;
        
        m_cost(:,i) = mainout.cost;
        
%         [no, yr, deal, both, c_no, c_both] = print_HomePreferences(mainout); 
%         m_hp_no(:, i) = no';
%         m_hp_yr(:,i) = yr';
%         m_hp_deal(:,i) = deal';
%         m_hp_both(:,i) = both';
%         m_hpc_no(:,i) =c_no;
%         m_hpc_both(:,i) = c_both;
        
        m_objVal(:,i) = mainout.objVal;
        m_seNonlin(:,i) = mainout.seNonlin;
        
    end
end

% save the lowest object value
[gmm_obj_lowest, idx] = min(m_objVal);
gmm_obj_lowest = gmm_obj_lowest(1);
count_lowest = sum(abs((m_objVal - gmm_obj_lowest)./gmm_obj_lowest)<1e-4); % if they are very close then we say they are the same

display('')
display('----------------------------------')
fprintf('the lowest 2nd stage gmm obj value is: %f in sub-job %g. There are %g jobs giving the same answer.\n', gmm_obj_lowest, idx(1), count_lowest)

clearvars -except idx  rList m_parnonlin  m_parlin  m_cost  m_objVal   m_seNonlin  m_parnonlin_guess
Load_File = sprintf('../demand_output/%s', rList(idx(1)).name');
load(Load_File)
    
%Save everything.
saveFile = ['..' filesep 'demand_output' filesep 'secMultiResult.mat'];
save(saveFile);

% exit matlab for clusters
if isunix
     exit
end
