% This function compute the third piece in Hessian -- \partial^2 s /  \partial \delta^2 
% this function use the chain rule to compute the derivatives directly.

function    share2Deriv_delta = getShare2Deriv_delta_chain_parallel_loopMkt(lambda, m, share, share_ij)

quadweight = m.quadweight;
nNodes = m.nNodes;
nObs = m.nObs;
nMkts = m.nMkts;
mktCode = m.mktCode;

share2Deriv_delta = sparse(nObs, nObs);

share2Deriv_delta_mk = cell(nMkts,1);
 
assert( sum(sort(mktCode) == mktCode) == nObs ) % make sure the order of the mktCode is correct -- run from 1 to nObs

% slice share_ij
share_ij_mk = cell(nMkts,1);
for mk = 1:nMkts
    ind_mk = (mktCode==mk);
    share_ij_mk{mk} = share_ij(ind_mk,:);  
end
         
parfor mk = 1:nMkts % for each market
%mk;
              ind_mk = (mktCode==mk);
              n_mod = sum(ind_mk);    
            %  n_previous_row = sum( mktCode<mk );
              share2Deriv_delta_mk{mk} = sparse(n_mod,n_mod);
              %Jac_market_ij_cell_mk = Jac_market_ij_cell{mk};
              [~, ~, ~,~, Jac_market_ij_cell_mk] = shareConstraintsParallel_base(share, share_ij, m, mk);
              
          for  r_mk = 1:n_mod % for each delta
           %   r = r_mk + n_previous_row; % this is the r in the index from 1 to nObs
                  
              % prepare positions
%               pos_1 = zeros(n_mod,n_mod); % 1) this is fast
%               pos_1(r_mk,:) = 1;

%               pos_1 = sparse(r_mk,[1:n_mod],1,n_mod,n_mod); % 2) this is slow but use less space -- we use 3) do not use it at all, but operate the matrix below directly.
%               pos_2 = ones(n_mod,n_mod) - pos_1;
              

              share2Deriv_delta_mk_r = 0;
     
              for my_cons = 1:nNodes % each of the following should be n_mod x n_mod  
%                       s_r = share_ij(r,my_cons); 
%                       part_1 = Jac_market_ij_cell{mk}(:,:,my_cons) .* (1-2*s_r*ones(n_mod));
%                       part_2 = - Jac_market_ij_cell{mk}(:,:,my_cons) .* s_r .* ones(n_mod) - share_ij(ind_mk,my_cons) * Jac_market_ij_cell{mk}(r_mk,:,my_cons);

                      s_r = share_ij_mk{mk}(r_mk,my_cons); 
                      part_1 = Jac_market_ij_cell_mk(:,:,my_cons) .* (1-2*s_r*ones(n_mod));
                      part_2 = - Jac_market_ij_cell_mk(:,:,my_cons) .* s_r .* ones(n_mod) - share_ij_mk{mk}(:,my_cons) * Jac_market_ij_cell_mk(r_mk,:,my_cons);
                      
                      %share2Deriv_delta_mk_r  = share2Deriv_delta_mk_r + quadweight(1,my_cons) *( part_1 .* pos_1 + part_2 .* pos_2  );
                      part_2(r_mk,:) = part_1(r_mk,:); % to save memory, we use part_2 directly (without naming a new variable)
                      share2Deriv_delta_mk_r  = share2Deriv_delta_mk_r + quadweight(1,my_cons) *part_2;
                      
              end
              
%               temp = zeros(1,nObs);
%               temp(ind_mk) = lambda.eqnonlin(ind_mk)' * share2Deriv_delta_mk;
%               share2Deriv_delta(r,:) =  temp;
                  share2Deriv_delta_mk{mk}(r_mk,:)=  lambda.eqnonlin(ind_mk)' * share2Deriv_delta_mk_r; 
              
           end
     
end

for mk = 1:nMkts % for each market
    ind_mk = (mktCode==mk);
    share2Deriv_delta(ind_mk,ind_mk) = share2Deriv_delta_mk{mk};
end
             
         
end