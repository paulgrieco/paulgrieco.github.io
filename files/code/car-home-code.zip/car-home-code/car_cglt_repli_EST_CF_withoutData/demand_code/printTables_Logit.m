% this function print the result for the logit estimation.

% The input, beta_full, contains the full set of coefficients: for example,
% it contains coefficients for price and price*income, as well as the set
% of coefficients for all variables in the original m.linX.

function printTables_Logit(beta_full,se_full, m, c2str) 

[fid, err] = fopen(['..' filesep 'demand_output' filesep 'results_logit.txt'], 'w');
assert(fid > 0,err)

%unit_adjusted_norm = [1   77.0506    7.9830   27.4259]; % for mpg, we have 1 here since the first one is a constant, no unit
unit_adjusted_norm = [7.8756    8.0139   4.6345]'; % Note that using this means we use horse power per 100kg (rather than 1000kg as before)
if m.chsq == 1 % if we used square terms as the linear linX
      unit_adjusted_norm = [unit_adjusted_norm; unit_adjusted_norm.^2];
end

%% Load the specific result
    if m.chsq == 1 % if we used square terms as the linear linX
        char_length = 3*9*2; % 3 chars 9 countries, and with square
    else
        char_length = 3*9;
    end
    
beta_char = beta_full(2+1:2+char_length); % Note here is hard-writing: the first two are for the price-related variables.
se_char = se_full(2+1:2+char_length);

%% Print table: estimated parameters of the demand equation
    % fill with content
    
    if m.chsq == 1 % if we used square terms as the linear linX
        %row_varName = {'Constant', 'HP per Weight', 'HP per Weight Square', 'Size', 'Size Square', 'MPDCITY', 'MPDCITY Square'};
        row_varName = {'HP per Weight',  'Size', 'MPDCITY','HP per Weight Square', 'Size Square', 'MPDCITY Square'};
    else
        row_varName = {'HP per Weight', 'Size', 'MPDCITY'};
    end
        
    col_varName = c2str.Ctys;
    
    col_leng = size(col_varName,1);
    row_leng = size(row_varName,2);
    
    res_est = reshape(beta_char,col_leng,row_leng)'./repmat(unit_adjusted_norm, 1, col_leng); % here col_leng comes first and then transpose since this is how beta_char is organized.
    res_se = reshape(se_char,col_leng,row_leng)'./repmat(unit_adjusted_norm, 1, col_leng);
               
% Then print the head ...     
    
    fprintf(fid, '\\begin{table}[t] \n'); 
    fprintf(fid, '\\begin{center} \n');
    fprintf(fid, '\\caption{Estimated Logit parameters of the demand equation }\\centering \n');

        fprintf(fid, '\\begin{tabular}{@{}c|ccccccccc}\n'); % one more c
        fprintf(fid, '\\toprule   \n');
        fprintf(fid, ' Variable & \\multicolumn{9}{c}{Estimate} \\\\\n');

    fprintf(fid, '\\midrule  \n');
    for i = 1:length(col_varName)
        fprintf(fid, '&%s', col_varName{i} );
    end
    fprintf(fid, '\\\\\n' );
    fprintf(fid, '\\midrule  \n');
   
    %Print main content
    for i = 1:row_leng
            fprintf(fid, '%s &%4.3f &%4.3f &%4.3f &%4.3f&%4.3f&%4.3f&%4.3f&%4.3f&%4.3f \\\\ \n', row_varName{i},res_est(i,:));
            fprintf(fid, '    &\\footnotesize{(%4.3f)} &\\footnotesize{(%4.3f)} &\\footnotesize{(%4.3f)}&\\footnotesize{(%4.3f)}&\\footnotesize{(%4.3f)}&\\footnotesize{(%4.3f)}&\\footnotesize{(%4.3f)}&\\footnotesize{(%4.3f)}&\\footnotesize{(%4.3f)}\\\\ \n ',  res_se(i,:) );
    end
    
    % print for price-related estimate separately:
    fprintf(fid, '\\midrule  \n');
     
    % print extra coefficient
    fprintf(fid, ' Price & %4.3f \\\\\n', beta_full(1));
    fprintf(fid, ' &\\footnotesize{(%4.3f)} \\\\ \n', se_full(1)  );  
    fprintf(fid, ' Price X Income & %4.3f \\\\\n', beta_full(2));
    fprintf(fid, '& \\footnotesize{(%4.3f)} \\\\ \n', se_full(2)  );  
        
    fprintf(fid, '\\bottomrule \n');
    fprintf(fid, '\\end{tabular} \n');
    fprintf(fid, '\\end{center} \n');
    fprintf(fid, '\\end{table} \n');
   

fclose('all');      
    
end