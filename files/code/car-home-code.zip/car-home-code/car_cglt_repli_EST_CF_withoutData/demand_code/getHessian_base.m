% this function compute Hessian 
% Hessian is an n-by-n matrix, sparse or
% dense, where n is the number of variables. lambda is
% a structure with the Lagrange multiplier vectors associated with the
% nonlinear constraints:lambda.ineqnonlin lambda.eqnonlin
% In our case, we only have lambda.eqnonlin

function [hessian,  share2Deriv_nonlin, share2Deriv_nonlinDelta, share2Deriv_delta ] = getHessian_base(mpec_x, lambda, W, m) 

% Unpack and prepare 
[parnonlin, g, delta] = unpackMpecX(mpec_x, m); 
[mu, alphai] = getMu(parnonlin, m); 
[share, share_ij] = getShare(delta, mu, m);

[Gradient, shareijDeriv_nonlin] = ShareDeriv_nonlin_base(share_ij, alphai, m); % shareijDeriv_nonlin is a cell (m.nMkts,m.size_nl) -- each element has size nObs(in mk) x nNode(#consumers)

% There are four major pieces in the Hessian
% First piece -- \partial^2 s / \partial^2 \theta --  for nonlinear parameters
tic
share2Deriv_nonlin = getShare2Deriv_nonlin(lambda, shareijDeriv_nonlin, share_ij, alphai, m);
toc

% Second piece -- \partial^2 s / \partial \theta \partial \delta 
tic
share2Deriv_nonlinDelta = getShare2Deriv_nonlinDelta_parallel(lambda, shareijDeriv_nonlin, share_ij, m.quadweight, m.nNodes,m.nMkts, m.size_nl, m.nObs, m.mktCode);
toc

% Third piece -- \partial^2 s / \partial \delta^2   
tic
%[~, ~, ~, ~, Jac_market_ij_cell] = shareConstraintsParallel_base(share, share_ij, m);
%share2Deriv_delta = getShare2Deriv_delta_mkt(lambda, share_ij, m.quadweight, m.nNodes, m.nObs, m.nMkts, m.mktCode);        % mkt or matrix is good
share2Deriv_delta = getShare2Deriv_delta_chain_parallel_loopMkt(lambda, m, share, share_ij);     
toc  

% Fourth piece 
share2Deriv_g = 2*W;

%Original pattern:
%hessian = [share2Deriv_nonlin,                                                                      share2Deriv_nonlinDelta,                                                                zeros(size(share2Deriv_nonlin,1), size(share2Deriv_g,2))
%                share2Deriv_nonlinDelta',                                                              share2Deriv_delta,                                                                         zeros(size(share2Deriv_delta,1), size(share2Deriv_g,2))
%                zeros(size(share2Deriv_g,1), size(share2Deriv_nonlin,2)),               zeros(size( share2Deriv_g,1), size(share2Deriv_delta,2)),                 share2Deriv_g                           ];

%Paul's Attempt after Felix's comment on ordering: 
hessian = [share2Deriv_nonlin,                                                                    zeros(size(share2Deriv_nonlin,1), size(share2Deriv_g,2)),   share2Deriv_nonlinDelta;                                                              
           zeros(size(share2Deriv_g,1), size(share2Deriv_nonlin,2)),                                                              share2Deriv_g ,             zeros(size(share2Deriv_g,1), size(share2Deriv_delta,2));
           share2Deriv_nonlinDelta',               zeros(size( share2Deriv_delta,1), size(share2Deriv_g,2)),                 share2Deriv_delta                          ];

%hessian = sparse(hessian);            
end






