
function [parnonlin, moments, delta ] = unpackMpecX(mpec_x,m)
    parnonlin = mpec_x(1:m.size_nl);
    moments = mpec_x(m.size_nl+1:m.size_nl+m.size_g);
    delta = mpec_x(m.size_nl+m.size_g+1:end);
end