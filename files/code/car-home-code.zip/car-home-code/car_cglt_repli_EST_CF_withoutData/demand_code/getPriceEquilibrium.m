% Input: nonlinear parameters; linear parameters (beta_hat); demand shocks,
% and costs from the demand estimation.
function [price, share] = getPriceEquilibrium(parnonlin, parlin, DShocks, costs, m)
%getPriceEquilibrium uses contraction map to solve for new equilibrium
%   takes prices in the data as the start point (m.p). 

   price_cell = cell(m.nMkts,1);
   share_cell = cell(m.nMkts,1);
   outflag = cell(m.nMkts,1);
   parfor mk = 1:m.nMkts
       [price_cell{mk}, share_cell{mk}, outflag{mk}] = price_contraction(parnonlin, parlin, DShocks, costs, m, mk);
       if outflag{mk}==1
           fprintf('getPriceEquilibrium: Market %d is being dampened.\n', mk);
           [price_cell{mk}, share_cell{mk}, outflag{mk}] = price_contraction(parnonlin, parlin, DShocks, costs, m, mk, .66, 1000);
       end
       fprintf('getPriceEquilibrium: Market %d Finished.\n', mk);
   end
   
   price = zeros(size(costs));
   share = price;
   for mk=1:m.nMkts
       ind_mk = (m.mktCode==mk);
       price(ind_mk) = price_cell{mk};
       share(ind_mk) = share_cell{mk};
       if outflag{mk} == 1
           fprintf('getPriceEquilibrium: Market %d Failed to Converge\n', mk);
           assert(0==1, 'getPriceEquilibrium: Halting do to Convergence Failure, more iterations or something worse?');
       end
       
   end
   

end

