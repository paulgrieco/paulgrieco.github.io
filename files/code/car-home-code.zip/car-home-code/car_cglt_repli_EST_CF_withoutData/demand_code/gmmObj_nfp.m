function [ obj, grad, delta_solved ] = gmmObj_nfp(parnonlin, W, G, m)
global delta_start
    tic
    if isfield(m, 'debugFID')
        fprintf(m.debugFID, 'gmmObj_nfp evaluating: %s:\t', num2str(parnonlin',5)); 
    end
    %disp(parnonlin');
%% If global variable not set, use MNL solution from m...
    if isempty(delta_start)
        delta_start =  m.delta_start;
    end

%% Solve and Verify Solution to the share inversion...
    max_itr = 5;
    itr = 0;
    constrviolation = 1;
    IL_CRIT = 1e-6; %Inner loop stopping criteria, note we need to make sure it is also tightened inside if we change it.
    %This while loop enables problem to switch between contraction and
    %quasi-newton approach for solving the share constraints... Should only
    %run once most of the time.
    while (constrviolation > IL_CRIT && itr < max_itr) 
       [delta_solved, constrviolation] = NFP_innerLoop(parnonlin, delta_start, m);
       delta_start = delta_solved;
       itr = itr+1;
       if constrviolation > IL_CRIT
           disp(sprintf('gmmObj_nfp: Warning: Inner loop failed to converge after iteration %d: violation =  %.10f', itr, constrviolation));
       end
    end
    assert(constrviolation < IL_CRIT, sprintf('gmmObj_nfp: Inner loop failed to converge: %.10f', constrviolation));
       

%% Compute objective
     g = G*delta_solved;
     obj = g'*W*g;
 
%% Compute gradient 
    if nargout > 1
        grad = gmmobj_NFP_grad(parnonlin, delta_solved, W, G, m);
    end

%% Save the solution as the start point for next time...
% Not pretty but it works. 
    delta_start = delta_solved;
    
    elapsed = toc;

    if isfield(m, 'debugFID')
        fprintf(m.debugFID, ' =  %.3f, time = %.3f s\n', obj, elapsed); 
    end


%toc  
   
end
