function [mainout] = NFPmain(m,c2str, sW, bweight)
% This function uses Nested fixed point method, alternative is 'MPECmain.m'

%% Form Design matrix, setup sizes, and setup linear constraint matrices...
if (nargin < 3)
    fprintf('Forming problem\''s design matrices...\n');
    [W, G] = getDesign(m); % we need G to compute standard error later
elseif nargin==3
    fprintf('Using user-provided weight matrix, finding apropriate G');
    [W, G] = getDesign(m,sW);
elseif nargin==4 %Here we have weighted problem
    fprintf('Weighted GMM...forming design matrices');
    [W, G] = getDesign(m,sW,bweight);
end
    
ktropts = optimset('Display','iter');

%% Set bounds:
%All this really does is make sure that the sigmas are
%positive, they are all standard deviations, we're hoping this helps push
%them away from zero...
guess = m.parnonlin_guess;
lb    = -Inf*ones(size(guess));

%Make sure the variance parameters are weakly postive:
%SigmaEntries are the first elements of the nonlinear parameters.
% NOTE: This only works because we only have variances in Sigma, no
% covariances
lb(1:size(m.SigmaEntries,1)) = -50;
% NOTE: Variance of alpha is the final entry in the nonlinear parameter
% vector. This should actually be fairly robust.
ub = Inf*ones(size(guess));
ub(1:size(m.SigmaEntries,1)) = 70;

%This bounds the Pi parameters, currently just income. These bounds are
%specificaiton specific and need to be moved to setup structs. 
lb(size(m.SigmaEntries,1)+1:size(m.SigmaEntries,1)+size(m.PiEntries,1)) = -100;
ub(size(m.SigmaEntries,1)+1:size(m.SigmaEntries,1)+size(m.PiEntries,1)) = 100;


A = [];
b = [];

if m.lognormprice == 1
   % NOTE: Variance of alpha is the final entry in the nonlinear parameter
   % vector. This should actually be fairly robust.
    %Bounding sigma_p
    lb(m.size_nl) = -1;
    ub(m.size_nl) = 2.5;
    
    %Bounding pi_p
    lb(m.size_nl-1) = -3;
    ub(m.size_nl-1) = 0.25;
    
    %Bounding alpha_bar (tough to gaudge get's very sensitive due to exponentiation)
    ub(m.size_nl-2) = 3.5;
    lb(m.size_nl-2) = -1;
    
    
    % SHENGYU BOUND WITHOUT NORMALIZING INCOME
    %A                = zeros(2,m.size_nl);
    %A(1,m.size_nl-2) = 1;
    %A(1,m.size_nl-1) = 10;
    %A(2,m.size_nl-2) = -1;
    %A(2,m.size_nl-1) = -10;
    %b = [4.5; 4.5];
else
    lb(end) = -2;
    ub(end) = 2; % this is just for pi of income on price
end

%% FIRST STAGE ESTIMATION:
fprintf('Calling KNITRO to solve the NFP estimation problem...\n');

%Allow for re-start based on m.max_restart:
%This code will restart any failed run (with negative exit flag)
%m.max_restart times.  For backwards compatibility of m.max_restart does 
%not exist, it is assumed to be zero.
%
% Note: we save the results file after every failure so it can be examined
% during runs on the cluster
tries = 0;
exitflag_theta = -999;
if (isfield(m, 'max_restart') == 0)
    max_restart = 0;
else
    max_restart = m.max_restart;
end
    
while (tries <= max_restart) && (exitflag_theta < 0) 
   tries = tries + 1
   %[parnonlin1,objVal,exitflag_theta,~] = knitrolink(@(x) gmmObj_nfp(x, W, G,  m),guess,A,b,[],[],lb,ub, [],ktropts,m.knitroFile);
   [parnonlin1,objVal,exitflag_theta,~] = knitrolink(@(x) gmmObj_nfp(x, W, G,  m),guess,[],[],[],[],lb,ub, [],ktropts,m.knitroFile);
   guess = parnonlin1;
   save(m.resFile);
end
   
%% second stage GMM
fprintf('Second stage GMM ...\n');

% get optimal weight matrix for 2nd stage GMM:
[ ~, ~, delta_solved] = gmmObj_nfp(parnonlin1, W, G, m);
mpec_x1               = [parnonlin1; G*delta_solved; delta_solved];
if nargin < 4 % The unweighted case...
    [ ~,~, W_opt]  = recoverBeta(mpec_x1, W, m );   % recover linear parameters
    [~, oG]               = getDesign(m,W_opt); 
else %Here we are using weighted GMM
    [ ~,~, W_opt]  = recoverBeta(mpec_x1, W, m, bweight );
    [~, oG] = getDesign(m, W_opt, bweight);
end
    
%% Second Stage Call
% We know also auto-restart on the second stage, should probably have a
% function call to do this?  
fprintf('Calling KNITRO to solve the NFP estimation problem (2nd stage)...\n');
%ktropts = optimset('Display','iter','JacobPattern',Jac_Pattern_nonlin_sparse, 'HessPattern',Hessian_Pattern_sparse, 'Hessian','user-supplied', 'HessFcn', @(mpec_x, lambda) getHessian(mpec_x, lambda, oW, m) );

tries = 0;
exitflag_theta_2nd = -999;


% SHENGYU has used this to randomize the multistart, not sure its a good
% idea definitely not a good idea when trying to find an initial estimate.
%guess = m.parnonlin_guess; % here we use m.parnonlin_guess instead of guess since it is better if we run multi-starts (otherwise, 2nd GMM will be the same if the estimate of 1gmm is the same.)


while (tries <= max_restart) && (exitflag_theta_2nd < 0) 
    tries = tries + 1  
    %[parnonlin_hat,objVal_2nd,exitflag_theta_2nd,~] = knitrolink(@(x) gmmObj_nfp(x, W_opt, oG,  m), guess,A,b,[],[],lb,ub, [],ktropts,m.knitroFile);
    [parnonlin_hat,objVal_2nd,exitflag_theta_2nd,~] = knitrolink(@(x) gmmObj_nfp(x, W_opt, oG,  m), guess,[],[],[],[],lb,ub, [],ktropts,m.knitroFile);
    guess = parnonlin_hat;
    save(m.resFile);
end
    
%% Post-Estimation Block
% Recover linear paramters and demand shocks:
[ ~, ~, delta_solved]  = gmmObj_nfp(parnonlin_hat, W_opt, oG, m);
mpec_x_hat             = [parnonlin_hat; oG*delta_solved; delta_solved];

if nargin < 4 %unweighted case...
   [beta_hat, DShocks, ~] = recoverBeta(mpec_x_hat, W_opt,  m );
else
   [beta_hat, DShocks, ~] = recoverBeta(mpec_x_hat, W_opt,  m, bweight );
end
   
% Compute standard errors 
%   For linear and nonlinear parameters (beta_bar, alpha_bar, and nonlinear para)
%   seLin (seNonlin) is the standard error of linear (nonlinear) parameters;
%   var_Nonlin_Lin is the variance matrix of all linear and nonlinear
%   parameters in that order.
[seLin, seNonlin, var_Nonlin_Lin] = getSe(mpec_x_hat, W_opt,  m); 

%Compute price elasticity and Costs
%  elast_market_cell is the elasticity matrix by market, while full_Elast is
%  the entire elasticity matrix across all market (should includes many zeros)
[~, full_Elast] = getElast(parnonlin_hat, beta_hat, DShocks,  m);
cost            = getCost(parnonlin_hat, beta_hat, DShocks, m);

%Extract the home preference estimates from the country-brand dummies, if
%necessary, otherwise home dummy is directly estimated and we set these to
%empty.  For country level, homep_cty is ordered by market country
%according to c2str and NaN when a country has no home brand.
% Note that print_HomePreferences.m does that in the printeTables_Demand.m
% again in more detail and prints the results to tex table
if isfield(m,'startBCdums')
    [homep_homog, se_homep_homog, homep_cty, se_homep_cty] = extractHomeFromCBD(beta_hat, var_Nonlin_Lin, m);
else
    homep_homog=[]; se_homep_homog=[]; homep_cty=[]; se_homep_cty=[];
end

%% Save Output Files
save(m.resFile, 'beta_hat', 'c2str', 'cost', 'full_Elast', 'm', 'objVal', ...
    'objVal_2nd', 'parnonlin1', 'parnonlin_hat', 'seLin', 'seNonlin', ...
    'mpec_x1', 'mpec_x_hat', 'W_opt', 'var_Nonlin_Lin', 'DShocks', ...
    'homep_homog', 'se_homep_homog', 'homep_cty', 'se_homep_cty');

mainout.beta_hat       = beta_hat;
mainout.c2str          = c2str;
mainout.cost           = cost;
mainout.full_Elast     = full_Elast;
mainout.objVal         = objVal;
mainout.objVal_2nd     = objVal_2nd;
mainout.parnonlin1     = parnonlin1;
mainout.parnonlin_hat  = parnonlin_hat;
mainout.seLin          = seLin;
mainout.seNonlin       = seNonlin;
mainout.mpec_x1        = mpec_x1;
mainout.mpec_x_hat     = mpec_x_hat;
mainout.m              = m;
mainout.homep_homog    = homep_homog;
mainout.se_homep_homog = se_homep_homog;
mainout.homep_cty      = homep_cty;
mainout.se_homep_cty   = se_homep_cty;
mainout.W_opt          = W_opt;
mainout.DShocks        = DShocks;
mainout.var_Nonlin_Lin = var_Nonlin_Lin;

fprintf('Result file ''%s.mat'' saved.\n', m.resFile);

end