% this code is to construct blp instruments from raw car characteristics

% a matrix of all car characteristics, including a constant (1) column.
% a constant is included to construct the instrument using the number of
% models.
carChar = [ones(m.nObs,1), hppwt, sz, mpgcty]; 
carChar_dim = size(carChar,2); % the dimention of characteristics (including the constant column)

charSumMkt = zeros(m.nObs,1); % this is the sum of characteristics over market
charSumMktFm = zeros(m.nObs,1); % this is the sum of characteristics over firm, within a market

for k = 1: carChar_dim % for each characteristic
    for mk = 1:m.nMkts % for each market
        ind_mk = (m.mktCode==mk);
        charSumMkt(ind_mk) = sum(carChar(ind_mk,k));
        for fm = unique(m.firmCode(ind_mk))' % for each firm in this market
            ind_fm = (m.firmCode==fm)&(m.mktCode==mk);
            charSumMktFm(ind_fm) = sum(carChar(ind_fm,k));
        end
    end
       
    ivown(:,k) = charSumMktFm - carChar(:,k);
    ivriv(:,k) = charSumMkt - charSumMktFm;
end
       
blpIV_raw = [ivown, ivriv];

mean_mat = repmat(mean(blpIV_raw,1),m.nObs,1); % a matrix consists of means of each column
std_mat = repmat(std(blpIV_raw,0,1),m.nObs,1); % a matrix consists of means of each column
blpIV_norm = (blpIV_raw - mean_mat)./std_mat;

%quantile(reshape(abs(blpIV - blpIV_norm)./abs(blpIV),[],1),.999)
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    


