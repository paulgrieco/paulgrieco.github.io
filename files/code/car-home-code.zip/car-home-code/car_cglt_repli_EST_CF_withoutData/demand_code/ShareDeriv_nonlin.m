
function [Gradient] = ShareDeriv_nonlin(share_ij, alphai, m)

  
[Gradient] = ShareDeriv_nonlin_base(share_ij, alphai, m); % note the second output is not required to reduce burden
          
end