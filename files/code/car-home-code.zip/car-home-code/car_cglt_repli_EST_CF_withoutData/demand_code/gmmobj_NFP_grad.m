% this function computes the gradients of objective function for NFP

function [grad delta_Deriv_parnonlin] = gmmobj_NFP_grad(parnonlin, delta_solved, W, G, m)

    % get partial share/ partial parnonlin
    [mu, alphai] = getMu(parnonlin, m); 
    [share, share_ij] = getShare(delta_solved, mu, m);
    grad_nonlin = ShareDeriv_nonlin(share_ij, alphai, m);     

    % get partial share/ partial delta
    [~, ~, ~, grad_delta] = shareConstraintsParallel_base(share, share_ij, m);
    
    % get partial delta/ partial parnonlin
    delta_Deriv_parnonlin = - eye(length(delta_solved))/grad_delta * grad_nonlin;
    
    % get gradient wrt to parnonlin
   grad = 2*delta_Deriv_parnonlin' * (G'*W*G) * delta_solved;
   
end