function print_Markups_firmLevel(mainout)

% indicate if we want dollar in the table or not
dollar_ind = 0; % 0 mean no dollar in the table

percMkup = mainout.m.p./mainout.cost - 1;
dollarMkup = mainout.m.p - mainout.cost;
varProf = (mainout.m.p - mainout.cost).*mainout.m.sales; % note that in previous versions, we do not save m.sales.
%firmCodeShow = [6,7,8, 16, 25, 26]; % Toyota, GM, VW, Ford, PSA and Fiat

% Extract brand codes 
temp_code = 1:mainout.m.nFirms;
firmCodeShow = zeros(1,length(mainout.m.firm_names_for_markups));
for i = 1:length(mainout.m.firm_names_for_markups)
    firm_code_temp = strcmp(mainout.m.firm_names_for_markups(i),mainout.c2str.Firms);
    firmCodeShow(i) = temp_code(firm_code_temp);
end

nShow = length(firmCodeShow);

percMkup_mat = ones(nShow,mainout.m.nCtys);
dollarMkup_mat = ones(nShow,mainout.m.nCtys);
varProf_mat = ones(nShow,mainout.m.nCtys);

for f = 1:nShow
    fCode = firmCodeShow(f);
    for c = 1:mainout.m.nCtys
        idShow = mainout.m.firmCode == fCode & mainout.m.ctyCode == c; 
        
%         percMkup_mat(f,c) = median(percMkup(idShow));
%         dollarMkup_mat(f,c) = median(dollarMkup(idShow));
%         varProf_mat(f,c) = median(varProf(idShow));
        
        percMkup_mat(f,c) = sum(percMkup(idShow).*(mainout.m.sales(idShow)./sum(mainout.m.sales(idShow))));
        dollarMkup_mat(f,c) = sum(dollarMkup(idShow).*(mainout.m.sales(idShow)./sum(mainout.m.sales(idShow))));
        varProf_mat(f,c) = sum(varProf(idShow).*(mainout.m.sales(idShow)./sum(mainout.m.sales(idShow))));
        
    end
end
        

%% print  a table for it
fid = fopen([ '..' filesep 'demand_output' filesep 'results_mkup_firm.txt'], 'w');

    % First print the head ...     
%    fprintf(fid, '\\begin{landscape} \n');
    fprintf(fid, '\\begin{table}[t] \n'); 
     fprintf(fid, '\\begin{center} \n');
    fprintf(fid, '\\caption{Median markups of manufacturers across markets }\\centering \n');
    fprintf(fid, '\\begin{tabular}{@{}ll|ccccccccc} \n');
    fprintf(fid, '\\toprule   \n');
    
    fprintf(fid, '&');
    for i = 1:mainout.m.nCtys
        fprintf(fid, '&%s', mainout.c2str.Ctys{i});
    end
    fprintf(fid, '\\\\\n' );
    
    fprintf(fid, '\\midrule  \n');
        
        
    %Print main content
    
    for i = 1:nShow
        fprintf(fid, '%s ', mainout.c2str.Firms{firmCodeShow(i)} );    
        if dollar_ind == 1
        fprintf(fid, ' & Percentage  '  );
        fprintf(fid, '  &%4.1f ', percMkup_mat(i,:)*100  );
        fprintf(fid, ' \\\\ \n'  );
        
        fprintf(fid, '  & Dollar   ' ); 
        fprintf(fid, ' &%4.0f   ',  dollarMkup_mat(i,:)*10000 ); 
        fprintf(fid, '   \\\\ \n '  ); 
        else
            fprintf(fid, ' &   '  );
            fprintf(fid, '  &%4.1f ', percMkup_mat(i,:)*100  );
            fprintf(fid, '  \\\\ \n'  );
        end
  
    end
    
    fprintf(fid, '\\bottomrule \n');
    fprintf(fid, '\\end{tabular} \n');
        fprintf(fid, '\\end{center} \n');
    fprintf(fid, '\\end{table} \n');
%    fprintf(fid, '\\end{landscape} \n');
        
        



