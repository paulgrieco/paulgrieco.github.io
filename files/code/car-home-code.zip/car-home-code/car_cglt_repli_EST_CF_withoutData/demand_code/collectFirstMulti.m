clear;
clc;

% after the array jobs are finished, load all result files and find the one with min obj value of 1stage gmm
n_subjob = 120; % currently we have 8 sub-array jobs
gmm_values = 1e+100*ones(n_subjob,1);
parnonlin_1st = 1e+100*ones(n_subjob,8);
parnonlin_2nd = 1e+100*ones(n_subjob,8);
parnonlin_guess = 1e+100*ones(n_subjob,8);

for i = 1:n_subjob 
    Load_File = sprintf('../demand_output/firstMulti_%g.mat', i);
     fprintf('Checking result file: %s ... \n', Load_File) 
    if exist(Load_File, 'file') %check wither file exists
	load(Load_File)
    fprintf('Loading result file: %s ... \n', Load_File) % print it out so that we can verify all existing result is loaded.
    	gmm_values(i) = mainout.objVal;
        %parnonlin_1st(i,:) = mainout.parnonlin1;
        parnonlin_1st(i,:) = mainout.parnonlin_hat; % as this is just for single step
        parnonlin_guess(i,:) = mainout.m.parnonlin_guess;
    end
end

[gmm_obj_lowest, idx] = min(gmm_values);
gmm_obj_lowest = gmm_obj_lowest(1);
count_lowest = sum(abs((gmm_values - gmm_obj_lowest)./gmm_obj_lowest)<1e-4); % if they are very close then we say they are the same

display('')
display('----------------------------------')
fprintf('the lowest first stage gmm obj value is: %f in sub-job %g. There are %g jobs giving the same answer.\n', gmm_obj_lowest, idx(1), count_lowest)

clearvars -except idx gmm_values   parnonlin_guess parnonlin_1st parnonlin_2nd
Load_File = sprintf('../demand_output/firstMulti_%g', idx(1));
load(Load_File)
    
save('../demand_output/demandresult','mainout', 'gmm_values', 'parnonlin_1st',  'parnonlin_guess')

% Simple MNL specification for comparison
[objValue_1_mnl, objValue_2_mnl, beta_c_mnl, beta_mnl, se_mnl, V_mnl, u_mnl] = logitSpec( mainout.m );
fprintf('Multinominal logit obj value is: %g.\n', objValue_1_mnl)

% Print tables
%clear
%load demandresult
%printTables_Demand(mainout,0,0) 

% exit matlab for clusters
if isunix
    exit
end
