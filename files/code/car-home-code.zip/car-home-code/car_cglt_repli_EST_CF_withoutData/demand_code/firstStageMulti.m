%This is the master script for a second stage multi-start, we use the point in 
%demandresult as our weight matrix and start point. 
clear;
clc;
tic;

%% Multistart is off when testing on local computers.   
NTASKS = 1;
myseed = 24; % save the seed to generate initial guesses.

%% Set identifiers for specifications: user-interface to choose options for specification
[m, c2str] = setupStructs(); % This script generates an (m, c2str) pair 

%% Parallel Cluster Settings
[~, hname] = system('hostname');

if ~isempty(strfind(hname, 'midway'))    % Are we on the UofC clusters 
    s = matlabpool('size');
    if s~=0
        matlabpool('close')
    end
    pc = parcluster('local');
    % explicitly set the JobStorageLocation to the temp directory that was created in your sbatch script
    pc.JobStorageLocation = strcat('/tmp/shengyuli/', getenv('SLURM_JOB_ID'), '/', getenv('SLURM_ARRAY_TASK_ID'));
    pause(1+180*rand()) % 
    matlabpool(pc, pc.NumWorkers);      % start the matlabpool with 12 workers
else
    if isempty(gcp('nocreate'))~=1
        poolobj = gcp('nocreate');
        delete(poolobj);
    end
    pc = parcluster('local');
    parpool(pc.NumWorkers);
end

%% Set starting points
 % assert(~isempty(strfind(hname, 'midway')), 'demandEstimation: multistart option only available on midway cluster');
    rng(myseed);
    if m.lognormprice == 1
        %parnonlin_preEst =  [10     10     10    10          -2      2     -1    1]'; % use the result from last converged estimation as a initial point -- just to make sure it converges quickly
        parnonlin_preEst =  [1.4620   -3.5100    0.2552   -0.0600   -3.6478    2.5021   -0.9650    0.0460]';
        parnonlin_preEst_pi =  [2     2     2    2           -5      2     -1    1]'; % use the result from last converged estimation as a initial point -- just to make sure it converges quickly
        parnonlin_preEst_sigma =  [10     10     10       2       -2      2     -1    1]'; % use the result from last converged estimation as a initial point -- just to make sure it converges quickly
   
    else
        parnonlin_preEst = [ 6*ones(size(m.SigmaEntries,1),1) ; -.2*ones(size(m.PiEntries,1),1) ]; 
    end
    parnonlin_guess_all = parnonlin_preEst'; 
    MSRUN = 1;
    while MSRUN<NTASKS
        if MSRUN<=40
            parnonlin_guess =  2*parnonlin_preEst' .* rand(1 ,size(parnonlin_preEst,1)); % here we are making sure that the magnitudes of these non-linear parameters are reasonable. temp is checking that. LATER: change this such that starting points are set separately once and read in.
        elseif MSRUN>40 & MSRUN<=60
            parnonlin_guess =  2*parnonlin_preEst_pi' .* rand(1 ,size(parnonlin_preEst,1)); % here we are making sure that the magnitudes of these non-linear parameters are reasonable. temp is checking that. LATER: change this such that starting points are set separately once and read in.
        else 
            parnonlin_guess =  2*parnonlin_preEst_sigma' .* rand(1 ,size(parnonlin_preEst,1)); % here we are making sure that the magnitudes of these non-linear parameters are reasonable. temp is checking that. LATER: change this such that starting points are set separately once and read in.
        end
        %temp = (( parnonlin_guess(:,end-2)  + 10*parnonlin_guess(:,end-1) + parnonlin_guess(:,end) ) < 5) & (( parnonlin_guess(:,end-2)  + 10*parnonlin_guess(:,end-1) + parnonlin_guess(:,end) ) > 0);
        temp = 1;
        if temp == 1
            parnonlin_guess_all = [parnonlin_guess_all; parnonlin_guess];
            MSRUN = MSRUN + 1;
        end
    end
    
    task_id = str2num(getenv('SLURM_ARRAY_TASK_ID'));
    
    if isempty(task_id) == 1 % make sure the code works if no multi-start is required.
        task_id = 1;
    end
    
    ms_run    = task_id;
    parnonlin_start = parnonlin_guess_all(ms_run,:)'

fprintf('my task_id = %d\n', task_id);

%% Now setup estimation
m.theta_start = real(genMPECStart(m,parnonlin_start)); % generate a nice start point
if max(abs(imag(m.theta_start))) > 0
    fprintf('Warning: m.theta_start has imag part (but corrected)!!! The max is: %f \n', max(abs(imag(m.theta_start))));
    m.theta_start = real(m.theta_start);
end

[~, ~, m.delta_start ] = unpackMpecX(m.theta_start,m); % sign the solution of delta to m.delta_start
m.parnonlin_guess      = parnonlin_start;
m.max_restart          = 10; % Extra m-structure settings related to system-specific runs
clearvars -except m c2str saveFile knitroOptions Est_Method ms_run task_id myseed; 

%% Main estimation
switch m.Est_Method
    case 'MPEC'
         assert(0, 'MPEC method not implemented for weighted version');
         %Define a knitroOptions file if one is not defined. Note that this default is ALWAYS used by the LionX cluster.
         if (exist('knitroOptions', 'var') == 0)
                m.knitroFile = 'knitro_9_12core_Hessian.opt';
         else
                m.knitroFile = knitroOptions;
         end
         mainout      = MPECmain(m, c2str);
    case 'NFP' 
         global delta_start % this is to save time -- use from previously solved delta
         delta_start  = m.delta_start;
         m.knitroFile = 'knitro_9_nfp.opt';
         mainout      = NFPsingstep(m, c2str);
    otherwise
       fprintf('Error: Unrecognized Estimation Method Requested! \n');
       return;
end

disp(sprintf('Completed iteration %d\n', ms_run));

outFile = sprintf('firstMulti_%d.mat', task_id);
save(['..' filesep 'demand_output' filesep outFile], 'mainout', 'myseed');
toc;

%% Exit and close the parallel computation
[~, hname] = system('hostname');

   poolobj = gcp('nocreate');
   delete(poolobj);
   
   % exit matlab for clusters
if isunix
    exit
end
