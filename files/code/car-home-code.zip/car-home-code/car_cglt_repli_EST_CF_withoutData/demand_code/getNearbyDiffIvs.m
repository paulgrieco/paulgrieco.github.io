function [ IV ] = getNearbyDiffIvs(X, mktCode)
%This function calculates the IVs for random coefficients based on Ghandi &
%Houde (http://conference.nber.org/confer//2016/IOs16/Gandhi_Houde.pdf)
%page 23. 

%IV's are constructed market by market
numMkts = max(mktCode);
 

%We'll count the number of products within a standard deviation of X over
%the entire dataset. 
%cutoff = std(X);

%Too broad, instead let's see the average market level std
for mkt = 1:numMkts
    sdXmkt(mkt,:) = std(X(mktCode==mkt,:));
    numProd(mkt) = sum(mktCode==mkt);
end
cutoff = mean(sdXmkt);

%Initialize IV array,
IV = zeros(size(X));
IVt = IV;

%Loop over dimensions of random coeffients
for dim = 1:size(X,2)
    %Compute differentiation within a market
    for mkt = 1:numMkts
       %Grab vector of characteristics for this market
       Xmkt = X(mktCode ==mkt, dim);
       %Compute differences
       Dmkt = bsxfun(@minus, Xmkt, Xmkt');
       %Let instruments be number of products within 1 standard deviation
       %radius of product j's charachteristic. 
       %
       %For now, we're ignoreing firm affiliaiton. We're keeping track of number of products within 1 and .1 standard deviations...
       %Also consider .5 and .25 standard deviations but correlation seemed
       %high. Also .1 seems to be between 10 and 30 cars which fits the
       %idea of a "class" of autos. 
       IV(mktCode==mkt,dim) = sum(abs(Dmkt)< cutoff(dim));
       IVt(mktCode==mkt,dim) = sum(abs(Dmkt)< .1*cutoff(dim));
    end
end

%Use both cutoffs as IVs right now. Also experimented with only the 1sd
%version
IV = [IV IVt];