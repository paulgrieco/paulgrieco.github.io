function [c, Diff_share, dc, full_Jac] = shareConstraintsParallel(share, share_ij, m)

 [c, Diff_share, dc, full_Jac] = shareConstraintsParallel_base(share, share_ij, m);
 
end