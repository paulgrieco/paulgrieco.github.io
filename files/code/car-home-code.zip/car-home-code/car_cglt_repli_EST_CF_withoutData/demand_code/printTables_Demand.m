% This is to print tables from the result file.
% This one is for lognormal distribution specification.

% Input: resultName = 'Res_NormFra_12Inst_mpg';
% France_in = 1 -- France is normalized; France_in = 0 -- France is kept.

% This version is copied from printTable but to print the specifications
% with less RC.
% The input of method can be 'NFP' or 'MPEC'
% model_file is the hand-picked models to present elasticities
% modelDumInd: an indicator of whether we are using model dummies (1) or
% brand-country dummies (0) in the result
% the current result (leading result) is
% job570CF_Res_KeepFra_brandDumInter_full_4newCostIV_PartInter.mat

% this function comes from printTable_fullSpec.m and is changed to
% integrate all parts together.
% Input boot_ind is an indicator that if we want to use bootstrapping se or
% not.


function printTables_Demand(mainout, boot_ind, report_standardized_demand_coeff) 
if boot_ind == 1
% load bootstrapping result:
load('../demand_output/wBootresult','bootSe_parlin','bootSe_parnonlin')
end

method   = mainout.m.Est_Method;
dummies  = mainout.m.xSet;

France_in = 1; % from the old version where we normalized wrt France. Now no such normalization, france_in always equal to 1 for the code below

switch dummies
    case 'modelDum'
        modelDumInd = 1;
    case 'brandDumInter_full'
        modelDumInd = 0;        
    case 'brandDumInter_full_YrCtyDum'
        modelDumInd = 0;         
    case 'brandYrCtyDum_full'
        modelDumInd = 0;         
    case 'brandDum_nohomedummy'
        modelDumInd = 0; % remember this spec has the same linX structure as brandDumInter_full -- linX starts with chars and no constant included (a full set of brand dummies is used)
    otherwise
       fprintf('Error: Unrecognized set of dummies (xSet) requested: %s \n', dummies);
       return;
end

if mainout.m.same_rc_distr == 1 % if we are in the specification of the same taste, then we need to extend the result vector to be the same as other spec to use this function
      % save the original result. Here I replaced the demand estimate to re-use the code of demand estimate printing;
      % so be sure not to mistakely use the replaced estimate to do the
      % home preference projection.
      mainout_orig = mainout; 
      N_taste_para = (mainout.m.lognormprice==0) + 3 + 3*(mainout.m.chsq==1) + (mainout.m.chsq==2); % 3 means three chars
      taste_para = mainout.beta_hat( 1:N_taste_para ); % this is the taste parameters (mean taste)
      taste_ext = repmat(taste_para,1, mainout.m.nCtys);
      taste_ext = reshape(taste_ext',[],1);

      taste_se_para = mainout.seLin( 1:N_taste_para ); % this is the taste parameters (mean taste)
      taste_se_ext = repmat(taste_se_para,1, mainout.m.nCtys);
      taste_se_ext = reshape(taste_se_ext',[],1);

      mainout.beta_hat = [taste_ext; mainout.beta_hat( N_taste_para + 1:end)];
      mainout.seLin = [taste_se_ext; mainout.seLin( N_taste_para + 1:end)];
end



% allow to use task output file directly from lionXg.
switch method
     case 'MPEC'
         beta_hat = argsout{1, 1}.mainout.beta_hat;
         c2str= argsout{1, 1}.mainout.c2str;
         theta_hat = argsout{1, 1}.mainout.theta_hat;
         seLin= argsout{1, 1}.mainout.seLin;
         seNonlin= argsout{1, 1}.mainout.seNonlin;
         m = argsout{1, 1}.m;
         full_Elast = argsout{1, 1}.mainout.full_Elast;
         cost = argsout{1, 1}.mainout.cost;
    case 'NFP'
        theta_hat =mainout.mpec_x_hat;
    otherwise
       fprintf('Error: Unrecognized Method Set Requested: %s \n', method);
       return;
end

fid = fopen(['..' filesep 'demand_output' filesep 'results_demand.txt'], 'w');
%fid = fopen('results_demand.txt', 'w');

%unit_adjusted_norm = [1   77.0506    7.9830   27.4259]; % for mpg, we have 1 here since the first one is a constant, no unit
%unit_adjusted_norm = [7.8756    8.0139   4.6345]; % Note that using this means we use horse power per 100kg (rather than 1000kg as before)
if report_standardized_demand_coeff == 0
    unit_adjusted_norm = mainout.m.unit_adjusted_norm;
else % Question: do we need to take care of square of size??? Better to do this in setupstruct and run demand estimation again....
      %%%% Actually, if do manually, we should add the 2*coeff of the
      %%%% size^2 to the coeff of size, after done all this.
      
%       % Also, the following is how to calculate the mean income of each
%       country, from the data used in the code (after normalization):
%       inc_mkt = mean(mainout.m.demog_nodes(1,:,:),2);
%       inc_mkt = reshape(inc_mkt,[],1);
%       inc_cty = [mean(inc_mkt(1:4)), mean(inc_mkt(5:9)),mean(inc_mkt(10:11)),mean(inc_mkt(12:16)), ...
%       mean(inc_mkt(17:21)), mean(inc_mkt(22:26)), mean(inc_mkt(27:31)), mean(inc_mkt(32:36)), ...
%       mean(inc_mkt(37:41))]';

    unit_adjusted_norm = [2.5786    7.1843    3.5747];% this is hard-coded: it should be mean(char)/std(char) --- mean([hppwt sz mpgcty])./std([hppwt sz mpgcty])
end

if mainout.m.chsq == 1 % if we used square terms as the linear linX
      unit_adjusted_norm = [unit_adjusted_norm, unit_adjusted_norm.^2];
elseif mainout.m.chsq == 2 %only size is squared
      unit_adjusted_norm = [unit_adjusted_norm, unit_adjusted_norm(2).^2];
end

if modelDumInd == 1
     unit_adjusted_norm = [1, unit_adjusted_norm];
end

if mainout.m.lognormprice == 0 % In this case we have price
     unit_adjusted_norm = [unit_adjusted_norm, 1]; % the last one is for price
end

%% Load the specific result
[parnonlin_hat, ~, ~ ] = unpackMpecX(theta_hat,mainout.m);
[ Sigma_hat,  Pi_hat, alphaBar_hat, PiAlpha_hat, sigAlpha_hat ] = unpackNonlinParams(parnonlin_hat, mainout.m );
Sigma_hat = abs(Sigma_hat); % make sure the sigma's are positive

if boot_ind == 1 
    [ Sigma_se_hat, Pi_se_hat] = unpackNonlinParams(bootSe_parnonlin, mainout.m ); % use the bootstrapping result
else
    [ Sigma_se_hat, Pi_se_hat] = unpackNonlinParams(mainout.seNonlin, mainout.m ); % use the unpack again to take se of random coefficients as a vector (in both this line and the next line)
end
Sigma_se_hat = diag(Sigma_se_hat);

if modelDumInd == 1
homeDum_est = beta_hat(mainout.m.homeDidx);
homeDum_se = seLin(mainout.m.homeDidx);
end

%% Print table: estimated parameters of the demand equation
% First assgin estimates: all but price, which is assigned separately.
    % drop FRA since it is normalized
    for c = 1:mainout.m.nCtys
      if (strcmp(mainout.c2str.Ctys{c}, 'FRA'))
          fraCode = c;
          break
      end
    end
    CtyStr = mainout.c2str.Ctys;
    if France_in == 0 % drop France in the result if France is not in the result
        CtyStr(fraCode) = [];
    end

    % fill with content
    
    if mainout.m.chsq == 1 % if we used square terms as the linear linX
        %row_varName = {'Constant', 'HP per Weight', 'HP per Weight Square', 'Size', 'Size Square', 'MPDCITY', 'MPDCITY Square'};
        row_varName = {'HP per Weight',  'Size', 'MPDCITY','HP per Weight Square', 'Size Square', 'MPDCITY Square'};
    elseif mainout.m.chsq == 2
        row_varName = {'HP per Weight',  'Size', 'MPDCITY','Size Square'};
    else
        row_varName = {'HP per Weight', 'Size', 'MPDCITY'};
    end
    if modelDumInd == 1
        row_varName = ['Constant', row_varName];
    end
        
    col_varName = [CtyStr', 'R.C. Std', '$\Pi$'];
    
    col_leng = size(col_varName,2);
    row_leng = size(row_varName,2);
    
    res_est = cell(row_leng,col_leng);
    res_se = cell(row_leng,col_leng);
    
    if boot_ind == 1
        seLin_final = bootSe_parlin; % use the bootstrapping result
    else
        seLin_final = mainout.seLin; 
    end
    
    for i = 1:row_leng 
        % minus 1 since "Std of random coeff." is not in beta_hat
        res_est(i,1:end-2) = num2cell(mainout.beta_hat( (i-1)*(col_leng-2) + 1 : (i)*(col_leng-2))/unit_adjusted_norm(i) )'; 
        res_se(i,1:end-2) = num2cell(seLin_final( (i-1)*(col_leng-2) + 1 : (i)*(col_leng-2)) /unit_adjusted_norm(i))';
    end
    
    % the last column is for "Std of random coeff."
    res_est(:,col_leng-1:end) = [num2cell( 0 )]; 
    res_se(:,col_leng-1:end) = [ num2cell(0)];  
    
    if modelDumInd == 0
        rc_ind = [1:3+(mainout.m.lognormprice==0)]; % in case we have standard normal spec, we need to add one more.
        Sigma_vec_hat = diag(Sigma_hat);
        res_est(rc_ind,col_leng-1:end) = [num2cell(Sigma_vec_hat(2:size(mainout.m.rcX,2))./unit_adjusted_norm(rc_ind)' ), num2cell(Pi_hat(2:size(mainout.m.rcX,2),1)./unit_adjusted_norm(rc_ind)' )]; 
        res_se(rc_ind,col_leng-1:end) = [ num2cell(Sigma_se_hat(2:size(mainout.m.rcX,2))./unit_adjusted_norm(rc_ind)'), num2cell(Pi_se_hat(2:size(mainout.m.rcX,2),1)./unit_adjusted_norm(rc_ind)' )];   
    else
        rc_ind = [1:4+(mainout.m.lognormprice==0)];
        Sigma_vec_hat = diag(Sigma_hat);
        res_est(rc_ind,col_leng-1:end) = [num2cell( Sigma_vec_hat(1:size(mainout.m.rcX,2))./unit_adjusted_norm(rc_ind)' ), num2cell(Pi_hat(2:size(mainout.m.rcX,2),1)./unit_adjusted_norm(rc_ind)' )]; 
        res_se(rc_ind,col_leng-1:end) = [ num2cell(Sigma_se_hat(1:size(mainout.m.rcX,2))./unit_adjusted_norm(rc_ind)'), num2cell(Pi_se_hat(2:size(mainout.m.rcX,2),1)./unit_adjusted_norm(rc_ind)' )];  
    end
   
           
% Then print the head ...     
    
%   fprintf(fid, '\\begin{landscape} \n');
    fprintf(fid, '\\begin{table}[t] \n'); 
    fprintf(fid, '\\begin{center} \n');
    fprintf(fid, '\\caption{Estimated parameters of the demand equation }\\centering \n');
    if France_in == 0
        fprintf(fid, '\\begin{tabular}{@{}c|cccccccc|cc}\n');
        fprintf(fid, '\\toprule   \n');
        fprintf(fid, ' Variable & \\multicolumn{9}{c}{Estimate} \\\\\n');
    else
        fprintf(fid, '\\begin{tabular}{@{}cccccccccc|cc}\n'); % one more c
        fprintf(fid, '\\toprule   \n');
        fprintf(fid, ' Variable & \\multicolumn{10}{c}{Estimate} \\\\\n');
    end
    
    fprintf(fid, '\\midrule  \n');
    for i = 1:length(col_varName)
        fprintf(fid, '&%s', col_varName{i} );
    end
    fprintf(fid, '\\\\\n' );
    fprintf(fid, '\\midrule  \n');
   
    %Print main content
    for i = 1:row_leng
            fprintf(fid, '%s ', row_varName{i});
            fprintf(fid, '&%4.3f ',  cell2mat(res_est(i,1:end)) );
            fprintf(fid, '\\\\ \n');
            
            fprintf(fid, '   &\\footnotesize{(%4.3f)} ',  cell2mat(res_se(i,1:end)) ); 
            fprintf(fid, '   \\\\ \n ' );   
    end
    
    % print for price-related estimate separately:
    fprintf(fid, '\\midrule  \n');
     
    if modelDumInd == 1 % if we use model dummy, then we should list constant in the first row, so the last panel should be all about price parameters
        fprintf(fid, 'Price & \\multicolumn{4}{c}{$\\overline{\\alpha}$} & \\multicolumn{4}{c}{$\\pi_{p}$} & \\multicolumn{1}{c}{$\\sigma_{p}$}\\\\\n');
        fprintf(fid, ' &\\multicolumn{4}{c}{%4.3f} &\\multicolumn{4}{c}{%4.3f}  &\\multicolumn{2}{c}{%4.3f}  \\\\ \n',  alphaBar_hat, PiAlpha_hat(1), sigAlpha_hat  );
        fprintf(fid, ' &\\multicolumn{4}{c}{(%4.3f)} &\\multicolumn{4}{c}{(%4.3f)}  &\\multicolumn{2}{c}{(%4.3f)}  \\\\ \n',  mainout.seNonlin(end-2:end)  ); % here end-2 is hard-writen: assume we always have 3 price-related paramters.
    else
        fprintf(fid, 'Constant R.C. & \\multicolumn{3}{c}{$\\overline{\\alpha}$} & \\multicolumn{3}{c}{$\\pi_{p}$} & \\multicolumn{1}{c}{$\\sigma_{p}$}\\\\\n');
        fprintf(fid, ' {%4.3f}&\\multicolumn{3}{c}{%4.3f} &\\multicolumn{3}{c}{%4.3f}  &\\multicolumn{1}{c}{%4.3f}  \\\\ \n',  abs(mainout.parnonlin_hat(1)), alphaBar_hat, PiAlpha_hat(1), abs(sigAlpha_hat)  );
        if boot_ind == 1
            fprintf(fid, ' \\footnotesize{(%4.3f)}&\\multicolumn{3}{c}{\\footnotesize{(%4.3f)}} &\\multicolumn{3}{c}{\\footnotesize{(%4.3f)}}  &\\multicolumn{1}{c}{\\footnotesize{(%4.3f)}}  \\\\ \n', bootSe_parnonlin(1), bootSe_parnonlin(end-2:end)  ); % use bootstrapping result
        else
            fprintf(fid, ' \\footnotesize{(%4.3f)}&\\multicolumn{3}{c}{\\footnotesize{(%4.3f)}} &\\multicolumn{3}{c}{\\footnotesize{(%4.3f)}}  &\\multicolumn{1}{c}{\\footnotesize{(%4.3f)}}  \\\\ \n', mainout.seNonlin(1), mainout.seNonlin(end-2:end)  ); % here end-2 is hard-writen: assume we always have 3 price-related paramters.
        end
    end
    
    if modelDumInd == 1
   fprintf(fid, '\\midrule  \n');
    if France_in == 0
        fprintf(fid, 'Home Dummy & \\multicolumn{9}{l}{%4.3f} \\\\ \n', homeDum_est);
        fprintf(fid, ' &\\multicolumn{9}{l}{(%4.3f)}  \\\\ \n', homeDum_se);
    else
        fprintf(fid, 'Home Dummy & \\multicolumn{10}{l}{%4.3f} \\\\ \n', homeDum_est);
        fprintf(fid, ' &\\multicolumn{10}{l}{(%4.3f)}  \\\\ \n', homeDum_se);
    end
    
    end
        
    fprintf(fid, '\\bottomrule \n');
    fprintf(fid, '\\end{tabular} \n');
        fprintf(fid, '\\end{center} \n');
    fprintf(fid, '\\end{table} \n');
%   fprintf(fid, '\\end{landscape} \n');
    
% recover the original mainout (see note above)
if mainout.m.same_rc_distr == 1
    mainout = mainout_orig;
end

%% A sample of elasticities
   print_Elast(mainout);
 
%% A sample of markups and variable profits 
   print_Markups_firmLevel(mainout);
   print_Markups_modelLevel(mainout);

%% Home preferences (only do this for some cases)
if strcmp(dummies, 'brandDum_nohomedummy') == 0
   print_HomePreferences(mainout,boot_ind);
end

fclose('all');      
    
end