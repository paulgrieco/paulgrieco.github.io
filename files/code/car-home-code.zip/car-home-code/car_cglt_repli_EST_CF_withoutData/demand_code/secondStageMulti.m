%This is the master script for a second stage multi-start, we use the point in 
%demandresult as our weight matrix and start point. 
clear;
clc;
tic;

%% Multistart is off when testing on local computers. 
multistart = 0;     


%% Set identifiers for specifications: user-interface to choose options for specification
[m, c2str] = setupStructs(); % This script generates an (m, c2str) pair 

%% Parallel Cluster Settings
[~, hname] = system('hostname');

if ~isempty(strfind(hname, 'midway'))    % Are we on the UofC clusters 
    s = matlabpool('size');
    if s~=0
        matlabpool('close')
    end
    pc = parcluster('local');
    % explicitly set the JobStorageLocation to the temp directory that was created in your sbatch script
    pc.JobStorageLocation = strcat('/tmp/shengyuli/', getenv('SLURM_JOB_ID'), '/', getenv('SLURM_ARRAY_TASK_ID'));
    pause(1+180*rand()) % 
    matlabpool(pc, pc.NumWorkers);      % start the matlabpool with 12 workers
else
    if isempty(gcp('nocreate'))~=1
        poolobj = gcp('nocreate');
        delete(poolobj);
    end
    pc = parcluster('local');
    parpool(pc.NumWorkers);
end



%% Set Start Point & Weight Matrix
if m.lognormprice == 1
        %parnonlin_start = 0.99*[ -1.4062    0.2262   -1.2263    0.1785    9.2740   -0.7312    0.7899]'; % the nonlinear parameters -- the dimension depends on the dimension of Sigma and Pi matrix.
        load(['..' filesep 'demand_output' filesep 'demandresult']);
        parnonlin_start = mainout.parnonlin_hat;
        if isfield(mainout, 'W_opt')
            W_opt = mainout.W_opt;
        else
        % get optimal weight matrix for 2nd stage GMM:
%             [~, G] = getDesign(m);
%             [ ~, ~, delta_solved] = gmmObj_nfp(mainout.parnonlin_hat, mainout.W, G, m);
%             mpec_x1               = [mainout.parnonlin_hat; G*delta_solved; delta_solved];
           [ ~,~, W_opt]  = recoverBeta(mainout.mpec_x_hat, mainout.W, m );   % recover linear parameters
           clear mainout;
        end
else
        assert(0, 'Need to implement a start point for normal price setup');
        parnonlin_start = [ 6*ones(size(m.SigmaEntries,1),1) ; -.2*ones(size(m.PiEntries,1),1) ]; %Don't have a good start point for the "standard" setup right now.
end

%% Draw perturbations of the start point
seed = 5818;
if multistart == 1
    assert(~isempty(strfind(hname, 'midway')), 'demandEstimation: multistart option only available on midway cluster');
    task_id = str2num(getenv('SLURM_ARRAY_TASK_ID'));
    ms_run    = task_id;
    %parnonlin = parnonlin_guess_all(ms_run,:)';
else
    task_id = 1;
    ms_run = 1;
end
seed = seed+task_id;
rng(seed);
fprintf('my task_id = %d, seed = %d\n', task_id, seed);
start_shift = normrnd(0,1, size(parnonlin_start));

if numel(parnonlin_start) == 8
    if task_id == 1
        sig = 0
    elseif (task_id) < 50 & (task_id > 1)
        sig = 0.2*diag( [4 4 4 4 4 , .5 .3 .3]) % focus perturbe
    else
        sig = diag( [4 4 4 4 4 , .5 .3 .3])
    end
else
    sig = .1*eye(numel(parnonlin_start)); 
end

% give some disturb ONLY if we use multi-start
if multistart == 1
    parnonlin_start = parnonlin_start + sig*start_shift
else % else, use the previous estimate to save time
    parnonlin_start = [ 3.1824   -3.0703    0.3277   -0.0493   -3.2556    2.5243   -0.9972    0.0535]';
end
    
    

%% Now setup estimation
m.theta_start = real(genMPECStart(m,parnonlin_start)); % generate a nice start point
if max(abs(imag(m.theta_start))) > 0
    fprintf('Warning: m.theta_start has imag part (but corrected)!!! The max is: %f \n', max(abs(imag(m.theta_start))));
    m.theta_start = real(m.theta_start);
end

[~, ~, m.delta_start ] = unpackMpecX(m.theta_start,m); % sign the solution of delta to m.delta_start
m.parnonlin_guess      = parnonlin_start;
m.max_restart          = 10; % Extra m-structure settings related to system-specific runs
clearvars -except m c2str saveFile knitroOptions Est_Method ms_run task_id bweight W_opt seed; 

%% Main estimation
switch m.Est_Method
    case 'MPEC'
         assert(0, 'MPEC method not implemented for weighted version');
         %Define a knitroOptions file if one is not defined. Note that this default is ALWAYS used by the LionX cluster.
         if (exist('knitroOptions', 'var') == 0)
                m.knitroFile = 'knitro_9_12core_Hessian.opt';
         else
                m.knitroFile = knitroOptions;
         end
         mainout      = MPECmain(m, c2str);
    case 'NFP' 
         global delta_start % this is to save time -- use from previously solved delta
         delta_start  = m.delta_start;
         m.knitroFile = 'knitro_9_nfp.opt';
         mainout      = NFPsingstep(m, c2str, W_opt);
    otherwise
       fprintf('Error: Unrecognized Estimation Method Requested! \n');
       return;
end

disp(sprintf('Completed iteration %d\n', ms_run));

outFile = sprintf('secondMulti_%d.mat', task_id);
save(['..' filesep 'demand_output' filesep outFile], 'mainout', 'seed');
toc;

%% Exit and close the parallel computation
[~, hname] = system('hostname');

   poolobj = gcp('nocreate');
   delete(poolobj);

   % exit matlab for clusters
if isunix
    exit
end
