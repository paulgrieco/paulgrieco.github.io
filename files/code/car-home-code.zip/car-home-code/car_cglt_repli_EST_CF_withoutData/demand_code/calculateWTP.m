% this function produces the willingness to pay

function calculateWTP(mainout)

%load('secMultiResult.mat')

m = mainout.m;
[Sigma, Pi, alphaBar, PiAlpha, sigAlpha] = unpackNonlinParams(mainout.parnonlin_hat, m);
for mk = 1:m.nMkts                             % random coefficients for hp, size, weight, and price.
    ind_mk = (m.mktCode==mk);
    alpha(mk) = median(exp(alphaBar + PiAlpha*m.demog_nodes(:,:,mk))); % median consumer (in income)
end

% willingness to pay for home brand
homeP = 0.513; % this is hard-coded, from the home preference projection result
WTP_homeP = homeP./alpha' *10000;

% willingness to pay for home assembly
homeAsm = 0.396; % this is hard-coded, from the home preference projection result
WTP_homeAsm = homeAsm./alpha' *10000;

%% Save the data to model_implied_flows.xlsx which will be read into Stata
filename = sprintf('willingnessToPay');
sheet = 1;
varname{1} = 'Willingness to pay for home brand (USD)';
xlRange = 'B1';
xlswrite(['..' filesep 'demand_output' filesep filename],varname,sheet,xlRange)

varname{1} = 'Willingness to pay for home assembly (USD)';
xlRange = 'C1';
xlswrite(['..' filesep 'demand_output' filesep filename],varname,sheet,xlRange)

xlRange = 'A2';
xlswrite(['..' filesep 'demand_output' filesep filename],mainout.c2str.Mkts,sheet,xlRange)

xlRange = 'B2';
xlswrite(['..' filesep 'demand_output' filesep filename],WTP_homeP,sheet,xlRange)
xlRange = 'C2';
xlswrite(['..' filesep 'demand_output' filesep filename],WTP_homeAsm,sheet,xlRange)

return