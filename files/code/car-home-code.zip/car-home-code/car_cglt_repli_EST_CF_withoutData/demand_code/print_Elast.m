% This script calculate the median/average elasticities across selected
% models
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% The orientiation of the elasticities matrix: the current version produce the table that shows the substitution elasticity 
%%%% of models in the row with respect to the prices of models in the column.
%%%% This is done by the following "if r>=k" in the code. If we want to
%%%% rotate the table, we just need to use "if r<=k".
%%%% Note that the orientation of the getElast.m does not change -- the
%%%% matrix produced by getElast.m still read as "substitution elasticity 
%%%% of models in the COLUMN with respect to the prices of models in the ROW."
%%%% How to double check:
%%%% In getElast.m, we use 
%%%% price_share_offdiag = m.p * (1./share)'; (ignore the market)
%%%% That is:
%%%% ds1/dp1*(p1/s1)   ds2/dp1*(p1/s2)
%%%% ds1/dp2*(p2/s1)   ds2/dp2*(p2/s2)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function print_Elast(mainout)

% extract model codes
temp_code = 1:mainout.m.nModels;
model_codes = zeros(1,length(mainout.m.model_names_for_elast));
for i = 1:length(mainout.m.model_names_for_elast)
    model_code_temp = strcmp(mainout.m.model_names_for_elast(i),mainout.c2str.Models);
    model_codes(i) = temp_code(model_code_temp);
end
    
    
nModel = length(model_codes); % total number of models to show
Elast_cell = cell(nModel,nModel); % each cell will be a 3-dim array that collects cross-elasticities for all markets
Elast_median = nan(nModel,nModel); % this is the output matrix of elasticities
Elast_matix = full(mainout.full_Elast); % the full elasticity matrix
         
for r = 1:nModel
for k = 1:nModel 
  if r>=k %BE VERY CAREFUL HERE -- see the top of this code
    if r~=k % we only need to calculate the elasticities for two distinct models
          modelPair_codes = [model_codes(r), model_codes(k)];
    else
          modelPair_codes = [model_codes(r)]; % if it is in diag then we only need for one model
    end
    
    for j = 1:mainout.m.nMkts % for each market
            mktCode_show = j;
            mkt_showInd = mainout.m.mktCode == mktCode_show; % this is to abstract what we want from the big matrix
    
            % choose how many models to show in this market, currently it
            % is always 2
           nModel_show = length(modelPair_codes);
      
            % abstract the elasticity matrix for this market
           Elast_mkt = Elast_matix(mkt_showInd,mkt_showInd);
           modelCode_mkt = mainout.m.modelCode(mkt_showInd); % this is the model code in this market
        
            % abstract the elasticity matrix for these choosen models
            model_show_ind = zeros(length(modelCode_mkt),1);
            for i = 1:nModel_show
                model_show_ind = model_show_ind | modelCode_mkt == modelPair_codes(i);
            end

         Elast_model = Elast_mkt(model_show_ind,model_show_ind);
         modelCode_show =  modelCode_mkt(model_show_ind); % note that in this way the order of models may be different from the original model_code file
         
         if size(Elast_model,1) == nModel_show % if we indeed have the two models in the same market
             Elast_cell{r,k}(:,:,end+1) = Elast_model;
         end
             
         
     end
      
    % here we need to take the median from 2 to the end since the first one
    % is always 0 -- by the construction of the cell matrix
    % we need to assign them separately since otherwise it will overwrite the diag part
    %temp = median(Elast_cell{r,k}(:,:,2:end),3); % the 3rd dim is for market
    temp = mean(Elast_cell{r,k}(:,:,2:end),3); % the 3rd dim is for market
    if r~=k
        Elast_median(r,k) = temp(1,2); 
        Elast_median(k,r) = temp(2,1); 
    else
        Elast_median(r,r) =  temp;
        
    end
    
  end
end

modelName_show(r,1) = mainout.c2str.Models(model_codes(r));

end
         
    fid = fopen(['..' filesep 'demand_output' filesep 'results_elast.txt'], 'wt');
    % First print the head ...     
%    fprintf(fid, '\\begin{landscape} \n');
    fprintf(fid, '\\begin{table}[t] \n'); 
        fprintf(fid, '\\begin{center} \n');
    fprintf(fid, '\\caption{A sample of price elasticities matrix (median across market)  }\\centering \n');
    fprintf(fid, '\\begin{tabular}{@{}');
    for i = 1:nModel+1 % plus 1 since there is extra column for model name
        fprintf(fid, 'c');
    end
    fprintf(fid, '} \n');
    
    fprintf(fid, '\\toprule   \n');
       
    for i = 1:nModel
        fprintf(fid, '&%s', modelName_show{i} );
    end
    fprintf(fid, '\\\\\n' );
      
    fprintf(fid, '\\midrule  \n');
   
    %Print main content
    
    for i = 1:nModel
        fprintf(fid, '%s', modelName_show{i} );    
            for j = 1:nModel
                   fprintf(fid, '&%4.3f', Elast_median(i,j) );
            end
        fprintf(fid, ' \\\\ \n'); 
    end
    
    fprintf(fid, '\\bottomrule \n');
    fprintf(fid, '\\end{tabular} \n');
        fprintf(fid, '\\end{center} \n');
    fprintf(fid, '\\end{table} \n');
%    fprintf(fid, '\\end{landscape} \n');


