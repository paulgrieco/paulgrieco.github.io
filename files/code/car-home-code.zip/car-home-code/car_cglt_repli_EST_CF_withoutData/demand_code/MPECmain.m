% this function is revised from MPECmain. 
% the changes are:
% 1) now it take the input structure m and save all
% results in the file named by m.resFile
% 2) it use the initial guess form m

function [mainout] = MPECmain(m,c2str, sW)

%% Form Design matrix, setup sizes, and setup linear constraint matrices...
if (nargin < 3)
    fprintf('Forming problem\''s design matrices...\n');
    [W, G] = getDesign(m); % we need G to compute standard error later
else 
    fprintf('Using user-provided weight matrix, finding apropriate G');
    [W, G] = getDesign(m,sW);
end
    
    
% save DesignMats W G;
% or we can load these from data
%load DesignMats;

%Get the size of our instrument matrix
size_g = m.size_g;
size_nl = m.size_nl;

%Now define the linear constraints based on G:
% ...for some MATLAB solvers, need this since they use equality to zero
% ...KNITRO wouldn't have cared. 
%  mpec_x = [ nl g delta]
%  Our constraint: g = G'*delta,
%    so rewrite  0 = (G'delta - g),
%    then convert to 0 = B*mpec_x:
Aeq = [ zeros(size_g,size_nl) eye(size_g) -G];
Beq = zeros(size_g,1); 


%% Step 2: Setup Jacobian Pattern and KNITRO options...
Jac_Pattern_delta = sparse(m.nObs, m.nObs);
for mk=1:m.nMkts;
          ind_mk = (m.mktCode==mk);
          Jac_Pattern_delta(ind_mk,ind_mk) = 1;
end

Jac_Pattern_nonlin = [ones(m.nObs,size_nl),zeros(m.nObs,size_g),Jac_Pattern_delta];

Jac_Pattern_nonlin_sparse = sparse(Jac_Pattern_nonlin);

%Clear out the non-essential stuff for maximum available memory
clear Jac_Pattern_nonlin 

% For Hessian Pattern 
Hessian_Pattern_delta = sparse(m.nObs, m.nObs);
for mk=1:m.nMkts;
          ind_mk = (m.mktCode==mk);
          Hessian_Pattern_delta(ind_mk,ind_mk) = 1;
end

%Original pattern:
%Hessian_Pattern = [ones(size_nl,size_nl), ones(size_nl,m.nObs), zeros(size_nl,size_g);
%                             ones(m.nObs,size_nl),  Hessian_Pattern_delta, zeros(m.nObs,size_g);
%                             zeros(size_g,size_nl), zeros(size_g,m.nObs), ones(size_g,size_g)];

% Paul's attempt after Felix pointed out inconsistency in ordering...
Hessian_Pattern = [ones(size_nl,size_nl), zeros(size_nl, size_g) ones(size_nl,m.nObs) ;
                   zeros(size_g, size_nl), ones(size_g,size_g) zeros(size_g, m.nObs) ;      
                   ones(m.nObs,size_nl),  zeros(m.nObs,size_g) Hessian_Pattern_delta ];
                            
                         
                         
Hessian_Pattern_sparse = sparse(Hessian_Pattern);

%Clear out the non-essential stuff for maximum available memory
clear Hessian_Pattern


%ktropts = optimset('Display','iter','JacobPattern',Jac_Pattern_nonlin_sparse);
ktropts = optimset('Display','iter','JacobPattern',Jac_Pattern_nonlin_sparse, 'HessPattern',Hessian_Pattern_sparse, 'Hessian','user-supplied', 'HessFcn', @(mpec_x, lambda) getHessian(mpec_x, lambda, W, m) );


%% Setup Starting Guess...many different options

%Inner loop also needs an initial guess. It uses a warm-start but we're
%trying to speed things up by re-using the last computed delta, hence
%we pass the guess through a file...
%m.delta_read = 1;
%m.delta_fname = 'last_delta_NFPmkt.mat';
%delta_start = zeros(m.nObs,1);
%save(m.delta_fname, 'delta_start');
%fprintf('Peforming contraction from nonlinear parameter guess for warm start on constraints...\n');
%Assign a guess for the non-linear parameters
%nl_guess = zeros(9,1);
%delta_guess = getDelta(m.delta_start,getMu(nl_guess,m),m, 50);
%guess = [ nl_guess ; G*delta_guess ; delta_guess];


%Or just load it from a file...
fprintf('Guess loaded from m-structure...\n');
guess = m.theta_start; % now use the guess stored in m
assert(length(guess) == size_nl + size_g + m.nObs, 'ERROR: theta_start is the wrong size!');


%% Set bounds:
%All this really does is make sure that the sigmas are
%positive, they are all standard deviations, we're hoping this helps push
%them away from zero...
lb = -Inf*ones(size(guess));
%Make sure the variance parameters are weakly postive:
%SigmaEntries are the first elements of the nonlinear parameters.
% NOTE: This only works because we only have variances in Sigma, no
% covariances
%%%% lb(1:size(m.SigmaEntries,1)) = 0; % we can allow for negative

if m.lognormprice
   % NOTE: Variance of alpha is the final entry in the nonlinear parameter
   % vector. This should actually be fairly robust.
   %%%%%%%%%  lb(size_nl) = 0; % can allow for negative sigmas
end
ub = Inf*ones(size(guess));

%% FIRST STAGE ESTIMATION:
fprintf('Calling KNITRO to solve the MPEC estimation problem...\n');

%Allow for re-start based on m.max_restart:
%This code will restart any failed run (with negative exit flag)
%m.max_restart times.  For backwards compatibility of m.max_restart does 
%not exist, it is assumed to be zero.
%
% Note: we save the results file after every failure so it can be examined
% during runs on the cluster
tries = 0;
exitflag_theta = -999;
if (isfield(m, 'max_restart') == 0)
    max_restart = 0;
else
    max_restart = m.max_restart;
end
    
while (tries <= max_restart) && (exitflag_theta < 0) 
    tries = tries + 1
   [theta1,objVal,exitflag_theta,output_theta] = knitrolink(@(x) gmmObj_mpec(x, W, size_nl, size_g),guess,[],[],Aeq,Beq,lb,ub, ...
    @(x) mpecConstraints(x, m),ktropts,m.knitroFile);

   guess = theta1;
   theta1(1:m.size_nl)

   % save Res_MPECmain_normFra
   save(m.resFile);
end
   
%% second stage GMM
fprintf('Second stage GMM ...\n');

% get optimal weight matrix for 2nd stage GMM:
[ foo1 foo2 W_opt] = recoverBeta(theta1, W, m );
[oW oG] = getDesign(m,W_opt);
%Setup linear constraints...
Aeq = [ zeros(size_g,size_nl) eye(size_g) -oG];
Beq = zeros(size_g,1); 

% choose a nice starting point (to satisfy the linear constraints):
delta_guess = theta1(size_nl+size_g+1:end);
g_guess = oG*delta_guess;
guess = theta1;
guess(size_nl+1:size_nl+size_g) = g_guess;

%% Second Stage Call
%
% We know also auto-restart on the second stage, should probably have a
% function call to do this?  
fprintf('Calling KNITRO to solve the MPEC estimation problem (2nd stage)...\n');
ktropts = optimset('Display','iter','JacobPattern',Jac_Pattern_nonlin_sparse, 'HessPattern',Hessian_Pattern_sparse, 'Hessian','user-supplied', 'HessFcn', @(mpec_x, lambda) getHessian(mpec_x, lambda, oW, m) );

tries = 0;
exitflag_theta_2nd = -999;
while (tries <= max_restart) && (exitflag_theta_2nd < 0) 
    tries = tries + 1
    [theta_hat,objVal_2nd,exitflag_theta_2nd,output_theta_2nd] = knitrolink(@(x) gmmObj_mpec(x, oW, size_nl, size_g),guess,[],[],Aeq,Beq,lb,ub, ...
        @(x) mpecConstraints(x, m),ktropts,m.knitroFile);
    
    guess = theta_hat;
    theta_hat(1:m.size_nl)
    save(m.resFile);
end
    
% display the estimate for the nonlinear parameters for analysis
parnonlin_hat = theta_hat(1:m.size_nl)'

% recover beta:
[beta_hat uhat foo2] = recoverBeta(theta_hat, W_opt,  m );

% compute standard errors for linear and nonlinear parameters (beta_bar, alpha_bar, and nonlinear para)
% seLin (seNonlin) is the standard error of linear (nonlinear) parameters;
% var_LinNonlin is the variance matrix of all linear and nonlinear
% parameters
[seLin seNonlin var_LinNonlin] = getSe(theta_hat, W_opt,  m); 


%% Compute price elasticity and Costs
% elast_market_cell is the elasticity matrix by market, while full_Elast is
% the entire elasticity matrix across all market (should includes many zeros)
[elast_market_cell full_Elast] = getElast(theta_hat,  m);

cost = getCost(theta_hat, m, beta_hat);

% save Res_MPECmain_normFra
save(m.resFile, 'beta_hat', 'c2str', 'cost', 'full_Elast', 'm', 'objVal', 'objVal_2nd', 'theta1', 'theta_hat', 'seLin', 'seNonlin');

mainout.beta_hat = beta_hat;
mainout.c2str = c2str;
mainout.cost = cost;
mainout.full_Elast = full_Elast;
mainout.objVal = objVal;
mainout.objVal_2nd = objVal_2nd;
mainout.seLin = seLin;
mainout.seNonlin = seNonlin;
mainout.mpec_x1 = theta1;
mainout.mpec_x_hat = theta_hat;
mainout.m = m;

%Also save costs for export to the cost estimation.
saveCost(m, c2str, cost);

fprintf('Result file ''%s.mat'' saved.\n', m.resFile);


end
