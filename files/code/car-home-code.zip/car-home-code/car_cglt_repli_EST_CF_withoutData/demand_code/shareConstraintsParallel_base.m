% this is the base function to compute gradient of shares wrt delta
% it also produce the matrix of  Jac_market_ij as cells if requested.

function [c, Diff_share, dc, full_Jac, Jac_market_ij_cell] = shareConstraintsParallel_base(share, share_ij, m, singleMkt)
  %This function takes a vector delta of mean utilities and a matrix
  % mu of individual deviations (all constructed outside) and computes
  % the mkt shares of each product and then formulates the difference between shares and true shares. 
  c = [];
  dc = [];
  Nmkt = m.nMkts;
  
  myNargout = nargout;
  
  %NOTE: THIS FUNCTION ASSUMES THAT share and share_ij were calculated by getShare,
  %i.e, 
  %  [share, share_ij] = getShare(delta, mu,m);
  
  Diff_share = share - m.share;
  
      
  if nargout > 2
      %Allocate the jacobian...keep it sparse.
      full_Jac = sparse(m.nObs, m.nObs);
      
      %The self-derivatives are fairly straightforward, do them for all
      %markets at once:
      Self_ind = share_ij.*(1-share_ij);
      Self_Deriv = Self_ind*m.quadweight';
      
      Jac_market_cell = cell(Nmkt,1);
      if myNargout>4
          Jac_market_ij_cell = cell(Nmkt,1);
      end
          
      % Parallel loop over calculating the Jacobian for each market.
      mktCode    = m.mktCode;   % To minimize communication overhead...
      nNodes     = m.nNodes;
      quadweight = m.quadweight;
      loop_consumers = 1;   % ==1 -> loop over consumers to save on memory
      
    if nargin == 4 % this is the case when we only want to compute for a single market
          Jac_market_ij_cell_mk = cell(1);
          [ Jac_market_cell_mk,  Jac_market_ij_cell_mk] = gradientConstraintMarket(share_ij,Self_Deriv,mktCode,nNodes,quadweight,singleMkt,loop_consumers);
          Jac_market_ij_cell = Jac_market_ij_cell_mk;
      elseif nargin <= 3
      
        parfor mk=1:Nmkt
          if myNargout<=4
              Jac_market_cell{mk} = gradientConstraintMarket(share_ij,Self_Deriv,mktCode,nNodes,quadweight,mk,loop_consumers);
          elseif myNargout==5
              [ Jac_market_cell{mk},  Jac_market_ij_cell{mk}] = gradientConstraintMarket(share_ij,Self_Deriv,mktCode,nNodes,quadweight,mk,loop_consumers);
          else
              printf('Too many output!')
          end
        end
       
      
       for mk=1:Nmkt
          ind_mk = (m.mktCode==mk);
          full_Jac(ind_mk, ind_mk) = Jac_market_cell{mk};
       end
       
    else 
        fprintf('Error: wrong number of input!')
       
    end
      
  end
end

% add output -- Jac_market_ij is the integrand -- size (#s x #consumer)
function [Jac_market, Jac_market_ij] = gradientConstraintMarket(share_ij,Self_Deriv,mktCode,nNodes,quadweight,mk,loop_consumers)

% I removed the m structure from m.mktDums,m.nNodes,m.quadweight

          ind_mk = (mktCode==mk);
          n_mod = sum(ind_mk);
          sh_mkt = share_ij(ind_mk,:);
          sh_mkt_trans = sh_mkt';
          
          if loop_consumers ==1
             % Jac = zeros(n_mod, n_mod, nNodes);
              Jac_market = 0;
%               if nargout>1
%                   Jac_market_ij = zeros(n_mod,nNodes);
%               end
              for my_cons = 1:nNodes
                 deriv_self           = share_ij(ind_mk,my_cons) .* (1-share_ij(ind_mk,my_cons));
                 deriv_offdiag        = - share_ij(ind_mk,my_cons) * share_ij(ind_mk,my_cons)';
                 %Jac(:,:,my_cons)     = (1-eye(sum(ind_mk))) .* deriv_offdiag + diag(deriv_self);
                 Jac_market           = Jac_market + quadweight(1,my_cons) * ((1-eye(sum(ind_mk))) .* deriv_offdiag + diag(deriv_self));
                 
                 if nargout>1
                     Jac_market_ij(:,:,my_cons) =  ((1-eye(sum(ind_mk))) .* deriv_offdiag + diag(deriv_self));
                 end
                 
              end
              %Jac_market = sum(bsxfun(@times, Jac, reshape(quadweight,1, 1, nNodes)),3);

          else
              Cross_S_A = repmat((sh_mkt(:))',n_mod,1);
              Cross_S_B1 = reshape(repmat(sh_mkt_trans(:),1,n_mod), nNodes, n_mod*n_mod);
              Cross_S_B = reshape(Cross_S_B1', n_mod, n_mod*nNodes);
              Cross_S = Cross_S_A.*Cross_S_B;
              Cross_S = reshape(Cross_S, n_mod, n_mod, nNodes);
              Cross_Deriv = -sum(bsxfun(@times, Cross_S, reshape(quadweight,1, 1, nNodes)),3);
              Jac_market = (1-eye(n_mod)).*Cross_Deriv + diag(Self_Deriv(ind_mk));
          end
end