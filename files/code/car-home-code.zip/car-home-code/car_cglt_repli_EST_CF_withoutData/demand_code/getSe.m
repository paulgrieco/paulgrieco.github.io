% this function jointly computes the standard errors for both
% linear and nonlinear parameters separately, and covariance matrix of all
% (linear and nonlinear) parameters.

function [seLin seNonlin var_LinNonlin] = getSe(mpec_x, W_opt, m)
%% prepare to compute: get delta and mu

[pardemandnonlin, foo, delta] = unpackMpecX(mpec_x,m);
[mu alphai] = getMu(pardemandnonlin, m); 
[share share_ij] = getShare(delta, mu,m);


%% this is the derivative of Xi with respective to linear (beta's) and nonlinear parameters
grad_lin = ShareDeriv_lin(delta, mu, m); 


[foo1, foo2, foo3, grad_delta] = shareConstraintsParallel(share, share_ij, m);
grad_nonlin = ShareDeriv_nonlin(share_ij, alphai, m); 

%% now stack the two derivatives and compute the derivatives of Xi wrt to linear and nonlinear parameters
jacXiLinNonlin = - eye(m.nObs)/grad_delta * [grad_nonlin, grad_lin];

% note:  Following Formula (6.115) on page 219 of Cameron-Trivedi for
% Asymptotic variance.
%
% Use pinv to account for the 1-market models.
var_LinNonlin = pinv( (m.IV'*jacXiLinNonlin)' * (W_opt) * (m.IV'*jacXiLinNonlin) );

seLinNonlin = (diag( var_LinNonlin ).^.5); 

seNonlin = seLinNonlin(1:m.size_nl);
seLin = seLinNonlin(m.size_nl+1:end);



