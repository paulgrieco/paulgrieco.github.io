function [ W G PZ ] = getDesign( m , Win, bweights )
%getDeisgn uses the data to develop the linear portions of the
% objective function and returns them. These may then be passed
% into the objective function so they are never re-computed. 

%%  Generate Design matrix XX and instrument matrix ZZ:
    % Removed non-general part to the setup script.
    XX = m.linX;
    ZZ = m.IV;
       

   %% Unweighted design
   if nargin < 3 
        
        %Construct W either scaled by instruments or with an input weight
        %matrix...
        if (nargin < 2) || (isempty(Win)) 
            W = eye(size(ZZ,2))/(ZZ'*ZZ);  %This is the initial weight matrix, for efficiency, 

            % increase the weight on the cost of IV (if not then the weight on cost IV is very small)
            %W([1:m.nCostIV],[1:m.nCostIV]) = 100*W([1:m.nCostIV],[1:m.nCostIV]);

        else
            W = Win;
        end
        
        %Here let's construct a projection for IV
        invIV = eye(size(XX,2))/(XX'*ZZ*W*ZZ'*XX);
        PZ = eye(size(XX,1)) - XX*invIV*XX'*ZZ*W*ZZ';
        G = ZZ'*PZ;
   else
   %% Bootstrap weights
      
      B = sparse( diag(bweights) );
      
      %Construct W either scaled by instruments or with an input weight
      %matrix...
      if (isempty(Win)) 
          W = eye(size(ZZ,2))/(ZZ'*B*ZZ);  %This is the initial weight matrix, for efficiency, 

      else
            W = Win;
      end
      
      invIV = eye(size(XX,2))/(XX'*B*ZZ*W*ZZ'*B*XX);
      %Weighted projection matrix produces UNWEIGHTED Xi
      PZ = eye(size(m.linX,1)) - XX*invIV*XX'*B*ZZ*W*ZZ'*B;
      %Weighted Moment
      G = ZZ'*B*PZ;
      %G = ZZ*PZ;
   end

end

