% this is the function for abstract the Hessian matrix (wrt deltas') from
% the base function, for the dummy objective function.

function [Hessian_delta] = getHessian_dumObj(delta, lambda, mu, m) 
% Unpack and prepare 
[share, share_ij] = getShare(delta, mu, m);

% This the Third piece of the bigger Hessian in MPECmian -- \partial^2 s / \partial \delta^2   
tic
share2Deriv_delta = getShare2Deriv_delta_chain_parallel_loopMkt(lambda, m, share, share_ij);     
toc  

Hessian_delta = share2Deriv_delta;

end
