% this function compute the difference between the acutally estimated cost
% with the simulated cost given a new set of prices.

function  [c, cost_diff] = FOCConstraints(x,m_sub,mpec_x)
c = [];

m_sub.p = x; % this is the new price

cost_sim = getCost(mpec_x,m_sub, 0);

cost_diff = m_sub.cost - cost_sim;


