function [Gradient, shareijDeriv_nonlin] = ShareDeriv_nonlin_base(share_ij, alphai, m)

%NOTE: This function assumes getShare and getMu 
  %were called to generate share_ij, alphai

 
   Gradient = zeros(m.nObs, m.size_nl);
   
   if nargout>1
        shareijDeriv_nonlin = cell(m.nMkts,m.size_nl);% generate empty cell for derivatives
   end
   
   for mk=1:m.nMkts
       ind_mk = (m.mktCode==mk);
       share_ij_mk = share_ij(ind_mk,:);
       
       if sum(ind_mk) == 0
           continue
       end
       
       n_mod = sum(ind_mk);
       %Next line grabs non-linear characteristics for derivatives wrt
       %sig_x sig_p pi_p (recall that price is the only characteristic
       %interacted with income). This is NOT general. 
       
       
       
       %NOTE: The ordering here needs to match getMu:, 
       %  
       % must be consistent with the next two lines...
       rcX =  m.rcX(ind_mk,:);
       
       % First element: Sigma: 
       model_chars = rcX(:,[ m.SigmaEntries(:,1)] );
       dem_chars =  m.zeta_nodes(m.SigmaEntries(:,2),:);
       
       % Second element: Pi (if it exists):
       if ~isempty(m.PiEntries)
           model_chars =  [model_chars rcX(:, [m.PiEntries(:,1)]) ];   % m.nObs x size_nl      
           dem_chars =  [ dem_chars;  squeeze(m.demog_nodes( m.PiEntries(:,2), :, mk )) ];    % size_nl x m.nNodes
       end
       
       %These are the extra elements for a lognormal price, note they are
       %the only ones that use alphai: 
       if (m.lognormprice==1)
           % Third element: alphaBar:
           model_chars = [model_chars -m.p(ind_mk)];
           dem_chars   = [dem_chars; alphai(mk,:)];

           % Fourth element: PiAlpha (if it exists):
           if ~isempty(m.AlphaPiEntries)
               model_chars = [model_chars -repmat(m.p(ind_mk),1,length(m.AlphaPiEntries))];
               dem_chars =   [dem_chars; alphai(mk,:).*m.demog_nodes(m.AlphaPiEntries, :, mk) ];
           end

           % Fifth and final element: SigmaAlpha:
           model_chars = [model_chars -m.p(ind_mk) ];
           dem_chars = [dem_chars; alphai(mk,:).*m.zeta_nodes(end,:)]; %Note: By construction, price is always last zeta shock. 
       end
           
       inSum = model_chars' * share_ij_mk;          % 4 x 389 in "standard version" 
       
       
       for dc = 1:m.size_nl
           kernel = share_ij_mk.* bsxfun(@minus, model_chars(:,dc), inSum(dc,:));
                % n_mod x 389   .* n_mod x 389   

           ourweights = dem_chars(dc,:) .* m.quadweight;   % 1 x 810
           Gradient(ind_mk,dc)  = kernel * ourweights';
           
       % this is added -- to produce the derivative of share_ij wrt
       % nonlinear parameters
       if nargout > 1
           shareijDeriv_nonlin{mk,dc} = kernel.*repmat(dem_chars(dc,:), size(kernel,1), 1);    % note repmat here since each share has the same consumers. Dim: nObs(in mk) x nNode(#consumers)
       end
       
       end
       
           
   end
   
end
