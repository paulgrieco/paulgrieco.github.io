% this is the function for abstract the Hessian matrix (wrt to all
% parameters -- nonlinear and linear deltas') from the base function.

function [hessian] = getHessian(mpec_x, lambda, W, m) 

[hessian ] = getHessian_base(mpec_x, lambda, W, m);

end






