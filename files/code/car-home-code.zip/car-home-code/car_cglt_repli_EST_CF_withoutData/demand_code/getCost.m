% This function compute marginal cost of production, can only back out
% costs from a valid demand estimate, so we assume price is as in the data. 

function cost = getCost(parnonlin, parlin, DShocks, m, doSave)

if (nargin<5)
   doSave = 0;  % Kerem: at the bottom. what is the purpose of this?
end

[~, ~, full_DsDp] = getElast(parnonlin, parlin, DShocks, m);

% this is the cost vector that store the recovered cost:

cost = zeros(m.nObs,1);

  %% begin to compute cost by market
  Nmkt = m.nMkts;
  
      %We really should parallelize this...testing the post-estimation
      %block takes forever.
      for mk=1:Nmkt
          
        %  fprintf('Computing cost in market %d out of %d ...\n', mk,Nmkt)
          
          % find firms in this market
          ind_mk = (m.mktCode==mk);
          fmCode_uniq = unique(m.firmCode(ind_mk));
          
          % for each firm in this market, compute its cost for each model
          for k = 1:length(fmCode_uniq)
              % Construct Omega for this firm in this market, from
              % full_DsDp

              fm = fmCode_uniq(k);
              
              ind_mk_fm = ( ind_mk.*(m.firmCode==fm) ) == 1; % to make it logical.
              indMatrix_mk_fm = ((+ind_mk_fm)*(+ind_mk_fm)') == 1; % need to construct this matrix to take Omega from full_DsDp
              
              
              Omega_vec = - full_DsDp(indMatrix_mk_fm)'; % Note: need to take transpose. Double check this.
              % But note that Omega_vec is a vector, so we need to reshape
              % it to a square matrix
              Omega = reshape(Omega_vec,sum(ind_mk_fm),sum(ind_mk_fm));

              cost_mk_fm = m.p(ind_mk_fm) - ( eye(size(Omega))/Omega )*m.share(ind_mk_fm);
              
              % Then we need to put cost back into the big vector in the
              % correct position, so that the cost vector have same order
              % as the observation in m.
              
              assert( length(cost_mk_fm) == sum(ind_mk_fm) ); % check the size is correct
              j = 1; % this is the pointer of the position of cost_mk_fm
              for i = 1:m.nObs
                  if ind_mk_fm(i) == 1
                      cost(i) = cost_mk_fm(j);
                      j = j + 1; % move the pointer to the next position
                  end
              end
                      
          
          end
      

      end
    
% %% Now save cost as .csv file   
% filename_cost = 'cost_recovered.csv'; 
% fileID_cost = fopen(filename_cost,'wt');
% 
% filename_cost_xls = 'cost_recovered.xls'; 
% fileID_cost_xls = fopen(filename_cost_xls,'wt');
% 
% % we need read in csv file to use the strings of markets, etc.
% filename = 'demandDataFeb2014.csv';
% readInCsv;  % this csv file added to more iv's
% 
% % write variable names
% var_name = {'ctyCode', 'cty', 'mktCode', 'mkt','firmcode', 'firm', 'modelCode', 'model' ,'cost'};
% [~, columns] = size(var_name);
% for index = 1:columns-1    
%     fprintf(fileID_cost_xls, '%s,', var_name{1,index});
% end 
% fprintf(fileID_cost_xls, '%s\n', var_name{1,end});
% fclose(fileID_cost_xls);
% 
% % write numerical data 
% cost_fileContent = [m.ctyCode, cty, m.mktCode, mkt, m.firmCode firm, m.modelCode, model, cost];
% %dlmwrite(filename_cost, cost_fileContent ,'-append', 'delimiter', ',');
% xlswrite(filename_cost_xls, cost_fileContent);
% 
% fprintf('%s, %s, %s, and %s are saved as file: %s \n', var_name{1},var_name{3},var_name{5},var_name{7},filename_cost) 

%% Now save cost as an excel file   

if (doSave~=0)

    % we need read in csv file to use the strings of markets, etc.
    filename = ['..' filesep 'input_files' filesep 'demandData.csv'];
    readInCsv;  % why is this needed??

    filename_cost = ['..' filsep 'demand_output' filesep 'cost_recovered.csv']; 

    % start to write data
    cty_ext = [cty(1); cty]; % make a room for the variable name
    xlswrite(filename_cost, cty_ext,1,'A');

    ctyCode_ext = [m.ctyCode(1); m.ctyCode]; % make a room for the variable name
    xlswrite(filename_cost, ctyCode_ext,1,'B');

    mkt_ext = [mkt(1); mkt]; % make a room for the variable name
    xlswrite(filename_cost, mkt_ext,1,'C');

    mktCode_ext = [m.mktCode(1); m.mktCode]; % make a room for the variable name
    xlswrite(filename_cost, mktCode_ext,1,'D');

    firm_ext = [firm(1); firm]; % make a room for the variable name
    xlswrite(filename_cost, firm_ext,1,'E');

    firmCode_ext = [m.firmCode(1); m.firmCode]; % make a room for the variable name
    xlswrite(filename_cost, firmCode_ext,1,'F');

    model_ext = [model(1); model]; % make a room for the variable name
    xlswrite(filename_cost, model_ext,1,'G');

    modelCode_ext = [m.modelCode(1); m.modelCode]; % make a room for the variable name
    xlswrite(filename_cost, modelCode_ext,1,'H');

    cost_ext = [cost(1); cost]; % make a room for the variable name
    xlswrite(filename_cost, cost_ext,1,'I');

    % write the variable names in the first line
    var_name = {'cty', 'ctyCode', 'mkt','mktCode', 'firm', 'firmcode',  'model' ,'modelCode','cost'};
    xlswrite(filename_cost, var_name);

    fprintf('%s, %s, %s, and %s are saved as file: %s \n', var_name{1},var_name{3},var_name{5},var_name{7},filename_cost) 
end

end




