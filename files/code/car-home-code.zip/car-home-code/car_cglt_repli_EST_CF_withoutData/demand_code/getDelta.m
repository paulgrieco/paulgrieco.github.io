% This function uses iteration to calculate mean utility of each model-year-country
% observation.

% The difference of this one and getDelta is it prints less message

function [delta, diff_max] = getDelta(delta0, mu, m, varargin)


tol  = 1e-8;              % tolerance for iteration stopping rule
diff = 1;                 % initial value of difference across iterations
i    = 1;                 % iteration counts
deltai = delta0;

%Set the default value for maxit (optional input...in future add tolerances
%via options structure?
if isempty(varargin)
   maxit = 1e3;
   tol  = 1e-8;
else
    maxit = varargin{1};
    tol = varargin{2};
end

while diff > tol && i<maxit
    share_guess = getShare(deltai,mu, m);    % market shares if 
                                        % deltanew is the mean utility vector
    diff_max    = max(abs(share_guess-m.share));  % difference between predicted and observed market shares.
    diff_mean   = mean(abs(share_guess-m.share));   
    
    if (isnan(diff_mean))
        fprintf('getDelta: TROUBLE! getShare hit overflow...\n');
        if (i ==1)
            fprintf('\t ...Trying to recover with MNL Startpoint\n');
            deltai = log(m.share) - log(m.outshare);
            continue;
        else
            fprintf('\t ...Giving up.\n');
            error('getDelta failed to find an interior share point.\n');
        end
    end    
        
    if min(share_guess) > 0
        deltanew = deltai + log(m.share ) - log(share_guess);
    else
        fprintf('getDelta: TROUBLE! getShare returned a zero share...\n');
        %expdeltanew = exp(deltai).*m.share./(max(share_guess, min(share_guess(share_guess>0)) ) );  % update mean utility vector
        %deltanew = log(expdeltanew);
        if (i==-1)
           fprintf('\t...trying to recover with MNL startpoint...\n');
           deltanew = log(m.share) - log(m.outshare);
        else
           fprintf('\t...trying to recover by bounding minimum share...\n');
           deltanew = deltai + log(m.share ) - max(log(share_guess), log(1e-8));
        end
           
    end
    
    diff_delta_max = max(abs(deltanew - deltai));
    diff_delta_mean = mean(abs(deltanew - deltai));
%     if mod(i,500)==1
%              display(['getDelta: Iteration of mean utility :' num2str(i)])
%              display(['   max(share_guess - share_data) :' num2str(diff_max)])
%              display(['   mean(share_guess - share_data) :' num2str(diff_mean)])
%              display(['   max(delta_new - delta_i)      :' num2str(diff_delta_max)])
%              display(['   mean(delta_new - delta_i)      :' num2str(diff_delta_mean)])
%     end                            % show iterating process
    diff = diff_delta_max;
    i = i+1;              % update iteration count
    deltai = deltanew;
end

delta = deltanew;             % mean utility equal to converged vector.
    % in some cases, if the choice of the initial nonlinear parameters are not good, then this function return imag guess of delta.
    % This is because: in getShare.m, we use finite nodes to approximate
    % the intergal.
    
%    max(abs(imag(delta)))
    
    %assert(max(abs(imag(delta))) == 0 ) % this is to verifty that we have a good delta estimate.

end
