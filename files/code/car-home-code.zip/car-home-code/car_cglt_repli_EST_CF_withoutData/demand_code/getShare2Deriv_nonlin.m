% This function compute the first piece in Hessian -- \partial^2 s / \partial^2 \theta --  for nonlinear parameters

function    share2Deriv_nonlin = getShare2Deriv_nonlin(lambda, shareijDeriv_nonlin, share_ij, alphai, m)
% First, compute the second derivative wrt nonlinear parameters:
 share2Deriv_nonlin = zeros(m.size_nl, m.size_nl);
 share2Deriv_nonlin_mk = zeros(m.size_nl, m.size_nl); % this is for a specific market mk -- they sums up to get share2Deriv_nonlin.
   
   for mk=1:m.nMkts
       ind_mk = (m.mktCode==mk);
       share_ij_mk = share_ij(ind_mk,:);
       
       if sum(ind_mk) == 0
           continue
       end
       
       % The order of the nonlinear parameters are -- the order cannot be changed!!!
       % simga_k, pi_k, alpha_bar, pi_p, sigma_p
       % There are three components in the first derivative of share wrt to nonlinear parameters (see note).
       % First: alpha_i or 1, second: share_ij, third: things in (). Now
       % prepare as follows:
       
       %% Part 1 (prepare): To make derivatives forms consistant, we specify the first component and the derivative of
       % the first component wrt nonlinear parameters in the following cell structures:

        for k = 1:m.size_nl % 
           for r = 1:m.size_nl  % for all nonlinear parameters
           comp1{k,r} = 1; 
           comp1Deriv_nonlin{k,r} = 0; 
           end
        end

        size_SigPi = size(m.SigmaEntries,1) + size(m.PiEntries,1);
        for k = (size_SigPi + 1):m.size_nl %
            
           for r = 1:size_SigPi
                comp1{k,r} = alphai(mk,:); 
                comp1Deriv_nonlin{k,r} = 0;     
           end
           comp1{k,size_SigPi+1} = alphai(mk,:); 
           comp1Deriv_nonlin{k,size_SigPi+1} = alphai(mk,:); 
           for r = 1:length(m.AlphaPiEntries)
                comp1{k,size_SigPi+1+r} = alphai(mk,:); 
                comp1Deriv_nonlin{k,size_SigPi+1+r} = alphai(mk,:).*m.demog_nodes(r, :, mk); 
           end
           comp1{k,end} = alphai(mk,:);
           comp1Deriv_nonlin{k,end} = alphai(mk,:).*m.zeta_nodes(end,:);
        end
        
        %% We incorporate dem_node in the first order derivative into it.
        
        % for sigmas'
        for r = 1:m.size_nl % for each column, it is the same
            
            for k = 1:size(m.SigmaEntries,1) % for each sigma
                comp1{k,r} = comp1{k,r}.*m.zeta_nodes(m.SigmaEntries(k,2),:);
                comp1Deriv_nonlin{k,r} = comp1Deriv_nonlin{k,r}.*m.zeta_nodes(m.SigmaEntries(k,2),:);
            end
            
            for k = 1+size(m.SigmaEntries,1) :size(m.SigmaEntries,1) + size(m.PiEntries,1)  % for each pi, if exists
                comp1{k,r} = comp1{k,r}.*squeeze(m.demog_nodes( m.PiEntries(k-size(m.SigmaEntries,1),2), :, mk ));
                comp1Deriv_nonlin{k,r} = comp1Deriv_nonlin{k,r}.*squeeze(m.demog_nodes( m.PiEntries(k-size(m.SigmaEntries,1),2), :, mk ));
            end
            
            
            % for pi_sigma  -- we have this change (this is end is hard-written) only if we are in lognormal
           % specification.
           if (m.lognormprice==1)
            % for alpha_bar, it is x 1, so it is unchanged.
           
             % for pi_alpha, if any
               for k = size_SigPi + 1 + 1 : size_SigPi + 1 + length(m.AlphaPiEntries)  % for each pi, if exists    
                   comp1{k,r} = comp1{k,r}.*m.demog_nodes(m.AlphaPiEntries( k-size_SigPi-1 ), :, mk);
                   comp1Deriv_nonlin{k,r}  = comp1Deriv_nonlin{k,r} .*m.demog_nodes(m.AlphaPiEntries( k-size_SigPi-1), :, mk);
               end
           
           
               comp1{end,r} = comp1{end,r}.*m.zeta_nodes(end,:);%Note: By construction, price is always last zeta shock. 
               comp1Deriv_nonlin{end,r}  = comp1Deriv_nonlin{end,r} .*m.zeta_nodes(end,:);
           end
        end
               

       %% Part 2 (prepare): To get derivatives of share_ij wrt to all
       % nonlinear parameters.
       %shareijDeriv_nonlin_mk =  shareijDeriv_nonlin(mk,:); % note it is still a cell, each element has size nObs(in mk) x nNode(#consumers)
       
       %% Part 3 (prepare): to get model characteristics to loop over --
       % these corresponding to the first derivatives.
       
       rcX =  m.rcX(ind_mk,:);

       % First element: Sigma: 
       model_chars = rcX(:,[ m.SigmaEntries(:,1)] ); % this is the chars that in the bracket () -- see note
       
       % Second element: Pi (if it exists):
       if ~isempty(m.PiEntries)
           model_chars =  [model_chars rcX(:, [m.PiEntries(:,1)]) ];   % m.nObs x size_nl      
       end
       
       %Here are the log-normal coefficients for price, which don't exist in the
       %"standard case":
       if (m.lognormprice==1)
           % Third element: alphaBar:
           model_chars = [model_chars -m.p(ind_mk)];

           % Fourth element: PiAlpha (if it exists):
           if ~isempty(m.AlphaPiEntries)
               model_chars = [model_chars -repmat(m.p(ind_mk),1,length(m.AlphaPiEntries))];
           end

           % Fifth and final element: SigmaAlpha:
           model_chars = [model_chars -m.p(ind_mk) ];
       end

       %% Now let's compute:
       assert(size(model_chars,2) == m.size_nl)
       
       for k = 1:m.size_nl % move over nonlinear parameters (model chars)
          model_chars_k = model_chars(:,k); % k-th char -- corresponding to first order derivatives
           
          inSum = model_chars_k' * share_ij_mk;          %  
         
          kernel = bsxfun(@minus, model_chars_k, inSum);
          for dc = 1:m.size_nl
              kernel_1 = share_ij_mk.*kernel;
              kernel_2 = shareijDeriv_nonlin{mk,dc}.*kernel;
              
              Sum_Deriv = model_chars_k' * shareijDeriv_nonlin{mk,dc};          %  the inner product produce the sum -- dim is 1 x 389. This is index by consumer (i), the same for all models
              kernel_3 = - share_ij_mk.*repmat(Sum_Deriv, size(share_ij_mk,1),1);
              
              w_1 = comp1Deriv_nonlin{k,dc}.* m.quadweight; % our "weight" -- in the general sense -- it includes weight as well as the other time that has the same size as weight, index by i (consumer).
              w_2 = comp1{k,dc}.* m.quadweight;
              
              Deriv_2nd_temp = kernel_1 * w_1' + (kernel_2 + kernel_3) * w_2';
              
              share2Deriv_nonlin_mk(k,dc) = lambda.eqnonlin(ind_mk)' * Deriv_2nd_temp; % note this is for a specific market: mk, we need the sum of all mkt, so we have the next line outside this loop.
              
          end

       end
       
       share2Deriv_nonlin = share2Deriv_nonlin + share2Deriv_nonlin_mk;
       
   end
   
end