%This is the master script for the demand estimation 
clear;
clc;
tic;

%% Multistart vs manually set initial point
multistart = 1;     % yes for 1, any other number uses one (manually set) initial point
                    % eventually: (1) Move point generation to setupStructs
                    % (2) maybe have separate scripts. 
                    % 

%% Set identifiers for specifications: user-interface to choose options for specification
[m, c2str] = setupStructs(); % This script generates an (m, c2str) pair 

%% Parallel Cluster Settings
[~, hname] = system('hostname');

if ~isempty(strfind(hname, 'midway'))    % Are we on the UofC clusters 
    s = matlabpool('size');
    if s~=0
        matlabpool('close')
    end
    pc = parcluster('local');
    % explicitly set the JobStorageLocation to the temp directory that was created in your sbatch script
    pc.JobStorageLocation = strcat('/tmp/shengyuli/', getenv('SLURM_JOB_ID'), '/', getenv('SLURM_ARRAY_TASK_ID'));
    pause(1+60*rand()) % We would have an error when starting many parpools on the same machine at the same time. The jobs seem to write in the same temporary file and causing the error, 
    matlabpool(pc, pc.NumWorkers);      % start the matlabpool with 12 workers
else
    if isempty(gcp('nocreate'))~=1
        poolobj = gcp('nocreate');
        delete(poolobj);
    end
    pc = parcluster('local');
    parpool(pc.NumWorkers);
end

%% Draw weights...
seed = 5818;
if multistart == 1
    assert(~isempty(strfind(hname, 'midway')), 'demandEstimation: multistart option only available on midway cluster');
    task_id = str2num(getenv('SLURM_ARRAY_TASK_ID'));
    ms_run    = task_id;
    %parnonlin = parnonlin_guess_all(ms_run,:)';
else
    task_id = 0;
    ms_run = 0;
end
seed = seed+task_id;
rng(seed);
fprintf('my task_id = %d, seed = %d\n', task_id, seed);
%Draw the weights for this run...
bweight = exprnd(ones(m.nObs,1));

%% Set Start Point & Weight Matrix
if m.lognormprice == 1
        %parnonlin_start = 0.99*[ -1.4062    0.2262   -1.2263    0.1785    9.2740   -0.7312    0.7899]'; % the nonlinear parameters -- the dimension depends on the dimension of Sigma and Pi matrix.
        load(['..' filesep 'demand_output' filesep 'secMultiResult']);
        parnonlin_start = mainout.parnonlin_hat;
        W_boot = mainout.W; % NOTE: was loading mainout.W_opt, but since now we are doing first and second stage multi-start separately, W in mainout from the second stage is the optimal weight matrix used.
        clear mainout;
else
        assert(0, 'Need to implement a start point for normal price setup');
        parnonlin_start = [ 6*ones(size(m.SigmaEntries,1),1) ; -.2*ones(size(m.PiEntries,1),1) ]; %Don't have a good start point for the "standard" setup right now.
end


m.theta_start = real(genMPECStart(m,parnonlin_start)); % generate a nice start point
if max(abs(imag(m.theta_start))) > 0
    fprintf('Warning: m.theta_start has imag part (but corrected)!!! The max is: %f \n', max(abs(imag(m.theta_start))));
    m.theta_start = real(m.theta_start);
end

[~, ~, m.delta_start ] = unpackMpecX(m.theta_start,m); % sign the solution of delta to m.delta_start
m.parnonlin_guess      = parnonlin_start;
m.max_restart          = 10; % Extra m-structure settings related to system-specific runs
clearvars -except m c2str saveFile knitroOptions Est_Method ms_run task_id bweight W_boot seed; 

%% Main estimation
switch m.Est_Method
    case 'MPEC'
         assert(0, 'MPEC method not implemented for weighted version');
         %Define a knitroOptions file if one is not defined. Note that this default is ALWAYS used by the LionX cluster.
         if (exist('knitroOptions', 'var') == 0)
                m.knitroFile = 'knitro_9_12core_Hessian.opt';
         else
                m.knitroFile = knitroOptions;
         end
         mainout      = MPECmain(m, c2str);
    case 'NFP' 
         global delta_start % this is to save time -- use from previously solved delta
         delta_start  = m.delta_start;
         m.knitroFile = 'knitro_9_nfp.opt';
         mainout      = NFPsingstep(m, c2str, W_boot, bweight);
    otherwise
       fprintf('Error: Unrecognized Estimation Method Requested! \n');
       return;
end

disp(sprintf('Completed iteration %d\n', ms_run));

outFile = sprintf('weighted_%d.mat', task_id);
save(['..' filesep 'demand_output' filesep outFile], 'mainout', 'bweight', 'seed');
toc;

%% Exit and close the parallel computation
[~, hname] = system('hostname');
if ~isempty(strfind(hname, 'midway'))    % Are we on the UofC clusters
    matlabpool('close'); 
    exit
else
   poolobj = gcp('nocreate');
   delete(poolobj);
end

 % exit matlab for clusters
if isunix
    exit
end
