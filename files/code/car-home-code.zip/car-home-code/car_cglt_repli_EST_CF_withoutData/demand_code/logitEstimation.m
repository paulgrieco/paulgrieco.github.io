%This file runs a very simple multinomial logit demand model where we have
%a single price coefficient that is interacted by the mean income by
%country.  We allow for seperate brand-country dummies to account for
%unobserved heterogeneity across countries but do not allow for unobserved
%heterogeneity within countries. 

clear 
clc

%First we call setup structs, then we alter "m" to be approprate for the
%multinomial logit design. 
[m, c2str] = setupStructs();

%% Do the Multinomial Logit Estimation
%Get the mean income by market code. 
meanlogInc_mkt = squeeze(mean(m.demog_nodes(1,:,:)));

% we need the part of linX that does not contain price (that is, to get rid of price if we are coming from standard normal case.)
exogX = logical(1-(sum(m.linP,1)>0));
linX_exog = m.linX(:,exogX); 

%Add price and price interacted with mean income to m.linX: 
linX_orig = m.linX; % save the original linX before we make the change
m.linX = [ -m.p -m.p.*meanlogInc_mkt(m.mktCode) linX_exog];

[objValue_1, objValue_2, beta_c, beta, se, V, u] = logitSpec(m);

priceEst = beta(1:2);
priceSe  = se(1:2);

%Print tables
printTables_Logit(beta,se, m, c2str) 

%% Calculate the Home Preference:

%Setup to use extractHomeFromCBD


m.linX = linX_orig; % use the original linX
beta_np = beta(3:end);
foo = length(beta_np);

%Need to zero-pad to get back format from the random coefficients model
var_np = zeros(m.size_nl + foo,m.size_nl + foo);
var_np(m.size_nl+1:end,m.size_nl+1:end) = V(3:end,3:end);

% now put necessary variables in mainout (although we do not have an actual mainout, but we want reuse the printing code)
mainout.m = m;
mainout.beta_hat = beta_np;
mainout.var_Nonlin_Lin = var_np;
mainout.c2str.Ctys = c2str.Ctys;

% %% Print Home preferences 
% now put necessary variables in mainout (although we do not have an actual mainout, but we want reuse the printing code)
mainout.m = m;
mainout.beta_hat = beta_np;
mainout.var_Nonlin_Lin = var_np;
mainout.c2str.Ctys = c2str.Ctys;
print_HomePreferences(mainout);


%% Calculate elasticities and price derivatives for each car
 [elast_market_cell, full_Elast, full_DsDp] = getElastLogit(beta, meanlogInc_mkt, m);

 ownElast = full(diag(full_Elast));
 mean(ownElast)
 sum(ownElast>-1)
 
%Although the mean elasticity is -4, there are MANY inelastic demands, so
%we cannot compute costs.
