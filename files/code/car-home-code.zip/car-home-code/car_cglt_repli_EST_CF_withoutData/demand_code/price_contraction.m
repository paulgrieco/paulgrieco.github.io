% this function do the contraction mapping 



function [price_out, share_out, exitflag] = price_contraction(parnonlin, parlin, DShocks, costs, m, mkt, damp, iterMax)


          %Check if there is a dampening parameter.
          assert(nargin==6 || nargin==8)
          if nargin == 6
              damp = 1;
              iterMax = 200;
          end

          % begin to the contraction mapping, maybe softcode these?
          diff_tol = 1e-8;
          
          %Grab indices for models in this market
          ind_mk = (m.mktCode == mkt);
          
          %Get the set of Firms that participate in this market
          fmCode_uniq = unique(m.firmCode(ind_mk));
          
          %Start from prices in the data. 
          price_prev = m.p;
          price_new = m.p;
         
          
          itr = 1;
          diff = 1;
          while itr<=iterMax && diff>diff_tol
              [~, ~, full_DsDp] = getElast(parnonlin, parlin, DShocks, m, price_prev, mkt);
              delta_prev = constructDelta(parlin, price_prev, DShocks, m);
              mu_prev = getMu(parnonlin, m, price_prev);  
              share = getShare(delta_prev, mu_prev, m);
              share_mk = share(ind_mk);
              costs_mk = costs(ind_mk);
              
              price_new_mk = zeros(sum(ind_mk,1),1);
              
              % for each firm in this market, compute its price for each model
              for k = 1:length(fmCode_uniq)
                  % Construct Omega for this firm in this market, from
                  % full_DsDp

                  fm = fmCode_uniq(k);

                  ind_mk_fm = ( (m.firmCode(ind_mk)==fm) ) == 1; % to make it logical.
                  indMatrix_mk_fm = ((+ind_mk_fm)*(+ind_mk_fm)') == 1; % need to construct this matrix to take Omega from full_DsDp


                  Omega_vec = - full_DsDp(indMatrix_mk_fm)'; % Note: need to take transpose. Double check this.
                  % But note that Omega_vec is a vector, so we need to reshape
                  % it to a square matrix
                  Omega = reshape(Omega_vec,sum(ind_mk_fm),sum(ind_mk_fm));

                  %[pardemandnonlin, ~, delta] = unpackMpecX(theta_hat_part,m_sub);
                  

                  %Here is a tricky line, we need to delta relating to this
                  %price, 

                  
                  price_mk_fm = costs_mk(ind_mk_fm) + ( eye(size(Omega))/Omega )*share_mk(ind_mk_fm);                            

                  % Then we need to put cost back into the big vector in the
                  % correct position, so that the cost vector have same order
                  % as the observation in m.

                  assert( length(price_mk_fm) == sum(ind_mk_fm) ); % check the size is correct
                  j = 1; % this is the pointer of the position of cost_mk_fm
                  
                  for i = 1:sum(ind_mk)
                      if ind_mk_fm(i) == 1
                          price_new_mk(i) = price_mk_fm(j);
                          j = j + 1; % move the pointer to the next position
                      end
                  end
              end
             
             %We need to dampen only in one very special case (that we know
             %of...when we set US charachterstics to those of France and
             %recalculated equilibrium in USA2009.
             %
             % Interesting facts, 2009 was the year of US cash for clunkers
             % Our demand shock is big for Prius in 2009. 
             % When we give US French Tastes, they like MPD even more.
             price_new(ind_mk) = price_new_mk; 
             itr = itr+1;
             diff = max(abs(price_new - price_prev));
             price_prev(ind_mk) = damp*price_new(ind_mk) + (1-damp)*price_prev(ind_mk);
             %fprintf('Iteration: %d:  %.12f\n', itr, diff);
             %fprintf('Iteration: %d:  %.6f, Prius Price = %.10f Share = %.6f\n', itr, diff, price_new(7475), share(7475));
             %find(abs(price_new-price_prev) > diff)
          end
         
          if diff<diff_tol
              %Set flag to 0 for convergence without error. 
              exitflag = 0;
          else
              exitflag = 1;
          end
          
          price_out = price_new(ind_mk);
          share_out = share(ind_mk);
          
end
          
          








