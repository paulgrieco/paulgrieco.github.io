% Added one more output: homeass as the home assumbly dummy -- same as home
% as the home dummy.
% X and Xc: regressor used in the projection
% est and est_c: estimates when using X and Xc
function [ est_ret, se_ret, est_c_ret, se_c_ret, home, Hc , est_c_ass_ret, se_c_ass_ret, homeass, CountryD_homeass, X, Xc, est, est_c, R2, R2_c, n_X, n_Xc] = extractHomeFromCBD(beta_hat, var_cov, m , bmData, controls)
%extractHomeFromCBD This function uses GLS (with OLS option in comments) to
%construct the home dummy and country specific home dummes from the country
%brand dummies.  Inputs are the linear estimates and full variance
%covariance matrix (This part is kind of annoying, should take only linear part). 

if nargin==3
    bmData = [];
end

%% First we can only do this if we have the full set of country brand dummies
assert(isfield(m, 'startBCdums'));

%% Extract Home Dummies from beta_hat and the data that maps
%observations->country brand dummies. 
cbd_hat = beta_hat(m.startBCdums:m.endBCdums);
cbd_data = m.linX(:,m.startBCdums:m.endBCdums);
n_cbd = size(cbd_hat,1);

%% Extract the CountryxBrand Dummy Variance Covariance Matrix...
%first get linear variance covariance...
V_lin = var_cov(m.size_nl+1:end, m.size_nl+1:end);
%Then get the countryxbrand dummies:
V_cbd = V_lin(m.startBCdums:m.endBCdums,m.startBCdums:m.endBCdums);


%% Collapses Model Data to Unique Brand-Country Combinations, and then
%finds the Brand and Country code assoiciated with each Country-Brand
%Dummy.    CAREFUL HERE...don't reuse foo.
foo = unique([m.brandCode m.ctyCode cbd_data],'rows');
Brands = foo(:,3:end)*foo(:,1);
Countries = foo(:,3:end)*foo(:,2);

%% Construct Home Dummy for Country-Brand Level: 
% Again collapse model-level data to unique brand-country combinations
% and see when home dummy is on. Then match the home dummy to our
% Brand Model ordering of the Country-Brand Dummy Vector. 
%
% Note: The way the data is usually organized. The "unique" command actually
% produces the correct ordering. the second line is a safeguard that puts 
% correctly ordered the data in the correct order even if regardless of how
% the model data is sorted.
hl = unique([m.brandCode m.ctyCode m.homedummy],'rows');
home = hl( Brands==hl(:,1) & Countries==hl(:,2),3);

% Now do the same trick for the new regressors: homeowneddummy and domestic_assembly_by_brand_dummy
% In this way, the two additional variables has the same ordering as home.
ho = unique([m.brandCode m.ctyCode m.homeowneddummy],'rows');
homeowned = ho( Brands==ho(:,1) & Countries==ho(:,2),3);
ha = unique([m.brandCode m.ctyCode m.domestic_assembly_by_brand_dummy],'rows');
homeass = ha( Brands==ha(:,1) & Countries==ha(:,2),3);

CountryD = dummyvar(Countries);
BrandD = dummyvar(Brands);
BrandD(:,end) = [];

%% Calculate the weight matrix and construct X
iV = eye(size(V_cbd))/V_cbd;
% To use OLS rather than GLS, results seem to change much..
%iV = eye(size(V_cbd));
%This does the home dummy regression...standard errors tomorrow

X = [ home CountryD BrandD ];
X_pos = [1]; % this records the position of parameters of interest in X that will be returned.
ret_pos = [1]; % this records the position of the paramter should be fit into a fixed 5-dim parameter vector. This position should match X_pos.

%The Country-Home Regression is more complicated, must learn which
%countries have home brands
Hc = bsxfun(@times, home, CountryD);
hasHomeBrand = sum(Hc) > 0;

Xc = [ Hc(:,hasHomeBrand) CountryD BrandD];

%% Merge in bmData if needed...
% The order of the controls:
%Home Brand
%Years in Market
%Dealer Density
%Locally Owned Brand
%Locally Assembled Brand

% first, we produce interactions of dummies to be used later.
CountryD_homeass = bsxfun(@times, CountryD, homeass) ;

if ~isempty(bmData)
    assert(sum(bmData.brandCode ~= Brands)==0, 'extractHomeFromCBD: bmData merge failed on Brand Codes');
    assert(sum(bmData.ctyCode ~= Countries)==0, 'extractHomeFromCBD: bmData merge failed on Country Codes');
    switch controls
        case 'years'
            X  = [ X  2011-bmData.entyear];
            Xc = [ Xc 2011-bmData.entyear];
            X_pos = [1, size(X,2)]; % this records the position of parameters of interest in X that will be returned.
            ret_pos = [1, 2]; % this records the position of the paramter should be fit into a fixed 5-dim parameter vector. This position should match X_pos.
        case 'dealer'
            X  = [ X   bmData.dealerPH];
            Xc = [ Xc  bsxfun(@times, CountryD, bmData.dealerPH) ];
  
            
            X_pos = [1, size(X,2)]; % this records the position of parameters of interest in X that will be returned.
            ret_pos = [1, 3]; % this records the position of the paramter should be fit into a fixed 5-dim parameter vector. This position should match X_pos.
        case 'both'
            X  = [ X  2011-bmData.entyear bmData.dealerPH];
            Xc = [ Xc 2011-bmData.entyear bsxfun(@times, CountryD, bmData.dealerPH) ];
            X_pos = [1, size(X,2)-1, size(X,2)]; % this records the position of parameters of interest in X that will be returned.
            ret_pos = [1, 2 ,3]; % this records the position of the paramter should be fit into a fixed 5-dim parameter vector. This position should match X_pos.
        case 'addition' % add more controls. Alternatively, we could use m.domestic_assembly_by_brand_dummy or m.domestic_assembly_by_brand_num
            X  = [ X  2011-bmData.entyear bmData.dealerPH, homeowned, homeass];
            Xc = [ Xc 2011-bmData.entyear bsxfun(@times, CountryD, bmData.dealerPH), homeowned, homeass ];    
            X_pos = [1, (size(X,2)-3) : size(X,2)]; % this records the position of parameters of interest in X that will be returned.
            ret_pos = [1, 2 ,3,4,5]; % this records the position of the paramter should be fit into a fixed 5-dim parameter vector. This position should match X_pos.
            
        case 'localass' %  
            X  = [ X     homeass];
            Xc = [ Xc  CountryD_homeass];    
            X_pos = [1, size(X,2)]; % this records the position of parameters of interest in X that will be returned.
            ret_pos = [1, 5]; % this records the position of the paramter should be fit into a fixed 5-dim parameter vector. This position should match X_pos.
        case 'localass_years' %  
            X  = [ X   2011-bmData.entyear  homeass ];
            Xc = [ Xc  2011-bmData.entyear CountryD_homeass];    
            X_pos = [1, size(X,2)-1, size(X,2)]; % this records the position of parameters of interest in X that will be returned.
            ret_pos = [1, 2, 5]; % this records the position of the paramter should be fit into a fixed 5-dim parameter vector. This position should match X_pos.
        case 'localass_dealer' %  
            X  = [ X   bmData.dealerPH  homeass ];
            Xc = [ Xc  bsxfun(@times, CountryD, bmData.dealerPH)   CountryD_homeass];    
            X_pos = [1, size(X,2)-1, size(X,2)]; % this records the position of parameters of interest in X that will be returned.
            ret_pos = [1, 3, 5]; % this records the position of the paramter should be fit into a fixed 5-dim parameter vector. This position should match X_pos.
        case 'localass_both' %  
            X  = [ X   2011-bmData.entyear  bmData.dealerPH  homeass ];
            Xc = [ Xc  2011-bmData.entyear   bsxfun(@times, CountryD, bmData.dealerPH)   CountryD_homeass];    
            X_pos = [1, size(X,2)-2, size(X,2)-1, size(X,2)]; % this records the position of parameters of interest in X that will be returned.
            ret_pos = [1, 2, 3, 5]; % this records the position of the paramter should be fit into a fixed 5-dim parameter vector. This position should match X_pos.     
            
        case 'localown' %  
            X  = [ X     homeowned];
            Xc = [ Xc  homeowned ];   
            X_pos = [1,  size(X,2)]; % this records the position of parameters of interest in X that will be returned.
            ret_pos = [1, 4]; % this records the position of the paramter should be fit into a fixed 5-dim parameter vector. This position should match X_pos.
        case 'localown_dealer' % 
            X  = [ X     bmData.dealerPH, homeowned];
            Xc = [ Xc  bsxfun(@times, CountryD, bmData.dealerPH), homeass ];     
            X_pos = [1, size(X,2)-1, size(X,2)]; % this records the position of parameters of interest in X that will be returned.
            ret_pos = [1, 3 ,4]; % this records the position of the paramter should be fit into a fixed 5-dim parameter vector. This position should match X_pos.
        case 'localown_ass' % 
            X  = [ X    , homeowned, homeass];
            Xc = [ Xc , homeowned, homeass ];     
            X_pos = [1, size(X,2)-1, size(X,2)]; % this records the position of parameters of interest in X that will be returned.
            ret_pos = [1, 4 ,5]; % this records the position of the paramter should be fit into a fixed 5-dim parameter vector. This position should match X_pos.
          
       case 'both_ass' % year dealer and homeass
            % This one actually is the same as 'localass_both' 
            X  = [ X  2011-bmData.entyear bmData.dealerPH , homeass];
            Xc = [ Xc 2011-bmData.entyear bsxfun(@times, CountryD, bmData.dealerPH) , CountryD_homeass];
            X_pos = [1, size(X,2)-2, size(X,2)-1, size(X,2)]; % There was a bug: it was size(X,2)-2, size(X,2)-1.
            ret_pos = [1, 2, 3 ,5]; % this records the position of the paramter should be fit into a fixed 5-dim parameter vector. This position should match X_pos.  
       
    end
end


%% Estimate and Standard Errors
est = (X'*iV*X)\(X'*iV*cbd_hat);
est_c = (Xc'*iV*Xc)\(Xc'*iV*cbd_hat); % we do not make change here, but the last tenth and last 1-9th of est_c is the estimate for dealer and year and should be reported.

%%%%%%%%%%%%%%% R2 in instrument regression is not helpful
n_X = size(X,1); % number of observations in the regression
n_Xc = size(Xc,1); % number of observations in the regression
% 
% % for homogeneous regression:
% SST = sum((cbd_hat-mean(cbd_hat)).^2);
% cbd_fit = X*est;
% SSR = sum((cbd_fit- cbd_hat).^2);
% R2 = 1 - SSR/SST;
% 
% % for heterogenous regression:
% SST_c = sum((cbd_hat-mean(cbd_hat)).^2);
% cbd_fit_c = Xc*est_c;
% SSR_c = sum((cbd_fit_c-cbd_hat).^2);
% R2_c = 1 - SSR_c/SST_c;

R2 = [];
R2_c = [];

%Standard error formula for p 83 Table 4.2 of Cameron & Trividi...
se = diag( (inv((X'*iV*X)))^.5 );
se_c = diag( (inv((Xc'*iV*Xc)))^.5 );


%Robust Standard errors...not very exciting overall, but
%  if we use these, need to use OLS instead of GLS 
%Om = diag((cbd_hat - X*est).^2);
%se = diag( ( (X'*iV*X)\(X'*iV*Om*iV*X)/(X'*iV*X) ).^.5 );

%Om = diag((cbd_hat - Xc*est_c).^2);
%se_c = diag( ( (Xc'*iV*Xc)\(Xc'*iV*Om*iV*Xc)/(Xc'*iV*Xc) ).^.5 );


%% Extract Parameters of Interest for Return
% Return home dummy, with all (possible) controls -- even with some
% non-controls -- we will drop some later.
       est_ret = NaN*ones(5,1); % initiate the vector
       se_ret = NaN*ones(5,1);
       
       est_ret(ret_pos) = [est(X_pos)]'; % fill in results
       se_ret(ret_pos) = [se((X_pos))]';

% if nargin>3
% switch controls
%     case 'addition'
%        est_ret = [est(1);est(end-3:end)]';
%        se_ret = [se(1);se(end-3:end)]';
%        assert(length(est_ret) == 5) % make sure we only include 5 coefficient in this case: home, year, dealer, and two additional
% end
% end
    
% est_ret = [est(1),est(end)];
% se_ret = [se(1),se(end)];

% NaN Pad so Row = Country Code, Nan in Countries without home Brands.
c_HD_est = est_c(1:sum(hasHomeBrand));
c_HD_se = se_c(1:sum(hasHomeBrand));
est_c_ret = nan(size(CountryD, 2),1);
est_c_ret(hasHomeBrand, :) = c_HD_est;
se_c_ret = nan(size(CountryD, 2),1);
se_c_ret(hasHomeBrand, :) = c_HD_se;

% also report the country-homeassembly dummy estimates:
% we have an etimate for all countries, so this is easier.
% But note that, this only work for some options of cases -- these do have
% interactions of countries and home assembly.
   est_c_ass_ret = NaN*ones(m.nCtys,1);
   se_c_ass_ret = NaN*ones(m.nCtys,1); 
if nargin>3
 if strcmp(controls, 'localass') | strcmp(controls, 'both_ass') | strcmp(controls,'localass_both')
    est_c_ass_ret = est_c(end-m.nCtys+1:end);
    se_c_ass_ret = se_c(end-m.nCtys+1:end);
 end
end

end

