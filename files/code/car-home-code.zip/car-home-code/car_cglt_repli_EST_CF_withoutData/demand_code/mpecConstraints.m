function [ ineq_err, eq_err, grad_ineq, grad_eq] = mpecConstraints( mpec_x, m)
% This file provides the nonlinear constraints for an Mpec procedure. 
% These are simply the calculated shares equal the observed share
% (m.share). 
%
% This file is different from shareConstraints because its input and output
% are both different.  For inputs, this funciton takes the complete
% parameter vector, not just the list of shares. 
%
% For output while the err in the constraints is the same, the jacobian is
% different. Here we return the jacobian with respect to all elements of 
% mpec_x = [nonlin g delta] rather than just delta. 

    %This problem has no inequality constraints (thank jesus)
    ineq_err = [];
    grad_ineq = [];
    
    %First, we've got to unpack parameters.
    %parnonlin = mpec_x(1:size_nl);
    %g = mpec_x(size_nl+1:size_nl+size_g);
    %delta = mpec_x(size_nl+size_g+1:end);
    
    [parnonlin, g, delta] = unpackMpecX(mpec_x, m); 
    
    [mu alphai] = getMu(parnonlin, m); 
    [share share_ij] = getShare(delta, mu, m);
    
    if nargout < 3
        eq_err = share - m.share;
        return
    end

    %If we got here, then we need the derivatives too...
    [foo1, eq_err, foo2, grad_delta] = shareConstraintsParallel(share, share_ij, m);
    %grad_delta = ones(length(m.p), length(m.p)); %TEST DUMMY FOR ABOVE.
    grad_nonlin = ShareDeriv_nonlin(share_ij, alphai, m);     
    grad_eq = [ grad_nonlin zeros(length(eq_err),m.size_g) grad_delta]';
    
    
end

