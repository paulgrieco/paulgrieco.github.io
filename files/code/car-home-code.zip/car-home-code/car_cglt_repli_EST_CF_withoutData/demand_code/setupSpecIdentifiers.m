%% Specify the version of the file
fileVersion = 'Full'; % By choosing fileVersion, we can choose to load which version of input files:
                                      % 'Full' means to load the original
                                      % files -- including all countries;
                                      % 'noBRA' means to load the files
                                      % without Brazil;
                                      % 'EU' means to load the files with
                                      % EU countries only.

%% Price sensitivity 
priceRC = 'log_normal'; % 'log_normal'  Price is a log-normal coefficient seprate from other RCs
                        % 'stadard_rc'  Price is just another random coefficient.           
                        
priceFormat = 'Level'; % 'Log' means price is in log, 'Level' means price in level

%% Characteristics
CharSquare = 'SizeOnly'; % 'Squares'  square terms for characteristics
                        % 'NoSquares' no square terms for characteristics
                        % 'SizeOnly' only include square term for size

mpSet      = 'mpD';     % 'mpg'  miles per gallon 
                        % 'mpD'  miles per dollar: this one makes sense for demand estimation                                      
%% Integration method
integrationMethod = 'Halton_Shuffled';  % 'Sparse_Grid'
                                        % 'GQ'
                                        % 'MC'
                                        % 'Halton_Shuffled'                                     
%% Estimation method: MPEC vs Nested Fixed Point
Est_Method = 'NFP';  % 'MPEC', has anyone checked if this still works recently? 
                     % 'NFP'

%% Whether we want to force the distribution of random coefficients to be the same across countries
% If it is the same, it is essentially mean the means of the taste are the
% same.
same_rc_distr = 'Different'; % 'Same'; 'Different'

%% Set of dummies in the linear part
xSet = 'brandDumInter_full_YrCtyDum'; 
                             % 'modelDum';        % use model dummies
                             % 'firmDum';         % use firm dummies
                             % 'modelDum_homeVar' % this is to allow home dummy to vary by country
                             % 'brandDum'         % use brand dummies 
                             % ''brandDum_nohomedummy' '  % use brand dummies, but no home dummy (Note: no interaction of dummies of brands and countries)
                             % 'brandDum_type'    % use brand and car type dummies 
                             % 'firmDum_type'     % firm and car type dummies
                             % 'brandDum_typeInter'       % use brand dummies and (only) car type dummies in linX
                             % 'brandDumInter'            % use brand dummies interacted with counties in linX
                             % 'brandDumInter_typeInter'  % use brand dummies and car type dummies (both interacted with countries) in linX
                             % 'brandDumInter_full_YrCtyDum' %  'brandDumInter_full' plus a set of year and country interaction dummies (dropped one dummy).
                             % 'brandYrCtyDum_full' % full interaction of brand year and country, without dropping dummies.
                             % 'brandDumInter_full'       % THIS IS the one used in the draft: use a full set of brand dummies interacted with countries but do not use constant interacted countries
%% Instruments
ivSet = 'blp_4costIV_and_nearbyDiffIV'; % 
                                % 'blp_4costIV_and_nearbyDiffIV'; %2 BLPIVS, 4 COSTIVS 6 DIFF IVS
                                 %'4costIV_and_nearbyDiffIV'; %Cost IVs with no interaction pluss differentiation IVS...
                                 % '4newCostIV_PartInter_and_nearbyDiffIV';
                                 %  
                                 %  ***DRAFT>>>> '4newCostIV_PartInter';  
                                 % 'DiffIV_4NCPI', preferred plusdifferentiation ivs                          
                                 % 'DiffIV_minDist_prodLoc'
                                 % '4newCostIV' 
                                 % '4newCostIV_Inter'  
                                 % '4newCostIV_PartInter' **BEST SO FAR**
                                 % '3newCostIV_Inter' % this one does not use tariff, since it is highly correlated with distance 
                                 % '2newCostIV_Inter' % this one does not interact domestic dummy with country. Total 19 IVs.
                                 % 'Cost_lowcorr'     % this gives the lowest correlation between ivs on the cost side
                                 % 'Cost_lowcorr_selfInter'
                                 % '8blp'
                                 % '1blp_5newCost'
                                 % '3blp_5newCost' 
                                 % '4blp_5newCost' 
                                 % '8blp_5newCost' 
                                 % '1blp_5newCostIV' 
                                 % '3blp_5newCostIV' 
                                 % '4blp_3newCostIV' 
                                 % 'blp_Cost_lowcorr' % this one give the lowest correlation of ivs
                                 % 'blp_Cost_lowcorr_Inter' % this one use the interation with countries
                                 % '5newCostIV'  
                                 % '6newCostIV'
                                 % Here are the ones we used a long time ago, we can just ignore them for now.
                                 % '8blp_2cost'
                                 % '8blp_2costSqure'
                                 % '8blp_1cost'
                                 % '4blpInter_2cost' 
                                 % '3blpInter_2cost'
                                 % '8blp_2costInter'  
                                 % '4blpInter_1cost' 
                                 % '3blpInter_1cost'
                                 % '8blp_1costInter'  
                                 % '4blpInter_1costSquare' 
                                 % '3blpInter_1costSquare'
                                 % '8blp_1costSquareInter'
                                 % 'other1costSquareInter'
                                 % '1costInter1cost' % 1st cost interaction but 2nd cost does not
                                 % '1cost1costInter' % 1st cost no interaction but 2nd cost does
                                 % 'all2costInter' % both cost IV interact
                                 % '4blp_1costInter1cost'
                                 % '3blp_1costInter1cost'
                                 % '2cost'
                                 
%% Models for which elasticities will be reported                                 
model_names_for_elast  = { 'Audi A6';...
                            'Ford Focus';...
                            'Mercedes E 350';...
                            'Renault Clio';...
                            'Toyota Corolla'};
%% Firms and models for which markups will be reported                                 
firm_names_for_markups  =   {'Fiat Group Automobiles SpA';...
                            'Ford Group';...
                            'General Motors Group'; ...
                            'PSA Group';...
                            'Toyota Group';...
                            'Volkswagen Group'};   
                        
model_names_for_markups = {'Audi A4';...
                          'Audi A6';...
                          'BMW 530';...
                          'BMW X3';...
                          'Chrysler 300';...
                          'Ford Fiesta';...
                          'Ford Focus';...
                          'Honda Accord';...
                          'Honda CR-V';...
                          'Jaguar XF';...
                          'Jeep Grand Cherokee';...
                          'Lexus RX 450';...
                          'Mercedes E 350';...
                          'Mini New Mini';...
                          'Renault Clio';...
                          'Toyota Corolla';...
                          'Toyota RAV-4';...
                          'VW Golf';...
                          'VW Passat';...
                          'VW Tiguan'};
