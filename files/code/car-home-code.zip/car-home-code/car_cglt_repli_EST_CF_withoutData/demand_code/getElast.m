% This uses similar code of shareConstraintsParallel.m. However it is
% slightly more general in that it computes elasticity at any price, rather
% than that in the data.  If p is empty then it uses the price in the
% data (m.p). 

%%%% matrix produced by getElast.m is read as "substitution elasticity 
%%%% of models in the COLUMN with respect to the prices of models in the ROW."
%%%% How to double check:
%%%% In getElast.m, we use 
%%%% price_share_offdiag = m.p * (1./share)'; (ignore the market)
%%%% That is:
%%%% ds1/dp1*(p1/s1)   ds2/dp1*(p1/s2)
%%%% ds1/dp2*(p2/s1)   ds2/dp2*(p2/s2)

function [elast_market_cell, full_Elast, full_DsDp] = getElast(parnonlin, parlin, DShocks, m, p, singleMkt)
 
  if nargin==4
      p = [];
      singleMkt = [];
  elseif nargin ==5
      singleMkt = [];
  end

%% Prepare for the computation: get delta, mu, and DAlpha or alphai, alpha_bar
  %If p is not supplied, use 
  if isempty(p)
      p = m.p;
  end
  delta = constructDelta(parlin, p, DShocks, m);

  if (m.lognormprice==1)% this is automatically getting alphai or DAlpha
      [mu, alphai] = getMu(parnonlin, m, p);   
  else
      [mu, DAlpha] = getMu(parnonlin, m, p); 
      alpha_bar = parlin(1:m.nCtys); % the first 9 is for alpha_bar
      alpha_bar_vec = nan(m.nMkts,1);
      for mk=1:m.nMkts
          ind_mk = (m.mktCode==mk);
          cty_mk = unique(m.ctyCode(ind_mk));
          alpha_bar_vec(mk) = alpha_bar(cty_mk);
      end
      alphai = repmat(alpha_bar_vec,1,m.nNodes) + DAlpha; % this is plus or minus??????????
  end
  [share, share_ij] = getShare(delta, mu,m);
  
%% Compute Elasticity over all markets (parfor loop)....
      if isempty(singleMkt)
      
          Nmkt = m.nMkts;

          %Allocate the elasticity...keep it sparse.
          full_Elast = sparse(m.nObs, m.nObs);

          full_DsDp = sparse(m.nObs, m.nObs);

          elast_market_cell = cell(Nmkt,1);

          DsDp_market_cell = cell(Nmkt,1);
          % Parallel loop over calculating the elasticity for each market.


          parfor mk=1:Nmkt
              [elast_market_cell{mk},DsDp_market_cell{mk}] = elast_Market(share, share_ij, p, alphai(mk,:), m, mk);
          end

           for mk=1:Nmkt
              ind_mk = (m.mktCode==mk);
              full_Elast(ind_mk, ind_mk) = elast_market_cell{mk};
              full_DsDp(ind_mk, ind_mk) = DsDp_market_cell{mk};
           end
      else
%% Compute Elasticity only for specified market
% We do the other stuff for all markets even if we only want a market level
% elasticity but don't worry about it since it is the actual elasticity
% calculation that is hard to compute.
          assert(singleMkt <= m.nMkts);
          [full_Elast, full_DsDp] = elast_Market(share, share_ij, p, alphai(singleMkt,:), m, singleMkt);
          elast_market_cell = [];
      end

end


function [elast_Market, DsDp_Market] = elast_Market(share, share_ij, p, Alpha_i, m, mk)

          ind_mk = (m.mktCode==mk);
          
          %Country should be the same for all firms in the market, assert 
          %that this is true. 
          cty_mk = unique(m.ctyCode(ind_mk)); 
          assert( length(cty_mk) == 1 ); 
          
          
          elast_Market = 0;
          DsDp_Market  = 0;
          for my_cons = 1:m.nNodes % loop over all consumers: 389
              % ratio of price and share: self
              price_share_self = p(ind_mk)./share(ind_mk);
              deriv_self           = - price_share_self .* Alpha_i(my_cons) .* share_ij(ind_mk,my_cons) .* (1-share_ij(ind_mk,my_cons));
              DsDp_self           =  - Alpha_i(my_cons) .* share_ij(ind_mk,my_cons) .* (1-share_ij(ind_mk,my_cons));
              % ratio of price and share: off diag
              price_share_offdiag = p(ind_mk) * (1./share(ind_mk))';
              
              deriv_offdiag        = Alpha_i(my_cons) * price_share_offdiag .* ( share_ij(ind_mk,my_cons) * share_ij(ind_mk,my_cons)' );
              DsDp_offdiag        = Alpha_i(my_cons) .* ( share_ij(ind_mk,my_cons) * share_ij(ind_mk,my_cons)' );
              
              elast_Market         = elast_Market + m.quadweight(1,my_cons) * ((1-eye(sum(ind_mk))) .* deriv_offdiag + diag(deriv_self));
              DsDp_Market          = DsDp_Market + m.quadweight(1,my_cons) * ((1-eye(sum(ind_mk))) .* DsDp_offdiag + diag(DsDp_self));
          end

end