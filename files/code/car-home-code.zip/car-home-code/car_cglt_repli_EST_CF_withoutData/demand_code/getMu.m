% this code calculates the individual deviation from mean utility--mu matrix
%and individual random price coefficients, The dimensions are both
% 28037*N_consumer.

% alpha_out = DAlpha (if normal distr) or alphai (if lognormal distr)
function [mu, alpha_out] = getMu(pardemandnonlin, m, p)  

%If a price is not specified, use price in the data
%This is here because we use getMu for both estimation and counterfactuals.
if nargin == 2
    p = m.p;
    rcX = m.rcX;
else
    rcX = bsxfun(@times, m.rcP, p) + (1-m.rcP).*m.rcX;
end

%Call function to convert parameter vector into Sigma and Pi matricies...
[Sigma, Pi, alphaBar, PiAlpha, sigAlpha] = unpackNonlinParams(pardemandnonlin, m);


mu = zeros(m.nObs,m.nNodes);                   % I*size(zeta,2) consumers in each country

alphai = nan(m.nMkts, m.nNodes);               % Set to nan because it is either set (if m.lognormprice==1) or not used
DAlpha = nan(m.nMkts, m.nNodes);                   % matrix of deviations to alphabar to create alpha_i's, if m.lognormprice==0
                                               % Alpha_i = Alpha_bar + DAlpha


% First, may as well calculate quadrature nodes outside of the main loop
zeta_devs = Sigma*m.zeta_nodes(1:size(Sigma,1),:);

if (m.lognormprice==1)
   zeta_dev_p = sigAlpha*m.zeta_nodes(end,:);
end

for mk = 1:m.nMkts                             % random coefficients for hp, size, weight, and price.
    ind_mk = (m.mktCode==mk);
    
    %coeff devs are the individual deviations from the average coefficients
    %it is a matrix (number of coefficients x number of consumers). 
    coeff_devs = (Pi*m.demog_nodes(:,:, mk) + zeta_devs);
    
    if (m.lognormprice==1)
        %Specify alphai: it is a lognormal so construct the normal and
        %exponentiate:
        alphai(mk,:) = exp(alphaBar + PiAlpha*m.demog_nodes(:,:,mk) + zeta_dev_p);

        %Mu is the utility nonlinear utility component,  
        %
        %Need to multiply coeff_dev by the models charachteristics 
        %(num models in market x number of consumers)...
        %
        %..and then account for different consumers different price
        %sensitivities.
        mu(ind_mk,:) = rcX(ind_mk,:)*coeff_devs - p(ind_mk,:)*alphai(mk,:);
    else
        mu(ind_mk,:) = rcX(ind_mk,:)*coeff_devs;
        %in this case alphai also depends on linear parameters...However
        %this represents the deviations.
        
        %If we want to return the deviations for the price coefficient,
        %which are useful because they allow us to construct the price foc,
        %we just need to take the final row of the mkt_devs matrix. 
        
        DAlpha(mk,:) = coeff_devs(end,:);
                                     % Pi(end)*D_i + Sigma(end,:)* zeta_i. 
    end
        
    end

 


if (m.lognormprice==0) % return alpha_out depending on which specification we have, in this way we do not need to change the way we call getmu
    alpha_out = DAlpha;
else
    alpha_out = alphai;
end

end