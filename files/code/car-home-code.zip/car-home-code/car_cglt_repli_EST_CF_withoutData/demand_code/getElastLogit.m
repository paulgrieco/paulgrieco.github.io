% Calculates Elasticity for the Multinomial logit estimation conducted in
% logit estimation which assumes price and price*inc are the first two
% linear variables. 
%
% Only computes elasticities at OBSERVED prices and shares, not intendended
% for use with counterfactuals. 

%%%% matrix produced by getElast.m is read as "substitution elasticity 
%%%% of models in the COLUMN with respect to the prices of models in the ROW."
%%%% How to double check:
%%%% In getElast.m, we use 
%%%% price_share_offdiag = m.p * (1./share)'; (ignore the market)
%%%% That is:
%%%% ds1/dp1*(p1/s1)   ds2/dp1*(p1/s2)
%%%% ds1/dp2*(p2/s1)   ds2/dp2*(p2/s2)

function [elast_market_cell, full_Elast, full_DsDp] = getElastLogit(beta, meanlogInc_mkt, m)
 
 


%% Prepare for the computation: Construct the alpha parameter given mean income:
    %This creates a distinct alpha for each market, ordered by market code.
    alpham = beta(1) + beta(2)*meanlogInc_mkt;
    
    %Keep this code just in case we need to add this functionality, allows
    %us to calculate elasticities for a single market which we use in the
    %general case for counterfactuals
    singleMkt = [];
  
  
%% Compute Elasticity over all markets (parfor loop)....
      if isempty(singleMkt)
      
          Nmkt = m.nMkts;

          %Allocate the elasticity...keep it sparse.
          full_Elast = sparse(m.nObs, m.nObs);

          full_DsDp = sparse(m.nObs, m.nObs);

          elast_market_cell = cell(Nmkt,1);

          DsDp_market_cell = cell(Nmkt,1);
          % Parallel loop over calculating the elasticity for each market.


          for mk=1:Nmkt
              [elast_market_cell{mk},DsDp_market_cell{mk}] = elast_Market(m.share, m.p, alpham(mk), m, mk);
          end

           for mk=1:Nmkt
              ind_mk = (m.mktCode==mk);
              full_Elast(ind_mk, ind_mk) = elast_market_cell{mk};
              full_DsDp(ind_mk, ind_mk) = DsDp_market_cell{mk};
           end
      else
%% Compute Elasticity only for specified market
% We do the other stuff for all markets even if we only want a market level
% elasticity but don't worry about it since it is the actual elasticity
% calculation that is hard to compute.
          assert(singleMkt <= m.nMkts);
          [full_Elast, full_DsDp] = elast_Market(share, share_ij, alphai(singleMkt,:), m, singleMkt);
          elast_market_cell = [];
      end

end


function [elast_Market, DsDp_Market] = elast_Market(share, p, Alpha_m, m, mk)

          ind_mk = (m.mktCode==mk);
          
          %Country should be the same for all firms in the market, assert 
          %that this is true. 
          cty_mk = unique(m.ctyCode(ind_mk)); 
          assert( length(cty_mk) == 1 ); 
          
          
          % ratio of price and share: self
          price_share_self = p(ind_mk)./share(ind_mk);
          elast_self           = - price_share_self .* Alpha_m .* share(ind_mk) .* (1-share(ind_mk));
          DsDp_self           =  - Alpha_m .* share(ind_mk) .* (1-share(ind_mk));
          % ratio of price and share: off diag
          price_share_offdiag = p(ind_mk) * (1./share(ind_mk))';

          elast_offdiag        = Alpha_m * price_share_offdiag .* ( share(ind_mk) * share(ind_mk)' );
          DsDp_offdiag        =  Alpha_m .* ( share(ind_mk) * share(ind_mk)' );

          elast_Market         =   ((1-eye(sum(ind_mk))) .* elast_offdiag + diag(elast_self));
          DsDp_Market          =   ((1-eye(sum(ind_mk))) .* DsDp_offdiag + diag(DsDp_self));


end