function [objValue_1, objValue_2, beta_c, beta, se, V, u] = logitSpec( m )
% This funciton takes a structure m and estimates a logit estimation using
% its linear parameters. We do a 2-stage linear GMM. 
   
   %Unpack data so we don't need to use long names.  Note that the
   %structure should be set up so that 
   %    - linX contains endogenous and exogeneous regresors
   %    - IV  contains the exogenous regressors plus the instruments 
   X = m.linX;
   Z = m.IV;
   N = m.nObs;
   delta = log(m.share) - log(m.outshare);

   %First stage estimator..
   W_c = eye(size(Z,2))/(Z'*Z);
   invIV_c = eye(size(X,2))/(X'*Z*W_c*Z'*X) ;
   beta_c = invIV_c*X'*Z*W_c*Z'*delta;
   u_c = delta - X*beta_c;
   
   objValue_1 = u_c'*Z*W_c*Z'*u_c;
   
   %Second stage optimal estimator:
   %We have 35 models that only appear in one country, their fixed effect
   %is able to exactly solve the model, leading to a loss of rank in Shat
   %to fix this, we add a small number to these (negligible) errors.
   %
   % I'm a little uncomfortable with this, but we can't just delete these
   % models since they play a role in the equilibrium calculation.  Any
   % weight matrix is consistent, and this one is asymptotically optimal 
   % as long as the amount we add is going to zero...
   % u_hat = u_c + (abs(u_c) < 1e-3)*.01;
   % Shat = (Z'*diag(u_hat.^2)*Z);
   % W = N*eye(size(Z,2))/Shat;
   %
   % Talked to Joris and got permission to use the Moore-Penrose
   % generalized inverse to deal with this issue...
   % these two methods don't give the exact same answer (and shouldn't), 
   % but they are pretty close.
   Shat = (Z'*diag(u_c.^2)*Z) + (1/m.nObs)*eye(size(W_c));
   W = inv(Shat);
   
   invIV = eye(size(X,2))/(X'*Z*W*Z'*X);
   beta = invIV*X'*Z*W*Z'*delta;
   u = delta - X*beta;
   
   V = (eye(size(X,2))/(X'*Z*W*Z'*X));
   se = diag(V).^(.5);
   
   objValue_2 = u'*Z*W*Z'*u;
end

