clear;

% Load the demand result file
load(['..' filesep 'demand_output' filesep 'secMultiResult.mat']);

parnonlin = mainout.parnonlin_hat;
parlin = mainout.beta_hat;
%homep_homog = mainout.homep_homog';
%homep_cty = mainout.homep_cty;
cost = mainout.cost;

[hp_no, hp_yr, hp_deal, hp_both, hpc_no, hpc_both, hp_add, hpc_add,       hp_localass, hpc_both_ass,  c_ass_both_ass, ...
    hp_localass_yr ,   ...
    hp_localass_deal,   ...
    hp_localass_both] = print_HomePreferences(mainout,0,'noprint');% 0 mean do not load boot se file, since there is none 

rList = dir([ '..' filesep 'demand_output' filesep 'weighted_*mat']); 
nB = numel(rList);

%These are going to hold the outcomes of each bootstrap draw
n_valid = 200; % total number of bootstrapping we use
b_parnonlin = nan(numel(parnonlin) , n_valid);
b_parlin = nan(numel(parlin) , n_valid);
%b_homep_homog = nan(numel(homep_homog) ,nB);
%b_homep_cty = nan(numel(homep_cty), nB);
b_cost = nan(numel(cost), n_valid);
b_weight = nan(numel(cost), n_valid);

b_hp_no = nan(numel(hp_no), n_valid);
b_hp_yr = nan(numel(hp_yr), n_valid);
b_hp_deal = nan(numel(hp_deal), n_valid);
b_hp_both = nan(numel(hp_both), n_valid);
b_hpc_no = nan(numel(hpc_no), n_valid);
b_hpc_both = nan(numel(hpc_both), n_valid);
b_hp_add = nan(numel(hp_add), n_valid);
b_hpc_add = nan(numel(hpc_add),n_valid);

b_hp_localass = nan(numel(hp_localass), n_valid);
b_hpc_both_ass = nan(numel(hpc_both_ass), n_valid);
b_c_ass_both_ass= nan(numel(c_ass_both_ass), n_valid);

b_hp_localass_yr = nan(numel(hp_localass_yr), n_valid);
b_hp_localass_deal = nan(numel(hp_localass_deal), n_valid);
b_hp_localass_both= nan(numel(hp_localass_both), n_valid);

% b_beta_nocontrols = nan(numel(beta_nocontrols), nB);
% b_beta_years = nan(numel(beta_years), nB);
% b_beta_dealer = nan(numel(beta_dealer), nB);
% b_beta_bothcontrols = nan(numel(beta_bothcontrols), nB);
% b_betac_nocontrols = nan(numel(betac_nocontrols), nB);
% b_betac_bothcontrols = nan(numel(betac_bothcontrols), nB);
% b_beta_addcontrols = nan(numel(beta_addcontrols), nB);
% b_betac_addcontrols = nan(numel(betac_addcontrols), nB);


%Collect Data
n=1;
for i = 1:nB
    Load_File = sprintf('../demand_output/%s', rList(i).name);
    if exist(Load_File, 'file') %check wither file exists
	load(Load_File)
    if (min(mainout.cost)>0) && (n <= n_valid ) % we only need 200
        
    	%gmm_values(i) = mainout.objVal;
        b_parnonlin(:,n ) = mainout.parnonlin_hat;
        b_parlin(:,n ) = mainout.beta_hat;
        %b_homep_homog(:,i) = mainout.homep_homog';
        %b_homep_cty(:,i) = mainout.homep_cty;
        b_cost(:,n ) = mainout.cost;
        b_weight(:,n ) = bweight;
        
        [no, yr, deal, both, c_no, c_both, add, c_add,       localass,  both_ass,   ass_both_ass, ...
             localass_yr ,   ...
             localass_deal,   ...
             localass_both] = print_HomePreferences(mainout,0,'noprint'); % 0 means no to load boot se file 
        b_hp_no(:, n ) = no';
        b_hp_yr(:,n ) = yr';
        b_hp_deal(:,n ) = deal';
        b_hp_both(:,n ) = both';
        b_hpc_no(:,n ) =c_no;
        b_hpc_both(:,n ) = c_both;
        
        b_hp_add(:,n ) = add';
        b_hpc_add(:,n ) = c_add;
        
        b_hp_localass(:,n )  =  localass;
        b_hpc_both_ass(:,n )  = both_ass ;
        b_c_ass_both_ass(:,n ) =  ass_both_ass ;
        
        b_hp_localass_yr(:,n )  =  localass_yr;
        b_hp_localass_deal(:,n )  = localass_deal;
        b_hp_localass_both(:,n )  = localass_both;
        
        n  = n +1;
    end

    end
end
clearvars mainout no yr deal both c_no c_both add c_add

%Compute standard errors of bootstrap parameters...
bootSe_parnonlin = sqrt(sum(bsxfun(@minus, b_parnonlin, parnonlin).^2,2)/n_valid);
bootSe_parlin = sqrt(sum(bsxfun(@minus,b_parlin, parlin).^2,2)/n_valid);
%bootSe_homep_homog = sqrt(sum(bsxfun(@minus,b_homep_homog, homep_homog).^2,2)/nB);
%bootSe_homep_cty  = sqrt(sum(bsxfun(@minus, b_homep_cty, homep_cty).^2,2)/nB);

bootSe_hp_no = sqrt(sum(bsxfun(@minus, b_hp_no, hp_no).^2,2)/n_valid)';
bootSe_hp_yr = sqrt(sum(bsxfun(@minus,b_hp_yr, hp_yr).^2,2)/n_valid)';
bootSe_hp_deal = sqrt(sum(bsxfun(@minus,b_hp_deal, hp_deal).^2,2)/n_valid)';
bootSe_hp_both  = sqrt(sum(bsxfun(@minus, b_hp_both, hp_both).^2,2)/n_valid)';
bootSe_hpc_no = sqrt(sum(bsxfun(@minus,b_hpc_no, hpc_no).^2,2)/n_valid);
bootSe_hpc_both  = sqrt(sum(bsxfun(@minus, b_hpc_both, hpc_both).^2,2)/n_valid);

bootSe_hp_add  = sqrt(sum(bsxfun(@minus, b_hp_add, hp_add).^2,2)/n_valid)';
bootSe_hpc_add = sqrt(sum(bsxfun(@minus,b_hpc_add, hpc_add).^2,2)/n_valid);

bootSe_hp_localass  = sqrt(sum(bsxfun(@minus, b_hp_localass, hp_localass).^2,2)/n_valid)';
bootSe_hpc_both_ass = sqrt(sum(bsxfun(@minus,b_hpc_both_ass, hpc_both_ass).^2,2)/n_valid);
bootSe_c_ass_both_ass = sqrt(sum(bsxfun(@minus,b_c_ass_both_ass, c_ass_both_ass).^2,2)/n_valid);

bootSe_hp_localass_yr  = sqrt(sum(bsxfun(@minus, b_hp_localass_yr, hp_localass_yr).^2,2)/n_valid)';
bootSe_hp_localass_deal = sqrt(sum(bsxfun(@minus,b_hp_localass_deal, hp_localass_deal).^2,2)/n_valid);
bootSe_hp_localass_both = sqrt(sum(bsxfun(@minus,b_hp_localass_both, hp_localass_both).^2,2)/n_valid);

%Save everything.
saveFile = ['..' filesep 'demand_output' filesep 'wBootresult.mat'];
save(saveFile);

% exit matlab for clusters
if isunix
    exit
end
