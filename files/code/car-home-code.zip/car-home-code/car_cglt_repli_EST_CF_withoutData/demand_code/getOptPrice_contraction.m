
% Input: nonlinear parameters; linear parameters (beta_hat); demand shocks,
% and costs from the demand estimation.
function [price_opt, share_newEq, exitflag_mat] = getOptPrice_contraction(parnonlin, beta_hat, DShocks, costs, m)
%% begin to compute optimal price by market
Nmkt = m.nMkts;
price_opt_cell = cell(Nmkt,1);
share_newEq_cell = cell(Nmkt,1);

price_opt = zeros(m.nObs,1);
share_newEq = zeros(m.nObs,1);
exitflag_mat = -999*ones(Nmkt,1); 

for mk = 1:Nmkt
          ind_mk_mat(:,mk) = (m.mktCode == mk);
end

for mk=1:Nmkt
    
          fprintf('Computing optimal prices in market %d out of %d ...\n', mk,Nmkt)
          
          % find firms/models in this market
          ind_mk = ind_mk_mat(:,mk);
          
          % put the information of m in the market in m_sub
          %m_sub  = Abstract_obs(m, ind_mk, mk);
          
          %[parnonlin_hat, moments_hat, delta_hat ] = unpackMpecX(theta_hat,m);
          %delta_hat_part = delta_hat(ind_mk);
          %theta_hat_part = [parnonlin_hat; moments_hat; delta_hat_part ];
          
          %[p_solved, exitflag] = price_contraction(theta_hat_part,m_sub);
          [p_solved, share_solved, exitflag] = price_contraction(parnonlin, beta_hat, DShocks, costs, m, mk);

          price_opt_cell{mk} = p_solved;
          share_newEq_cell{mk} = share_solved;
          exitflag_mat(mk) = exitflag; 
end
    
      % fill the price in, as the original order for each market
      for mk = 1:Nmkt
          price_opt(ind_mk_mat(:,mk))= price_opt_cell{mk};
          share_newEq(ind_mk_mat(:,mk))= share_newEq_cell{mk};
      end
      

return
