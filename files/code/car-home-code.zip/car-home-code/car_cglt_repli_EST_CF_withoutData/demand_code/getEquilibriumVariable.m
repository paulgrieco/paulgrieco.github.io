% this function grab the correct counterfactual equilibrium and return it
% for futher analysis.

function [price_cf, share_cf, delta_cf, cost_cf] = getEquilibriumVariable(counterRes,counterfactual_name)

price_cf = [];
for i = 1:length(counterRes)
        if strcmp(counterRes(i).name,counterfactual_name)
            price_cf = counterRes(i).price;
        end
end
assert(isempty(price_cf )==0);  

share_cf = [];
for i = 1:length(counterRes)
        if strcmp(counterRes(i).name,counterfactual_name)
            share_cf = counterRes(i).share;
        end
end
assert(isempty(share_cf )==0);  

delta_cf = []; % A bug here? We no longer save delta, we use constructDelta to get it
for i = 1:length(counterRes)
        if strcmp(counterRes(i).name,counterfactual_name)
            delta_cf = counterRes(i).delta;
        end
end
assert(isempty(delta_cf )==0);  

cost_cf = [];
for i = 1:length(counterRes)
        if strcmp(counterRes(i).name,counterfactual_name)
            cost_cf = counterRes(i).cost;
        end
end
assert(isempty(cost_cf )==0); % to make sure we find the correct cost