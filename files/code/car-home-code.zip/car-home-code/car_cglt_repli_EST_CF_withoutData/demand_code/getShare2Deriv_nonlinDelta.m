% This function compute the second piece in Hessian -- \partial^2 s / \partial \theta \partial \delta 
% Note that this is function, we utilize the fact that the first derivative
% of share wrt delta's in other mkt is zero -- so when we take the final
% sum (see note), the sum is only about the models within the market.

function    share2Deriv_nonlinDelta = getShare2Deriv_nonlinDelta(lambda, shareijDeriv_nonlin, share_ij, quadweight, nNodes, nMkts, size_nl, nObs, mktCode)


 share2Deriv_nonlinDelta = zeros( size_nl,nObs); % the size of delta is m.nObs
 
 % for dc = 1:size_nl % for each nonlinear parameter -- (change the order of the layout of two loops (dc and mk) -- double check if it is correct.)
         
      for mk = 1:nMkts % for each market
              ind_mk = (mktCode==mk);
              share2Deriv_nonlinDelta_mk = zeros( size_nl,sum(ind_mk)); % for a specific mkt
              
           for dc = 1:size_nl % for each nonlinear parameter
          
              Jac_market = 0;
              for my_cons = 1:nNodes
                 deriv_self           = shareijDeriv_nonlin{mk,dc}(:,my_cons) .* (1-2*share_ij(ind_mk,my_cons));
                 deriv_offdiag        = - shareijDeriv_nonlin{mk,dc}(:,my_cons) * share_ij(ind_mk,my_cons)' - share_ij(ind_mk,my_cons) * shareijDeriv_nonlin{mk,dc}(:,my_cons)' ;
                 %Jac(:,:,my_cons)     = (1-eye(sum(ind_mk))) .* deriv_offdiag + diag(deriv_self);
                 Jac_market           = Jac_market + quadweight(1,my_cons) * ((1-eye(sum(ind_mk))) .* deriv_offdiag + diag(deriv_self));
              end
              % Jac_market will be m.nObs (share) x m.nObs (delta)
              share2Deriv_nonlinDelta_mk(dc,:) = lambda.eqnonlin(ind_mk)' * Jac_market;
              
           end
           share2Deriv_nonlinDelta (:,ind_mk)  = share2Deriv_nonlinDelta_mk; % see the note on the top of this function.
           
           
      end
          

          

% end
 
 
end
                 

              
         
         
 






















