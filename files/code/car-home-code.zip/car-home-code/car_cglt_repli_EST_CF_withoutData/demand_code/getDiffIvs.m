function [ DiffIVs ] = getDiffIvs(Xhist, Xinter, groupCode, K )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

   numGroups = max(groupCode);
   numHistD = size(Xhist,2);
   numInterD = size(Xinter,2);
   
   DiffIVs = zeros(size(Xhist,1), numHistD*numInterD*K);
   
   
   %Calculate group cuttoffs
   for g = 1:numGroups
       IV_d = [];
       for d = 1:numHistD
           xD = Xhist(groupCode == g, d);
           diff = bsxfun(@minus, xD, xD');
           diff = diff./(1-eye(size(diff)));
           distr = diff(:);
           distr(isnan(distr)) = [];
           
           IV_k = [];
           for kk = 1:K
              cut = prctile(distr, 100*kk/(K+1));
              IV_k = [IV_k (diff < cut)*Xinter(groupCode==g,:) ];
           end
           
           IV_d = [IV_d IV_k];      
       end
       DiffIVs(groupCode == g, :) = IV_d;
   end
   
   %First, find cutoffs. 
    
end

