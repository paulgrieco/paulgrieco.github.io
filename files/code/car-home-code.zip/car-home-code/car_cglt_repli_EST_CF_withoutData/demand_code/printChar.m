% This function print the charicteristics of cars across markets
% Note: hpszwtmpg is the one used in the estimation -- so it is normalized
% with mean 1 (no change in std);
% While other char variables are loaded directly from data (without normalization)
% eff can be either mpD or mpg
function printChar(hppwt, sz, eff, hpszwtmpg, m, c2str) 

fid = fopen(['..' filesep 'demand_output' filesep 'chars.txt'], 'w');

 row_varName = {'hppwt mean','hppwt std' , 'sz mean', 'sz std', 'eff mean', 'eff std'};
 col_varName = c2str.Ctys;
 
     hppwt_show = hppwt;
     sz_show = sz;
     eff_show = eff;
     

     for i = 1:length(col_varName)
        char_value(1,i) = mean(hppwt_show(m.ctyCode==i))*100; 
        char_value(3,i) = mean(sz_show(m.ctyCode==i))/1e+6; 
        char_value(5,i) = mean(eff_show(m.ctyCode==i)); 
        char_value(2,i) = std(hppwt_show(m.ctyCode==i))*100; 
        char_value(4,i) = std(sz_show(m.ctyCode==i))/1e+6; 
        char_value(6,i) = std(eff_show(m.ctyCode==i)); 
     end
    
%   fprintf(fid, '\\begin{landscape} \n');
    fprintf(fid, '\\begin{table}[t] \n'); 
    fprintf(fid, '\\begin{center} \n');
    fprintf(fid, '\\caption{Characteristics across countries}\\centering \n');

        fprintf(fid, '\\begin{tabular}{@{}c|ccccccccc}\n');
        fprintf(fid, '\\toprule   \n');
        fprintf(fid, ' Characteristic & \\multicolumn{9}{c}{Country} \\\\\n');

    fprintf(fid, '\\midrule  \n');
    for i = 1:length(col_varName)
        fprintf(fid, '&%s', col_varName{i} );
    end
    fprintf(fid, '\\\\\n' );
    fprintf(fid, '\\midrule  \n');
   
    %Print main content
    for i = 1:length(row_varName)
            fprintf(fid, '%s &%4.3f &%4.3f &%4.3f&%4.3f&%4.3f&%4.3f&%4.3f&%4.3f &%4.3f\\\\ \n', row_varName{i},char_value(i,:));
    end
    
        
    fprintf(fid, '\\bottomrule \n');
    fprintf(fid, '\\end{tabular} \n');
        fprintf(fid, '\\end{center} \n');
    fprintf(fid, '\\end{table} \n');







return
