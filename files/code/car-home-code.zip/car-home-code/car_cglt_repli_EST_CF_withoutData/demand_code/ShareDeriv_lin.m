% this is based on ShareDeriv_nonlin. It is the derivative of share with
% respective to linear parameters (i.e., betaBar and alphaBar).

function [Gradient] = ShareDeriv_lin(delta, mu, m)


  %This will already be done as part of constraints
   [foo1, share_ij ] = getShare(delta, mu, m);
 
   size_lin = size(m.linX,2); % total number of linear parameters, including price, which is the first part
   Gradient = zeros(m.nObs, size_lin); % gradient is for each market share and each linear parameter
   for mk=1:m.nMkts
       ind_mk = (m.mktCode==mk);
       share_ij_mk = share_ij(ind_mk,:);
       
       if sum(ind_mk) == 0
           continue
       end

       
       linX_mk = m.linX(ind_mk,:); % characters/variables for this market "mk"
            
       for dc = 1:size_lin % for each linear parameter
           
           inSum = linX_mk(:,dc)' * share_ij_mk;          
           
           kernel = share_ij_mk.* bsxfun(@minus, linX_mk(:,dc), inSum);

           Gradient(ind_mk,dc)  = kernel * m.quadweight';
       end
          
   end
          
end