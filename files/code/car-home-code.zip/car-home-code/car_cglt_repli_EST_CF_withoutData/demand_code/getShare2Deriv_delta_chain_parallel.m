% This function compute the third piece in Hessian -- \partial^2 s /  \partial \delta^2 
% this function use the chain rule to compute the derivatives directly.

function    share2Deriv_delta = getShare2Deriv_delta_chain_parallel(lambda, share_ij, quadweight, nNodes, nObs, nMkts, mktCode, Jac_market_ij_cell)

share2Deriv_delta = zeros(nObs, nObs);
 
% for dc = 1:m.size_nl % for each nonlinear parameter
     parfor  r = 1:nObs % for each delta
         %r
         
         for mk = 1:nMkts % for each market
              if mktCode(r) == mk
                  
              ind_mk = (mktCode==mk);
              n_mod = sum(ind_mk);
              
              % prepare positions
              r_mk = r - sum( ind_mk(1:r) == 0 ); % r_mk is the position of r in the current market.
              assert(r_mk<=n_mod);
              pos_1 = zeros(n_mod,n_mod);
              pos_1(r_mk,:) = 1;
              pos_2 = ones(n_mod,n_mod) - pos_1;
              

              share2Deriv_delta_mk = 0;
     
              for my_cons = 1:nNodes % each of the following should be n_mod x n_mod  
                      s_r = share_ij(r,my_cons); 
                      part_1 = Jac_market_ij_cell{mk}(:,:,my_cons) .* (1-2*s_r*ones(n_mod));
                      part_2 = - Jac_market_ij_cell{mk}(:,:,my_cons) .* s_r .* ones(n_mod) - share_ij(ind_mk,my_cons) * Jac_market_ij_cell{mk}(r_mk,:,my_cons);
                      
                      share2Deriv_delta_mk  = share2Deriv_delta_mk + quadweight(1,my_cons) *( part_1 .* pos_1 + part_2 .* pos_2  );
              end
              
              temp = zeros(1,nObs);
              temp(ind_mk) = lambda.eqnonlin(ind_mk)' * share2Deriv_delta_mk;
              %share2Deriv_delta(r,:) = share2Deriv_delta(r,:) + temp;
              share2Deriv_delta(r,:) = temp;
              
              end
              
         end
         
     end
                  
                      
                  
                  
                  













