
function [data, varNames] = readInCsv(fname,cost)
%This function reads in all variables from a csv, it's main restriction is
%that the list of string variables must be specified as 'stringVars' 
%
% For our data, these are always the same set of variables, a more flexible
% version could pass stringvars in as an argument. 
%
    fileID = fopen(fname);
    assert(fileID ~= -1, sprintf('readInCsv: failed to open csv file: %s', fname));

    A = fgetl(fileID);
    nCols = sum(A==',') + 1;
    frewind(fileID);

    formatSpec = '';
    for c = 1:nCols
       formatSpec = strcat(formatSpec,'%q');
    end
    formatSpec = strcat(formatSpec, '%[^\n\r]');

    colHeadArray = textscan(fileID, formatSpec, 1, 'Delimiter', ',');
    dataArray = textscan(fileID, formatSpec, 'delimiter', ',');


       %These are the variables that match to strings, everything else is numeric.
        stringVars = {'mkt', 'cty', 'brand', 'firm', 'model', 'brandcty', ...
            'iso1', 'iso2', 'iso3', 'iso4', 'iso5', 'iso6', 'iso7', 'iso8', ...
            'iso9', 'iso10', 'iso11', 'iso12', 'iso13', 'iso14', 'iso15', ...
            'iso_hq', 'isohq'};


        %Not sure why textscan brings in a blank column at the end, but it seems to
        %be consistent, did it for the MATLAB-generated code als, so we go to the
        %second to last column.
        for c = 1:length(dataArray)-1
        %c = 2;
           varName = colHeadArray{c}{1};

           %This line strips out the underscore '_' from names, since we
           %haven't been using them on the MATLAB side...This is a legacy from
           %the GUI import I'm very sorry I ever used. -P
           if nargin == 1
               varName = strrep(varName, '_', '');
           end

           if (strcmp(varName, ''))
               continue;
           end
           varNames{c} = varName;
           %Determine if this is a text or numeric variable
           castToCell = 0;
           for s = 1:length(stringVars)
               if strcmp(varName, stringVars{s})
                   castToCell = 1;
                   continue;
               end
           end

           if castToCell == 1
              data.(varName) =  dataArray{:,c};
           else
              %Now we have our numeric columns, convert all non-numericas to nan
              rawData = dataArray{c};
              numeric = nan(size(rawData));
                % Create a regular expression to detect and remove non-numeric prefixes and
                % suffixes.
                regexstr = '(?<prefix>.*?)(?<numbers>([-]*(\d+[\,]*)+[\.]{0,1}\d*[eEdD]{0,1}[-+]*\d*[i]{0,1})|([-]*(\d+[\,]*)*[\.]{1,1}\d+[eEdD]{0,1}[-+]*\d*[i]{0,1}))(?<suffix>.*)';
                try
                    result = regexp(rawData, regexstr, 'names');
                catch me
                end

                for j = 1:size(rawData,1)
                    %First, check whether or not any text was in the cell at
                    %all...
                    if (isempty(result{j}))
                        numeric(j) = nan;
                        continue;
                    end
                    %There was, so see if it can be converted to numeric...
                    numD = cell2mat(textscan(strrep(result{j}.numbers, ',', ''), '%f'));
                    if (isnumeric(numD) || islogical(numD) )
                       numeric(j) = numD;
                    else
                       numeric(j) = nan;
                    end
                end
              data.(varName) = numeric;
           end 
        end
        
end