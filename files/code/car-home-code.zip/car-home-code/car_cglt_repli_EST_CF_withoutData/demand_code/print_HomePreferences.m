% Input: mainout is the result file; boot_ind = 1 means to want to load and
% use the bootstrapping se; print says if we want to print the tables (we do not want to when we do demand bootstrapping.)
function [beta_nocontrols, beta_years, beta_dealer, beta_bothcontrols, betac_nocontrols, betac_bothcontrols,       beta_addcontrols,  betac_addcontrols,       beta_localass, betac_both_ass,  est_c_ass_both_ass, ...
    beta_localass_years ,   ...
    beta_localass_dealer ,   ...
    beta_localass_both] = print_HomePreferences(mainout, boot_ind, print)

if nargin == 2
    print = 'yes';
end

%% Read in the brand country dealer and entry year data
switch mainout.m.fileVersion
    case 'Full'
        brandDataFname = ['..' filesep 'input_files' filesep 'entryyears_dealers.csv'];  % consider saving this into demandData.csv in the Stata data generation so that we don't need to carry and load this separately
    case 'noBRA'
        brandDataFname = ['..' filesep 'input_files' filesep 'entryyears_dealers_noBRA.csv'];  % consider saving this into demandData.csv in the Stata data generation so that we don't need to carry and load this separately
    case 'EU'
        brandDataFname = ['..' filesep 'input_files' filesep 'entryyears_dealers_onlyEU.csv'];  % consider saving this into demandData.csv in the Stata data generation so that we don't need to carry and load this separately
    otherwise
       fprintf('Error: Unrecognized file version name: %s \n', mainout.m.fileVersion);
   return;
end
        
if boot_ind == 1
% load bootstrapping result:
load('../demand_output/wBootresult','bootSe*')
end

fid = fopen(brandDataFname);

cols = 8;
colHeadArray = textscan(fid, '%s %s %s %s %s %s %s %s', 1, 'Delimiter', ',');
dataArray = textscan(fid,    '%s %s %d %d %d %d %d %d', 'Delimiter', ',');

for i = 3:cols
    bmData.(colHeadArray{i}{1}) = double( dataArray{i} );
end

fclose(fid);

%Construct dealer per household number (mktsize, hhold/6) (in 10k households)...
bmData.dealerPH = 1e5*(bmData.ndealers_gmaps ./ bmData.hholds);

%% Home preferences
% The order of the controls:
%Home Brand
%Years in Market
%Dealer Density
%Locally Owned Brand
%Locally Assembled Brand

%This runs without the additional controls for brand-market effects
[beta_nocontrols, se_nocontrols, betac_nocontrols, sec_nocontrols, ~,~,~,~,~,~,~,~,~,~,  R2_nocontrols, R2c_nocontrols, n_X, n_Xc] = extractHomeFromCBD(mainout.beta_hat, mainout.var_Nonlin_Lin, mainout.m);
% beta_nocontrols(2:end) = NaN; % first component captures home preference, last two components capture years in the market and dealers
% se_nocontrols(2:end)   = NaN;

if boot_ind == 1
    se_nocontrols = bootSe_hp_no'; % use bootstrapping se
    sec_nocontrols = bootSe_hpc_no'; % use bootstrapping se
end


%This includes years in the market
[beta_years, se_years, betac_years, sec_years] = extractHomeFromCBD(mainout.beta_hat,mainout.var_Nonlin_Lin, mainout.m, bmData, 'years');
% beta_years(3:end) = NaN;  % last i.e. 3rd component captures the control
% se_years(3:end)  = NaN;

if boot_ind == 1
    se_years = bootSe_hp_yr; % use bootstrapping se
end

%This includes dealer density
[beta_dealer, se_dealer, betac_dealer, sec_dealer] = extractHomeFromCBD(mainout.beta_hat,mainout.var_Nonlin_Lin, mainout.m, bmData, 'dealer');
% beta_dealer([2,4,5]) = NaN; % 
% se_dealer([2,4,5]) = NaN;

if boot_ind == 1
    se_dealer = bootSe_hp_deal; % use bootstrapping se
end

%This includes both controls 
[beta_bothcontrols, se_bothcontrols, betac_bothcontrols, sec_bothcontrols, ~,~,~,~,~,~,~,~,~,~,  R2_bothcontrols, R2c_bothcontrols] = extractHomeFromCBD(mainout.beta_hat,mainout.var_Nonlin_Lin, mainout.m, bmData, 'both');
% beta_bothcontrols([4,5]) = NaN; % 
% se_bothcontrols([4,5]) = NaN;

if boot_ind == 1
    se_bothcontrols = bootSe_hp_both';
    sec_bothcontrols = bootSe_hpc_both'; % use bootstrapping se
end

%This includes additional controls 
[beta_addcontrols, se_addcontrols, betac_addcontrols, sec_addcontrols] = extractHomeFromCBD(mainout.beta_hat,mainout.var_Nonlin_Lin, mainout.m, bmData, 'addition');

if boot_ind == 1
    se_addcontrols = bootSe_hp_add;
    sec_addcontrols = bootSe_hpc_add; % use bootstrapping se
end

%This includes   'localass'
[beta_localass, se_localass, betac_localass, sec_localass, ~, ~, est_c_ass_localass, se_c_ass_localass, ~,~,~,~,~,~, R2_localass, R2c_localass] = extractHomeFromCBD(mainout.beta_hat,mainout.var_Nonlin_Lin, mainout.m, bmData, 'localass');
% beta_localass([2,3,4]) = NaN; % 
% se_localass([4,5]) = NaN;

if boot_ind == 1
    se_localass = bootSe_hp_localass';
%    sec_localass = bootSe_hpc_localass; % use bootstrapping se
end

% %This includes   'localown'
% [beta_localown, se_localown, betac_localown, sec_localown] = extractHomeFromCBD(mainout.beta_hat,mainout.var_Nonlin_Lin, mainout.m, bmData, 'localown');
% 
% if boot_ind == 1
%     se_localown = bootSe_hp_localown;
%     sec_localown = bootSe_hpc_localown; % use bootstrapping se
% end

% %This includes   'localown_dealer'
% [beta_localown_dealer, se_localown_dealer, betac_localown_dealer, sec_localown_dealer] = extractHomeFromCBD(mainout.beta_hat,mainout.var_Nonlin_Lin, mainout.m, bmData, 'localown_dealer');
% 
% if boot_ind == 1
%     se_localown_dealer = bootSe_hp_localown_dealer;
%     sec_localown_dealer = bootSe_hpc_localown_dealer; % use bootstrapping se
% end

% %This includes   'localown_ass'
% [beta_localown_ass, se_localown_ass, betac_localown_ass, sec_localown_ass] = extractHomeFromCBD(mainout.beta_hat,mainout.var_Nonlin_Lin, mainout.m, bmData, 'localown_ass');
% 
% if boot_ind == 1
%     se_localown_ass = bootSe_hp_localown_ass;
%     sec_localown_ass = bootSe_hpc_localown_ass; % use bootstrapping se
% end

%This includes   'both_ass'
[~, ~, betac_both_ass, sec_both_ass, ~, ~, est_c_ass_both_ass, se_c_ass_both_ass, ~,~,~,~,~,~,  R2_ass_both_ass, R2c_ass_both_ass] = extractHomeFromCBD(mainout.beta_hat,mainout.var_Nonlin_Lin, mainout.m, bmData, 'both_ass');

if boot_ind == 1
    %se_both_ass = bootSe_hp_both_ass;
    sec_both_ass = bootSe_hpc_both_ass; % use bootstrapping se
    se_c_ass_both_ass = bootSe_c_ass_both_ass;
end

%This includes   'localass_years': local assembly and years in the market
[beta_localass_years, se_localass_years, betac_localass_years, sec_localass_years, ~,~,~,~,~,~, ~,~,~,~, R2_localass_years, R2c_localass_years] = extractHomeFromCBD(mainout.beta_hat,mainout.var_Nonlin_Lin, mainout.m, bmData, 'localass_years');

if boot_ind == 1
    se_localass_years = bootSe_hp_localass_yr';
%    sec_localass_years = bootSe_hpc_localass_years; % use bootstrapping se
end

%This includes   'localass_dealer': local assembly and dealership
[beta_localass_dealer, se_localass_dealer, betac_localass_dealer, sec_localass_dealer, ~,~,~,~,~,~, ~,~,~,~, R2_localass_dealer, R2c_localass_dealer] = extractHomeFromCBD(mainout.beta_hat,mainout.var_Nonlin_Lin, mainout.m, bmData, 'localass_dealer');

if boot_ind == 1
    se_localass_dealer = bootSe_hp_localass_deal;
%    sec_localass_dealer = bootSe_hpc_localass_dealer; % use bootstrapping se
end

%This includes   'localass_both': local assembly and both years and dealership
% This one actually is the same as 'both_ass', can delete this one.
[beta_localass_both, se_localass_both, betac_localass_both, sec_localass_both, ~,~,~,~,~,~, ~,~,~,~, R2_localass_both, R2c_localass_both] = extractHomeFromCBD(mainout.beta_hat,mainout.var_Nonlin_Lin, mainout.m, bmData, 'localass_both');

if boot_ind == 1
    se_localass_both = bootSe_hp_localass_both;
 %   sec_localass_both = bootSe_hpc_localass_both; % use bootstrapping se
end

% % To temp print the result for excel, break here and print the following:
% % For the homog home dummy spec
% print_result = [beta_nocontrols, se_nocontrols, ...
% beta_localass , se_localass  , ...
% beta_localown  , se_localown  , ...
% beta_localown_dealer  , se_localown_dealer , ...
% beta_localown_ass , se_localown_ass , ...
% beta_addcontrols , se_addcontrols];

% For the homog home dummy spec
homog_home_est = [beta_nocontrols, ...
beta_bothcontrols, ...    
beta_localass ,   ...
beta_localass_years ,   ...
beta_localass_dealer ,   ...
beta_localass_both];

homog_home_se = [  se_nocontrols, ...
    se_bothcontrols, ...
  se_localass  , ...
 se_localass_years , ...
  se_localass_dealer, ...
  se_localass_both];

% homog_home_R2 = [R2_nocontrols, ...
% R2_bothcontrols, ...    
% R2_localass ,   ...
% R2_localass_years ,   ...
% R2_localass_dealer ,   ...
% R2_localass_both];
% 
% homog_home_n = repmat(n_X,size(homog_home_R2,2),1);

% % For the heterog home dummy spec
% result_withyrdealer = [betac_bothcontrols sec_bothcontrols  betac_both_ass sec_both_ass  est_c_ass_both_ass se_c_ass_both_ass]; 
% result_noyrdealer = [betac_nocontrols sec_nocontrols  betac_localass sec_localass  est_c_ass_localass se_c_ass_localass]; 

% heterog_home_est = [betac_localass   est_c_ass_localass ]; % this version does NOT include years and dealership in the regression
% heterog_home_se = [  sec_localass    se_c_ass_localass]; 

heterog_home_est = [betac_both_ass   est_c_ass_both_ass ]; % this version DOES include years and dealership in the regression
heterog_home_se = [  sec_both_ass    se_c_ass_both_ass]; 

%% Display and print results
% namevec = {'Home Preference',...   % variable names, with standard errors below coefficients
%            'Years in Market',...
%            'Dealer Density'}';
% 
% coef = [beta_nocontrols', beta_withcontrols'];
% serr   = [se_nocontrols', se_withcontrols'];
% 
% display('------------------------')       
% display('Explaining Home Preferences: coefficients')       
% horzcat(namevec,num2cell(coef))
% display('Explaining Home Preferences: st errors') 
% horzcat(namevec,num2cell(serr))

%% Print table
if strcmp(print, 'yes') 

 % print homogenous home preference table
outfile = [ '..' filesep 'demand_output' filesep 'results_homepreferences_homog.txt'];
fid = fopen(outfile, 'wt');

fprintf(fid, '\\begin{table}[t] \n'); 
fprintf(fid, '\\begin{center} \n');
fprintf(fid, '\\caption{Structural Homegenous Home Preference Parameters  }\\centering \n');
fprintf(fid, '\\begin{tabular}{@{}lccccccc}');  % variable, space, 4 specifications
fprintf(fid, '\\hline   \n');
fprintf(fid, '\\hline   \n');
fprintf(fid, ' &  & (%4.0f  ) & (%4.0f  )   & (%4.0f  )   &(%4.0f  )  &  (%4.0f  ) &  (%4.0f  ) \\\\ \n', [1 2 3 4 5 6]);  % number of specifications
fprintf(fid, '\\hline   \n');
fprintf(fid, '%s &  & %4.3f  & %4.3f  &%4.3f   &%4.3f  &  %4.3f &  %4.3f \\\\ \n', 'Home', homog_home_est(1,:));
fprintf(fid, '  &  & \\footnotesize{(%4.3f)} & \\footnotesize{(%4.3f)}  &\\footnotesize{(%4.3f)}   &\\footnotesize{(%4.3f)}  & \\footnotesize{(%4.3f)} & \\footnotesize{(%4.3f)}\\\\ \n', homog_home_se(1,:));
fprintf(fid, '%s &  &  %4.3f &  %4.3f  & %4.3f  & %4.3f&   %4.3f&  %4.3f\\\\ \n', 'Home Assembly',  homog_home_est(5,:));
fprintf(fid, '  &  &     \\footnotesize{(%4.3f)} &     \\footnotesize{(%4.3f)} &    \\footnotesize{(%4.3f)}  &  \\footnotesize{(%4.3f)} &    \\footnotesize{(%4.3f)}  &  \\footnotesize{(%4.3f)}\\\\ \n', homog_home_se(5,:));
fprintf(fid, '%s &   &  %4.3f   &  %4.3f  & %4.3f   &  %4.3f  &  %4.3f &  %4.3f\\\\ \n', 'Years in Market',homog_home_est(2,:));
fprintf(fid, '  &  & \\footnotesize{(%4.3f)} & \\footnotesize{(%4.3f)} &  \\footnotesize{(%4.3f)}  &\\footnotesize{(%4.3f)}   &   \\footnotesize{(%4.3f)} &  \\footnotesize{(%4.3f)}\\\\ \n',  homog_home_se(2,:));
fprintf(fid, '%s &  &    %4.3f &    %4.3f&   %4.3f&%4.3f  &  %4.3f &  %4.3f\\\\ \n', 'Dealer Density', homog_home_est(3,:));
fprintf(fid, '  &  &   \\footnotesize{(%4.3f)}&   \\footnotesize{(%4.3f)}  &  \\footnotesize{(%4.3f)}  &\\footnotesize{(%4.3f)}  &  \\footnotesize{(%4.3f)} &  \\footnotesize{(%4.3f)}\\\\ \n', homog_home_se(3,:));
fprintf(fid, '\\hline   \n');
 
% fprintf(fid, '%s &  &    %4.3f &    %4.3f&   %4.3f&%4.3f  &  %4.3f &  %4.3f\\\\ \n', '$R^2$', homog_home_R2);
% fprintf(fid, '%s &  &    %4.3f &    %4.3f&   %4.3f&%4.3f  &  %4.3f &  %4.3f\\\\ \n', 'Observations', homog_home_n);
 
    fprintf(fid, '\\hline   \n');
    fprintf(fid, '\\hline   \n');
    fprintf(fid, '\\end{tabular} \n');
    fprintf(fid, '\\end{center} \n');
    fprintf(fid, '\\end{table} \n');

    
 % print heterogenous home preference table: note that this version does
 % not have years and dealership as controls.
outfile = [ '..' filesep 'demand_output' filesep 'results_homepreferences_heterog.txt'];
fid = fopen(outfile, 'wt');

fprintf(fid, '\\begin{table}[t] \n'); 
fprintf(fid, '\\begin{center} \n');
fprintf(fid, '\\caption{Structural Heterogenous Home Preference Parameters (years and dealership controls included) }\\centering \n');
fprintf(fid, '\\begin{tabular}{@{}lcc}');  % 
fprintf(fid, '\\hline   \n');
    fprintf(fid, '\\hline   \n');
fprintf(fid, ' & %s & %s   \\\\ \n', 'Home Brand', 'Home Assembly');
    fprintf(fid, '\\hline   \n');
for i=1:length(mainout.c2str.Ctys) %  
        fprintf(fid, '%s &   %4.3f    & %4.3f \\\\ \n', mainout.c2str.Ctys{i},  heterog_home_est(i,:) );
        fprintf(fid, '   &   \\footnotesize{(%4.3f)}   &    \\footnotesize{(%4.3f)} \\\\ \n', heterog_home_se(i,:));
end

    fprintf(fid, '\\hline   \n');
    fprintf(fid, '\\hline   \n');
    fprintf(fid, '\\end{tabular} \n');
    fprintf(fid, '\\end{center} \n');
    fprintf(fid, '\\end{table} \n');
end

return