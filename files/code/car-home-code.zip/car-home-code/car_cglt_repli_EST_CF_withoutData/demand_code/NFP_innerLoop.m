% This is to solve for delta from the inner loop
function [delta_solved, constrviolation] = NFP_innerLoop(parnonlin, delta_start, m)
mu = getMu(parnonlin,m);

%% Solve constraints to get delta:

%Set up the jacobian pattern....this bit of code should really be
%functionalized someday...
Jac_Pattern_delta = zeros(m.nObs, m.nObs);
for mk=1:m.nMkts
          ind_mk = (m.mktCode==mk);
          Jac_Pattern_delta(ind_mk,ind_mk) = 1;
end

% For Hessian Pattern 
Hessian_Pattern_delta = sparse(m.nObs, m.nObs);
for mk=1:m.nMkts;
          ind_mk = (m.mktCode==mk);
          Hessian_Pattern_delta(ind_mk,ind_mk) = 1;
end           
Hessian_Pattern_delta_sparse = sparse(Hessian_Pattern_delta);

%Clear out the non-essential stuff for maximum available memory
clear Hessian_Pattern

%ktropts = optimset('Display','iter','JacobPattern',Jac_Pattern);
% note that x here is delta
%ktropts = optimset('Display','iter','JacobPattern',Jac_Pattern_delta, 'HessPattern',Hessian_Pattern_delta_sparse, 'Hessian','user-supplied', 'HessFcn', @(x, lambda) getHessian_dumObj(x, lambda, mu, m)  );
ktropts = optimset('Display','off','JacobPattern',Jac_Pattern_delta  );

% [guess, sh_diff_max] = getDelta(delta_start, mu, m, 10000);
% guess = real(guess);

% We do not want the iteration to go on for a very long time when KNITRO
% can solve it quickly, but we need to give a point that KNITRO indeed is
% able to solve.
i = 1;
sh_diff_max = 1;
contract_crit = 1e-4;
guess = delta_start;

    while (sh_diff_max > contract_crit)
       if (sh_diff_max < 1)
           fprintf('NFP_innerLoop: getDelta restart constraint violation = %e > %e \n', sh_diff_max, contract_crit);
       end
       [guess, sh_diff_max] = getDelta(guess, mu, m, 5000 , contract_crit);
       guess = real(guess);
       %fprintf('NFP_innerLoop: getDelta returned with constraint error %e\n', sh_diff_max);
    end

if sh_diff_max<1e-10 %Matches the solve tolerance in knitro_9_dumObj_noHess_NFP.opt
   delta_solved = guess;
   constrviolation = sh_diff_max;
elseif (sum(guess == Inf) == 0) && (sum(guess == -Inf) == 0) && (sum(isnan(guess) == 1) == 0)
   %fprintf('NFP_innerLoop: Calling KNITRO to Sharpen Answer\n');
   [delta_solved, fval ,exitflag_delta,output_delta] = knitrolink(@(x) dummy_objective(x),guess,[],[],[],[],[],[], ...
   @(x) shareConstraintsParallel_dumObj(x, mu,m),ktropts,'knitro_9_dumObj_noHess_NFP.opt');
   delta_solved = real(delta_solved);
   constrviolation = output_delta.constrviolation; % this is the accuraracy of share equation solved
else % otherwise use m.delta_start (to restart)
    %fprintf('NFP_innerLoop: Convergence Failure, Trying from MNL Startpoint (Hail Mary!)\n');
    delta_restart = log(m.share) - log(m.outshare);
   
    [guess, sh_diff_max] = getDelta(delta_restart, mu, m, 5000 , contract_crit);
    guess = real(guess);
    fprintf('NFP_innerLoop: getDelta restart returned with constraint error %e\n', sh_diff_max);
   
    [delta_solved, fval ,exitflag_delta,output_delta] = knitrolink(@(x) dummy_objective(x),delta_restart,[],[],[],[],[],[], ...
    @(x) shareConstraintsParallel_dumObj(x, mu,m),ktropts,'knitro_9_dumObj_noHess_NFP.opt');
    delta_solved = real(delta_solved);
    constrviolation = output_delta.constrviolation; % this is the accuraracy of share equation solved
end

%disp(constrviolation)

