%This is the master script for the demand estimation 
clear;
clc;
tic;

%% Multistart vs manually set initial point
multistart = 0;     % yes for 1, any other number uses one (manually set) initial point
                    % eventually: (1) Move point generation to setupStructs
                    % (2) maybe have separate scripts. 
                    % 

%% Set identifiers for specifications: user-interface to choose options for specification
[m, c2str] = setupStructs(); % This script generates an (m, c2str) pair 

%% Parallel Cluster Settings
[~, hname] = system('hostname');

if ~isempty(strfind(hname, 'midway'))    % Are we on the UofC clusters 
    s = matlabpool('size');
    if s~=0
        matlabpool('close')
    end
    pc = parcluster('local');
    % explicitly set the JobStorageLocation to the temp directory that was created in your sbatch script
    pc.JobStorageLocation = strcat('/tmp/shengyuli/', getenv('SLURM_JOB_ID'), '/', getenv('SLURM_ARRAY_TASK_ID'));
    pause(1+60*rand()) % We would have an error when starting many parpools on the same machine at the same time. The jobs seem to write in the same temporary file and causing the error, 
    matlabpool(pc, pc.NumWorkers);      % start the matlabpool with 12 workers
else
    if isempty(gcp('nocreate'))~=1
        poolobj = gcp('nocreate');
        delete(poolobj);
    end
    pc = parcluster('local');
    parpool(pc.NumWorkers);
end

%% Setting the necessary variables and initial points 
if multistart == 1
    assert(~isempty(strfind(hname, 'midway')), 'demandEstimation: multistart option only available on midway cluster');
    NTASKS = 40;
    rng(1000);
    if m.lognormprice == 1
        parnonlin_preEst =  [2.3861   -3.6829    0.0077   -0.0556   -2.9244    2.3504   -0.9917    0.0397]'; % use the result from last converged estimation as a initial point -- just to make sure it converges quickly
    else
        parnonlin_preEst = [ 6*ones(size(m.SigmaEntries,1),1) ; -.2*ones(size(m.PiEntries,1),1) ]; 
    end
    parnonlin_guess_all = parnonlin_preEst'; 
    MSRUN = 1;
    while MSRUN<NTASKS
        parnonlin_guess =  2*parnonlin_preEst' .* rand(1 ,size(parnonlin_preEst,1)); % here we are making sure that the magnitudes of these non-linear parameters are reasonable. temp is checking that. LATER: change this such that starting points are set separately once and read in.
        %temp = (( parnonlin_guess(:,end-2)  + 10*parnonlin_guess(:,end-1) + parnonlin_guess(:,end) ) < 5) & (( parnonlin_guess(:,end-2)  + 10*parnonlin_guess(:,end-1) + parnonlin_guess(:,end) ) > 0);
        temp = 1;
        if temp == 1
            parnonlin_guess_all = [parnonlin_guess_all; parnonlin_guess];
            MSRUN = MSRUN + 1;
        end
    end
    
    task_id = str2num(getenv('SLURM_ARRAY_TASK_ID'));
    ms_run    = task_id;
    parnonlin = parnonlin_guess_all(ms_run,:)'
else
    if m.lognormprice == 1
        parnonlin = [2.3861   -3.6829    0.0077   -0.0556   -2.9244    2.3504   -0.9917    0.0397]'; % the nonlinear parameters -- the dimension depends on the dimension of Sigma and Pi matrix.
        %load(['..' filesep 'input_files' filesep 'start_point']);
        %parnonlin = parnonlin_start;
    else
        parnonlin = [ 6*ones(size(m.SigmaEntries,1),1) ; -.2*ones(size(m.PiEntries,1),1) ]; %Don't have a good start point for the "standard" setup right now.
    end
    task_id = 0;
    ms_run = 0;
end
fprintf('my task_id = %d\n', task_id);

m.theta_start = real(genMPECStart(m,parnonlin)); % generate a nice start point
if max(abs(imag(m.theta_start))) > 0
    fprintf('Warning: m.theta_start has imag part (but corrected)!!! The max is: %f \n', max(abs(imag(m.theta_start))));
    m.theta_start = real(m.theta_start);
end

[~, ~, m.delta_start ] = unpackMpecX(m.theta_start,m); % sign the solution of delta to m.delta_start
m.parnonlin_guess      = parnonlin;
m.max_restart          = 10; % Extra m-structure settings related to system-specific runs
clearvars -except m c2str saveFile knitroOptions Est_Method ms_run task_id; 

%% Main estimation
switch m.Est_Method
    case 'MPEC'
         %Define a knitroOptions file if one is not defined. Note that this default is ALWAYS used by the LionX cluster.
         if (exist('knitroOptions', 'var') == 0)
                m.knitroFile = 'knitro_9_12core_Hessian.opt';
         else
                m.knitroFile = knitroOptions;
         end
         mainout      = MPECmain(m, c2str);
    case 'NFP' 
         global delta_start % this is to save time -- use from previously solved delta
         delta_start  = m.delta_start;
         m.knitroFile = 'knitro_9_nfp.opt';
         mainout      = NFPmain(m, c2str);
    otherwise
       fprintf('Error: Unrecognized Estimation Method Requested! \n');
       return;
end

disp(sprintf('Completed iteration %d\n', ms_run));

outFile = sprintf('result_%d.mat', task_id);
save(['..' filesep 'demand_output' filesep outFile], 'mainout')
toc;

%% Exit and close the parallel computation
[~, hname] = system('hostname');
if ~isempty(strfind(hname, 'midway'))    % Are we on the UofC clusters
    matlabpool('close'); 
    exit
else
   poolobj = gcp('nocreate');
   delete(poolobj);
end

%% Close debug file, if it exists
 if isfield(m, 'debugFID')
     fclose(m.debugFID);
 end
 
 % exit matlab for clusters
if isunix
    exit
end
