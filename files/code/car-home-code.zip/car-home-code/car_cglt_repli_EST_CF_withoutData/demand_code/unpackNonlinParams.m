function [ Sigma, Pi, alphaBar, PiAlpha, sigAlpha ] = unpackNonlinParams(parvec, m )
%This function just takes the non-linear parameter vector and returns the
%two matrices which govern the nonlinear deviations, it is essentially a
%sparse to full, except that the "active" (non-zero) coeffficients for the
%model are stored within m. 

lenSig = size(m.SigmaEntries,1);
locPi = lenSig+1;
lenPi  = size(m.PiEntries, 1);
if (m.lognormprice)
    locAlphaBar = lenSig+lenPi+1;
    locPiAlpha = locAlphaBar + 1;
    lenPiAlpha = length(m.AlphaPiEntries);
    locSigAlpha = locAlphaBar + lenPiAlpha + 1;
    assert(locSigAlpha == length(parvec));
else
    assert(lenSig + lenPi == length(parvec));
end

Sigma = full( sparse(m.SigmaEntries(:,1), m.SigmaEntries(:,2), parvec(1:lenSig), ... The assignment
              size(m.rcX,2), size(m.rcX,2) ) ); %Get the dimenisons right.

if isempty(m.PiEntries)
    Pi = zeros(size(m.rcX,2), m.nDemogDims);
else
    Pi    = full( sparse(m.PiEntries(:,1), m.PiEntries(:,2), parvec(locPi:locPi+lenPi-1) , ...
              size(m.rcX,2), m.nDemogDims ) );
end

if m.lognormprice
    %Now set the parameters of the distribution of alpha_i: 
    %Lognormal(alphaBar + AlphaPi*D, sigAlpha)
    alphaBar = parvec(locAlphaBar);
    PiAlpha = zeros(1,m.nDemogDims);
    foo  = parvec(locPiAlpha:locPiAlpha+lenPiAlpha - 1);
    for c = 1:lenPiAlpha
       PiAlpha(m.AlphaPiEntries(c)) = foo(c); 
    end
    sigAlpha = parvec(locSigAlpha); 
else
    alphaBar = [];
    PiAlpha = [];
    sigAlpha = [];
end

end

