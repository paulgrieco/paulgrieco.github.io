% This is the jacobian for the dummy objective function when we are solving
% the share equations.

function [c, Diff_share, dc, full_Jac] = shareConstraintsParallel_dumObj(delta, mu,m)

[share, share_ij] = getShare(delta, mu, m);

[c, Diff_share, dc, full_Jac] = shareConstraintsParallel_base(share, share_ij, m);
 
end



