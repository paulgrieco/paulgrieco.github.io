function [ beta_hat uhat W_opt] = recoverBeta(mpec_x, W, m, bweights )
% This funciton takes a structure m and estimates a logit estimation using
% its linear parameters. We do a 2-stage linear GMM. 
   
 
   %Unpack data so we don't need to use long names.  Note that the
   %structure should be set up so that 
   %    - linX contains endogenous and exogeneous regresors
   %    - IV  contains the exogenous regressors plus the instruments 
   X = m.linX;
   Z = m.IV;
   N = m.nObs;
   
   [foo1, foo2, delta] = unpackMpecX(mpec_x,m);

   if nargin==3 
   %% Unweighted case:
       %First stage estimator..
       invIV = eye(size(X,2))/(X'*Z*W*Z'*X) ;
       beta_hat = invIV*X'*Z*W*Z'*delta;
       uhat = delta - X*beta_hat;

       %This is the optimal weight matrix assuming that mpec_x contains a
       %consistent estimator...   
       % by definition, it should be: m.nObs * pinv(Z'*diag(uhat.^2)*Z);
       % it is ignore here since it is just about scale and it will not affect
       % the estimation.
       % However, when we compute standard errors of estimate, it involve W_opt and thus the scale matters. Since
       % W_opt is computed in this way, we need to recover its scale by multipling by m.nObs
       % when we compute standard errors.

       %Because some models are only availble in one market, the "standard"
       %weight matrix would be singular (u for these models is zero, and that
       %particular instrument row/column will be all zeros. We don't want to
       %just drop the instrument since we need it in the linear portion of BLP
       %and we don't want to drop the model because it's part of the market
       %equilibrium, instead we add 1/m.nObs, to the diagonal of the variance
       %estimate.  This addition is asymptotically negligible but keeps the
       %weight matrix invertible. 
       S = Z'*diag(uhat.^2)*Z + (1/m.nObs)*eye(size(W)); 
       W_opt = inv(S);
   
   else 
   %% Weighted Case, see comments above, otherwise just adds weights.
      assert(nargin==4, 'recoverBeta: incorrect number of arguments');
      B = sparse(diag(bweights));
      invIV = eye(size(X,2))/(X'*B*Z*W*Z'*B*X) ;
      beta_hat = invIV*X'*B*Z*W*Z'*B*delta;
      uhat = delta - X*beta_hat;
      S = Z'*B*diag(uhat.^2)*B*Z + (1/m.nObs)*eye(size(W)); 
      W_opt = inv(S);
   end
   
end

