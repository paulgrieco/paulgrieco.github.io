This is the Readme file to briefly describe the Matlab code for the estimation and counterfactual analysis of 
"What Drives Home Market Advantage?", by Kerem Cosar, Paul Grieco, Shengyu Li, and Felix Tintelnot, 2018, 
Journal of International Economics.

The master file in the folder "master" handles all the estimation and counterfactuals. One can run this file directly 
to replicate the tables in the published paper (given the data is supplied to the code). The detailed explanation of 
the code is explained as follows:

The estimation is divided into two parts: the demand estimation and supply (cost) estimation, in demand_code and 
cost_code respectively. 

In the demand estimation, the GMM estimation is conducted in two stages. In each stage, 
the code is written in a way to allow for different initial guesses of the estimate. This was what was actually carried out
in the estimation for the pulished paper. However, to save computational time for the replication, the code is set to use 
single starting guess. In particular, firstStageMulti.m and collectFirstMulti.m conduct the first stage GMM estimation 
and collection of the estimate respectively. Similarly, secondStageMulti.m and collectSecMulti.m conduct the second
stage GMM estimation and collection of the estimate respectively. Finally, while the estimation in the pulished paper used
weightedEstimation.m and collectBoot.m to conduct bootstrapping and collect the result, the current code ignore this step 
in order to speed up the replication process. (Note that the code for the bootstrapping is still contained in this folder.)

In the cost estimation, the main code is costEstimation.m. It estimates the supply side of the model and produces the cost
estimate for each model in the data.

Finally, the code for the counterfactual analysis is contained in folder post_estimation. The main code is run_postestimation. 
This code conducts all the counterfactuals and product the main counterfactual tables in the published paper.  