% This master file does the estimation and produces the main tables of the
% paper.

clc
clear
%% add the demand and cost code folders as the search path so that we do not need to keep duplicated copies of code such as getMu.m
path_name = ['..' filesep 'demand_code' ];
addpath(genpath(path_name))
path_name = ['..' filesep 'cost_code' ];
addpath(genpath(path_name))
path_name = ['..' filesep 'post_estimation' ];
addpath(genpath(path_name))
path_name = ['..' filesep 'input_files' ];
addpath(genpath(path_name))
path_name = ['..' filesep 'demand_output' ];
addpath(genpath(path_name))
path_name = ['..' filesep 'cost_output' ];
addpath(genpath(path_name))

% Step 1: demand estimation -- stage 1 GMM 
fprintf('Demand estimation: stage 1 GMM ... \n')
firstStageMulti
collectFirstMulti

% Step 2: demand estimation -- stage 2 GMM 
fprintf('Demand estimation: stage 2 GMM ... \n')
secondStageMulti
collectSecMulti

% Step 3: produce demand tables
report_standardized_demand_coeff = 0;
boot_ind = 0;
printTables_Demand(mainout, boot_ind, report_standardized_demand_coeff) 

% Step 4: cost estimation
costEstimation 

% Post estimation -- counterfactuals and tables
run_postestimation 
