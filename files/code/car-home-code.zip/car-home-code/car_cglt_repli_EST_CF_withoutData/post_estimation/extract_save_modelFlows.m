% revenue_flow = 1 means revenue flow    
function extract_save_modelFlows(tariff_baseline,dummy_baseline,fxrate_baseline,sealand_baseline,geo_baseline, revenue_flow)

myfilename = sprintf('cost_result_spec_dummies%d_tariff%d_fxrate%d_sealand%d_geo%d',dummy_baseline,tariff_baseline,fxrate_baseline,sealand_baseline,geo_baseline);
%load(myfilename);   
load(['..' filesep 'cost_output' filesep myfilename]);

if revenue_flow == 1
    flows_temp     = est_results_cost_side.revenue_flows_assembly_market_baseline;
else
    flows_temp     = est_results_cost_side.quantity_flows_assembly_market_baseline;
end

countryDummies = est_results_cost_side.m.countryDummies;

% re-generate dropped USA dummy
changedIndexes = diff(est_results_cost_side.m.countryDummies(:,8))~=0; % important that we are dropping country dummy in the 9th column in cost estimation, this is US. We need that code again to aggregate trade flows between markets and sources
index = max(find(changedIndexes==1));
countryDummies = [countryDummies zeros(size(countryDummies,1),1)];
countryDummies(index+1:size(countryDummies,1),9) = 1;

% total flows: multiply model-level (9-by-N matrix of country dummies with 
% (N-by-numasslocs) matrix of flows to find the country-source (9-by-numasslocs) matrix of flows
flows_model = countryDummies'*flows_temp; % this is aggregated flow over year

% Country names 
load costdata
cty        = unique(cty,'stable'); % this ensure that we don't get the alphabetical ordering BEL,BRA.. but rather preserve the ordering in the data as BRA,BEL.. important for matching with the ordering in the flows matrix

iso = {};
for i=1:est_results_cost_side.m.numassloc
    iso{i} = sprintf('iso%d',i);
end

%% Save the data to model_implied_flows.xlsx which will be read into Stata
filename = sprintf('model_implied_flows_dum%d_tar%d_fxr%d_sealand%d_geo%d_by_year',dummy_baseline,tariff_baseline,fxrate_baseline,sealand_baseline,geo_baseline);
sheet = 1;
varname{1} = 'cty';
xlRange = 'A1';
xlswrite(['..' filesep 'cost_output' filesep filename],varname,sheet,xlRange)
xlRange = 'A2';
xlswrite(['..' filesep 'cost_output' filesep filename],cty,sheet,xlRange)
xlRange = 'B1';
xlswrite(['..' filesep 'cost_output' filesep filename],iso,sheet,xlRange)
xlRange = 'B2';
%xlswrite(filename,flows_model,sheet,xlRange)
xlswrite(['..' filesep 'cost_output' filesep filename],flows_model,sheet,xlRange)

% compute flows year by year
for yr = 1:(max(myyear)-min(myyear)+1)
    yr_mat = repmat(myyear==(min(myyear)+yr-1),1,size(countryDummies,2)); %     min(year)+yr-1 is the year considered 
    flows_model_yr{yr} = (yr_mat.*countryDummies)'*flows_temp;
    % begin to write:
    sheet = yr+1; % starting from sheet 2
    varname{1} = {min(myyear)+yr-1};
    xlRange = 'A1';
    xlswrite(['..' filesep 'cost_output' filesep filename],varname,sheet,xlRange)
    xlRange = 'A2';
    xlswrite(['..' filesep 'cost_output' filesep filename],cty,sheet,xlRange)
    xlRange = 'B1';
    xlswrite(['..' filesep 'cost_output' filesep filename],iso,sheet,xlRange)
    xlRange = 'B2';
    xlswrite(['..' filesep 'cost_output' filesep filename],flows_model_yr{yr},sheet,xlRange)
 end

end