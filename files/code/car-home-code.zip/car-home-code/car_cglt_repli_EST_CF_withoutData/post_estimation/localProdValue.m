
% CF_name is the counterfactual name, such as 'NoHomeAsmP homog'
function [profit_total_change, quantity_total_change, price_weighted_change] = localProdValue(counterRes, m, c2str, CF_name,dummy_baseline,tariff_baseline,fxrate_baseline,sealand_baseline,geo_baseline)
%% Value of local production: Eliminate Local Production Preference, present a Brand x Country table that shows the impact on variable profits. 
    % Second, calculate the profit/share/markup changes for the brand of
    % interest.
    for i = 1: length(counterRes) % now find the index for this counterfactual
        if strcmp(counterRes(i).name, CF_name)
            noAsmCF_idx = i;
        end
    end

    profit_baseline_total = [];
    profit_noAsmCF_total = [];
    profit_total_change = [];
    
    mkt_size = m.sales./m.share;
    profit_baseline = (counterRes(1).price - counterRes(1).cost).*counterRes(1).share .* mkt_size;
    profit_noAsmCF = (counterRes(noAsmCF_idx).price - counterRes(noAsmCF_idx).cost).*counterRes(noAsmCF_idx).share .* mkt_size;
    
    
    quantity_baseline = counterRes(1).share .* mkt_size;
    quantity_noAsmCF  = counterRes(noAsmCF_idx).share .* mkt_size;
    
for c = 1:m.nCtys
    for b = 1:m.nBrands
    this_ind = (m.ctyCode == c) & (m.brandCode == b);
     
    % for profit:
    profit_baseline_total(b,c) = sum( profit_baseline(this_ind))  ./ length(unique(m.mktCode(this_ind)));
    profit_noAsmCF_total(b,c) = sum( profit_noAsmCF(this_ind))  ./ length(unique(m.mktCode(this_ind)));
    profit_total_change(b,c) = (profit_noAsmCF_total(b,c) - profit_baseline_total(b,c))/profit_baseline_total(b,c);
    
    % for quantity:
    quantity_baseline_total(b,c) = sum( quantity_baseline(this_ind))  ./ length(unique(m.mktCode(this_ind)));
    quantity_noAsmCF_total(b,c) = sum( quantity_noAsmCF(this_ind))  ./ length(unique(m.mktCode(this_ind)));
    quantity_total_change(b,c) = (quantity_noAsmCF_total(b,c) - quantity_baseline_total(b,c))/quantity_baseline_total(b,c);
    
    % for price:
    price_baseline_weighted(b,c) = sum( counterRes(1).price(this_ind) .*(m.sales(this_ind)./sum(m.sales(this_ind))) ) ;
    price_noAsmCF_weighted(b,c) = sum( counterRes(noAsmCF_idx).price(this_ind) .*(m.sales(this_ind)./sum(m.sales(this_ind))) );
    price_weighted_change(b,c) = (price_noAsmCF_weighted(b,c) - price_baseline_weighted(b,c))/price_baseline_weighted(b,c);
    
    end
end

% myfilename = sprintf('results_local_production_value_dum%d_tar%d_fx%d_sealand%d_geo_%d_%s',dummy_baseline,tariff_baseline,fxrate_baseline,sealand_baseline,geo_baseline, CF_name);
% myfilename = ['..' filesep 'cost_output' filesep myfilename];
% 
% sheet = 1;
% xlRange = 'A1';
% xlswrite(myfilename,{'Profit Change (x100 to get %)'},sheet,xlRange)
% xlRange = 'B2';
% xlswrite(myfilename,c2str.Ctys',sheet,xlRange)
% xlRange = 'A3';
% xlswrite(myfilename,c2str.Brands,sheet,xlRange)
% xlRange = 'B3';
% xlswrite(myfilename,profit_total_change,sheet,xlRange)
% 
% sheet = 2;
% xlRange = 'A1';
% xlswrite(myfilename,{'Quantity Change (x100 to get %)'},sheet,xlRange)
% xlRange = 'B2';
% xlswrite(myfilename,c2str.Ctys',sheet,xlRange)
% xlRange = 'A3';
% xlswrite(myfilename,c2str.Brands,sheet,xlRange)
% xlRange = 'B3';
% xlswrite(myfilename,quantity_total_change,sheet,xlRange)
% 
% sheet = 3;
% xlRange = 'A1';
% xlswrite(myfilename,{'Price Change (x100 to get %)'},sheet,xlRange)
% xlRange = 'B2';
% xlswrite(myfilename,c2str.Ctys',sheet,xlRange)
% xlRange = 'A3';
% xlswrite(myfilename,c2str.Brands,sheet,xlRange)
% xlRange = 'B3';
% xlswrite(myfilename,price_weighted_change,sheet,xlRange)

% %% change name of the sheet
% e = actxserver('Excel.Application'); % # open Activex server
% ewb = e.Workbooks.Open('...'); % # open file (enter full path!)
% ewb.Worksheets.Item(1).Name = CF_name; % # rename 1st sheet
% ewb.Save % # save to the same file
% ewb.Close(false)
% e.Quit
