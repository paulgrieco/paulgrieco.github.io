% This function replace the chars of the demand and cost side by the
% counterfactual ones in the loaded file.
% Very important note: this function is hard-written, two things need
% change if other specification are implemented:
% a) The way to construct bigX for the demand side;
% b) NoLocalAdaptation.mat should be generated again from csv file.

function [newdemandM, newcostM] = newM(demandM, costM)
%Note: for futher reference, we construct demand m in setupstruct in the
%demand code, and cost m in main_costall_log (see line 56 for linX for the cost side)

% This is how we load data from csv file
% hppwt = hppwt(2:end);
% sz= sz(2:end);
% mpDcty= mpDcty(2:end);
% price = price(2:end);
% wt = wt(2:end);
% mpgcty = mpgcty(2:end);
% hp = hp(2:end);

load('NoLocalAdaptation_home.mat') % NOTE: this needs to be manually updated if a new data set is supplied!!!
assert(sum(demandM.p ~= price/10000) <=10 )

newdemandM = demandM;
newcostM = costM;

% replace the demand side:
hpszwtmpg = bsxfun(@rdivide, [hppwt sz mpDcty], [0.0787374838483307,  8013343.22037351,  4.63355079173740]); % note we must use the original data mean

interX = [hpszwtmpg, hpszwtmpg.^2]; 

ctyInteract = dummyvar(demandM.ctyCode); % so we use a full set of country dummies

bigX = [];

    for v = 1:size(interX,2)
           bigX = [bigX bsxfun(@times, interX(:,v),ctyInteract) ];
    end

 newdemandM.linX(: ,1:size(bigX,2)) = bigX; % the first part is bigX
 
 % replace the cost side:
 newcostM.linX(: , end-3 : end) = [log(sz) , log(wt), log(hp) , log(mpgcty)]; % the final four columns are the chars
 
 
 