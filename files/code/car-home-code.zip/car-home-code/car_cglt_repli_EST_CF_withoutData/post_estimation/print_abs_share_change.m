% absolute market share changes (compared with the basline) by brand nationality (detailed breakdown)

function  print_abs_share_change(counterRes,m,c2str,dummy_baseline,tariff_baseline,fxrate_baseline,sealand_baseline, geo_baseline)
%% construct the detailed breakdown of brand nationality
[m.brandcty] = detailed_brandcty(m, c2str);

%% calculate market shares
for i=1:size(counterRes,2)
    [labels,shares(:,i)] = grpstats(counterRes(i).share,{m.ctyCode,m.brandcty},{'gname','sum'});
    %[~,markups(:,i)] = grpstats(counterRes(i).share.*(counterRes(i).price-counterRes(i).cost)./counterRes(i).cost,{m.ctyCode,m.brandcty},{'gname','sum'});
    %[~,markups_denominator(:,i)] = grpstats(counterRes(i).share,{m.ctyCode,m.brandcty},{'gname','sum'});    % sum of shares in each group
end
%markups = markups./markups_denominator; % divide by the sum of shares in each group to get the "weighted" markups

for i=1:size(counterRes,2)
    [homelabels,homeshares(:,i)] = grpstats(counterRes(i).share,{m.ctyCode,m.homedummy},{'gname','sum'});
   % [~,homemarkups(:,i)] = grpstats(counterRes(i).share.*(counterRes(i).price-counterRes(i).cost)./counterRes(i).cost,{m.ctyCode,m.homedummy},{'gname','sum'});
  %  [~,homemarkups_denominator(:,i)] = grpstats(counterRes(i).share,{m.ctyCode,m.homedummy},{'gname','sum'});    
end
%homemarkups = homemarkups./homemarkups_denominator;

% additional category: high or low efficiency cars
% construct high (or low) efficiency car labels
mpd_temp = sum(m.linX(:,19:27),2); % this is the normalized mpd for all models
higheff = zeros(size(m.homedummy));
for i = 1:m.nMkts
    mkt_ind = (m.mktCode == i);
    mpd_mkt = mpd_temp(mkt_ind);
    
    % % use median
    %mpd_med = median(mpd_mkt); 
    
    % % use weighted median
%     mpd_med = sum(mpd_mkt .* (m.share(mkt_ind)./(1-m.outshare(mkt_ind))));

% % use median ranked by market share
%     share_mkt = m.share(mkt_ind);
%     [~, idx] = sort(share_mkt);
%     mpd_med = mpd_mkt(idx(floor((length(idx)+1)/2)));

% use this cutoff: rank mpd_mkt from low to high, calculate the cumulative
% market share accordingly, then take the one with the cumulative share
% goes over 0.5 (exclusive).
    share_mkt = m.share(mkt_ind);
    outshare_mkt = unique(m.outshare(mkt_ind));
    [mpd_mkt_sorted, idx] = sort(mpd_mkt);
    share_mkt_sorted = share_mkt(idx);
    share_mkt_sorted_cum = cumsum(share_mkt_sorted);
    mpd_mkt_high = mpd_mkt_sorted(share_mkt_sorted_cum/(1-outshare_mkt)>=.5);
    mpd_med = mpd_mkt_high(1);

    higheff_mkt = (mpd_mkt>mpd_med);
    higheff(mkt_ind) = higheff_mkt; 
end

for i=1:size(counterRes,2)
    [highefflabels,higheffshares(:,i)] = grpstats(counterRes(i).share,{m.ctyCode,higheff},{'gname','sum'});
end

%clearvars -except labels shares markups counterRes m homeshares homelabels homemarkups dummy_baseline tariff_baseline fxrate_baseline

% in country codes:
% cty	ctyCode
% BEL	2
% BRA	1
% CAN	3
% DEU	4
% ESP	5
% FRA	6
% GBR	7
% ITA	8
% USA	9

for i=1:size(shares,1)
    if labels{i,1}~=1 || labels{i,1}~=3
        shares(i,:) = shares(i,:)/5;
        %markups(i,:) = markups(i,:)/1; % now we do not need to divide by 5 or something since we have done this correctly in the above
    elseif labels{i,1}==1  % brazil has 4 years of data
        shares(i,:) = shares(i,:)/4 ;
        %markups(i,:) = markups(i,:)/1 ;
    elseif labels{i,1}==3  % canada has 2 years of data
        shares(i,:) = shares(i,:)/2;
        %markups(i,:) = markups(i,:)/1;
    end
end

for i=1:size(homeshares,1)
    if homelabels{i,1}~=1 || homelabels{i,1}~=3
        homeshares(i,:) = homeshares(i,:)/5;
        %homemarkups(i,:) = homemarkups(i,:)/1;
    elseif labels{i,1}==1  % brazil has 4 years of data
        homeshares(i,:) = homeshares(i,:)/4 ;
        %homemarkups(i,:) = homemarkups(i,:)/1;
    elseif labels{i,1}==3  % canada has 2 years of data
        homeshares(i,:) = homeshares(i,:)/2;
        %homemarkups(i,:) = homemarkups(i,:)/1;
    end
end

for i=1:size(higheffshares,1)
    if highefflabels{i,1}~=1 || highefflabels{i,1}~=3
        higheffshares(i,:) = higheffshares(i,:)/5;
    elseif highefflabels{i,1}==1  % brazil has 4 years of data
        higheffshares(i,:) = higheffshares(i,:)/4 ;
    elseif highefflabels{i,1}==3  % canada has 2 years of data
        higheffshares(i,:) = higheffshares(i,:)/2;
    end
end

% collect shares in a matrix with columns showing markets, and rows scenarios
USAshares   = zeros(size(shares,2),m.nCtys);
%EU_othershares    = zeros(size(shares,2),m.nCtys);
JPNshares   = zeros(size(shares,2),m.nCtys);
OTHERshares = zeros(size(shares,2),m.nCtys);
HOMEshares = zeros(size(shares,2),m.nCtys);
FRAshares = zeros(size(shares,2),m.nCtys);
DEUshares = zeros(size(shares,2),m.nCtys);
% ITAshares = zeros(size(shares,2),m.nCtys);
% ESPshares = zeros(size(shares,2),m.nCtys);
HIGHEFFshares = zeros(size(shares,2),m.nCtys);

for ctycode = 1:m.nCtys
    for i=1:size(shares,1)
        if str2double(labels{i,1}) == ctycode
            if strcmp(labels{i,2},'USA')
                USAshares(:,ctycode) = shares(i,:)';
                %USAmarkups(:,ctycode) = markups(i,:)';
            %elseif strcmp(labels{i,2},'EU_other')
               % EU_othershares(:,ctycode)  = shares(i,:)';
                %EUmarkups(:,ctycode) = markups(i,:)';
            elseif strcmp(labels{i,2},'JAP')
                JPNshares(:,ctycode)  = shares(i,:)';
                %JPNmarkups(:,ctycode) = markups(i,:)';
            elseif strcmp(labels{i,2},'OTHER')
                OTHERshares(:,ctycode)  = shares(i,:)';
                %OTHERmarkups(:,ctycode) = markups(i,:)';
           elseif strcmp(labels{i,2},'FRA')
                FRAshares(:,ctycode)  = shares(i,:)';
                %  
           elseif strcmp(labels{i,2},'DEU')
                DEUshares(:,ctycode)  = shares(i,:)';
                %    
%           elseif strcmp(labels{i,2},'ITA')
%                 ITAshares(:,ctycode)  = shares(i,:)';
%                 %  
%            elseif strcmp(labels{i,2},'ESP')
%                 ESPshares(:,ctycode)  = shares(i,:)';
                %      
            end
        end
    end
end

for ctycode = 1:m.nCtys
    for i=1:size(homeshares,1)
        if str2double(homelabels{i,1}) == ctycode
            if strcmp(homelabels{i,2},'1')
                HOMEshares(:,ctycode) = homeshares(i,:)';
               % HOMEmarkups(:,ctycode) = homemarkups(i,:)';
            end
        end
    end
end

for ctycode = 1:m.nCtys
    for i=1:size(higheffshares,1)
        if str2double(highefflabels{i,1}) == ctycode
            if strcmp(highefflabels{i,2},'1')
                HIGHEFFshares(:,ctycode) = higheffshares(i,:)';
            end
        end
    end
end

USAsharestemp   = zeros(size(shares,2),m.nCtys);
%EU_othersharestemp    = zeros(size(shares,2),m.nCtys);
JPNsharestemp   = zeros(size(shares,2),m.nCtys);
OTHERsharestemp = zeros(size(shares,2),m.nCtys);
HOMEsharestemp = zeros(size(shares,2),m.nCtys);
FRAsharestemp = zeros(size(shares,2),m.nCtys);
DEUsharestemp = zeros(size(shares,2),m.nCtys);
% ITAsharestemp = zeros(size(shares,2),m.nCtys);
% ESPsharestemp = zeros(size(shares,2),m.nCtys);
HIGHEFFsharestemp = zeros(size(shares,2),m.nCtys);
% USAmarkupstemp   = zeros(size(shares,2),m.nCtys);
% EUmarkupstemp    = zeros(size(shares,2),m.nCtys);
% JPNmarkupstemp   = zeros(size(shares,2),m.nCtys);
% OTHERmarkupstemp = zeros(size(shares,2),m.nCtys);
% HOMEmarkupstemp = zeros(size(shares,2),m.nCtys);

for i = 1:size(USAshares,1)
    for j=1:size(USAshares,2)
        %EU_othersharestemp(i,j)    = EU_othershares(i,j)/(EU_othershares(i,j)+JPNshares(i,j)+OTHERshares(i,j)+USAshares(i,j)+FRAshares(i,j)+DEUshares(i,j));
        %EUmarkupstemp(i,j)    = 100*EUmarkups(i,j);% /(EUshares(i,j)+JPNshares(i,j)+OTHERshares(i,j)+USAshares(i,j)); % we have taken care of this in the above by using the denominator
        JPNsharestemp(i,j)   = JPNshares(i,j)/(JPNshares(i,j)+OTHERshares(i,j)+USAshares(i,j)+FRAshares(i,j)+DEUshares(i,j) );  
        %JPNmarkupstemp(i,j)   = 100*JPNmarkups(i,j);% /(EUshares(i,j)+JPNshares(i,j)+OTHERshares(i,j)+USAshares(i,j));
        OTHERsharestemp(i,j) = OTHERshares(i,j)/(JPNshares(i,j)+OTHERshares(i,j)+USAshares(i,j)+FRAshares(i,j)+DEUshares(i,j) );  
        %OTHERmarkupstemp(i,j) = 100*OTHERmarkups(i,j);% /(EUshares(i,j)+JPNshares(i,j)+OTHERshares(i,j)+USAshares(i,j)) ;
        USAsharestemp(i,j)   = USAshares(i,j)/(JPNshares(i,j)+OTHERshares(i,j)+USAshares(i,j)+FRAshares(i,j)+DEUshares(i,j) );  
        %USAmarkupstemp(i,j)   = 100*USAmarkups(i,j);% /(EUshares(i,j)+JPNshares(i,j)+OTHERshares(i,j)+USAshares(i,j));
        HOMEsharestemp(i,j)  = HOMEshares(i,j)/(JPNshares(i,j)+OTHERshares(i,j)+USAshares(i,j)+FRAshares(i,j)+DEUshares(i,j) );  
        %HOMEmarkupstemp(i,j)  = 100*HOMEmarkups(i,j);% /(EUshares(i,j)+JPNshares(i,j)+OTHERshares(i,j)+USAshares(i,j));
        FRAsharestemp(i,j)   = FRAshares(i,j)/(JPNshares(i,j)+OTHERshares(i,j)+USAshares(i,j)+FRAshares(i,j)+DEUshares(i,j) );  
        %USAmarkupstemp(i,j)   = 100*USAmarkups(i,j);% /(EUshares(i,j)+JPNshares(i,j)+OTHERshares(i,j)+USAshares(i,j));
        DEUsharestemp(i,j)  = DEUshares(i,j)/(JPNshares(i,j)+OTHERshares(i,j)+USAshares(i,j)+FRAshares(i,j)+DEUshares(i,j) );  
        %HOMEmarkupstemp(i,j)  = 100*HOMEmarkups(i,j);% /(EUshares(i,j)+JPNshares(i,j)+OTHERshares(i,j)+USAshares(i,j));
%         ITAsharestemp(i,j)  = ITAshares(i,j)/(JPNshares(i,j)+OTHERshares(i,j)+USAshares(i,j)+FRAshares(i,j)+DEUshares(i,j) + ITAshares(i,j)+ESPshares(i,j));  
%         ESPsharestemp(i,j)  = ESPshares(i,j)/(JPNshares(i,j)+OTHERshares(i,j)+USAshares(i,j)+FRAshares(i,j)+DEUshares(i,j) + ITAshares(i,j)+ESPshares(i,j));  
%         %HIGHEFFsharestemp(i,j)  = HIGHEFFshares(i,j)/(JPNshares(i,j)+OTHERshares(i,j)+USAshares(i,j)+FRAshares(i,j)+DEUshares(i,j) + ITAshares(i,j)+ESPshares(i,j));  
        HIGHEFFsharestemp(i,j)  = HIGHEFFshares(i,j)/(JPNshares(i,j)+OTHERshares(i,j)+USAshares(i,j)+FRAshares(i,j)+DEUshares(i,j) ); 
    end
end

%EU_othershares    =EU_othersharestemp;
JPNshares   =JPNsharestemp;
OTHERshares =OTHERsharestemp;
USAshares   =USAsharestemp;
HOMEshares  =HOMEsharestemp;
FRAshares   =FRAsharestemp;
DEUshares  =DEUsharestemp;
% ITAshares   =ITAsharestemp;
% ESPshares  =ESPsharestemp;
HIGHEFFshares  =HIGHEFFsharestemp;
% EUmarkups    =EUmarkupstemp;
% JPNmarkups   =JPNmarkupstemp;
% OTHERmarkups =OTHERmarkupstemp;
% USAmarkups   =USAmarkupstemp;
% HOMEmarkups  =HOMEmarkupstemp;

%clear EUsharestemp JPNsharestemp HOMEsharestemp OTHERsharestemp USAsharestemp homeshares i j ctycode m shares homelabels EUmarkupstemp JPNmarkupstemp OTHERmarkupstemp USAmarkupstemp HOMEmarkupstemp

% shares table
myfilename  = sprintf('results_appendixTable_marketshares_detailedbreakdown_dum%d_tar%d_fx%d_sealand%d_geo_%d.txt',dummy_baseline,tariff_baseline,fxrate_baseline,sealand_baseline, geo_baseline);
fid = fopen(['..' filesep 'cost_output' filesep myfilename],'wt');
 % First print the head ...     
fprintf(fid, '\\begin{table}[t] \n'); 
fprintf(fid, '\\begin{center} \n');
fprintf(fid, '\\caption{Absolute change of average area-level market share of brands across markets (in percentage)} \n');
fprintf(fid, '\\begin{tabular}{@{}l|ccccccccc} \n'); % scenario, empty column, coefficient
fprintf(fid, '\\hline \n');
fprintf(fid, '\\hline \n');
for i = 1:size(counterRes,2)
    fprintf(fid, '%s & %s & %s & %s & %s & %s & %s & %s & %s & %s  \\\\ \n', counterRes(i).name , 'BRA', 'BEL', 'CAN', 'DEU', 'ESP', 'FRA', 'GBR', 'ITA', 'USA' );
    fprintf(fid, '%s & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f  \\\\ \n', 'US brands',  100*USAshares(i,:) - 100*USAshares(1,:));    
    fprintf(fid, '%s & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f   \\\\ \n', 'FRA brands',  100*FRAshares(i,:) - 100*FRAshares(1,:) );
    fprintf(fid, '%s & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f   \\\\ \n', 'DEU brands',  100*DEUshares(i,:) - 100*DEUshares(1,:));
    %fprintf(fid, '%s & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f  \\\\ \n', 'ITA brands',  ITAshares(i,:) - ITAshares(1,:) );
    %fprintf(fid, '%s & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f  \\\\ \n', 'ESP brands',  ESPshares(i,:) - ESPshares(1,:));
    %fprintf(fid, '%s & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f  \\\\ \n', 'EU_other brands',  EU_othershares(i,:) - EU_othershares(1,:) );
    fprintf(fid, '%s & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f   \\\\ \n', 'JPN brands',  100*JPNshares(i,:) - 100*JPNshares(1,:));
    fprintf(fid, '%s & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f   \\\\ \n', 'Other brands',  100*OTHERshares(i,:) - 100*OTHERshares(1,:) );
    fprintf(fid, '%s & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f   \\\\ \n', 'Home brands',  100*HOMEshares(i,:) - 100*HOMEshares(1,:));
    fprintf(fid, '%s & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f   \\\\ \n', 'High Efficiency cars',  100*HIGHEFFshares(i,:) - 100*HIGHEFFshares(1,:));
%     fprintf(fid, '\\hline \n');
%     fprintf(fid, '%s & %s & %s & %s & %s & %s & %s & %s & %s & %s  \\\\ \n', counterRes(i).name , 'BRA', 'BEL', 'CAN', 'DEU', 'ESP', 'FRA', 'GBR', 'ITA', 'USA' );
%     fprintf(fid, '%s & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f  \\\\ \n', 'US brands',  USAshares(i,:) );    
%     fprintf(fid, '%s & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f  \\\\ \n', 'FRA brands',  FRAshares(i,:)   );
%     fprintf(fid, '%s & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f  \\\\ \n', 'DEU brands',  DEUshares(i,:) );
%     fprintf(fid, '%s & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f  \\\\ \n', 'JPN brands',  JPNshares(i,:)  );
%     fprintf(fid, '%s & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f  \\\\ \n', 'Other brands',  OTHERshares(i,:)   );
%     fprintf(fid, '%s & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f  \\\\ \n', 'Home brands',  HOMEshares(i,:)  );
%     fprintf(fid, '%s & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f  \\\\ \n', 'High Efficiency cars',  HIGHEFFshares(i,:)  );

    fprintf(fid, '\\hline \n');
end
fprintf(fid, '\\hline \n');
fprintf(fid, '\\end{tabular} \n');
fprintf(fid, '\\end{center} \n');
fprintf(fid, '\\end{table} \n');
fclose(fid);

% % markup table
% myfilename = sprintf('results_appendixTable_markups_dum%d_tar%d_fx%d.txt',dummy_baseline,tariff_baseline,fxrate_baseline);
% fid = fopen(['..' filesep 'cost_output' filesep myfilename], 'wt');
%  % First print the head ...     
% fprintf(fid, '\\begin{table}[t] \n'); 
% fprintf(fid, '\\begin{center} \n');
% fprintf(fid, '\\caption{Weighted average area-level markup (percent)} \n');
% fprintf(fid, '\\begin{tabular}{@{}l|ccccccccc} \n'); % scenario, empty column, coefficient
% fprintf(fid, '\\hline \n');
% fprintf(fid, '\\hline \n');
% for i = 1:size(counterRes,2)
%     fprintf(fid, '%s & %s & %s & %s & %s & %s & %s & %s & %s & %s  \\\\ \n', counterRes(i).name , 'BRA', 'BEL', 'CAN', 'DEU', 'ESP', 'FRA', 'GBR', 'ITA', 'USA' );
%     fprintf(fid, '%s & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f  \\\\ \n', 'US brands',  USAmarkups(i,:) );    
%     fprintf(fid, '%s & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f  \\\\ \n', 'EU brands',  EUmarkups(i,:) );
%     fprintf(fid, '%s & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f  \\\\ \n', 'JPN brands',  JPNmarkups(i,:) );
%     fprintf(fid, '%s & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f  \\\\ \n', 'Other brands',  OTHERmarkups(i,:) );
%     fprintf(fid, '%s & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f  \\\\ \n', 'Home brands',  HOMEmarkups(i,:) );
%     fprintf(fid, '\\hline \n');
% end
% fprintf(fid, '\\hline \n');
% fprintf(fid, '\\end{tabular} \n');
% fprintf(fid, '\\end{center} \n');
% fprintf(fid, '\\end{table} \n');
% fclose(fid);

% home-share-only table
myfilename  = sprintf('results_appendixTable_homeshares_detailedbreakdown_dum%d_tar%d_fx%d_sealand%d_geo_%d.txt',dummy_baseline,tariff_baseline,fxrate_baseline,sealand_baseline, geo_baseline);
fid = fopen(['..' filesep 'cost_output' filesep myfilename],'wt');
 % First print the head ...     
fprintf(fid, '\\begin{table}[t] \n'); 
fprintf(fid, '\\begin{center} \n');
fprintf(fid, '\\caption{Inclusive home market share of brands across markets (in percentage)} \n');
fprintf(fid, '\\begin{tabular}{@{}l|cccccc} \n'); % scenario, empty column, coefficient
fprintf(fid, '\\hline \n');
fprintf(fid, '\\hline \n');
for i = 1:size(counterRes,2)
    if i == 1
        fprintf(fid, '  %s & %s & %s & %s & %s & %s & %s  \\\\ \n', 'Scenarios' ,'DEU', 'ESP', 'FRA', 'GBR', 'ITA', 'USA' );
    end
    fprintf(fid, '%s &  %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f   \\\\ \n', counterRes(i).name,  100*HOMEshares(i,4:end));
    %fprintf(fid, '\\hline \n');
end
fprintf(fid, '\\hline \n');
fprintf(fid, '\\end{tabular} \n');
fprintf(fid, '\\end{center} \n');
fprintf(fid, '\\end{table} \n');
fclose(fid);


return