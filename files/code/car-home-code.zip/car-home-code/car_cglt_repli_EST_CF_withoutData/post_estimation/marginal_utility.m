% This script produces the marginal utitlity of size, using weighted size
% for median consumers (random coefficient part is zero).
 
% formular: MU = beta1/sz_bar + 2* (beta2/sz_bar)*(sz_normalized);
% sz_normalized is sz/sz_bar;
% divided by unit_adjusted_norm is to make it compariable to the numbers
% reported in the demand table -- they are in the same unit: how much
% utility will change if there is an increase of 1 m2.
path_name = ['..' filesep 'demand_code' ];
addpath(genpath(path_name))

clear
clc

load('..\demand_output\secMultiResult.mat')

%% for hppwt:
hppwt = mainout.m.char_mu_weighted(1,:)' * mainout.m.unit_adjusted_norm(1); % this is unnormalized 
MU_hppwt = mainout.beta_hat(1:9)/mainout.m.unit_adjusted_norm(1); 
disp([hppwt'; MU_hppwt']) 

%% for size:
sz = mainout.m.char_mu_weighted(2,:)' * mainout.m.unit_adjusted_norm(2); % this is unnormalized, sale weighted size in m2
MU_sz = mainout.beta_hat(10:18)/mainout.m.unit_adjusted_norm(2)  + 2*mainout.m.char_mu_weighted(2,:)' .* mainout.beta_hat(28:36)/mainout.m.unit_adjusted_norm(2) ; 
disp([sz'; MU_sz']) 

%% for mpD:
% need to compute the effect of income first: the median income of
% consumers. Note that given we have variation of mean income over time
% within a country, we need to first take the mean over time for each
% country.
for i = 1:mainout.m.nMkts
      log_inc_med = reshape(median(mainout.m.demog_nodes(1,:,i)),1,[]); % this is the median income of the consumer in log in each observation
      inc_med(i) = exp(log_inc_med); % recover median income in level
end

[~, Pi] = unpackNonlinParams(mainout.parnonlin_hat, mainout.m);
Pi_mpD = Pi(Pi~=0);
for cty = 1:mainout.m.nCtys
    ind_cty = (mainout.m.ctyCode==cty);
    mktCode_set = unique(mainout.m.mktCode(ind_cty));
    inc_med = [];
    for i = 1:length(mktCode_set)
        mktCode = mktCode_set(i);
        log_inc_med = median(mainout.m.demog_nodes(1,:,mktCode)); % this is the median income of the consumer in log in each observation
        inc_med(i) = exp(log_inc_med); % recover median income in level
    end
    cty_inc_mean = mean(inc_med);
    cty_inc_mean_log(cty) = log(cty_inc_mean);
    MU_mpD_inc_eff(cty) = Pi_mpD*cty_inc_mean_log(cty)/mainout.m.unit_adjusted_norm(3); % adjust it to the same unit as the linear parameter 
end

% for the linear part (this is the same as the demand estimate)
mpD = mainout.m.char_mu_weighted(3,:)' * mainout.m.unit_adjusted_norm(3); % this is unnormalized 
MU_mpD_lin = mainout.beta_hat(19:27)/mainout.m.unit_adjusted_norm(3); 

% combine the both parts
MU_mpD = MU_mpD_lin + MU_mpD_inc_eff';
disp([mpD'; MU_mpD']) 
