% This is to prepare a new tariff to compute cost due to tariff between USA,   and EU (compare the cost between the original and the one without tariff among these countries)
function newTariff = newTariff(m,n) % m is to provide the basic information, and n is for the tariff (from the cost data) WHY not providing basic information for the cost side??????
% constructing the new tariff
cty_ind = zeros(m.nObs,1);
for c = [2, 4,5,6,7,8,9] % not 1 (BRA) or 3 (Canada)
      cty_ind = cty_ind + (m.ctyCode == c);
end
tariff_free_mkt = (cty_ind>0); % this is to indicate if the market is in USA,  and EU

% assCode_freeTariff =
% [3,4,7,10,11,14,15,16,17,18,23,30,33,34,35,38,39,44]; % This was for the
% old data when we have only 49 assembly locations.
assCode_freeTariff = [3,4,  10,11,14,15,16,17,18,23,30,33,34,35,39,40,45]; % (No Canada,7) This for the new data set when we have 50 locations (SRB, iso=37 is added in the data, but it not taken as EU in this counterfactual)
loc_ind = zeros(size(n.tariff_assembly_market));
for j = assCode_freeTariff
    loc_ind = loc_ind + (n.location_code == j);
end
tariff_free_loc = (loc_ind>0); % this is to indicate if the assembling location is in USA, CAN, and EU
    
tariff_free_across = tariff_free_loc.*repmat(tariff_free_mkt,1,size(n.location_code,2));
newTariff = (1-tariff_free_across).*n.tariff_assembly_market; % set tariff as zero between USA, CAN, and EU

%%%%%%%%%%%%%%%%%% In case we do not record the iso-numerical mapping, here
%%%%%%%%%%%%%%%%%% is how to get it from the data:
% load('costdata.mat')
% 
% iso_all = [ iso1; 
%     iso2 
%     iso3 
%     iso4 
%     iso5 
%     iso6 
%     iso7 
%     iso8 
%     iso9 
%     iso10 
%     iso11 
%     iso12 
%     iso13 
%     iso14 
% iso15 ];
% 
% [iso_unique, iso_idx] = unique(iso_all);
% 
% iso_numeric_all = [iso1numeric 
%     iso2numeric 
%     iso3numeric 
%     iso4numeric 
%     iso5numeric 
%     iso6numeric 
%     iso7numeric 
%     iso8numeric 
%     iso9numeric 
%     iso10numeric 
%     iso11numeric 
%     iso12numeric 
%     iso13numeric 
%     iso14numeric 
% iso15numeric ];
% 
% iso_numeric_unique = iso_numeric_all(iso_idx);
% 
% iso_numeric_unique = iso_numeric_unique(2:end); % the first one is NaN or empty
% iso_unique = iso_unique(2:end);


