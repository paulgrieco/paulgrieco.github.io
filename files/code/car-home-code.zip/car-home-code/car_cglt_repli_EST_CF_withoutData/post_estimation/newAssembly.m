% This function generate a new cost data set:
% Eliminate the assembly plants in the MARKET country from the choice set 
% for that market of brands that are not HOME in said market.  
% That is if a US brand in the UK market is made in {USA, JPN, UK} the counterfactual set of assembly locations is {USA, JPN}. 

% Input: n is the cost data -- costM, s is the demand data -- m in our
% usual notation. 
% aggressive_ind=1: send the only plant back to the home country -- using
% the counterfactual cost data.
% aggressive_ind=0: do nothing with the only plant.

function costM_revised = newAssembly(n, case_ind, aggressive_ind) % n is the structure to be revised, and s provide the necessary coding information -- this is because mktCode etc are not in costM ......
%%%% load the counterfactual data:
if aggressive_ind == 1
  [cData, cVars] = readInCsv(['..' filesep 'input_files' filesep 'costData2005Prices_counterfactualData.csv']);
  assert(sum(n.hp ~= cData.hp) ==0) % double check the order

  for v = cVars
      eval(sprintf('%s = cData.%s;', v{1}, v{1}));
  end
  clear cVars cData v

  m_counter.distance_assembly_market   = [];
  m_counter.distance_assembly_hq       = [];
  m_counter.contiguity_assembly_market = [];
  m_counter.domestic_assembly_market   = [];
  m_counter.tariff_assembly_market     = [];
  m_counter.fxrate_assembly            = [];
  m_counter.location_code              = []; 
  m_counter.land_market_country        = [];
  for jj = 1:15 % this is 15!
      m_counter.distance_assembly_market   = [ m_counter.distance_assembly_market   , eval(sprintf('distmarketcountry%d',jj)) ./ 1000];
      m_counter.distance_assembly_hq       = [ m_counter.distance_assembly_hq       , eval(sprintf('disthqcountry%d',jj)) ./ 1000];
      m_counter.contiguity_assembly_market = [ m_counter.contiguity_assembly_market , eval(sprintf('contigmarketcountry%d',jj))];
      m_counter.domestic_assembly_market   = [ m_counter.domestic_assembly_market   , eval(sprintf('domesticmarketcountry%d',jj))];
      m_counter.tariff_assembly_market     = [ m_counter.tariff_assembly_market     , eval(sprintf('tariffmarketcountry%d',jj))];
      m_counter.fxrate_assembly            = [ m_counter.fxrate_assembly            , eval(sprintf('fxrate%d',jj))];
      m_counter.location_code              = [ m_counter.location_code ,  eval(sprintf('iso%dnumeric',jj))];
      m_counter.land_market_country        = [ m_counter.land_market_country ,  eval(sprintf('landmarketcountry%d',jj))];
  end    

end
%%%%%%%%%%%%%%%% load counterfactual data finished

m = n; % m is the temp one to make changes, n is the original one 

 load(['..' filesep 'cost_code' filesep 'costdata.mat'],'iso*','cty','mkt','brand','model');
 % first find the indicator of plant in the home country:
 iso_all_ass = [iso1, iso2, iso3, iso4, iso5, iso6,iso7, iso8, iso9,iso10, iso11, iso12,iso13, iso14, iso15];
 
 if length(case_ind)==1
     fprintf('Change costM for ALL firms ... \n')
     %case_ind = 1; % if not supplied, then set it as 1 always
 else
     fprintf('Change costM for SOME firms ... \n')
 end
 
 assembly_in_mkt = strcmp(iso_all_ass, repmat(cty,1,15));
 assert(max(sum(assembly_in_mkt,2)) <=1)  
 mktplant_ind = (sum(assembly_in_mkt,2) == 1); % indicator of cars with assembly plant in the market
    
 needChange_ind = (mktplant_ind) & (n.homedummy == 0)& (case_ind == 1); % has a plant in the market but not a local brand
    
% revise the data to remove the plant in the market country.
    single_foreign_plant = [];
    for i = 1:length(needChange_ind)
        if (needChange_ind(i) == 1) 
            if length(find(~cellfun(@isempty,iso_all_ass(i,:)))) > 1 % if the to-be-dropped plant is not the only plant
             pos = (assembly_in_mkt(i,:)==1);
             m.location_code(i,pos) = 51;
             m.tariff_assembly_market(i,pos) = NaN;
             m.distance_assembly_market(i,pos) = NaN;
             m.contiguity_assembly_market (i,pos) = NaN;
             m.domestic_assembly_market(i,pos) = NaN;
             m.distance_assembly_hq(i,pos) = NaN;
            else % if the to-be-dropped plant IS the only plant
                single_foreign_plant = [single_foreign_plant; i]; % we first record it
                if aggressive_ind == 1 % if we are in the Cases counterfactual -- looking only Toyota and Ford. 
                    % Replace with the counterfactual data:
                    pos = (assembly_in_mkt(i,:)==1);
                    m.location_code(i,pos) = m_counter.location_code(i,pos);
                    m.tariff_assembly_market(i,pos) = m_counter.tariff_assembly_market(i,pos);
                    m.distance_assembly_market(i,pos) = m_counter.distance_assembly_market(i,pos);
                    m.contiguity_assembly_market(i,pos) = m_counter.contiguity_assembly_market(i,pos);
                    m.domestic_assembly_market(i,pos) = m_counter.domestic_assembly_market(i,pos);
                    m.distance_assembly_hq(i,pos) = m_counter.distance_assembly_hq(i,pos);
                end
            end
        end
    end
    
    
    fprintf('In total, %g out of %g model-observation has a single plant in their market and thus using their original production locations ... \n', length(single_foreign_plant), sum(needChange_ind) )
    single_foreign_plant_mkt = mkt(single_foreign_plant);
    single_foreign_plant_brand = brand(single_foreign_plant);
    single_foreign_plant_model= model(single_foreign_plant);
    save('single_foreign_plant_obs.mat','single_foreign_plant', 'single_foreign_plant_mkt', 'single_foreign_plant_brand','single_foreign_plant_model')
 
 
costM_revised  = m;