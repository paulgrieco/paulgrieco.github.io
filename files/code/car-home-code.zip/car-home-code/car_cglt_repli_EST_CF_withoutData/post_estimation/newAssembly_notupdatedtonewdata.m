% This function generate a new cost data set that all cars are produced in
% the HQ country. If there is no plant in HQ, then we create a new one in
% HQ.

% Input: n is the cost data -- costM, s is the demand data -- m in our
% usual notation. 

function costM_revised = newAssembly(n,s) % n is the structure to be revised, and s provide the necessary coding information -- this is because mktCode etc are not in costM ......
 m = n; % m is the temp one to make changes, n is the original one 

 load(['..' filesep 'cost_code' filesep 'costdata.mat'],'iso*');
    % first find the indicator of plant in the headquater country:
    iso_all_ass = [iso1, iso2, iso3, iso4, iso5, iso6,iso7, iso8, iso9,iso10, iso11, iso12,iso13, iso14, iso15];
    assembly_in_hq = strcmp(iso_all_ass, repmat(iso_hq,1,15));
    assert(max(sum(assembly_in_hq,2)) <=1)  
    hqplant_ind = (sum(assembly_in_hq,2) == 1); % indicator of cars with assembly plant in hq -- we need to use the hq plant cost directly
    
    n_noHQplant = sum(length(hqplant_ind)) - sum(hqplant_ind);
    fprintf('There are a total of %g cars which have no plant in HQ. \n', n_noHQplant)
    
%% Initiate the new data set

m.location_code =  51*ones(size(n.location_code));
m.tariff_assembly_market = n.tariff_assembly_market * nan;
m.distance_assembly_market = n.distance_assembly_market * nan;
m.contiguity_assembly_market  = n.contiguity_assembly_market * nan;
m.domestic_assembly_marke  = n.domestic_assembly_market * nan;
m.distance_assembly_hq = n.distance_assembly_hq * nan;
    
    %% revise the data for the first time: if there is plant in HQ then delete all other locations.

    for i = 1:length(hqplant_ind)
        all_nan = nan(1,15);
        if hqplant_ind(i) == 1
             all_nan(assembly_in_hq(i,:) == 1) = 1; % only keep the HQ position, all others are NaN
             m.location_code(i,:) = (assembly_in_hq(i,:) == 1) .* n.location_code(i,:) + (1 - (assembly_in_hq(i,:) == 1)) .* 51;
             m.tariff_assembly_market(i,:) = n.tariff_assembly_market(i,:).* all_nan;
             m.distance_assembly_market(i,:) = n.distance_assembly_market(i,:).* all_nan;
             m.contiguity_assembly_market (i,:) = n.contiguity_assembly_market(i,:).* all_nan;
             m.domestic_assembly_marke(i,:) = n.domestic_assembly_market(i,:).* all_nan;
             m.distance_assembly_hq(i,:) = n.distance_assembly_hq(i,:).* all_nan;
        end
    end
    
    %% revise the data for the second time: copy the char of assembly plant over if there is no plant in HQ for this car but has a plant for another car
   copied_ind = zeros(length(hqplant_ind),1); % to recover which one is copied over
   
   for i = 1:length(hqplant_ind)
         %i
        if hqplant_ind(i) == 0
            cty_ind = (s.ctyCode == s.ctyCode(i)); % only search for the same market as i 
            temp =  strcmp(iso_all_ass, iso_hq(i)) .* repmat(cty_ind,1,15); % to see if there is some cars has a plant in this HQ
            if sum(sum(temp))>0 % if there is a match
                copied_ind(i) = 1;
                j = 1;
                found_ind = 0;
                while j<=length(hqplant_ind)  & found_ind == 0 % now search for the first one that matches
                    if sum(temp(j,:)) > 0
                        a = j;
                        [~,idx] = sort(temp(j,:));
                        b = idx(end); % take the index of the largest one
                        found_ind = 1;
                    else
                        j = j+1;
                    end
                end
                
                % put the found one in the first column of line i
                m.location_code(i,1) = n.location_code(a,b);
                m.tariff_assembly_market(i,1) = n.tariff_assembly_market(a,b);
                m.distance_assembly_market(i,1) = n.distance_assembly_market(a,b);
                m.contiguity_assembly_market (i,1) = n.contiguity_assembly_market(a,b);
                m.domestic_assembly_marke(i,1) = n.domestic_assembly_market(a,b);
                m.distance_assembly_hq(i,1) = n.distance_assembly_hq(a,b);
             end
           
        end
   end
    
    n_copied = sum(copied_ind);
    fprintf('Now %g cars are created with a new plant at HQ, and still have %g cars has no HQ plant. \n', n_copied, n_noHQplant - n_copied)
    
    assert(sum(sum(isnan(m.distance_assembly_hq)==0)) + n_noHQplant - n_copied  == length(hqplant_ind)) % make sure each car has only one production location
    
    %% Finally, we use the original data for the remain cars (since there are only 3 cars ....) -- or we can put these numbers manually -- will not make much difference 
    remain_ind = (sum(isnan(m.distance_assembly_hq)==0, 2) == 0); % what remain cars without HQ production
   
    temp_idx = [        6451
        5083
        2848
        5289
        1223
        6225
        3092
        1461]; % these are models are now produced in FRA as HQ, which as a very lower cost compared with the original data. We replace them with the original cost.
    
    remain_ind(temp_idx) = 1;
    remain_ind = (remain_ind == 1);
    
    fprintf('In total, %g of models are using their original production locations ... \n', sum(remain_ind))
    
                m.location_code(remain_ind,:) = n.location_code(remain_ind,:) ;
                m.tariff_assembly_market(remain_ind,:)  = n.tariff_assembly_market(remain_ind,:) ;
                m.distance_assembly_market(remain_ind,:)  = n.distance_assembly_market(remain_ind,:) ;
                m.contiguity_assembly_market(remain_ind,:)  = n.contiguity_assembly_market(remain_ind,:) ;
                m.domestic_assembly_marke(remain_ind,:)  = n.domestic_assembly_market(remain_ind,:) ;
                m.distance_assembly_hq(remain_ind,:) = n.distance_assembly_hq(remain_ind,:) ;

costM_revised  = m;

