% this function compute the individual utility of a set of consumer
% input is theta, containing delta and m, containing price
% output is a nMkt x i_node matrix of utility

function indUtility = indUtility(pardemandnonlin, delta,p, m)

%[pardemandnonlin, ~, delta] = unpackMpecX(theta,m);
[mu, alphai] = getMu(pardemandnonlin, m, p);  

expu = exp(bsxfun(@plus, delta, mu));

  %% begin to compute welfare of consumer i by market
  Nmkt = m.nMkts;

      for mk=1:Nmkt
          ind_mk = (m.mktCode==mk);
          indUtility(mk,:) = log( sum( expu(ind_mk,:), 1 ) + 1e-100) ./alphai(mk,:); % 1e-100 is to make sure log(0) does not happen
      end
      
          

return




