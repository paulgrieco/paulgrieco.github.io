function runCounterfactuals(tariff_baseline,dummy_baseline,fxrate_baseline,sealand_baseline,geo_baseline,demandresult_name)
display('-------------------------')
display('Counterfactual scenarios')
display('-------------------------')
outputFile = sprintf('counterScenarios_spec_dummies%d_tariff%d_fxrate%d_sealand%d_geo%d.mat',dummy_baseline,tariff_baseline,fxrate_baseline,sealand_baseline,geo_baseline);

%% Load files
load(demandresult_name)
myfilename = sprintf('cost_result_spec_dummies%d_tariff%d_fxrate%d_sealand%d_geo%d.mat',dummy_baseline,tariff_baseline,fxrate_baseline,sealand_baseline,geo_baseline);
load(['..' filesep 'cost_output' filesep myfilename]);
clear myfilename
%% Set up variables for analysis
beta_hat        = mainout.beta_hat; % is this necessary? betahat used below separetely.
D_lin_hat       = mainout.beta_hat;
D_nonlin_hat    = mainout.parnonlin_hat;
DShocks         = mainout.DShocks;
m               = mainout.m;
c2str   =   mainout.c2str;

costM           = est_results_cost_side.m;
costM.homedummy = m.homedummy; % pass the home dummy to costM, as it will be used later...
cost_Nonlin_hat = est_results_cost_side.paraNonlinCost;
cost_Lin_hat    = est_results_cost_side.paraLinCost;
costShocks      = est_results_cost_side.cost_residual;

%% Test that the two files actually agree on what costs are.
[log_costs, base_share_assembly] = predict_counterfactual_cost_outcomes_func(costShocks, cost_Lin_hat, cost_Nonlin_hat,costM,est_results_cost_side.tariff,est_results_cost_side.fxdum,est_results_cost_side.sealand,est_results_cost_side.geo);
baseline_costs = exp(log_costs);
display('Recover the baseline...')
[baseline_price, baseline_share] = getPriceEquilibrium(D_nonlin_hat, D_lin_hat, DShocks, baseline_costs,  m);
diff                             = [ max(max(abs(mainout.cost - baseline_costs))) max(max(abs(m.p - baseline_price))) max(max(abs(m.share - baseline_share))) ]; 
assert(diff(1) < 1e-3 && diff(2) < 1e-3 && diff(3) < 1e-5, 'runCounterfactuals: Demand and Cost files do not appear to match.');

%% Read in home preference regression controls: dealers and brand histories
brandDataFname = 'entryyears_dealers.csv';  % consider saving this into demandData.csv in the Stata data generation so that we don't need to carry and load this separately

fid = fopen(brandDataFname);

cols = 8;
colHeadArray = textscan(fid, '%s %s %s %s %s %s %s %s', 1, 'Delimiter', ',');
dataArray = textscan(fid,    '%s %s %d %d %d %d %d %d', 'Delimiter', ',');

for i = 3:cols
    bmData.(colHeadArray{i}{1}) = double( dataArray{i} );
end

fclose(fid);

%Construct dealer per household number (mktsize, hhold/6) (in 10k households)...
bmData.dealerPH = 1e5*(bmData.ndealers_gmaps ./ bmData.hholds);
controls  = 'localass_both'; % both dealer and years in market, as well as domestic production dummy.

%% Construct Structure Array For Countefactuals, the baseline will be counterRes(1)
%numCounters = 14;  %1 baseline plus 14 counterfactual experiments.
idx         = 1;

% Let "Counterfactual 1" be the baseline data:
counterRes(idx).name = 'Baseline';
counterRes(idx).nameprint = 'Baseline';
counterRes(idx).descr = 'Constructed using estimated parameters, matches data (up to rounding errors).';
counterRes(idx).Dlin     = D_lin_hat;
counterRes(idx).Dnonlin  = D_nonlin_hat;
counterRes(idx).DShocks  = DShocks;
counterRes(idx).Clin     = cost_Lin_hat;
counterRes(idx).Cnonlin  = cost_Nonlin_hat;
counterRes(idx).cost     = baseline_costs;
counterRes(idx).CShocks  = costShocks;
counterRes(idx).assemblyShares = base_share_assembly;
counterRes(idx).price          = baseline_price;
counterRes(idx).share          = baseline_share;

%%This is a cheap way to pre-allocate.
%counterRes(numCounters).name = 'Stub';
  
%% Counterfactual 2: Remove Homogeneous Home Dummies
idx = idx + 1;
display('Counterfactual 2: Remove Homogeneous Home Dummies...')
%The home dummy, if we use BrandxCountry Dummies, must be extracted:
if isfield(m,'startBCdums')
   [homeP, ~, homePc, ~, home, Hc] = extractHomeFromCBD(D_lin_hat, mainout.var_Nonlin_Lin, m, bmData, controls);
    % Remove Homogeneous Home Preference Estimate
    % Take hommogeneous home dummy out of brand country dummies.
    homeP_est = homeP(1);
    beta_nohomeP = beta_hat;
    beta_nohomeP(m.startBCdums:m.endBCdums) = beta_hat(m.startBCdums:m.endBCdums) - home*homeP_est;
else
   beta_nohomeP             = beta_hat;
   beta_nohomeP(m.homeDidx) = 0;
end

%Set Names, and Costs don't change at all
counterRes(idx).name = 'NoHomeP homog';
counterRes(idx).nameprint = 'No home preference, homogeneous';
counterRes(idx).descr = 'Remove Homogeneous Home Preference From the Model.';
counterRes(idx).Dlin           = beta_nohomeP;
counterRes(idx).Dnonlin        = D_nonlin_hat;
counterRes(idx).DShocks        = DShocks;
counterRes(idx).Clin           = cost_Lin_hat;
counterRes(idx).Cnonlin        = cost_Nonlin_hat;
counterRes(idx).CShocks        = costShocks;
counterRes(idx).cost           = baseline_costs;
counterRes(idx).assemblyShares = base_share_assembly;
 
%Recalculate Equilibrium...
[counterRes(idx).price, counterRes(idx).share] = getPriceEquilibrium(counterRes(idx).Dnonlin, counterRes(idx).Dlin, counterRes(idx).DShocks, counterRes(idx).cost, m);

%% Counterfactual 2.5: Remove Homogeneous Home Dummies and local production preference
if isfield(m,'startBCdums')
    idx = idx + 1;
    display('Counterfactual 2.5: Remove Homogeneous Home Dummies and local production preference ...')
    [homeP, ~, homePc, ~, home, Hc, ~, ~, homeass] = extractHomeFromCBD(D_lin_hat, mainout.var_Nonlin_Lin, m, bmData, controls);
    homeassP_est = homeP(5); % from the last result; the 5th is always preference for home assembly!
    beta_nohomePnoAsmP = beta_hat;
    beta_nohomePnoAsmP(m.startBCdums:m.endBCdums) = beta_hat(m.startBCdums:m.endBCdums) - home*homeP_est - homeass*homeassP_est;

%Set Names, and Costs don't change at all
counterRes(idx).name = 'NoHomeP and NoHomeAsmP homog';
counterRes(idx).nameprint = 'No home preference or  local production, homogeneous';
counterRes(idx).descr = 'Remove Homogeneous Home Preference and  local production From the Model.';
counterRes(idx).Dlin           =  beta_nohomePnoAsmP;
counterRes(idx).Dnonlin        = D_nonlin_hat;
counterRes(idx).DShocks        = DShocks;
counterRes(idx).Clin           = cost_Lin_hat;
counterRes(idx).Cnonlin        = cost_Nonlin_hat;
counterRes(idx).CShocks        = costShocks;
counterRes(idx).cost           = baseline_costs;
counterRes(idx).assemblyShares = base_share_assembly;
 
%Recalculate Equilibrium...
[counterRes(idx).price, counterRes(idx).share] = getPriceEquilibrium(counterRes(idx).Dnonlin, counterRes(idx).Dlin, counterRes(idx).DShocks, counterRes(idx).cost, m);
end

%% Counterfactual 2.6: Remove  local production preference only
if isfield(m,'startBCdums')
    idx = idx + 1;
    display('Counterfactual 2.6: Remove only local production preference (homogenous) ...')
    [homeP, ~, homePc, ~, home, Hc, ~, ~, homeass] = extractHomeFromCBD(D_lin_hat, mainout.var_Nonlin_Lin, m, bmData, controls);
    homeassP_est = homeP(5); % from the last result; the 5th is always preference for home assembly!
    beta_noAsmP = beta_hat;
    beta_noAsmP(m.startBCdums:m.endBCdums) = beta_hat(m.startBCdums:m.endBCdums) - homeass*homeassP_est;

%Set Names, and Costs don't change at all
counterRes(idx).name = 'NoHomeAsmP homog';
counterRes(idx).nameprint = 'No local preference, homogeneous';
counterRes(idx).descr = 'Remove Homogeneous local production preference from the Model.';
counterRes(idx).Dlin           =  beta_noAsmP;
counterRes(idx).Dnonlin        = D_nonlin_hat;
counterRes(idx).DShocks        = DShocks;
counterRes(idx).Clin           = cost_Lin_hat;
counterRes(idx).Cnonlin        = cost_Nonlin_hat;
counterRes(idx).CShocks        = costShocks;
counterRes(idx).cost           = baseline_costs;
counterRes(idx).assemblyShares = base_share_assembly;
 
%Recalculate Equilibrium...
[counterRes(idx).price, counterRes(idx).share] = getPriceEquilibrium(counterRes(idx).Dnonlin, counterRes(idx).Dlin, counterRes(idx).DShocks, counterRes(idx).cost, m);
end

%% Counterfactual 2.7:Equalize dealer networks
if isfield(m,'startBCdums')
    idx = idx + 1;
    display('Counterfactual 2.7: Equalize dealer networks ...')
    
    % construct a new dealnetwork:
    bmData_sameNet = bmData;
    for cty = 1:m.nCtys
        cty_ind = (bmData.ctyCode == cty);
        bmData_sameNet.dealerPH(cty_ind) = median(bmData.dealerPH(cty_ind));
    end
    [~, ~, ~, ~, ~, ~, ~, ~, ~, ~, X , Xc,  est, est_c] = extractHomeFromCBD(D_lin_hat, mainout.var_Nonlin_Lin, m, bmData, controls);
    [~, ~, ~, ~, ~, ~, ~, ~, ~, ~, X_sameNet, Xc_sameNet] = extractHomeFromCBD(D_lin_hat, mainout.var_Nonlin_Lin, m, bmData_sameNet, controls);
    beta_sameNet = beta_hat;
    beta_sameNet(m.startBCdums:m.endBCdums) = beta_sameNet(m.startBCdums:m.endBCdums) - (X - X_sameNet) * est; % take the change(difference) away

%Set Names, and Costs don't change at all
counterRes(idx).name = 'Equalize dealer networks';
counterRes(idx).nameprint = 'Equalize dealer networks';
counterRes(idx).descr = 'Equalize dealer networks: set each dealer network size to the within-country median';
counterRes(idx).Dlin           =  beta_sameNet;
counterRes(idx).Dnonlin        = D_nonlin_hat;
counterRes(idx).DShocks        = DShocks;
counterRes(idx).Clin           = cost_Lin_hat;
counterRes(idx).Cnonlin        = cost_Nonlin_hat;
counterRes(idx).CShocks        = costShocks;
counterRes(idx).cost           = baseline_costs;
counterRes(idx).assemblyShares = base_share_assembly;
 
%Recalculate Equilibrium...
[counterRes(idx).price, counterRes(idx).share] = getPriceEquilibrium(counterRes(idx).Dnonlin, counterRes(idx).Dlin, counterRes(idx).DShocks, counterRes(idx).cost, m);
end

% %% Counterfactual 3: Remove Country-Specific Home Preference Estimate
% % Only applies to country-brand dummies case for now.
% display('Counterfactual 3: Remove Country-Specific Home Preference Estimate...')
% if isfield(m,'startBCdums')
%     idx = idx + 1;
%     %Take hommogeneous home dummy out of brand country dummies.
%     [homeP, ~, homePc, ~, home, Hc] = extractHomeFromCBD(D_lin_hat, mainout.var_Nonlin_Lin, m, bmData, controls);
%     beta_nohomePc = beta_hat;
%     homePc(isnan(homePc)) = 0;
%     beta_nohomePc(m.startBCdums:m.endBCdums) = beta_hat(m.startBCdums:m.endBCdums) - Hc*homePc;
%     
%     %Set Names, and Costs don't change at all
%     counterRes(idx).name = 'NoHomeP_cty';
%     counterRes(idx).nameprint = 'No home preference, country-specific';
%     counterRes(idx).descr = 'Remove Country-Specific Home Preference From the Model.';
%     counterRes(idx).Dlin           = beta_nohomePc;
%     counterRes(idx).Dnonlin        = D_nonlin_hat;
%     counterRes(idx).DShocks        = DShocks;
%     counterRes(idx).Clin           = cost_Lin_hat;
%     counterRes(idx).Cnonlin        = cost_Nonlin_hat;
%     counterRes(idx).CShocks        = costShocks;
%     counterRes(idx).cost           = baseline_costs;
%     counterRes(idx).assemblyShares = base_share_assembly;
% 
%     %Recalculate Equilibrium...
%     [counterRes(idx).price, counterRes(idx).share] = getPriceEquilibrium(counterRes(idx).Dnonlin, counterRes(idx).Dlin, counterRes(idx).DShocks, counterRes(idx).cost, m);
% 
% end
 
% %% Counterfactual 3.2: Remove Country-Specific Home Preference Estimate and country specific local production preference
% % Only applies to country-brand dummies case for now.
% display('Counterfactual 3.2: Remove Country-Specific Home Preference Estimate and country specific local production preference...')
% if isfield(m,'startBCdums')
%     idx = idx + 1;
%     %Take hommogeneous home dummy out of brand country dummies.
%     [~, ~, homePc, ~, ~, Hc, AsmPc, ~, ~,CountryD_homeass] = extractHomeFromCBD(D_lin_hat, mainout.var_Nonlin_Lin, m, bmData, controls);
%     beta_nohomePcnoAsmPc = beta_hat;
%     homePc(isnan(homePc)) = 0;  
%     beta_nohomePcnoAsmPc(m.startBCdums:m.endBCdums) = beta_hat(m.startBCdums:m.endBCdums) - Hc*homePc - CountryD_homeass*AsmPc;
%     
%     %Set Names, and Costs don't change at all
%     counterRes(idx).name = 'NoHomePAsmP-cty';
%     counterRes(idx).nameprint = 'No home preference nor local production preference, country-specific';
%     counterRes(idx).descr = 'Remove Country-Specific Home Preference and country specific local production preference From the Model.';
%     counterRes(idx).Dlin           = beta_nohomePcnoAsmPc;
%     counterRes(idx).Dnonlin        = D_nonlin_hat;
%     counterRes(idx).DShocks        = DShocks;
%     counterRes(idx).Clin           = cost_Lin_hat;
%     counterRes(idx).Cnonlin        = cost_Nonlin_hat;
%     counterRes(idx).CShocks        = costShocks;
%     counterRes(idx).cost           = baseline_costs;
%     counterRes(idx).assemblyShares = base_share_assembly;
% 
%     %Recalculate Equilibrium...
%     [counterRes(idx).price, counterRes(idx).share] = getPriceEquilibrium(counterRes(idx).Dnonlin, counterRes(idx).Dlin, counterRes(idx).DShocks, counterRes(idx).cost, m);
% 
% end

% %% Counterfactual 3.5: Remove Homogeneous Home Dummies -- no local brand controls
% % Make sure it comes after the first two kinds of counterfactuals removing
% % home preference, since it overwite homeP etc.
% idx = idx + 1;
% display('Counterfactual 3.5: Remove Homogeneous (no local brand controls) ...')
% %The home dummy, if we use BrandxCountry Dummies, must be extracted:
% if isfield(m,'startBCdums')
%    [homeP, ~, homePc, ~, home, Hc] = extractHomeFromCBD(D_lin_hat, mainout.var_Nonlin_Lin, m);
%     % Remove Homogeneous Home Preference Estimate
%     % Take hommogeneous home dummy out of brand country dummies.
%     homeP = homeP(1);
%     beta_nohomeP = beta_hat;
%     beta_nohomeP(m.startBCdums:m.endBCdums) = beta_hat(m.startBCdums:m.endBCdums) - home*homeP;
% else
%    beta_nohomeP             = beta_hat;
%    beta_nohomeP(m.homeDidx) = 0;
% end
% 
% %Set Names, and Costs don't change at all
% counterRes(idx).name = 'NoHomeP_homog_nocontrol';
% counterRes(idx).nameprint = 'No home preference, homogeneous, no local controls';
% counterRes(idx).descr = 'Remove Homogeneous Home Preference (estimated from no control) From the Model.';
% counterRes(idx).Dlin           = beta_nohomeP;
% counterRes(idx).Dnonlin        = D_nonlin_hat;
% counterRes(idx).DShocks        = DShocks;
% counterRes(idx).Clin           = cost_Lin_hat;
% counterRes(idx).Cnonlin        = cost_Nonlin_hat;
% counterRes(idx).CShocks        = costShocks;
% counterRes(idx).cost           = baseline_costs;
% counterRes(idx).assemblyShares = base_share_assembly;
%  
% %Recalculate Equilibrium...
% [counterRes(idx).price, counterRes(idx).share] = getPriceEquilibrium(counterRes(idx).Dnonlin, counterRes(idx).Dlin, counterRes(idx).DShocks, counterRes(idx).cost, m);

% %% Counterfactual 4: If Napolean had won. The world has French tastes for characteristics. 
% display('Counterfactual 4: The world has French tastes for characteristics...')
% france_code = 6;
% beta_france = D_lin_hat;
% if isfield(m,'startBCdums')
%    numCharSets = (m.startBCdums-1)/m.nCtys;
% else
%    numCharSets = (m.homeDidx-1)/m.nCtys;
% end
% 
% for charSet = 1:numCharSets
%     beta_france((charSet-1)*m.nCtys+1:charSet*m.nCtys) = D_lin_hat((charSet-1)*m.nCtys+france_code);
% end
% 
% idx = idx + 1;
% %Set Names, and Costs don't change at all
% counterRes(idx).name = 'AllFrance';
% counterRes(idx).nameprint = 'All countries have French tastes for characteristics';
% counterRes(idx).descr = 'Make tastes for charachteristics in all countries match France.';
% counterRes(idx).Dlin    = beta_france;
% counterRes(idx).Dnonlin = D_nonlin_hat;
% counterRes(idx).DShocks = DShocks;
% counterRes(idx).Clin    = cost_Lin_hat;
% counterRes(idx).Cnonlin = cost_Nonlin_hat;
% counterRes(idx).CShocks = costShocks;
% counterRes(idx).cost    = baseline_costs;
% counterRes(idx).assemblyShares = base_share_assembly;
% 
% %Recalculate Equilibrium...
% [counterRes(idx).price, counterRes(idx).share] = getPriceEquilibrium(counterRes(idx).Dnonlin, counterRes(idx).Dlin, counterRes(idx).DShocks, counterRes(idx).cost, m);
% 
% %% Counterfactual 4.5: If the world has US tastes for characteristics. 
% display('Counterfactual 4.5: The world has US tastes for characteristics...')
% us_code = 9;
% beta_us = D_lin_hat;
% if isfield(m,'startBCdums')
%    numCharSets = (m.startBCdums-1)/m.nCtys;
% else
%    numCharSets = (m.homeDidx-1)/m.nCtys;
% end
% 
% for charSet = 1:numCharSets
%     beta_us((charSet-1)*m.nCtys+1:charSet*m.nCtys) = D_lin_hat((charSet-1)*m.nCtys+us_code);
% end
% 
% idx = idx + 1;
% %Set Names, and Costs don't change at all
% counterRes(idx).name = 'AllUS';
% counterRes(idx).nameprint = 'All countries have US tastes for characteristics';
% counterRes(idx).descr = 'Make tastes for charachteristics in all countries match US.';
% counterRes(idx).Dlin    = beta_us;
% counterRes(idx).Dnonlin = D_nonlin_hat;
% counterRes(idx).DShocks = DShocks;
% counterRes(idx).Clin    = cost_Lin_hat;
% counterRes(idx).Cnonlin = cost_Nonlin_hat;
% counterRes(idx).CShocks = costShocks;
% counterRes(idx).cost    = baseline_costs;
% counterRes(idx).assemblyShares = base_share_assembly;
% 
% %Recalculate Equilibrium...
% [counterRes(idx).price, counterRes(idx).share] = getPriceEquilibrium(counterRes(idx).Dnonlin, counterRes(idx).Dlin, counterRes(idx).DShocks, counterRes(idx).cost, m);

%% Counterfactual 5: Remove all Tariffs
display('Counterfactual 5: Remove all Tariffs...')
idx = idx + 1;
notariffs_Cnonlin = cost_Nonlin_hat;

% if est_results_cost_side.tariff == 1 % if tariff was estimated
%     notariffs_Cnonlin(2) = 0;
% else
%     notariffs_Cnonlin = [notariffs_Cnonlin(1:4);0;notariffs_Cnonlin(5:end)]; % !! we should change this to make the tariff matrix all zeros, when the tariff coefficient becomes power, this will be bad!!
% end
costM_notrf = costM;
costM_notrf.tariff_assembly_market = 0*costM_notrf.tariff_assembly_market; % make the tariff matrix all zeros -- only need this for cost side, demand side m does not change

counterRes(idx).name       = 'NoTariff';
counterRes(idx).nameprint = 'All tariffs eliminated';
counterRes(idx).descr      = 'Remove All Tariffs from the Model.';
counterRes(idx).Dlin       = D_lin_hat;
counterRes(idx).Dnonlin    = D_nonlin_hat;
counterRes(idx).DShocks    = DShocks;
counterRes(idx).Clin       = cost_Lin_hat;
counterRes(idx).Cnonlin    = notariffs_Cnonlin;
counterRes(idx).CShocks    = costShocks;
[log_cost_func, counterRes(idx).assemblyShares] = predict_counterfactual_cost_outcomes_func(counterRes(idx).CShocks, counterRes(idx).Clin, counterRes(idx).Cnonlin, costM_notrf, 1, est_results_cost_side.fxdum,est_results_cost_side.sealand,est_results_cost_side.geo); % note that this counterfactual is coded such that est_results_cost_side.tariff=1 is passed here, but the relevant tariff component is adjusted above
counterRes(idx).cost = exp(log_cost_func);
[counterRes(idx).price, counterRes(idx).share] = getPriceEquilibrium(counterRes(idx).Dnonlin,  counterRes(idx).Dlin, counterRes(idx).DShocks, counterRes(idx).cost, m);


%% Counterfactual 6: Remove all Assembly-Market Trade Costs
idx = idx + 1;
display('Counterfactual 6: Remove all Assembly-Market Trade Costs...')
noTradeCosts_Cnonlin = cost_Nonlin_hat;
%This removes contiguity dummy...
%noTradeCosts_Cnonlin (3) = 0;
%This gives every assembly location the cost advantage of domestic
costM_notradecostTemp = costM;
costM_notradecostTemp.contiguit_assembly_market = zeros(size(costM.contiguity_assembly_market)); 
%This gives every assembly location the cost advantage of domestic
costM_notradecostTemp.domestic_assembly_market = ones(size(costM.domestic_assembly_market));
%This sets all distances to internal distances
costM_notradecostTemp.distance_assembly_market = costM.distinternal*ones(1,size(costM.domestic_assembly_market,2)); % creates the right sized matrix of internal distances
temp1 = costM.distance_assembly_market./costM.distance_assembly_market; % this preserves NaN locations and sets the other ones to 1,
costM_notradecostTemp.distance_assembly_market = temp1.*costM_notradecostTemp.distance_assembly_market./1000; % so that this line multiplies them with internal distance of the destination market
                                                                                                              % consistent with line 79 in main_costall_log.m which puts distance to assembly into 1000km
counterRes(idx).name = 'NoShipCost';
counterRes(idx).nameprint = 'No international trade frictions';
counterRes(idx).descr = 'Removes contiguity dummy, reduces distance to internal dist, gives all sources domestic cost advantage, keeps tariffs and FDI costs.';
counterRes(idx).Dlin     = D_lin_hat;
counterRes(idx).Dnonlin  = D_nonlin_hat;
counterRes(idx).DShocks  = DShocks;
counterRes(idx).Clin     = cost_Lin_hat;
counterRes(idx).Cnonlin  = noTradeCosts_Cnonlin;
counterRes(idx).CShocks  = costShocks;
[log_cost_func, counterRes(idx).assemblyShares] = predict_counterfactual_cost_outcomes_func(counterRes(idx).CShocks, counterRes(idx).Clin, counterRes(idx).Cnonlin, costM_notradecostTemp, est_results_cost_side.tariff, est_results_cost_side.fxdum,est_results_cost_side.sealand,est_results_cost_side.geo);

counterRes(idx).cost = exp(log_cost_func);
[counterRes(idx).price, counterRes(idx).share] = getPriceEquilibrium(counterRes(idx).Dnonlin,  counterRes(idx).Dlin, counterRes(idx).DShocks, counterRes(idx).cost, m);

%% Counterfactual 7: Remove  FDI Costs
idx = idx + 1;
display('Counterfactual 7: Remove  FDI Costs...')
noFDICosts_Cnonlin = cost_Nonlin_hat;
%This removes fdi costs ...
%noFDICosts_Cnonlin (4) = 0;
costM_noFDIcostTemp = costM;
costM_noFDIcostTemp.distance_assembly_hq = ones(size(costM.distance_assembly_hq)); % make it as 1 rather than 0 because we are using log(distance)

counterRes(idx).name    = 'NoFDICost';
counterRes(idx).nameprint = 'No multinational production frictions';
counterRes(idx).descr   = 'Removes distance between assembly and headquarters costs.';
counterRes(idx).Dlin    = D_lin_hat;
counterRes(idx).Dnonlin = D_nonlin_hat;
counterRes(idx).DShocks = DShocks;
counterRes(idx).Clin    = cost_Lin_hat;
counterRes(idx).Cnonlin = noFDICosts_Cnonlin;
counterRes(idx).CShocks = costShocks;
[log_cost_func, counterRes(idx).assemblyShares] = predict_counterfactual_cost_outcomes_func(counterRes(idx).CShocks, counterRes(idx).Clin, counterRes(idx).Cnonlin, costM_noFDIcostTemp, est_results_cost_side.tariff, est_results_cost_side.fxdum,est_results_cost_side.sealand,est_results_cost_side.geo);
counterRes(idx).cost = exp(log_cost_func);
[counterRes(idx).price, counterRes(idx).share] = getPriceEquilibrium(counterRes(idx).Dnonlin,  counterRes(idx).Dlin, counterRes(idx).DShocks, counterRes(idx).cost, m);
  
%% Counterfactual 8: Remove All Trade Frictions
idx = idx + 1;
display('Counterfactual 8: Remove All Trade Frictions...')
noTradeFrics_Cnonlin = cost_Nonlin_hat;
% %This removes contiguity dummy...
% noTradeFrics_Cnonlin(3) = 0;
% %This removes fdi costs ...
% noTradeFrics_Cnonlin(4)  = 0;
% %This removes the tariff ...
% if est_results_cost_side.tariff == 1
%     noTradeFrics_Cnonlin(5) = 0;
% else
%     noTradeFrics_Cnonlin = [noTradeFrics_Cnonlin(1:4);0;noTradeFrics_Cnonlin(5:end)];
% end
%Construct costM for counterfactual:
costM_noTradeFricsTemp = costM;
costM_noTradeFricsTemp.domestic_assembly_market = ones(size(costM.domestic_assembly_market)); %This gives every assembly location the cost advantage of domestic
costM_noTradeFricsTemp.contiguit_assembly_market = zeros(size(costM.contiguity_assembly_market)); %This removes contiguity dummy...
% This sets all distances to internal distances
costM_noTradeFricsTemp.distance_assembly_market = costM.distinternal*ones(1,size(costM.domestic_assembly_market,2)); % creates the right sized matrix of internal distances
temp2 = costM.distance_assembly_market./costM.distance_assembly_market; % this preserves NaN locations and sets the other ones to 1,
costM_noTradeFricsTemp.distance_assembly_market = temp2.*costM_noTradeFricsTemp.distance_assembly_market./1000; % so that this line multiplies them with internal distance of the destination market
                                                                                                                % consistent with line 79 in main_costall_log.m which puts distance to assembly into 1000km:
costM_noTradeFricsTemp.distance_assembly_hq = ones(size(costM.distance_assembly_hq)); % remove hq distance effect
costM_noTradeFricsTemp.tariff_assembly_market = 0*costM.tariff_assembly_market; % make the tariff matrix all zeros -- only need this for cost side, demand side m does not change
                                                                                                        
counterRes(idx).name    = 'NoTradeFrics';
counterRes(idx).nameprint = 'No tariffs, trade or multinational production frictions';
counterRes(idx).descr   = 'Removes all trade frictions (tariffs, assemb-mkt, assem-hq) from the model. Handles distances, domestic and continuity dummies in the same way as NoShipCost';
counterRes(idx).Dlin    = D_lin_hat;
counterRes(idx).Dnonlin = D_nonlin_hat;
counterRes(idx).DShocks = DShocks;
counterRes(idx).Clin    = cost_Lin_hat;
counterRes(idx).Cnonlin = noTradeFrics_Cnonlin;
counterRes(idx).CShocks = costShocks;
[log_cost_func, counterRes(idx).assemblyShares] = predict_counterfactual_cost_outcomes_func(counterRes(idx).CShocks, counterRes(idx).Clin, counterRes(idx).Cnonlin, costM_noTradeFricsTemp, 1, est_results_cost_side.fxdum,est_results_cost_side.sealand,est_results_cost_side.geo);  % see above: tariff dummy set to 1 for dimensionality, tariff coefficient set to zero for counterfactual
counterRes(idx).cost = exp(log_cost_func);
[counterRes(idx).price, counterRes(idx).share] = getPriceEquilibrium(counterRes(idx).Dnonlin,  counterRes(idx).Dlin, counterRes(idx).DShocks, counterRes(idx).cost, m);

%% Counterfactual 9: German gas prices 
idx = idx + 1;
display('Counterfactual 9: German gas prices everywhere...')
mTemp      = m;
mTemp.rcX  = m.rcXcounter;
mTemp.linX = m.linXcounter;

counterRes(idx).name    = 'German gas prices everywhere';
counterRes(idx).nameprint = 'All countries have German gas prices';
counterRes(idx).descr   = 'Sets all gas prices equal to the level in Germany and recalculates miles per dollar';
counterRes(idx).Dlin    = D_lin_hat;
counterRes(idx).Dnonlin = D_nonlin_hat;
counterRes(idx).DShocks = DShocks;
counterRes(idx).Clin    = cost_Lin_hat;
counterRes(idx).Cnonlin = cost_Nonlin_hat;
counterRes(idx).CShocks = costShocks;
counterRes(idx).cost    = baseline_costs;
counterRes(idx).assemblyShares = base_share_assembly;

[counterRes(idx).price, counterRes(idx).share] = getPriceEquilibrium(counterRes(idx).Dnonlin,  counterRes(idx).Dlin, counterRes(idx).DShocks, counterRes(idx).cost, mTemp);

%% Counterfactual 10: Value of Domestic Status for Foreign Brands 
% This is to simply reduce only the interesting brands brandxcountry dummy by
% the home preference (rather than all home brands) and re-equilibriate.

if isfield(m,'startBCdums')
    display('Counterfactual 10: If (a selected set of) brands do not have domestic status/preference ...')
    idx = idx + 1;
    
    % identify the set of cases we want to look at:
    % Seat in Spain (VW)
    ind_1 = (m.mktCode >=17  & m.mktCode <=21) & (m.brandCode == 50);
    assert(length(unique(m.firmCode(ind_1))) == 1); % make sure it is from a single firm -- we did not mess things up
    % Vauxhall in UK (GM)
    ind_2 = (m.mktCode >=27  & m.mktCode <=31) & (m.brandCode == 59);
    assert(length(unique(m.firmCode(ind_2))) == 1); 
    % Chrysler in US (Fiat)
    ind_3 = (m.mktCode >=37  & m.mktCode <=41) & (m.brandCode == 10);
    assert(length(unique(m.firmCode(ind_3))) == 1); 
    % Opel  in Germany (GM)
    ind_4 = (m.mktCode >=12  & m.mktCode <=16) & (m.brandCode == 39);
    assert(length(unique(m.firmCode(ind_4))) == 1); 
    
    % Four more cases (largest home brand)
    % VW in DEU
    ind_5 = (m.mktCode >=12  & m.mktCode <=16) & (m.brandCode == 58);
    assert(length(unique(m.firmCode(ind_5))) == 1); 
    % Renault in FRA
    ind_6 = (m.mktCode >=22  & m.mktCode <=26) & (m.brandCode == 45);
    assert(length(unique(m.firmCode(ind_6))) == 1); 
    % Fiat in ITA
    ind_7 = (m.mktCode >=32  & m.mktCode <=36) & (m.brandCode == 16);
    assert(length(unique(m.firmCode(ind_7))) == 1); 
    % Chevrolet in US
    ind_8 = (m.mktCode >=37  & m.mktCode <=41) & (m.brandCode == 9);
    assert(length(unique(m.firmCode(ind_8))) == 1); 

   
    %ind_case = ind_1 | ind_2 | ind_3 | ind_4; % pool all cases together 
    ind_case = ind_1 | ind_2 | ind_3 | ind_4| ind_5 | ind_6 | ind_7| ind_8; % pool all cases together 
    
    %retrive the home preference estimate -- need to re-extract since
    %otherwise changed in the previous code.
    [homeP, ~, homePc, ~, home, Hc] = extractHomeFromCBD(D_lin_hat, mainout.var_Nonlin_Lin, m, bmData, controls);
    homeP = homeP(1);
    homePc(isnan(homePc)) = 0;

    %Take home dummy out of brand country dummies.
    temp_1 = m.linX(ind_case, m.startBCdums:m.endBCdums); % all the brand and country dummies in linX for our cases
    temp_2 = sum(unique(temp_1,'rows'), 1); % should be ones or zeros: one means we it is pointing to a brand country dummy in our case
    assert(max(temp_2) == 1 & min(temp_2) == 0);
    % take homogenous home preference out only
    beta_ForeignLossHomeAdv = beta_hat; 
    beta_ForeignLossHomeAdv(m.startBCdums:m.endBCdums) = beta_hat(m.startBCdums:m.endBCdums) - homeP*temp_2'; % just take home preference away from cases we are interested in
    % take country specific home preference out  
    beta_ForeignLossHomeAdv_c = beta_hat;
    Hc_part = Hc .* repmat(temp_2',1,length(homePc)); % only take the part for the cases
    beta_ForeignLossHomeAdv_c(m.startBCdums:m.endBCdums) = beta_hat(m.startBCdums:m.endBCdums) - Hc_part*homePc;
    
    %Set Names, and Costs don't change at all
    counterRes(idx).name = 'ForeignLossHomeAdv';
    counterRes(idx).nameprint = 'Value of Domestic Status for Foreign Brands';
    counterRes(idx).descr = 'Remove home preference for (a selected set of) foreign brands in some markets';
    counterRes(idx).Dlin           = beta_ForeignLossHomeAdv_c;
    counterRes(idx).Dnonlin        = D_nonlin_hat;
    counterRes(idx).DShocks        = DShocks;
    counterRes(idx).Clin           = cost_Lin_hat;
    counterRes(idx).Cnonlin        = cost_Nonlin_hat;
    counterRes(idx).CShocks        = costShocks;
    counterRes(idx).cost           = baseline_costs;
    counterRes(idx).assemblyShares = base_share_assembly;

    %Recalculate Equilibrium...
    [counterRes(idx).price, counterRes(idx).share] = getPriceEquilibrium(counterRes(idx).Dnonlin, counterRes(idx).Dlin, counterRes(idx).DShocks, counterRes(idx).cost, m);
end

% %% Counterfactual 12: (All firms) noFDI  -- Eliminate the local production preference AND foreign assembly locations in the market country. 
% idx = idx + 1;
% display('Counterfactual 12:  (All firms) Eliminate the local production preference AND foreign assembly locations in the market country...')
% 
% % remove the local production preference
%  [homeP, ~, homePc, ~, home, Hc, ~, ~, homeass] = extractHomeFromCBD(D_lin_hat, mainout.var_Nonlin_Lin, m, bmData, controls);
%  homeassP_est = homeP(5); % from the last result; the 5th is always preference for home assembly!
%  beta_noAsmP = beta_hat;
%  beta_noAsmP(m.startBCdums:m.endBCdums) = beta_hat(m.startBCdums:m.endBCdums) - homeass.*(1-home).*homeassP_est; % take away local preference only if it is not a home brand
%     
% counterRes(idx).name       = 'NoFDI (noAsmP-noPlant)';
% counterRes(idx).nameprint = 'No FDI (noAsmP-noPlant)';
% counterRes(idx).descr      = '(All firms) Eliminate the local production preference AND foreign assembly locations in the market country. ';
% counterRes(idx).Dlin       = beta_noAsmP;
% counterRes(idx).Dnonlin    = D_nonlin_hat;
% counterRes(idx).DShocks    = DShocks;
% counterRes(idx).Clin       = cost_Lin_hat;
% counterRes(idx).Cnonlin    = cost_Nonlin_hat;
% counterRes(idx).CShocks    = costShocks;
% noFDI = 0; % No this noFDI, but use revised costM:
% costM_noFDI = newAssembly(costM, 1, 0); % second input: case_ind=1; third input: aggressive_ind=0
% [log_cost_func, counterRes(idx).assemblyShares] = predict_counterfactual_cost_outcomes_func(counterRes(idx).CShocks, counterRes(idx).Clin, counterRes(idx).Cnonlin, costM_noFDI, 1, est_results_cost_side.fxdum, est_results_cost_side.sealand,est_results_cost_side.geo, noFDI,c2str, m.mktCode); % note that this counterfactual is coded such that est_results_cost_side.tariff=1 is passed here, but the relevant tariff component is adjusted above
% counterRes(idx).cost = exp(log_cost_func);
% %%%%%%%%%%%%%%%%% If the counterfactual cost is too high, due to very low
% %%%%%%%%%%%%%%%%% production dummy, then use the original cost, and record
% %%%%%%%%%%%%%%%%% which models they are.
% unreasonable_cost_ind = (counterRes(idx).cost./exp(costM.cost) > 2);
% counterRes(idx).cost(unreasonable_cost_ind) = exp(costM.cost(unreasonable_cost_ind));
% fprintf('There are %g models have unreasonably high counterfactual cost, as the production dummy is too low \n', sum(unreasonable_cost_ind))
% fprintf('Thus, their costs are kept as it was in the original model. They are: model code: %g\n', m.modelCode(unreasonable_cost_ind))
% fprintf('In market code: %g\n', m.mktCode(unreasonable_cost_ind))
% %%%%%%%%%%%%%%%%%%
% 
% [counterRes(idx).price, counterRes(idx).share] = getPriceEquilibrium(counterRes(idx).Dnonlin,  counterRes(idx).Dlin, counterRes(idx).DShocks, counterRes(idx).cost, m);
% 
% %% Counterfactual 12.2 : (all firms) noFDI -- Eliminate the local production preference. 
% idx = idx + 1;
% display('Counterfactual 12.2:  (All firms) Eliminate the local production preference (but not for home brand) ...')
% 
% % remove the local production preference
%  [homeP, ~, homePc, ~, home, Hc, ~, ~, homeass] = extractHomeFromCBD(D_lin_hat, mainout.var_Nonlin_Lin, m, bmData, controls);
%  homeassP_est = homeP(5); % from the last result; the 5th is always preference for home assembly!
%  beta_noAsmP = beta_hat;
%  beta_noAsmP(m.startBCdums:m.endBCdums) = beta_hat(m.startBCdums:m.endBCdums) - homeass.*(1-home).*homeassP_est; % take away local preference only if it is not a home brand
%     
% counterRes(idx).name       = 'NoFDI (noAsmP)';
% counterRes(idx).nameprint = 'No FDI  (noAsmP)';
% counterRes(idx).descr      = '(All firms) Eliminate the local production preference (but not for home brand) ';
% counterRes(idx).Dlin       = beta_noAsmP;
% counterRes(idx).Dnonlin    = D_nonlin_hat;
% counterRes(idx).DShocks    = DShocks;
% counterRes(idx).Clin       = cost_Lin_hat;
% counterRes(idx).Cnonlin    = cost_Nonlin_hat;
% counterRes(idx).CShocks    = costShocks;
% counterRes(idx).cost           = baseline_costs;
% counterRes(idx).assemblyShares = base_share_assembly;
% 
% [counterRes(idx).price, counterRes(idx).share] = getPriceEquilibrium(counterRes(idx).Dnonlin,  counterRes(idx).Dlin, counterRes(idx).DShocks, counterRes(idx).cost, m);

% %% Counterfactual 12.4: (All firms) noFDI  -- Eliminate foreign assembly locations in the market country. 
% idx = idx + 1;
% display('Counterfactual 12.4:  (All firms) Eliminate foreign assembly locations in the market country...')
% 
% % remove the local production preference
% counterRes(idx).name       = 'NoFDI (noPlant)';
% counterRes(idx).nameprint = 'No FDI (noPlant)';
% counterRes(idx).descr      = '(All firms) Eliminate foreign assembly locations in the market country. ';
% counterRes(idx).Dlin       = beta_hat;
% counterRes(idx).Dnonlin    = D_nonlin_hat;
% counterRes(idx).DShocks    = DShocks;
% counterRes(idx).Clin       = cost_Lin_hat;
% counterRes(idx).Cnonlin    = cost_Nonlin_hat;
% counterRes(idx).CShocks    = costShocks;
% noFDI = 0; % No this noFDI, but use revised costM:
% costM_noFDI = newAssembly(costM, 1, 0); % second input: case_ind=1; third input: aggressive_ind=0
% [log_cost_func, counterRes(idx).assemblyShares] = predict_counterfactual_cost_outcomes_func(counterRes(idx).CShocks, counterRes(idx).Clin, counterRes(idx).Cnonlin, costM_noFDI, 1, est_results_cost_side.fxdum, est_results_cost_side.sealand,est_results_cost_side.geo, noFDI,c2str, m.mktCode); % note that this counterfactual is coded such that est_results_cost_side.tariff=1 is passed here, but the relevant tariff component is adjusted above
% counterRes(idx).cost = exp(log_cost_func);
% %%%%%%%%%%%%%%%%% If the counterfactual cost is too high, due to very low
% %%%%%%%%%%%%%%%%% production dummy, then use the original cost, and record
% %%%%%%%%%%%%%%%%% which models they are.
% unreasonable_cost_ind = (counterRes(idx).cost./exp(costM.cost) > 2);
% counterRes(idx).cost(unreasonable_cost_ind) = exp(costM.cost(unreasonable_cost_ind));
% fprintf('There are %g models have unreasonably high counterfactual cost, as the production dummy is too low \n', sum(unreasonable_cost_ind))
% fprintf('Thus, their costs are kept as it was in the original model. They are: model code: %g\n', m.modelCode(unreasonable_cost_ind))
% fprintf('In market code: %g\n', m.mktCode(unreasonable_cost_ind))
% %%%%%%%%%%%%%%%%%%
% 
% [counterRes(idx).price, counterRes(idx).share] = getPriceEquilibrium(counterRes(idx).Dnonlin,  counterRes(idx).Dlin, counterRes(idx).DShocks, counterRes(idx).cost, m);

%% Counterfactual 13: Remove local preference and foreign assembly plant for (a selected set of) foreign firms in some markets
idx = idx + 1;
display('Counterfactual 13:  Remove local preference and foreign assembly plant for (a selected set of) foreign firms in some markets...')

% identify the set of cases we want to look at:
    % Toyota in US 
    ind_1 = (m.ctyCode == 9) & (m.firmCode == 26);
    % Ford in German
    ind_2 = (m.ctyCode == 4) & (m.firmCode == 8);
   
    ind_case = ind_1 | ind_2; % pool all cases together 
    
    %retrive the home preference estimate -- need to re-extract since
    %otherwise changed in the previous code.
    [homeP, ~, homePc, ~, home, Hc, ~, ~, homeass] = extractHomeFromCBD(D_lin_hat, mainout.var_Nonlin_Lin, m, bmData, controls);
    homeassP_est = homeP(5); % from the last result; the 5th is always preference for home assembly!

    %Take local preference dummy out of brand country dummies.
    temp_1 = m.linX(ind_case, m.startBCdums:m.endBCdums); % all the brand and country dummies in linX for our cases
    temp_2 = sum(unique(temp_1,'rows'), 1); % should be ones or zeros: one means we it is pointing to a brand country dummy in our case
    assert(max(temp_2) == 1 & min(temp_2) == 0);
    % take homogenous home preference out only
    beta_noFDISpec= beta_hat; 
    beta_noFDISpec(m.startBCdums:m.endBCdums) = beta_hat(m.startBCdums:m.endBCdums) - homeassP_est*temp_2'; % just take local preference away from cases we are interested in
    
    %Set Names, and Costs don't change at all
    counterRes(idx).name = 'NoFDI (noAsmP-noPlant, Cases)';
    counterRes(idx).nameprint = 'NoFDI (noAsmP-noPlant, Cases)';
    counterRes(idx).descr = 'Remove local preference and local plant for (a selected set of) foreign firms in some markets';
    counterRes(idx).Dlin           = beta_noFDISpec;
    counterRes(idx).Dnonlin        = D_nonlin_hat;
    counterRes(idx).DShocks        = DShocks;
    counterRes(idx).Clin           = cost_Lin_hat;
    counterRes(idx).Cnonlin        = cost_Nonlin_hat;
    counterRes(idx).CShocks        = costShocks;
    noFDI = 0; % No this noFDI, but use revised costM:
    costM_noFDI = newAssembly(costM, ind_case, 0); % third input: aggressive_ind=0
    [log_cost_func, counterRes(idx).assemblyShares] = predict_counterfactual_cost_outcomes_func(counterRes(idx).CShocks, counterRes(idx).Clin, counterRes(idx).Cnonlin, costM_noFDI, 1, est_results_cost_side.fxdum, est_results_cost_side.sealand,est_results_cost_side.geo, noFDI,c2str, m.mktCode); % note that this counterfactual is coded such that est_results_cost_side.tariff=1 is passed here, but the relevant tariff component is adjusted above
    counterRes(idx).cost = exp(log_cost_func);

    %Recalculate Equilibrium...
    [counterRes(idx).price, counterRes(idx).share] = getPriceEquilibrium(counterRes(idx).Dnonlin, counterRes(idx).Dlin, counterRes(idx).DShocks, counterRes(idx).cost, m);

    %% Counterfactual 13.2: Remove foreign plants for (a selected set of) foreign firms in some markets
idx = idx + 1;
display('Counterfactual 13.2:  Remove foreign plants for (a selected set of) foreign firms in some markets...')

% identify the set of cases we want to look at:
    % Toyota in US 
    ind_1 = (m.ctyCode == 9) & (m.firmCode == 26);
    % Ford in German
    ind_2 = (m.ctyCode == 4) & (m.firmCode == 8);
   
    ind_case = ind_1 | ind_2; % pool all cases together 
    
    %retrive the home preference estimate -- need to re-extract since
    %otherwise changed in the previous code.
    [homeP, ~, homePc, ~, home, Hc, ~, ~, homeass] = extractHomeFromCBD(D_lin_hat, mainout.var_Nonlin_Lin, m, bmData, controls);
    homeassP_est = homeP(5); % from the last result; the 5th is always preference for home assembly!

    %Take local preference dummy out of brand country dummies.
    temp_1 = m.linX(ind_case, m.startBCdums:m.endBCdums); % all the brand and country dummies in linX for our cases
    temp_2 = sum(unique(temp_1,'rows'), 1); % should be ones or zeros: one means we it is pointing to a brand country dummy in our case
    assert(max(temp_2) == 1 & min(temp_2) == 0);
    % take homogenous home preference out only
    beta_noFDISpec= beta_hat; 
    beta_noFDISpec(m.startBCdums:m.endBCdums) = beta_hat(m.startBCdums:m.endBCdums) - homeassP_est*temp_2'; % just take local preference away from cases we are interested in
    
    %Set Names, and Costs don't change at all
    counterRes(idx).name = 'NoFDI (noAsmP, Cases)';
    counterRes(idx).nameprint = 'NoFDI (noAsmP, Cases)';
    counterRes(idx).descr = 'Remove local preference for (a selected set of) foreign firms in some markets';
    counterRes(idx).Dlin           = beta_noFDISpec;
    counterRes(idx).Dnonlin        = D_nonlin_hat;
    counterRes(idx).DShocks        = DShocks;
    counterRes(idx).Clin           = cost_Lin_hat;
    counterRes(idx).Cnonlin        = cost_Nonlin_hat;
    counterRes(idx).CShocks        = costShocks;
    counterRes(idx).cost           = baseline_costs;
    counterRes(idx).assemblyShares = base_share_assembly;

    %Recalculate Equilibrium...
    [counterRes(idx).price, counterRes(idx).share] = getPriceEquilibrium(counterRes(idx).Dnonlin, counterRes(idx).Dlin, counterRes(idx).DShocks, counterRes(idx).cost, m);

 %% Counterfactual 13.4: Remove foreign assembly plant for (a selected set of) foreign firms in some markets
idx = idx + 1;
display('Counterfactual 13:  Remove  foreign assembly plant for (a selected set of) foreign firms in some markets...')

% identify the set of cases we want to look at:
    % Toyota in US 
    ind_1 = (m.ctyCode == 9) & (m.firmCode == 26);
    % Ford in German
    ind_2 = (m.ctyCode == 4) & (m.firmCode == 8);
   
    ind_case = ind_1 | ind_2; % pool all cases together 
    
    %Set Names, and Costs don't change at all
    counterRes(idx).name = 'NoFDI (noPlant, Cases)';
    counterRes(idx).nameprint = 'NoFDI (noPlant, Cases)';
    counterRes(idx).descr = 'Remove local plant for (a selected set of) foreign firms in some markets';
    counterRes(idx).Dlin           = beta_hat;
    counterRes(idx).Dnonlin        = D_nonlin_hat;
    counterRes(idx).DShocks        = DShocks;
    counterRes(idx).Clin           = cost_Lin_hat;
    counterRes(idx).Cnonlin        = cost_Nonlin_hat;
    counterRes(idx).CShocks        = costShocks;
    noFDI = 0; % No this noFDI, but use revised costM:
    costM_noFDI = newAssembly(costM, ind_case, 0); % third input: aggressive_ind=0
    [log_cost_func, counterRes(idx).assemblyShares] = predict_counterfactual_cost_outcomes_func(counterRes(idx).CShocks, counterRes(idx).Clin, counterRes(idx).Cnonlin, costM_noFDI, 1, est_results_cost_side.fxdum, est_results_cost_side.sealand,est_results_cost_side.geo, noFDI,c2str, m.mktCode); % note that this counterfactual is coded such that est_results_cost_side.tariff=1 is passed here, but the relevant tariff component is adjusted above
    counterRes(idx).cost = exp(log_cost_func);

    %Recalculate Equilibrium...
    [counterRes(idx).price, counterRes(idx).share] = getPriceEquilibrium(counterRes(idx).Dnonlin, counterRes(idx).Dlin, counterRes(idx).DShocks, counterRes(idx).cost, m);
 
%%    
%%%%%%%%%%%%% Now for aggressive no FDI counterfactual for Cases:
%%%%%%%%%%%%% If the there is an only Toyota plant in US, for example, send
%%%%%%%%%%%%% it to Japan, using the counterfactual cost data.
% Counterfactual 14: (Aggressive!)Remove local preference and foreign assembly plant for (a selected set of) foreign firms in some markets
idx = idx + 1;
display('Counterfactual 14:  (Aggressive!) Remove local preference and foreign assembly plant for (a selected set of) foreign firms in some markets...')

% identify the set of cases we want to look at:
    % Toyota in US 
    ind_1 = (m.ctyCode == 9) & (m.firmCode == 26);
    % Ford in German
    ind_2 = (m.ctyCode == 4) & (m.firmCode == 8);
   
    ind_case = ind_1 | ind_2; % pool all cases together 
    
    %retrive the home preference estimate -- need to re-extract since
    %otherwise changed in the previous code.
    [homeP, ~, homePc, ~, home, Hc, ~, ~, homeass] = extractHomeFromCBD(D_lin_hat, mainout.var_Nonlin_Lin, m, bmData, controls);
    homeassP_est = homeP(5); % from the last result; the 5th is always preference for home assembly!

    %Take local preference dummy out of brand country dummies.
    temp_1 = m.linX(ind_case, m.startBCdums:m.endBCdums); % all the brand and country dummies in linX for our cases
    temp_2 = sum(unique(temp_1,'rows'), 1); % should be ones or zeros: one means we it is pointing to a brand country dummy in our case
    assert(max(temp_2) == 1 & min(temp_2) == 0);
    % take homogenous home preference out only
    beta_noFDISpec= beta_hat; 
    beta_noFDISpec(m.startBCdums:m.endBCdums) = beta_hat(m.startBCdums:m.endBCdums) - homeassP_est*temp_2'; % just take local preference away from cases we are interested in
    
    %Set Names, and Costs don't change at all
    counterRes(idx).name = 'NoFDI (noAsmP-noPlant, Cases, Agg)';
    counterRes(idx).nameprint = 'NoFDI (noAsmP-noPlant, Cases, Agg)';
    counterRes(idx).descr = '(Aggressive!) Remove local preference and local plant for (a selected set of) foreign firms in some markets';
    counterRes(idx).Dlin           = beta_noFDISpec;
    counterRes(idx).Dnonlin        = D_nonlin_hat;
    counterRes(idx).DShocks        = DShocks;
    counterRes(idx).Clin           = cost_Lin_hat;
    counterRes(idx).Cnonlin        = cost_Nonlin_hat;
    counterRes(idx).CShocks        = costShocks;
    noFDI = 0; % No this noFDI, but use revised costM:
    costM_noFDI = newAssembly(costM, ind_case, 1); % third input: aggressive_ind=1
    [log_cost_func, counterRes(idx).assemblyShares] = predict_counterfactual_cost_outcomes_func(counterRes(idx).CShocks, counterRes(idx).Clin, counterRes(idx).Cnonlin, costM_noFDI, 1, est_results_cost_side.fxdum, est_results_cost_side.sealand,est_results_cost_side.geo, noFDI,c2str, m.mktCode); % note that this counterfactual is coded such that est_results_cost_side.tariff=1 is passed here, but the relevant tariff component is adjusted above
    counterRes(idx).cost = exp(log_cost_func);

    %Recalculate Equilibrium...
    [counterRes(idx).price, counterRes(idx).share] = getPriceEquilibrium(counterRes(idx).Dnonlin, counterRes(idx).Dlin, counterRes(idx).DShocks, counterRes(idx).cost, m);

 %% Counterfactual 14.4: (Aggressive!) Remove foreign assembly plant for (a selected set of) foreign firms in some markets
idx = idx + 1;
display('Counterfactual 14.4:  (Aggressive!) Remove  foreign assembly plant for (a selected set of) foreign firms in some markets...')

% identify the set of cases we want to look at:
    % Toyota in US 
    ind_1 = (m.ctyCode == 9) & (m.firmCode == 26);
    % Ford in German
    ind_2 = (m.ctyCode == 4) & (m.firmCode == 8);
   
    ind_case = ind_1 | ind_2; % pool all cases together 
    
    %Set Names, and Costs don't change at all
    counterRes(idx).name = 'NoFDI (noPlant, Cases, Agg)';
    counterRes(idx).nameprint = 'NoFDI (noPlant, Cases, Agg)';
    counterRes(idx).descr = '(Aggressive!) Remove local plant for (a selected set of) foreign firms in some markets';
    counterRes(idx).Dlin           = beta_hat;
    counterRes(idx).Dnonlin        = D_nonlin_hat;
    counterRes(idx).DShocks        = DShocks;
    counterRes(idx).Clin           = cost_Lin_hat;
    counterRes(idx).Cnonlin        = cost_Nonlin_hat;
    counterRes(idx).CShocks        = costShocks;
    noFDI = 0; % No this noFDI, but use revised costM:
    costM_noFDI = newAssembly(costM, ind_case, 1); % third input: aggressive_ind=1
    [log_cost_func, counterRes(idx).assemblyShares] = predict_counterfactual_cost_outcomes_func(counterRes(idx).CShocks, counterRes(idx).Clin, counterRes(idx).Cnonlin, costM_noFDI, 1, est_results_cost_side.fxdum, est_results_cost_side.sealand,est_results_cost_side.geo, noFDI,c2str, m.mktCode); % note that this counterfactual is coded such that est_results_cost_side.tariff=1 is passed here, but the relevant tariff component is adjusted above
    counterRes(idx).cost = exp(log_cost_func);

    %Recalculate Equilibrium...
    [counterRes(idx).price, counterRes(idx).share] = getPriceEquilibrium(counterRes(idx).Dnonlin, counterRes(idx).Dlin, counterRes(idx).DShocks, counterRes(idx).cost, m);
 
    
%% Clean and save
%save(outputFile, 'counterRes', 'm', 'costM');
save(['..' filesep 'cost_output' filesep outputFile], 'counterRes', 'm', 'costM', 'c2str');
end