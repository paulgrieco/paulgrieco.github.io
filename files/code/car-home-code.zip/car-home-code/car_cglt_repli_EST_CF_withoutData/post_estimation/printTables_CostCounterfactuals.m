function printTables_CostCounterfactuals(tariff_baseline,dummy_baseline,fxrate_baseline,sealand_baseline, geo_baseline,demandresult_name,report_boot_se)

%% Table: cost estimates
%load costresult % this one has both tariff specification to be reported, below we will pick the baseline one for further tables
load(['..' filesep 'cost_output' filesep 'costresult']);

if report_boot_se == 1
    costSEs = [];
    for tar_temp = [0,1]
        for fx_temp = [0,1]
            for sealand_temp = [0]
            for geo_temp = [2]
           bootfilename = sprintf('wBootCostresult_dummies%d_tariff%d_fxrate%d_sealand%d_geo%d.mat',dummy_baseline,tar_temp,fx_temp, sealand_temp,geo_temp);
           load(['..' filesep 'cost_output' filesep bootfilename]);
    
    % NOTE: since we do not have the estimate saved in the loaded file, we
    % use bootSe_parnonlinCost, bootSe_parlinCost to fill the position
    % where should be estimate!!!
          boot_se = [bootSe_parlinCost; bootSe_parnonlinCost];
          [~, costSEs_temp] = reportCoef(bootSe_parnonlinCost, bootSe_parlinCost, boot_se, tar_temp,fx_temp, sealand_temp, geo_temp, 0.01);
          costSEs = [costSEs, costSEs_temp];
            end
            end
        end
    end
end

namevec = {'Distance to HQ Distance, $\delta^{hqdist}$';
    'Tariff, $\zeta$';
    'FX rate, $\delta^{xr}$';
    'Assembly to Market Distance, $\delta^{mdist}$';
    'Assembly to Market Distance (land), $\delta^{mdist}_{land}$';
    'Assembly to Market Distance (sea), $\delta^{mdist}_{sea}$';
    'Domestic Location, $\delta^{dom}$';
    'Contiguous Location, $\delta^{ctg}$';
    'Same Land, $\delta^{same}$';
    'Horsepower, $\kappa^{hp}$';
    'Weight, $\kappa^{wt}$';
    'Size, $\kappa^{sz}$';
    'Miles per Gallon, $\kappa^{mg}$'};


%delete results_costEstimates.txt
fid = fopen(['..' filesep 'cost_output' filesep 'results_costEstimates.txt'], 'wt');
     
fprintf(fid, '\\begin{table}[t] \n'); 
fprintf(fid, '\\begin{center} \n');
fprintf(fid, '\\caption{Cost Estimates}\n');
fprintf(fid, '\\begin{tabular}{@{}l');
for i = 1:size(costSpecs,2)
    fprintf(fid, 'c');
end
fprintf(fid, '} \n');
fprintf(fid, '\\hline \n');
fprintf(fid, '\\hline \n');
fprintf(fid, '%s','Variable');
    for j = 1:size(costSpecs,2)
        fprintf(fid, '&%4.0f', j);
    end
fprintf(fid, '\\\\ \n');
fprintf(fid, '\\hline \n');

for i = 1:length(namevec)
    fprintf(fid, '%s ', namevec{i} );
    for j = 1:size(costSpecs,2)
        fprintf(fid, '&%4.3f', costCOEFs(i,j) );
    end
    fprintf(fid, '\\\\ \n');
    fprintf(fid, '%s', '' );
    for j = 1:size(costSpecs,2)
        fprintf(fid, '&\\footnotesize{(%4.3f)}', costSEs(i,j) );
    end
    fprintf(fid, '\\\\ \n');
end  
fprintf(fid, '\\hline \n');
for i = 1:length(specnamevec)
    fprintf(fid, '%s', specnamevec{i} );
    for j = 1:size(costSpecs,2)
        fprintf(fid, '&%4.3f', costSpecs(i,j) );
    end
    fprintf(fid, '\\\\ \n');
end
fprintf(fid, '\\hline \n');
fprintf(fid, '\\hline \n');
fprintf(fid, '\\end{tabular} \n');
fprintf(fid, '\\end{center} \n');
fprintf(fid, '\\end{table} \n');
fclose(fid);

clearvars -except tariff_baseline dummy_baseline fxrate_baseline demandresult_name  sealand_baseline  geo_baseline

%% setup the baseline case (data/original estimate)
load(demandresult_name)
c2str = mainout.c2str;

clearvars -except c2str tariff_baseline dummy_baseline fxrate_baseline  sealand_baseline  geo_baseline

myfilename = sprintf('counterScenarios_spec_dummies%d_tariff%d_fxrate%d_sealand%d_geo%d.mat',dummy_baseline,tariff_baseline,fxrate_baseline,sealand_baseline, geo_baseline);
load(['..' filesep 'cost_output' filesep myfilename]); 

% number of effective key nonlinear parameters
numcostvar           = (1) + (tariff_baseline + fxrate_baseline) + ( 1 + sealand_baseline) + 2*(geo_baseline==1) ...
                                                                 + 1*(geo_baseline==2) ...
                                                                 + 2*(geo_baseline==3) ... % was 3 -- a bug???
                                                                 + 1*(geo_baseline==5) ...
                                                                 + 3*(geo_baseline==6); % number of geographical variables
                                                             
% trade cost due to external shipping 
tradeCost_perc_mkt = tradeCost_noReallocation(costM, counterRes(1).assemblyShares, costM.sigma_v*counterRes(1).Cnonlin(1:numcostvar) ,0,tariff_baseline,fxrate_baseline,sealand_baseline, geo_baseline);

% trade cost due to distance to HQ
tradeCost_perc_hq  = tradeCost_noReallocation(costM, counterRes(1).assemblyShares, costM.sigma_v*counterRes(1).Cnonlin(1:numcostvar) ,1,tariff_baseline,fxrate_baseline,sealand_baseline, geo_baseline);

%% Table: Weighted average external shipping cost
firm_names_set = m.firm_names_for_markups;
temp_code      = 1:m.nFirms;
firmCodeShow   = zeros(1,length(firm_names_set));
for i = 1:length(firm_names_set)
    firm_code_temp  = strcmp(firm_names_set(i),c2str.Firms);
    firmCodeShow(i) = temp_code(firm_code_temp);
end

nShow        = length(firmCodeShow);
TC_mkt_mat   = ones(nShow,m.nCtys);
TC_hq_mat    = ones(nShow,m.nCtys);
tariff_mat = ones(nShow,m.nCtys);

% load tariff data
% costfilename = sprintf('costdata');
% load(['..' filesep 'cost_code' filesep costfilename],'tariff_market_country*'); 
% tariff_mkt_cty = [tariff_market_country1, tariff_market_country2, tariff_market_country3,tariff_market_country4, tariff_market_country5, ...
%                          tariff_market_country6, tariff_market_country7, tariff_market_country8,tariff_market_country9, tariff_market_country10, ...
%                          tariff_market_country11, tariff_market_country12, tariff_market_country13,tariff_market_country14, tariff_market_country15];
%
% This is the tariff paid by each model, just the same format as TC_hq_mat
assemblyShares_extend = [counterRes(1).assemblyShares,zeros(m.nObs,1) ]; % the last one of for the number 51
for i = 1:m.nObs
     assemblyShares_mkt_cty(i,:) = assemblyShares_extend(i,costM.location_code(i,:));
end
tariff_mkt_agg = nansum(costM.tariff_assembly_market.*assemblyShares_mkt_cty,2); % sum over assembly locations

for f = 1:nShow
    fCode = firmCodeShow(f);
    for c = 1:m.nCtys
        idShow = m.firmCode == fCode & m.ctyCode == c;
        % take weighted averages by market
        TC_mkt_mat(f,c) = sum(tradeCost_perc_mkt(idShow).*(m.sales(idShow)./sum(m.sales(idShow))));
        TC_hq_mat(f,c) = sum(tradeCost_perc_hq(idShow).*(m.sales(idShow)./sum(m.sales(idShow))));   
        tariff_mat(f,c) = sum(tariff_mkt_agg(idShow).*(m.sales(idShow)./sum(m.sales(idShow))));   
    end
end

% print external shipping costs -- table 1
%delete results_extShipCost.txt
myfilename = sprintf('results_extShipCost_dum%d_tar%d_fx%d_sealand%d_geo%d.txt',dummy_baseline,tariff_baseline,fxrate_baseline,sealand_baseline,geo_baseline);
fid = fopen(['..' filesep 'cost_output' filesep myfilename],'wt');
 % First print the head ...     
fprintf(fid, '\\begin{table}[t] \n'); 
fprintf(fid, '\\begin{center} \n');
fprintf(fid, '\\caption{Weighted average external shipping cost (assembly to market, including domestic and contiguity effects) in overall cost for firms across markets}\n');
fprintf(fid, '\\begin{tabular}{@{}l|ccccccccc} \n');
fprintf(fid, '\\hline \n');
fprintf(fid, '\\hline \n');
  
for i = 1:m.nCtys
    fprintf(fid, '&%s', c2str.Ctys{i});
end
fprintf(fid, '\\\\\n' );
    
fprintf(fid, '\\hline \n');
%Print main content
for i = 1:nShow
    fprintf(fid, '%s ', c2str.Firms{firmCodeShow(i)} );    
        fprintf(fid, '  &%4.1f&%4.1f &%4.1f&%4.1f&%4.1f&%4.1f&%4.1f&%4.1f &%4.1f\\\\ \n', TC_mkt_mat(i,:)*100  );
end
    
fprintf(fid, '\\hline \n');
fprintf(fid, '\\hline \n');
fprintf(fid, '\\end{tabular} \n');
fprintf(fid, '\\end{center} \n');
fprintf(fid, '\\end{table} \n');
fclose(fid);       

%% print remote production costs -- table 2
%delete results_remoteProdCost.txt
myfilename = sprintf('results_remoteProdCost_dum%d_tar%d_fx%d_sealand%d_geo_%d.txt',dummy_baseline,tariff_baseline,fxrate_baseline,sealand_baseline,geo_baseline);
fid = fopen(['..' filesep 'cost_output' filesep myfilename],'wt');
 % First print the head ...     
fprintf(fid, '\\begin{table}[t] \n'); 
fprintf(fid, '\\begin{center} \n');
fprintf(fid, '\\caption{Weight average remote production cost (assembly to HQ) in overall cost for firms across markets} \n');
fprintf(fid, '\\begin{tabular}{@{}l|ccccccccc} \n');
fprintf(fid, '\\hline \n');
fprintf(fid, '\\hline \n');
  
for i = 1:m.nCtys
    fprintf(fid, '&%s', c2str.Ctys{i});
end
fprintf(fid, '\\\\\n' );
    
fprintf(fid, '\\hline \n');
%Print main content
for i = 1:nShow
    fprintf(fid, '%s ', c2str.Firms{firmCodeShow(i)} );    
        fprintf(fid, '  &%4.1f&%4.1f &%4.1f&%4.1f&%4.1f&%4.1f&%4.1f&%4.1f &%4.1f\\\\ \n', TC_hq_mat(i,:)*100  );
end
    
fprintf(fid, '\\hline \n');
fprintf(fid, '\\hline \n');
fprintf(fid, '\\end{tabular} \n');
fprintf(fid, '\\end{center} \n');
fprintf(fid, '\\end{table} \n');
fclose(fid); 

% %% print tariff paid by each brand -- table 3
% myfilename = sprintf('results_tariffpaid_dum%d_tar%d_fx%d_sealand%d_geo_%d.txt',dummy_baseline,tariff_baseline,fxrate_baseline,sealand_baseline,geo_baseline);
% fid = fopen(['..' filesep 'cost_output' filesep myfilename],'wt');
%  % First print the head ...     
% fprintf(fid, '\\begin{table}[t] \n'); 
% fprintf(fid, '\\begin{center} \n');
% fprintf(fid, '\\caption{Tariff Paid (share weighted) by firms across markets} \n');
% fprintf(fid, '\\begin{tabular}{@{}l|ccccccccc} \n');
% fprintf(fid, '\\hline \n');
% fprintf(fid, '\\hline \n');
%   
% for i = 1:m.nCtys
%     fprintf(fid, '&%s', c2str.Ctys{i});
% end
% fprintf(fid, '\\\\\n' );
%     
% fprintf(fid, '\\hline \n');
% %Print main content
% for i = 1:nShow
%     fprintf(fid, '%s ', c2str.Firms{firmCodeShow(i)} );    
%         fprintf(fid, '  &%4.1f&%4.1f &%4.1f&%4.1f&%4.1f&%4.1f&%4.1f&%4.1f &%4.1f\\\\ \n', tariff_mat(i,:)*100  );
% end
%     
% fprintf(fid, '\\hline \n');
% fprintf(fid, '\\hline \n');
% fprintf(fid, '\\end{tabular} \n');
% fprintf(fid, '\\end{center} \n');
% fprintf(fid, '\\end{table} \n');
% fclose(fid); 


%% Print table: Home market advantage under counterfactual scenarios
coef = ones(1,size(counterRes,2));

CtyYearD      = dummyvar(m.mktCode);
BrandD        = dummyvar(m.brandCode);
BrandD(:,end) = [];
ModelD        = dummyvar(m.modelCode);
ModelD(:,end) = [];
%X             = [m.homedummy CtyYearD BrandD ];
X             = [m.homedummy CtyYearD ModelD ];

%%%%%%%%%%% Use another projection:
 load(['..' filesep 'cost_code' filesep 'costdata.mat'],'domesticassemblybybranddummy');
 X_wAsm             = [m.homedummy domesticassemblybybranddummy CtyYearD ModelD ];

for i = 1:size(counterRes,2)
   Y = log(counterRes(i).share);
   %est = (X'*X)\(X'*Y);
   [est, std] = lscov(X,Y);
   coef(i) = est(1); 
   coef_std(i) = std(1);
   
   [est_wAsm, std_wAsm] = lscov(X_wAsm,Y);
   coef_wAsm(i,:) = est_wAsm([1,2]); 
   coef_std_wAsm(i,:) = std_wAsm([1,2]);
   
end

mktShGap = ( exp(coef - 0.5*coef_std.^2) -1 )./( exp(coef(1) - 0.5*coef_std(1).^2) -1) - 1; % this is the market share gap induced by the coefficient.

%coef = coef/coef(1);  % normalize by the baseline (or show the raw coefficient)

myfilename = sprintf('results_homeAdvCounterfactuals_dum%d_tar%d_fx%d_sealand%d_geo_%d.txt',dummy_baseline,tariff_baseline,fxrate_baseline,sealand_baseline,geo_baseline);
fid = fopen(['..' filesep 'cost_output' filesep myfilename],'wt');
 % First print the head ...     
fprintf(fid, '\\begin{table}[t] \n'); 
fprintf(fid, '\\begin{center} \n');
fprintf(fid, '\\caption{Home market advantage under counterfactual scenarios} \n');
fprintf(fid, '\\begin{tabular}{@{}lccc|cc} \n'); % scenario, empty column, coefficient
fprintf(fid, '\\hline \n');
fprintf(fid, '\\hline \n');
fprintf(fid, ' %s &  & %s  & %s  & %s  & %s \\\\ \n', 'Scenario', 'Coefficient', 'Market Share Gap', 'Coef (home)', 'Coef (Asm)');
fprintf(fid, '\\hline \n');
for i = 1:size(counterRes,2)
    fprintf(fid, '%s &  & %4.2f & %4.1f & %4.2f & %4.2f \\\\ \n', counterRes(i).nameprint,  coef(i), 100*mktShGap(i), coef_wAsm(i,:));    
end
fprintf(fid, '\\hline \n');
fprintf(fid, '\\hline \n');
fprintf(fid, '\\end{tabular} \n');
fprintf(fid, '\\end{center} \n');
fprintf(fid, '\\end{table} \n');
fclose(fid);

%% Print table: Value of Domestic Status for Foreign Brands 

% This part is the same as the runCounterfactuals (not sure there is a better way to store the information somewhere, so we set it up here again).
% First, identify the set of cases we want to look at:
    % Seat in Spain (VW)
    ind_1 = (m.mktCode >=17  & m.mktCode <=21) & (m.brandCode == 50);
    assert(length(unique(m.firmCode(ind_1))) == 1); % make sure it is from a single firm -- we did not mess things up
    % Vauxhall in UK (GM)
    ind_2 = (m.mktCode >=27  & m.mktCode <=31) & (m.brandCode == 59);
    assert(length(unique(m.firmCode(ind_2))) == 1); 
    % Chrysler in US (Fiat)
    ind_3 = (m.mktCode >=37  & m.mktCode <=41) & (m.brandCode == 10);
    assert(length(unique(m.firmCode(ind_3))) == 1); 
    % Opel  in Germany (GM)
    ind_4 = (m.mktCode >=12  & m.mktCode <=16) & (m.brandCode == 39);
    assert(length(unique(m.firmCode(ind_4))) == 1); 
    
    % Four more cases (largest home brand)
    % VW in DEU
    ind_5 = (m.mktCode >=12  & m.mktCode <=16) & (m.brandCode == 58);
    assert(length(unique(m.firmCode(ind_5))) == 1); 
    % Renault in FRA
    ind_6 = (m.mktCode >=22  & m.mktCode <=26) & (m.brandCode == 45);
    assert(length(unique(m.firmCode(ind_6))) == 1); 
    % Fiat in ITA
    ind_7 = (m.mktCode >=32  & m.mktCode <=36) & (m.brandCode == 16);
    assert(length(unique(m.firmCode(ind_7))) == 1); 
    % Chevrolet in US
    ind_8 = (m.mktCode >=37  & m.mktCode <=41) & (m.brandCode == 9);
    assert(length(unique(m.firmCode(ind_8))) == 1); 
    
%     caseName = {'Seat in Spain (VW)', 'Vauxhall in UK (GM)', 'Chrysler in US (Fiat)', 'Opel  in Germany (GM)'};
%     caseInd = {ind_1, ind_2, ind_3, ind_4}; % the indicator of cars of interest for each case
    
    caseName = {'Seat in Spain (VW)', 'Vauxhall in UK (GM)', 'Chrysler in US (Fiat)', 'Opel  in Germany (GM)', ...
        'VW in DEU', 'Renault in FRA', 'Fiat in ITA', 'Chevrolet in US'};
    caseInd = {ind_1, ind_2, ind_3, ind_4, ind_5, ind_6, ind_7, ind_8}; % the indicator of cars of interest for each case
    
    % Second, calculate the profit/share/markup changes for the brand of
    % interest.
    nCase        = length(caseName);
    share_change   = ones(nCase,1);
    markup_change   = ones(nCase,1);
    profit_change   = ones(nCase,1);

    %baseline_idx = 1; % the baseline is always the first one
    for i = 1: length(counterRes) % now find the index for this counterfactual
        if strcmp(counterRes(i).name, 'ForeignLossHomeAdv')
            thisCF_idx = i;
        end
    end
    
for c = 1:nCase
    this_ind = caseInd{c};
    % take weighted averages by baseline shares
    share_change(c) = sum( (counterRes(thisCF_idx).share(this_ind) - counterRes(1).share(this_ind) ) .*(m.sales(this_ind)./sum(m.sales(this_ind))));
    share_baseline_weighted(c) = sum( counterRes(1).share(this_ind)  .*(m.sales(this_ind)./sum(m.sales(this_ind))));
    share_thisCF_weighted(c) = sum( counterRes(thisCF_idx).share(this_ind)  .*(m.sales(this_ind)./sum(m.sales(this_ind))) );
    share_baseline_total(c) = sum( counterRes(1).share(this_ind)  ) ./ length(unique(m.mktCode(this_ind))); % this is the total in each market year (on average):  note that we have divided by the number of years
    share_thisCF_total(c) = sum( counterRes(thisCF_idx).share(this_ind)  )  ./ length(unique(m.mktCode(this_ind)));
    
    markup_baseline  = (counterRes(1).price(this_ind) - counterRes(1).cost(this_ind))./counterRes(1).cost(this_ind);
    markup_thisCF  = (counterRes(thisCF_idx).price(this_ind) - counterRes(thisCF_idx).cost(this_ind))./counterRes(thisCF_idx).cost(this_ind);
    markup_change(c) = sum( (markup_thisCF - markup_baseline) .*(m.sales(this_ind)./sum(m.sales(this_ind))) );
    markup_baseline_weighted(c) = sum( markup_baseline .*(m.sales(this_ind)./sum(m.sales(this_ind))) ) ;
    markup_thisCF_weighted(c) = sum( markup_thisCF .*(m.sales(this_ind)./sum(m.sales(this_ind))) );
    
    mkt_size = m.sales./m.share;
    profit_baseline = (counterRes(1).price(this_ind) - counterRes(1).cost(this_ind)).*counterRes(1).share(this_ind) .* mkt_size(this_ind);
    profit_thisCF  = (counterRes(thisCF_idx).price(this_ind) - counterRes(thisCF_idx).cost(this_ind)).*counterRes(thisCF_idx).share(this_ind) .* mkt_size(this_ind);
    profit_change(c) = sum( (profit_thisCF - profit_baseline) .*(m.sales(this_ind)./sum(m.sales(this_ind))) );
    profit_baseline_total(c) = sum( profit_baseline)  ./ length(unique(m.mktCode(this_ind)));
    profit_thisCF_total(c) = sum( profit_thisCF)  ./ length(unique(m.mktCode(this_ind)));
    profit_total_change(c) = (profit_thisCF_total(c) - profit_baseline_total(c))/profit_baseline_total(c);
    
    quantity_baseline = counterRes(1).share(this_ind) .* mkt_size(this_ind);
    quantity_thisCF  = counterRes(thisCF_idx).share(this_ind) .* mkt_size(this_ind);
    quantity_change(c) = sum( (quantity_thisCF - quantity_baseline) .*(m.sales(this_ind)./sum(m.sales(this_ind))) );
    quantity_baseline_total(c) = sum( quantity_baseline)  ./ length(unique(m.mktCode(this_ind)));
    quantity_thisCF_total(c) = sum( quantity_thisCF)  ./ length(unique(m.mktCode(this_ind)));
    quantity_total_change(c) = (quantity_thisCF_total(c) - quantity_baseline_total(c))/quantity_baseline_total(c);
    
    price_baseline_weighted(c) = sum( counterRes(1).price(this_ind) .*(m.sales(this_ind)./sum(m.sales(this_ind))) ) ;
    price_thisCF_weighted(c) = sum( counterRes(thisCF_idx).price(this_ind) .*(m.sales(this_ind)./sum(m.sales(this_ind))) );
    price_weighted_change(c) = (price_thisCF_weighted(c) - price_baseline_weighted(c))/price_baseline_weighted(c);
end

myfilename = sprintf('results_ForeignLossHomeAdv_dum%d_tar%d_fx%d_sealand%d_geo_%d.txt',dummy_baseline,tariff_baseline,fxrate_baseline,sealand_baseline,geo_baseline);
fid = fopen(['..' filesep 'cost_output' filesep myfilename],'wt');
 % First print the head ...     
fprintf(fid, '\\begin{table}[t] \n'); 
fprintf(fid, '\\begin{center} \n');
fprintf(fid, '\\caption{Changes if Foreign Brands loss their Domestic Status} \n');
fprintf(fid, '\\begin{tabular}{@{}lccc} \n'); % scenario, empty column, coefficient
fprintf(fid, '\\hline \n');
fprintf(fid, '\\hline \n');
%fprintf(fid, ' %s &   %s & %s & %s &   %s & %s & %s  \\\\ \n', 'Case', 'Data Share', 'CF Share', 'Data Markup', 'CF Markup', 'Data Profit', 'CF Profit');
fprintf(fid, ' %s &   %s & %s & %s    \\\\ \n', 'Case', 'Weighted Price Change',  'Total Quantity Change',  'Total Profit Change' );
fprintf(fid, '\\hline \n');
for i = 1:nCase
    fprintf(fid, '%s   & %4.1f & %4.1f  & %4.1f  \\\\ \n', caseName{i},  100*price_weighted_change(i), 100*quantity_total_change(i), 100*profit_total_change(i));    
end
fprintf(fid, '\\hline \n');
fprintf(fid, '\\hline \n');
fprintf(fid, '\\end{tabular} \n');
fprintf(fid, '\\end{center} \n');
fprintf(fid, '\\end{table} \n');
fclose(fid);


%% Value of local production: Eliminate Local Production Preference, present a Brand x Country table that shows the impact on variable profits. 
change_report  = [];

[profit_total_change, quantity_total_change, price_weighted_change] = localProdValue(counterRes, m,  c2str, 'NoFDI (noAsmP, Cases)',dummy_baseline,tariff_baseline,fxrate_baseline,sealand_baseline,geo_baseline);
% Note that the following part is hard coded: the case of Ford in DEU and
% Toyota in US:
profit_change_Ford_DEU = profit_total_change(17,4);
quantity_change_Ford_DEU = quantity_total_change(17,4);
price_change_Ford_DEU = price_weighted_change(17,4);
profit_change_Toyota_US = profit_total_change(57,9);
quantity_change_Toyota_US = quantity_total_change(57,9);
price_change_Toyota_US = price_weighted_change(57,9);

change_report = [change_report; price_change_Toyota_US, quantity_change_Toyota_US, profit_change_Toyota_US];
change_report = [change_report; price_change_Ford_DEU, quantity_change_Ford_DEU, profit_change_Ford_DEU];

[profit_total_change, quantity_total_change, price_weighted_change] = localProdValue(counterRes, m,  c2str, 'NoFDI (noPlant, Cases, Agg)',dummy_baseline,tariff_baseline,fxrate_baseline,sealand_baseline,geo_baseline);
% Note that the following part is hard coded: the case of Ford in DEU and
% Toyota in US:
profit_change_Ford_DEU = profit_total_change(17,4);
quantity_change_Ford_DEU = quantity_total_change(17,4);
price_change_Ford_DEU = price_weighted_change(17,4);
profit_change_Toyota_US = profit_total_change(57,9);
quantity_change_Toyota_US = quantity_total_change(57,9);
price_change_Toyota_US = price_weighted_change(57,9);

change_report = [change_report; price_change_Toyota_US, quantity_change_Toyota_US, profit_change_Toyota_US];
change_report = [change_report; price_change_Ford_DEU, quantity_change_Ford_DEU, profit_change_Ford_DEU];

[profit_total_change, quantity_total_change, price_weighted_change] = localProdValue(counterRes, m,  c2str, 'NoFDI (noAsmP-noPlant, Cases, Agg)',dummy_baseline,tariff_baseline,fxrate_baseline,sealand_baseline,geo_baseline);
% Note that the following part is hard coded: the case of Ford in DEU and
% Toyota in US:
profit_change_Ford_DEU = profit_total_change(17,4);
quantity_change_Ford_DEU = quantity_total_change(17,4);
price_change_Ford_DEU = price_weighted_change(17,4);
profit_change_Toyota_US = profit_total_change(57,9);
quantity_change_Toyota_US = quantity_total_change(57,9);
price_change_Toyota_US = price_weighted_change(57,9);

change_report = [change_report; price_change_Toyota_US, quantity_change_Toyota_US, profit_change_Toyota_US];
change_report = [change_report; price_change_Ford_DEU, quantity_change_Ford_DEU, profit_change_Ford_DEU];

% print the table:
change_report = 100*change_report;
scenario_name = {'No local assembly preference (Ford plants in Germany)';
'No local assembly preference (Toyota plants in US)';
'Only cost effect (Ford plants in Germany)';
'Only cost effect  (Toyota plants in US)';
'Combined  (Ford plants in Germany)';
'Combined  (Toyota plants in US)'};

myfilename = sprintf('results_demand_cost_effects_FDI%d_tar%d_fx%d_sealand%d_geo_%d.txt',dummy_baseline,tariff_baseline,fxrate_baseline,sealand_baseline,geo_baseline);
fid = fopen(['..' filesep 'cost_output' filesep myfilename],'wt');
 % First print the head ...     
fprintf(fid, '\\begin{table}[t] \n'); 
fprintf(fid, '\\begin{center} \n');
fprintf(fid, '\\caption{Demand and cost effects of FDI for selected brands} \n');
fprintf(fid, '\\begin{tabular}{@{}lccc} \n'); % scenario, empty column, coefficient
fprintf(fid, '\\hline \n');
fprintf(fid, '\\hline \n');
fprintf(fid, ' %s &    %s  & %s & %s  \\\\ \n', 'Scenario', 'Price', 'Quantity', 'Profit');
fprintf(fid, '\\hline \n');
for i = 1:size(change_report,1)
    fprintf(fid, '%s &    %4.1f & %4.1f & %4.1f \\\\ \n', scenario_name{i},  change_report(i,:));    
end
fprintf(fid, '\\hline \n');
fprintf(fid, '\\hline \n');
fprintf(fid, '\\end{tabular} \n');
fprintf(fid, '\\end{center} \n');
fprintf(fid, '\\end{table} \n');
fclose(fid);

%% Print table: Welfare implications of FDI
% We want the % changes in (pre-share weighted) prices and overall consumer welfare in each country.

% first we calculate the consumer surplus: ECV is in the absolute value
% (dollar).
parnonlin_baseline = counterRes(1).Dnonlin;
p_baseline = counterRes(1).price;
DShocks_baseline =  counterRes(1).DShocks;
Dlin_baseline = counterRes(1).Dlin;

    for i = 1: length(counterRes) % now find the index for this counterfactual
        if strcmp(counterRes(i).name, 'NoFDI')
            thisCF_idx = i;
        end
    end
parnonlin_thisCF = counterRes(thisCF_idx).Dnonlin;
p_thisCF = counterRes(thisCF_idx).price;
DShocks_thisCF =  counterRes(thisCF_idx).DShocks;
Dlin_thisCF = counterRes(thisCF_idx).Dlin;

delta_baseline = constructDelta(Dlin_baseline, p_baseline, DShocks_baseline, m); % retrive delta
delta_thisCF = constructDelta(Dlin_thisCF, p_thisCF, DShocks_thisCF, m); % retrive delta

[ ECV, ~, ~] = getECV(parnonlin_baseline,delta_baseline, p_baseline, parnonlin_thisCF,delta_thisCF, p_thisCF, m);

% organize ECV for print
ECV_avg = ones(1,m.nCtys);
for i = 1:m.nCtys
    temp1 = [m.mktCode, m.ctyCode];
    temp2 = unique(temp1,'rows');
    ctyInd = (temp2(:,2) == i);
    ECV_avg(i) = mean(ECV(ctyInd));
end

% organize price changes for print
price_change_avg = ones(1,m.nCtys);
for i = 1:m.nCtys
    ctyInd = (m.ctyCode== i);
    price_change = (p_thisCF(ctyInd) - p_baseline(ctyInd))./p_baseline(ctyInd); % the change is in percentage
    price_change_avg(i) = sum(price_change.*(m.sales(ctyInd)./sum(m.sales(ctyInd))) ); % use the share-weighted average
end

% myfilename = sprintf('results_NoFDIAllowed_dum%d_tar%d_fx%d_sealand%d_geo_%d.txt',dummy_baseline,tariff_baseline,fxrate_baseline,sealand_baseline,geo_baseline);
% fid = fopen(['..' filesep 'cost_output' filesep myfilename],'wt');
%  % First print the head ...     
% fprintf(fid, '\\begin{table}[t] \n'); 
% fprintf(fid, '\\begin{center} \n');
% fprintf(fid, '\\caption{Changes of prices and overall consumer welfare when no FDI is allowed} \n');
% fprintf(fid, '\\begin{tabular}{@{}lccccccccc} \n'); % scenario, empty column, coefficient
% fprintf(fid, '\\hline \n');
% 
%     for i = 1:m.nCtys
%         fprintf(fid, '&%s', c2str.Ctys{i});
%     end
% fprintf(fid, '\\\\\n' );
% fprintf(fid, '\\hline \n');
% fprintf(fid, '%s   & %4.2f & %4.2f  & %4.2f & %4.2f & %4.2f  & %4.2f & %4.2f & %4.2f  & %4.2f \\\\ \n', 'Price Change',  100*price_change_avg);    % in percentage
% fprintf(fid, '%s   & %4.0f & %4.0f  & %4.0f & %4.0f & %4.0f  & %4.0f & %4.0f & %4.0f  & %4.0f \\\\ \n', 'Consumer Welfare Change',  10000*ECV_avg);    % in USD
% 
% fprintf(fid, '\\hline \n');
% fprintf(fid, '\\hline \n');
% fprintf(fid, '\\end{tabular} \n');
% fprintf(fid, '\\end{center} \n');
% fprintf(fid, '\\end{table} \n');
% fclose(fid);

% %% Print table: Welfare implications of FDI -- the alternative
% % We want the % changes in (pre-share weighted) prices and overall consumer welfare in each country.
% 
% % first we calculate the consumer surplus: ECV is in the absolute value
% % (dollar).
% parnonlin_baseline = counterRes(1).Dnonlin;
% p_baseline = counterRes(1).price;
% DShocks_baseline =  counterRes(1).DShocks;
% Dlin_baseline = counterRes(1).Dlin;
% 
%     for i = 1: length(counterRes) % now find the index for this counterfactual
%         if strcmp(counterRes(i).name, 'NoFDI_NewPant')
%             thisCF_idx = i;
%         end
%     end
% parnonlin_thisCF = counterRes(thisCF_idx).Dnonlin;
% p_thisCF = counterRes(thisCF_idx).price;
% DShocks_thisCF =  counterRes(thisCF_idx).DShocks;
% Dlin_thisCF = counterRes(thisCF_idx).Dlin;
% 
% delta_baseline = constructDelta(Dlin_baseline, p_baseline, DShocks_baseline, m); % retrive delta
% delta_thisCF = constructDelta(Dlin_thisCF, p_thisCF, DShocks_thisCF, m); % retrive delta
% 
% [ ECV, ~, ~] = getECV(parnonlin_baseline,delta_baseline, p_baseline, parnonlin_thisCF,delta_thisCF, p_thisCF, m);
% 
% % organize ECV for print
% ECV_avg = ones(1,m.nCtys);
% for i = 1:m.nCtys
%     temp1 = [m.mktCode, m.ctyCode];
%     temp2 = unique(temp1,'rows');
%     ctyInd = (temp2(:,2) == i);
%     ECV_avg(i) = mean(ECV(ctyInd));
% end
% 
% % organize price changes for print
% price_change_avg = ones(1,m.nCtys);
% for i = 1:m.nCtys
%     ctyInd = (m.ctyCode== i);
%     price_change = (p_thisCF(ctyInd) - p_baseline(ctyInd))./p_baseline(ctyInd); % the change is in percentage
%     price_change_avg(i) = sum(price_change.*(m.sales(ctyInd)./sum(m.sales(ctyInd))) ); % use the share-weighted average
% end
% 
% myfilename = sprintf('results_NoFDIAllowed_NewPlant_dum%d_tar%d_fx%d.txt',dummy_baseline,tariff_baseline,fxrate_baseline);
% fid = fopen(['..' filesep 'cost_output' filesep myfilename],'wt');
%  % First print the head ...     
% fprintf(fid, '\\begin{table}[t] \n'); 
% fprintf(fid, '\\begin{center} \n');
% fprintf(fid, '\\caption{Changes of prices and overall consumer welfare when no FDI is allowed} \n');
% fprintf(fid, '\\begin{tabular}{@{}lccccccccc} \n'); % scenario, empty column, coefficient
% fprintf(fid, '\\hline \n');
% 
%     for i = 1:m.nCtys
%         fprintf(fid, '&%s', c2str.Ctys{i});
%     end
% fprintf(fid, '\\\\\n' );
% fprintf(fid, '\\hline \n');
% fprintf(fid, '%s   & %4.2f & %4.2f  & %4.2f & %4.2f & %4.2f  & %4.2f & %4.2f & %4.2f  & %4.2f \\\\ \n', 'Price Change',  100*price_change_avg);    % in percentage
% fprintf(fid, '%s   & %4.0f & %4.0f  & %4.0f & %4.0f & %4.0f  & %4.0f & %4.0f & %4.0f  & %4.0f \\\\ \n', 'Consumer Welfare Change',  10000*ECV_avg);    % in USD
% 
% fprintf(fid, '\\hline \n');
% fprintf(fid, '\\hline \n');
% fprintf(fid, '\\end{tabular} \n');
% fprintf(fid, '\\end{center} \n');
% fprintf(fid, '\\end{table} \n');
% fclose(fid);

%% Appendix tables: market shares and markups by brand nationality
print_abs_share_change(counterRes,m,c2str,dummy_baseline,tariff_baseline,fxrate_baseline,sealand_baseline, geo_baseline); % print the table (similar to the below but with more detailed breakdown of nationality)


for i=1:size(counterRes,2)
    [labels,shares(:,i)] = grpstats(counterRes(i).share,{m.ctyCode,m.brandcty},{'gname','sum'});
    [~,markups(:,i)] = grpstats(counterRes(i).share.*(counterRes(i).price-counterRes(i).cost)./counterRes(i).cost,{m.ctyCode,m.brandcty},{'gname','sum'});
    [~,markups_denominator(:,i)] = grpstats(counterRes(i).share,{m.ctyCode,m.brandcty},{'gname','sum'});    % sum of shares in each group
end
markups = markups./markups_denominator; % divide by the sum of shares in each group to get the "weighted" markups

for i=1:size(counterRes,2)
    [homelabels,homeshares(:,i)] = grpstats(counterRes(i).share,{m.ctyCode,m.homedummy},{'gname','sum'});
    [~,homemarkups(:,i)] = grpstats(counterRes(i).share.*(counterRes(i).price-counterRes(i).cost)./counterRes(i).cost,{m.ctyCode,m.homedummy},{'gname','sum'});
    [~,homemarkups_denominator(:,i)] = grpstats(counterRes(i).share,{m.ctyCode,m.homedummy},{'gname','sum'});    
end
homemarkups = homemarkups./homemarkups_denominator;

clearvars -except labels shares markups counterRes m homeshares homelabels homemarkups dummy_baseline tariff_baseline fxrate_baseline sealand_baseline geo_baseline

% in country codes:
% cty	ctyCode
% BEL	2
% BRA	1
% CAN	3
% DEU	4
% ESP	5
% FRA	6
% GBR	7
% ITA	8
% USA	9

for i=1:size(shares,1)
    if labels{i,1}~=1 || labels{i,1}~=3
        shares(i,:) = shares(i,:)/5;
        markups(i,:) = markups(i,:)/1; % now we do not need to divide by 5 or something since we have done this correctly in the above
    elseif labels{i,1}==1  % brazil has 4 years of data
        shares(i,:) = shares(i,:)/4 ;
        markups(i,:) = markups(i,:)/1 ;
    elseif labels{i,1}==3  % canada has 2 years of data
        shares(i,:) = shares(i,:)/2;
        markups(i,:) = markups(i,:)/1;
    end
end

for i=1:size(homeshares,1)
    if homelabels{i,1}~=1 || homelabels{i,1}~=3
        homeshares(i,:) = homeshares(i,:)/5;
        homemarkups(i,:) = homemarkups(i,:)/1;
    elseif labels{i,1}==1  % brazil has 4 years of data
        homeshares(i,:) = homeshares(i,:)/4 ;
        homemarkups(i,:) = homemarkups(i,:)/1;
    elseif labels{i,1}==3  % canada has 2 years of data
        homeshares(i,:) = homeshares(i,:)/2;
        homemarkups(i,:) = homemarkups(i,:)/1;
    end
end

% collect shares in a matrix with columns showing markets, and rows scenarios
USAshares   = zeros(size(shares,2),m.nCtys);
EUshares    = zeros(size(shares,2),m.nCtys);
JAPshares   = zeros(size(shares,2),m.nCtys);
OTHERshares = zeros(size(shares,2),m.nCtys);
HOMEshares = zeros(size(shares,2),m.nCtys);

for ctycode = 1:m.nCtys
    for i=1:size(shares,1)
        if str2double(labels{i,1}) == ctycode
            if strcmp(labels{i,2},'USA')
                USAshares(:,ctycode) = shares(i,:)';
                USAmarkups(:,ctycode) = markups(i,:)';
            elseif strcmp(labels{i,2},'EU')
                EUshares(:,ctycode)  = shares(i,:)';
                EUmarkups(:,ctycode) = markups(i,:)';
            elseif strcmp(labels{i,2},'JAP')
                JAPshares(:,ctycode)  = shares(i,:)';
                JAPmarkups(:,ctycode) = markups(i,:)';
            elseif strcmp(labels{i,2},'OTHER')
                OTHERshares(:,ctycode)  = shares(i,:)';
                OTHERmarkups(:,ctycode) = markups(i,:)';
            end
        end
    end
end

for ctycode = 1:m.nCtys
    for i=1:size(homeshares,1)
        if str2double(homelabels{i,1}) == ctycode
            if strcmp(homelabels{i,2},'1')
                HOMEshares(:,ctycode) = homeshares(i,:)';
                HOMEmarkups(:,ctycode) = homemarkups(i,:)';
            end
        end
    end
end

USAsharestemp   = zeros(size(shares,2),m.nCtys);
EUsharestemp    = zeros(size(shares,2),m.nCtys);
JAPsharestemp   = zeros(size(shares,2),m.nCtys);
OTHERsharestemp = zeros(size(shares,2),m.nCtys);
HOMEsharestemp = zeros(size(shares,2),m.nCtys);
USAmarkupstemp   = zeros(size(shares,2),m.nCtys);
EUmarkupstemp    = zeros(size(shares,2),m.nCtys);
JAPmarkupstemp   = zeros(size(shares,2),m.nCtys);
OTHERmarkupstemp = zeros(size(shares,2),m.nCtys);
HOMEmarkupstemp = zeros(size(shares,2),m.nCtys);

for i = 1:size(EUshares,1)
    for j=1:size(EUshares,2)
        EUsharestemp(i,j)    = EUshares(i,j)/(EUshares(i,j)+JAPshares(i,j)+OTHERshares(i,j)+USAshares(i,j));
        EUmarkupstemp(i,j)    = 100*EUmarkups(i,j);% /(EUshares(i,j)+JAPshares(i,j)+OTHERshares(i,j)+USAshares(i,j)); % we have taken care of this in the above by using the denominator
        JAPsharestemp(i,j)   = JAPshares(i,j)/(EUshares(i,j)+JAPshares(i,j)+OTHERshares(i,j)+USAshares(i,j));
        JAPmarkupstemp(i,j)   = 100*JAPmarkups(i,j);% /(EUshares(i,j)+JAPshares(i,j)+OTHERshares(i,j)+USAshares(i,j));
        OTHERsharestemp(i,j) = OTHERshares(i,j)/(EUshares(i,j)+JAPshares(i,j)+OTHERshares(i,j)+USAshares(i,j)) ;
        OTHERmarkupstemp(i,j) = 100*OTHERmarkups(i,j);% /(EUshares(i,j)+JAPshares(i,j)+OTHERshares(i,j)+USAshares(i,j)) ;
        USAsharestemp(i,j)   = USAshares(i,j)/(EUshares(i,j)+JAPshares(i,j)+OTHERshares(i,j)+USAshares(i,j));
        USAmarkupstemp(i,j)   = 100*USAmarkups(i,j);% /(EUshares(i,j)+JAPshares(i,j)+OTHERshares(i,j)+USAshares(i,j));
        HOMEsharestemp(i,j)  = HOMEshares(i,j)/(EUshares(i,j)+JAPshares(i,j)+OTHERshares(i,j)+USAshares(i,j));
        HOMEmarkupstemp(i,j)  = 100*HOMEmarkups(i,j);% /(EUshares(i,j)+JAPshares(i,j)+OTHERshares(i,j)+USAshares(i,j));
    end
end

EUshares    =EUsharestemp;
JAPshares   =JAPsharestemp;
OTHERshares =OTHERsharestemp;
USAshares   =USAsharestemp;
HOMEshares  =HOMEsharestemp;
EUmarkups    =EUmarkupstemp;
JAPmarkups   =JAPmarkupstemp;
OTHERmarkups =OTHERmarkupstemp;
USAmarkups   =USAmarkupstemp;
HOMEmarkups  =HOMEmarkupstemp;

clear EUsharestemp JAPsharestemp HOMEsharestemp OTHERsharestemp USAsharestemp homeshares i j ctycode m shares homelabels EUmarkupstemp JAPmarkupstemp OTHERmarkupstemp USAmarkupstemp HOMEmarkupstemp

% shares table
myfilename  = sprintf('results_appendixTable_marketshares_dum%d_tar%d_fx%d_sealand%d_geo_%d.txt',dummy_baseline,tariff_baseline,fxrate_baseline,sealand_baseline,geo_baseline);
fid = fopen(['..' filesep 'cost_output' filesep myfilename],'wt');
 % First print the head ...     
fprintf(fid, '\\begin{table}[t] \n'); 
fprintf(fid, '\\begin{center} \n');
fprintf(fid, '\\caption{Average area-level market share of brands across markets (in percentage)} \n');
fprintf(fid, '\\begin{tabular}{@{}l|ccccccccc} \n'); % scenario, empty column, coefficient
fprintf(fid, '\\hline \n');
fprintf(fid, '\\hline \n');
for i = 1:size(counterRes,2)
    fprintf(fid, '%s & %s & %s & %s & %s & %s & %s & %s & %s & %s  \\\\ \n', counterRes(i).name , 'BRA', 'BEL', 'CAN', 'DEU', 'ESP', 'FRA', 'GBR', 'ITA', 'USA' );
    fprintf(fid, '%s & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f  \\\\ \n', 'US brands',  100*USAshares(i,:) );    
    fprintf(fid, '%s& %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f \\\\ \n', 'EU brands',  100*EUshares(i,:) );
    fprintf(fid, '%s & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f  \\\\ \n', 'JPN brands',  100*JAPshares(i,:) );
    fprintf(fid, '%s & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f \\\\ \n', 'Other brands',  100*OTHERshares(i,:) );
    fprintf(fid, '%s & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f  \\\\ \n', 'Home brands',  100*HOMEshares(i,:) );
    fprintf(fid, '\\hline \n');
end
fprintf(fid, '\\hline \n');
fprintf(fid, '\\end{tabular} \n');
fprintf(fid, '\\end{center} \n');
fprintf(fid, '\\end{table} \n');
fclose(fid);

% shares table (absolute changes)
myfilename  = sprintf('results_appendixTable_marketshares_changes_dum%d_tar%d_fx%d_sealand%d_geo_%d.txt',dummy_baseline,tariff_baseline,fxrate_baseline,sealand_baseline,geo_baseline);
fid = fopen(['..' filesep 'cost_output' filesep myfilename],'wt');
 % First print the head ...     
fprintf(fid, '\\begin{table}[t] \n'); 
fprintf(fid, '\\begin{center} \n');
fprintf(fid, '\\caption{Absolute changes of average area-level market share of brands across markets (in percentage)} \n');
fprintf(fid, '\\begin{tabular}{@{}l|ccccccccc} \n'); % scenario, empty column, coefficient
fprintf(fid, '\\hline \n');
fprintf(fid, '\\hline \n');
for i = 1:size(counterRes,2)
    fprintf(fid, '%s & %s & %s & %s & %s & %s & %s & %s & %s & %s  \\\\ \n', counterRes(i).name , 'BRA', 'BEL', 'CAN', 'DEU', 'ESP', 'FRA', 'GBR', 'ITA', 'USA' );
    fprintf(fid, '%s & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f  \\\\ \n', 'US brands',  100*USAshares(i,:)-100*USAshares(1,:) );    
    fprintf(fid, '%s& %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f \\\\ \n', 'EU brands',  100*EUshares(i,:) -100*EUshares(1,:));
    fprintf(fid, '%s & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f  \\\\ \n', 'JPN brands',  100*JAPshares(i,:)  - 100*JAPshares(1,:) );
    fprintf(fid, '%s & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f \\\\ \n', 'Other brands',  100*OTHERshares(i,:) - 100*OTHERshares(1,:));
    fprintf(fid, '%s & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f & %4.1f  \\\\ \n', 'Home brands',  100*HOMEshares(i,:) -100*HOMEshares(1,:));
    fprintf(fid, '\\hline \n');
end
fprintf(fid, '\\hline \n');
fprintf(fid, '\\end{tabular} \n');
fprintf(fid, '\\end{center} \n');
fprintf(fid, '\\end{table} \n');
fclose(fid);



% markup table
myfilename = sprintf('results_appendixTable_markups_dum%d_tar%d_fx%d.txt',dummy_baseline,tariff_baseline,fxrate_baseline);
fid = fopen(['..' filesep 'cost_output' filesep myfilename], 'wt');
 % First print the head ...     
fprintf(fid, '\\begin{table}[t] \n'); 
fprintf(fid, '\\begin{center} \n');
fprintf(fid, '\\caption{Weighted average area-level markup (percent)} \n');
fprintf(fid, '\\begin{tabular}{@{}l|ccccccccc} \n'); % scenario, empty column, coefficient
fprintf(fid, '\\hline \n');
fprintf(fid, '\\hline \n');
for i = 1:size(counterRes,2)
    fprintf(fid, '%s & %s & %s & %s & %s & %s & %s & %s & %s & %s  \\\\ \n', counterRes(i).name , 'BRA', 'BEL', 'CAN', 'DEU', 'ESP', 'FRA', 'GBR', 'ITA', 'USA' );
    fprintf(fid, '%s & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f  \\\\ \n', 'US brands',  USAmarkups(i,:) );    
    fprintf(fid, '%s & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f  \\\\ \n', 'EU brands',  EUmarkups(i,:) );
    fprintf(fid, '%s & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f  \\\\ \n', 'JAP brands',  JAPmarkups(i,:) );
    fprintf(fid, '%s & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f  \\\\ \n', 'Other brands',  OTHERmarkups(i,:) );
    fprintf(fid, '%s & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f & %4.2f  \\\\ \n', 'Home brands',  HOMEmarkups(i,:) );
    fprintf(fid, '\\hline \n');
end
fprintf(fid, '\\hline \n');
fprintf(fid, '\\end{tabular} \n');
fprintf(fid, '\\end{center} \n');
fprintf(fid, '\\end{table} \n');
fclose(fid);

end 