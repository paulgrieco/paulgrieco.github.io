% This script: Calculate the probability that a car is sourced from its
% nearest location. In particular, it is calculated in the sale-weighted
% average sense.

clc
clear
%% add the demand and cost code folders as the search path so that we do not need to keep duplicated copies of code such as getMu.m
path_name = ['..' filesep 'cost_output' ];
addpath(genpath(path_name))

 load('cost_result_spec_dummies2_tariff1_fxrate1.mat')
 
 share_assembly_loc = est_results_cost_side.share_assembly_loc; % shares of sourcing from different locations
 assembly_mkt_dist_min = min(est_results_cost_side.m.distance_assembly_market,[],2); %nearest distance from mkt to assembly
 assembly_mkt_nearest =  (repmat(assembly_mkt_dist_min,1,size(est_results_cost_side.m.distance_assembly_market,2)) == est_results_cost_side.m.distance_assembly_market); % indicator of nearest assembly
 
 share_assembly_nearest = nansum(share_assembly_loc.*assembly_mkt_nearest,2);
 
 % calculate in terms of mean and weighted average
 mean(share_assembly_nearest)
 sum(share_assembly_nearest.*est_results_cost_side.total_sales)/sum(est_results_cost_side.total_sales)