% This code do all the cost estimation

costEstimation

