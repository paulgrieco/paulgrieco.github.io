% This function produces the detailed breakdown of brand country
function [brandcty_detail] = detailed_brandcty(m, c2str)
%% find out FRA and DEU brands:
FRA_brands = {'Renault', 'Citroen', 'Peugeot'};
DEU_brands = {'BMW','Mercedes', 'VW', 'Porsche','Audi','Opel','Smart'};
% ITA_brands = {'Alfa Romeo', 'DR Motor', 'Fiat','Lancia'};
% ESP_brands = {'Santana','Seat'};
FRA_brandCodes = [];
DEU_brandCodes = [];
ITA_brandCodes = [];
ESP_brandCodes = [];
brandCodes = 1:length(c2str.Brands);
brandcty_detail = m.brandcty;

for i = 1:length(FRA_brands)
    tempCode = brandCodes(strcmp(c2str.Brands,FRA_brands{i}));
    FRA_brandCodes = [FRA_brandCodes, tempCode]; 
    brandcty_detail(m.brandCode == tempCode) = {'FRA'};
end

for i = 1:length(DEU_brands)
    tempCode = brandCodes(strcmp(c2str.Brands,DEU_brands{i}));
    DEU_brandCodes = [DEU_brandCodes, tempCode]; 
    brandcty_detail(m.brandCode == tempCode) = {'DEU'};
end

% for i = 1:length(ITA_brands)
%     tempCode = brandCodes(strcmp(c2str.Brands,ITA_brands{i}));
%     ITA_brandCodes = [ITA_brandCodes, tempCode]; 
%     brandcty_detail(m.brandCode == tempCode) = {'ITA'};
% end
% 
% for i = 1:length(ESP_brands)
%     tempCode = brandCodes(strcmp(c2str.Brands,ESP_brands{i}));
%     ESP_brandCodes = [ESP_brandCodes, tempCode]; 
%     brandcty_detail(m.brandCode == tempCode) = {'ESP'};
% end

 %brandcty_detail( strcmp(brandcty_detail,'EU') ) = {'EU_other'};
brandcty_detail( strcmp(brandcty_detail,'EU') ) = {'OTHER'}; % convert all other EU brands into others 

 return