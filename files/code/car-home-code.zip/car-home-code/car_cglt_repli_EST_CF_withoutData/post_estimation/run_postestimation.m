% This script conduct the post cost estimation analysis:
% ---- counterfactuals
% ---- print tables of counterfactuals

clc
clear
%% add the demand and cost code folders as the search path so that we do not need to keep duplicated copies of code such as getMu.m
path_name = ['..' filesep 'demand_code' ];
addpath(genpath(path_name))
path_name = ['..' filesep 'cost_code' ];
addpath(genpath(path_name))
path_name = ['..' filesep 'input_files' ];
addpath(genpath(path_name))

%% load the baseline setup used in the cost estimation. This is used in the following functions for counterfactuals
load(['..' filesep 'cost_output' filesep 'cost_baseline_setup']);

% Run the counterfactual with the baseline specification
runCounterfactuals(tariff_baseline,dummy_baseline,fxrate_baseline,sealand_baseline, geo_baseline, demandresult_name);

% Save model implied trade flows to be compared with the data by Stata file do_compare_flows.do
revenue_flow = 1; % 1 means computing revenue flows; 0 mean quantity flows
extract_save_modelFlows(tariff_baseline,dummy_baseline,fxrate_baseline,sealand_baseline, geo_baseline, revenue_flow);

% write output tables to latex
report_boot_se = 0; % report bootstrapping se or not: choose 1 or 0
printTables_CostCounterfactuals(tariff_baseline,dummy_baseline,fxrate_baseline,sealand_baseline,geo_baseline,demandresult_name,report_boot_se);


