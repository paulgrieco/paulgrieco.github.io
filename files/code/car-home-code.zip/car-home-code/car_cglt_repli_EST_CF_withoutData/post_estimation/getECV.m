% this function compute the Expected compensation variation -- welfare
% analysis
% The input is the origianal nonlinear parameters, delta, and
% counterfactual counterparts.
function [ ECV, U_before, U_after] = getECV(parnonlin,delta, p, parnonlin_cf,delta_cf, p_cf, m)
  
   indUtility_before = indUtility(parnonlin,delta,p, m);
   indUtility_after = indUtility(parnonlin_cf,delta_cf, p_cf, m);
   
   
  ECV = (indUtility_after - indUtility_before)*m.quadweight';
  
  U_before= indUtility_before*m.quadweight';
  
  U_after= indUtility_after*m.quadweight';

end