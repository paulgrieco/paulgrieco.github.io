% this function jointly computes the standard errors for both
% linear and nonlinear parameters separately, and covariance matrix of all
% (linear and nonlinear) parameters.

function [se,  var_mat] = getSeCost(parvec, m,tar,fxdum,sealandinter, geodummies)

%cost_residual is the residuals of the nlls regression
%omega jacob is the PARTIAL derivative of omega with respect to the
%nonlinear parameters only
 [ ~ ,~, ~,cost_residual,omega_jacob ] = cost_objective_func_log_gradient(parvec,m,tar,fxdum,sealandinter, geodummies);


%% for variance and std of all linear and nonlinear parameters
nObs = size(m.linX,1);
A = [m.linX omega_jacob]' * [m.linX omega_jacob];
B = [m.linX omega_jacob]' * diag(cost_residual.^2) * [m.linX omega_jacob];

% NOTE: if sigma_nu is low (as we estimate), then a small subset of the assembly location dummies may become
%nearly perfectly colinear with small subset of the Model or ModelxCountry
%dummies in the linear part. This will lead the following inversion to throw a warning. 
%However, we have investigated this warning for specification 171 and,
%after tracking down all colinearities using Stata (e.g., the model
%"Proton" is only made in Iran and it is the only Iranian
%model) the warning no longer occurs.  The resultant standard errors are
%invariant to removing these colinearities or not, and pinv and "/" give
%similar answers. Since determing these colinearities is a combinatorial
%problem (detemining which subset of linear dummies sums to the assembly
%location), and it makes no difference to the final result, we do not try
%to track them down and just use the Moore-Penrose pseudo-inverse. 
%
%A_inv = eye(size(A))/A; 
A_inv = pinv(A);

var_mat = A_inv * B * A_inv;

se = diag( var_mat ).^.5; 



