function tradeCost_perc = tradeCost_noReallocation(costM, assemblyShares, para, hq_only, tar,fxdum, sealandinter, geodummies)

% para_mkt   = para(1);
% para_dom   = para(2);
% para_cont  = para(3);
% para_hq    = para(4);
[gamma_par, tariff_par , fx_par , tau_dist_par , tau_landdist_par , tau_seadist_par, tau_dom_par , tau_contig_par, tau_land_par] = unpack_cost_para(para, tar,fxdum, sealandinter, geodummies);

% trade cost due to distance to the market -- set the distance to the market to the internal cost of the market country
internal_dist_markets  = costM.distinternal*ones(1,size(costM.domestic_assembly_market,2)); % creates the right sized matrix of internal distances
temp                   = costM.distance_assembly_market./costM.distance_assembly_market; % this preserves NaN locations and sets the other ones to 1,
internal_dist_markets  = temp.*internal_dist_markets./1000; % so that this line multiplies them with internal distance of the destination market
 
internal_dist_hqs      = costM.distinternalhq*ones(1,size(costM.domestic_assembly_market,2)); % creates the right sized matrix of internal distances
temp                   = costM.distance_assembly_market./costM.distance_assembly_market; % this preserves NaN locations and sets the other ones to 1,
internal_dist_hqs      = temp.*internal_dist_hqs./1000; % so that this line multiplies them with internal distance of the destination market
  
cost_before =  (tau_dist_par *log (costM.distance_assembly_market)) ...
            + tau_contig_par *  costM.contiguity_assembly_market + tau_dom_par *costM.domestic_assembly_market + gamma_par * log(costM.distance_assembly_hq) ...
            + tau_landdist_par *  costM.land_market_country .* log(costM.distance_assembly_market) ... % this is added
            + tau_seadist_par  *  (1- costM.land_market_country) .* log(costM.distance_assembly_market) ...     % this is added
            + tau_land_par *  costM.land_market_country; % this is added
        
if hq_only == 0;
%     cost_after = para_mkt*log(internal_dist_markets) ...
%                   + para_dom*ones(size(internal_dist_markets)) ...
%                   + para_cont*zeros(size(internal_dist_markets)) ...
%                   + para_hq*log(costM.distance_assembly_hq);
   cost_after =  (tau_dist_par *log (internal_dist_markets)) ...
            + tau_contig_par *  zeros(size(internal_dist_markets)) + tau_dom_par *ones(size(internal_dist_markets)) + gamma_par * log(costM.distance_assembly_hq) ...
            + tau_landdist_par *  1 .* ones(size(internal_dist_markets)) ... % this is added
            + tau_seadist_par  * 0 .* ones(size(internal_dist_markets)) ...     % this is added
            + tau_land_par *  ones(size(internal_dist_markets)); % this is added           
else
    cost_after =  (tau_dist_par *log (costM.distance_assembly_market)) ...
            + tau_contig_par *  costM.contiguity_assembly_market + tau_dom_par *costM.domestic_assembly_market + gamma_par * log(internal_dist_hqs) ...
            + tau_landdist_par *  costM.land_market_country .* log(costM.distance_assembly_market) ... % this is added
            + tau_seadist_par  *  (1- costM.land_market_country) .* log(costM.distance_assembly_market) ...     % this is added
            + tau_land_par *  costM.land_market_country; % this is added 
end

cost_dif = cost_before-cost_after;

% Bring to the same shape as assemblyShares, indexing the costs from baseline sourcing locations
cost_dif_ext = zeros(size(assemblyShares)); % the total is 50 and plus 1 since the last one is for NaN
for i=1:1:length(costM.cost)
    for kk = 1:costM.maxplantmodel
        cost_dif_ext(i,costM.location_code(i,kk)) = cost_dif(i,kk);
    end
end

cost_dif_ext(:,costM.numassloc+1) = []; % set the (50 + 1)th to be empty since it is should be NaN

diff_dist = nansum(cost_dif_ext.* assemblyShares,2);

tradeCost_perc = (1 - exp(- diff_dist) ); % this is (c_estiamted - c_counterfactual)/c_estiamted
%tradeCost = ( tradeCost_perc.*exp(costM.cost) )'; % this is (c_estiamted - c_counterfactual) at level

end