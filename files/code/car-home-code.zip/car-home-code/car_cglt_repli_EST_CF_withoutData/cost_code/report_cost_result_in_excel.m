 function  result_all  = report_cost_result_in_excel()
% sum((est_results_cost_side.m.cost- mean(est_results_cost_side.m.cost)).^2)
 namevec = { 'deltahqdist',...
           'deltatariff',...
           'deltafxrate',...
           'deltamdist',...   % variable names
           'deltalanddist',...
           'deltaseadist',...
           'deltadom',...
           'deltacgt',...
           'deltasameland',...
           'kappahp',...
           'kappawt',...
           'kappasz',...
           'kappampg'}';
       
estimatetariff  = [0 1];       % =0 for tariff coef restricted to one, =1 for tariff coef estimated
estimatefxrate  = [0 1];       % =1 for estimating with exchange rate variation, =0 otherwise
dummies         = [1 2 3 4];         % =1 for model,country,year FEs, =2 for model,country-year FEs, =3 for brand,country,year FEs, =4 for brand-country,year FEs
sealand = [0 1];          % =1: have (market-assembly) sea and land dummies interacted with market distance; =0 otherwise
geodummies = [1,2,3,4,5,6];  

 result_all = cell(0);
 for j = 1:length(estimatetariff)
    tar = estimatetariff(j);
    for d = 1:length(dummies)
        dum = dummies(d);
        for i = 1:length(estimatefxrate)
            fx = estimatefxrate(i);
            for k = 1:length(sealand)
                sealandinter = sealand(k);
                for r = 1:length(geodummies)
                    geo = geodummies(r);

                    myfilename = sprintf('cost_result_spec_dummies%d_tariff%d_fxrate%d_sealand%d_geo%d.mat',dum,tar,fx,sealandinter, geo);
                     if exist(myfilename) > 0
                             load( myfilename );
                             costCOEFs  = est_results_cost_side.coefs ;
                             costSEs   = est_results_cost_side.coefSE;
                             result_this = [namevec, mat2cell(costCOEFs,ones(1,size(namevec,1)),[1]), mat2cell(costSEs,ones(1,size(namevec,1)),[1])];
                             
                             result_this(size(result_this,1)+1,1:2) = [{'ObjValue'},{est_results_cost_side.fval}];
                             result_this(size(result_this,1)+1,1:2) = [{'Dummy Set'},{dum}];
                             result_this = [result_this, cell(size(result_this,1),1)];
                             
                             result_all = [ result_all,  result_this];
                     end
                end
            end
        end
    end
 end
 
 for i = 1: size(result_all,1)
     for j = 1:size(result_all,2)
         if (cell2mat(result_all(i,j)) == 0) |  (cell2mat(result_all(i,j)) == 1) % should be 1 as this is just for tariff: when tariff is fixed it is fixed at 1
             result_all(i,j) = {'-'};
         end
     end
 end
 

end