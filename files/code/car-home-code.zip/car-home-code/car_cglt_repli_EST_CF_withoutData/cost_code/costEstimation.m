clc
clear
%% add the demand code folder as the search path so that we do not need to keep duplicated copies of code such as getMu.m
path_name = ['..' filesep 'demand_code' ];
addpath(genpath(path_name))

%% Load and prepare cost data 
setupSpecIdentifiers; % run this so that we do not have to specify the file version in the cost estimation.

switch fileVersion 
    case 'Full'
         [cData, cVars] = readInCsv(['..' filesep 'input_files' filesep 'costData.csv']);  % this csv file added to more iv's
    case 'noBRA'
         [cData, cVars] = readInCsv(['..' filesep 'input_files' filesep 'noBRA_costData.csv']);  % this csv file added to more iv's
    case 'EU'
         [cData, cVars] = readInCsv(['..' filesep 'input_files' filesep 'onlyEU_costData.csv']);  % this csv file added to more iv's
    otherwise
       fprintf('Error: Unrecognized file version name: %s \n', fileVersion);
   return;
end

for v = cVars
    eval(sprintf('%s = cData.%s;', v{1}, v{1}));
end
clear cVars cData v
% Extract number of assembly countries 
all_variables_iso = who('iso*');
maxplantmodel     = (numel(all_variables_iso)-1)/2; % -1 for isohq, /2 for every assembly plant appearing as isoK and isoKnumeric
num_plants        = zeros(maxplantmodel,1);
for kk =1:maxplantmodel
    num_plants(kk) = max(eval(sprintf('iso%dnumeric',kk)));
end
numassloc = max(num_plants);
clear num_plants all_variables_iso kk v
myyear = year;
save costdata
clear
 
%% demand result
demandresult_name = ['..' filesep 'demand_output' filesep 'secMultiResult.mat']; % used to be demandresult.mat, but we now do the two stages of demand separately.

%% Specifications to be estimated
estimatetariff  = [0 1 ];       % =0 for tariff coef restricted to one, =1 for tariff coef estimated
estimatefxrate  = [0  1];       % =1 for estimating with exchange rate variation, =0 otherwise
dummies         = [2 ];         % =1 for model,country,year FEs, =2 for model,country-year FEs, =3 for brand,country-year FEs, =4 for brand-country,year FEs
sealand = [0 ];          % =1: have (market-assembly) sea and land dummies interacted with market distance; =0 otherwise
geodummies = [2];            % =1: domestic(Y) + contiguous(Y) + land(N); 
                               % =2: domestic(Y) + contiguous(N) + land(N); 
                               % =3: domestic(Y) + contiguous(N) + land(Y); 
                               % =4: domestic(N) + contiguous(N) + land(N); 
                               % =5: domestic(N) + contiguous(N) + land(Y); 
                               % =6: domestic(Y) + contiguous(Y) + land(Y);
                               
tariff_baseline =  1;          % which of the tariff spec as the baseline to be used in counterfactuals and printed in trade cost share tables
dummy_baseline  =  2;          % which of the FEs as the baseline to be used in counterfactuals and printed in trade cost share tables
fxrate_baseline =  1;
sealand_baseline = 0;
geo_baseline = 2;
costSpecs       = [] ;         % collect the results
costCOEFs       = [];
costSEs         = [];
include_ass_ind = 1; % =0: NOT include any of the assembly dummies; =1: include some or all of the dummies depending on the specification (this is the original model WE used in the draft paper).
simple_assignment = 0; %=1: we just assign each model a simple sourcing location: the nearest location to market. (Some ass dummies may be not identified.) Thus, to do this, we revise the data of m structure so that all other locations are NaN; =0: we use the original

%% estimations and counterfactuals
for j = 1:length(estimatetariff)
    tar = estimatetariff(j);
    for d = 1:length(dummies)
        dum = dummies(d);
        for i = 1:length(estimatefxrate)
            fx = estimatefxrate(i);
            for k = 1:length(sealand)
                sealandinter = sealand(k);
                for r = 1:length(geodummies)
                    geo = geodummies(r);
                    display('Solving for cost specification...')
                    tar
                    dum
                    fx
                    sealandinter
                    geo
                    
                   est_results_cost_side = main_costall_log(tar,dum,fx,sealandinter, geo, include_ass_ind, simple_assignment, demandresult_name);
            
                   myfilename = sprintf('cost_result_spec_dummies%d_tariff%d_fxrate%d_sealand%d_geo%d',dum,tar,fx,sealandinter, geo);
 
                  save(['..' filesep 'cost_output' filesep myfilename], 'est_results_cost_side')

                  costSpecs     = horzcat(costSpecs,[tar;dum;fx;sealandinter;geo ]); % code what the tariff spec and set of dummies are for the regression output
                  costCOEFs     = horzcat(costCOEFs,est_results_cost_side.coefs);
                  costSEs       = horzcat(costSEs,est_results_cost_side.coefSE);
                end
            end
        end
    end
end

%% print the cost estimation result
specnamevec = {'tariff' , 'dummies', 'fxrate','sealand','geo'}';
gamma_par           = 0;
tariff_par          = 0;
fx_par              = 0;
tau_dist_par        = 0;
tau_landdist_par    = 0;
tau_seadist_par     = 0;
tau_dom_par         = 0;
tau_contig_par      = 0;     
tau_land_par        = 0;
namevec = { 'deltahqdist',...
           'deltatariff',...
           'deltafxrate',...
           'deltamdist',...   % variable names
           'deltalanddist',...
           'deltaseadist',...
           'deltadom',...
           'deltacgt',...
           'deltasameland',...
           'kappahp',...
           'kappawt',...
           'kappasz',...
           'kappampg'}';
display('**************************')       
display('**************************')       
display('Cost estimation results')       
for i=1:size(costCOEFs,2)
    spec   = horzcat(specnamevec,num2cell(costSpecs(:,i)));
    result = horzcat(namevec,num2cell(costCOEFs(:,i)),num2cell(costSEs(:,i)));
    spec
    display('result: variable, coefficient, standard error')
    result
    display('------------------------')    
end
display('**************************')       
display('**************************')       
%save costresult namevec costCOEFs costSEs costSpecs specnamevec
save(['..' filesep 'cost_output' filesep 'costresult'], 'namevec', 'costCOEFs', 'costSEs', 'costSpecs', 'specnamevec');

% save the key variables that will be loaded by post estimation code (counterfactuals)
save(['..' filesep 'cost_output' filesep 'cost_baseline_setup'], 'tariff_baseline','dummy_baseline','fxrate_baseline','sealand_baseline','geo_baseline','demandresult_name');

% clean and exit if on university clusters
% delete costdata.mat % we need it for further use
[~, hname] = system('hostname');
if ~isempty(strfind(hname, 'midway'))    % Are we on the UofC clusters
    matlabpool('close'); 
    exit
elseif strcmp(getenv('USERNAME'),'sli')  ~=1   % desktop 
   poolobj = gcp('nocreate');
   delete(poolobj);
end

 % exit matlab for clusters
if isunix
    exit
end