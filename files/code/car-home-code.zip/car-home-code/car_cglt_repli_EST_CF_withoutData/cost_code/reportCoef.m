% This function organize and report the coefficients and se's of interest
% Note that the input se is the se contain all the estimate vector.

function [coefs_report, coefSE_report] = reportCoef(paraNonlinCost, paraLinCost, se, tar,fxdum, sealandinter, geodummies, sigma_v)
%numcostvar = 4 + tar + fxdum ; % number of geographical variables: 2 distances always in and tariff coefficient depending on tar
numcostvar           = (1) + (tar + fxdum) + ( 1 + sealandinter) + 2*(geodummies==1) ...
                                                                 + 1*(geodummies==2) ...
                                                                 + 2*(geodummies==3) ... % was 3 -- a bug???
                                                                 + 1*(geodummies==5) ...
                                                                 + 3*(geodummies==6); % number of geographical variables
                                                             
% coefficients and standard errors to be written to output and reported: extract the estimates and standard errors of geographical and characteristics costs
coefs  =  cat(1,paraNonlinCost(1:numcostvar)*sigma_v,...
    paraLinCost(length(paraLinCost)-3:length(paraLinCost)));
                   
coefSE = cat(1,se(length(paraLinCost)+1:length(paraLinCost)+numcostvar)*sigma_v,...
    se(length(paraLinCost)-3:length(paraLinCost)));
                     
% if tar==0  
%     if fxdum == 0
%         coefs = [coefs(1:4);NaN;NaN;coefs(5:8)];
%         coefSE = [coefSE(1:4);NaN;NaN;coefSE(5:8)];
%     else
%         coefs = [coefs(1:4);NaN;coefs(5:9)];
%         coefSE = [coefSE(1:4);NaN;coefSE(5:9)];
%     end
% elseif tar==1
%     if fxdum == 0
%         coefs  = [coefs(1:4);...
%             coefs(5)/sigma_v;...  % since tariff coef is not linear but rather exponential, it doesn't scale here. in the cost_objective_func_log_gradient.m, it is already divided by sigma_v
%             NaN;...
%             coefs(6:9)];
%         coefSE = [coefSE(1:4);...
%             coefSE(5)/sigma_v;...
%             NaN;...
%             coefSE(6:9)];
%     else
%         coefs  = [coefs(1:4);...
%             coefs(5)/sigma_v;...  % since tariff coef is not linear but rather exponential, it doesn't scale here. in the cost_objective_func_log_gradient.m, it is already divided by sigma_v
%             coefs(6:10)];
%         coefSE = [coefSE(1:4);...
%             coefSE(5)/sigma_v;...
%             coefSE(6:10)];
%     end
% end

[gamma_par, tariff_par , fx_par , tau_dist_par , tau_landdist_par , tau_seadist_par, tau_dom_par , tau_contig_par, tau_land_par] = unpack_cost_para(coefs(1:end-3), tar,fxdum, sealandinter, geodummies); % the last four are for chars: they are linear
if tar==1 % only when tariff coefficient is estimated, otherwise it is set as 1, so not adjustment is needed
    tariff_par = tariff_par/sigma_v; % since tariff coef is not linear but rather exponential, it doesn't scale here. in the cost_objective_func_log_gradient.m, it is already divided by sigma_v
end
coefs_report = [gamma_par; tariff_par;fx_par ; tau_dist_par ; tau_landdist_par ;tau_seadist_par; tau_dom_par ;tau_contig_par; tau_land_par; ...
                           coefs(end-3:end)];

[gamma_par_se, tariff_par_se , fx_par_se , tau_dist_par_se , tau_landdist_par_se , tau_seadist_par_se, tau_dom_par_se , tau_contig_par_se, tau_land_par_se] = unpack_cost_para(coefSE(1:end-3), tar,fxdum, sealandinter, geodummies); % the last four are for chars: they are linear
if tar==1
    tariff_par_se = tariff_par_se/sigma_v; % since tariff coef is not linear but rather exponential, it doesn't scale here. in the cost_objective_func_log_gradient.m, it is already divided by sigma_v
end
coefSE_report = [gamma_par_se; tariff_par_se ;fx_par_se; tau_dist_par_se ; tau_landdist_par_se ; tau_seadist_par_se;tau_dom_par_se ; tau_contig_par_se;tau_land_par_se; ...
                           coefSE(end-3:end)];




