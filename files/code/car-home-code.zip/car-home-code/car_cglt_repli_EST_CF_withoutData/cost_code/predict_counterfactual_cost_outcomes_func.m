% Note: noFDI is a binary variable to indicate if we force every model to be only
% produced at home. (If no home plant avariable, we let the cost of home production as the highest cost overseas.)
function [cost_vector, share_assembly] = predict_counterfactual_cost_outcomes_func(cost_side_error,lin_param_costs,nonlin_param_costs,m,tar,fxdum, sealandinter, geodummies, noFDI,c2str,mktCode, newTariff)

% use the supplied tariff if it is supplied
if exist('newTariff') == 1 %  
    m.tariff_assembly_market = newTariff;
end

%% Nonlinear Parameters
% tau_dist_par       = nonlin_param_costs(1);
% tau_dom_par        = nonlin_param_costs(2);
% tau_contig_par     = nonlin_param_costs(3);
% gamma_par          = nonlin_param_costs(4);
% 
% if tar ==1 % If there is a coefficient on tariff
%     tariff_par     = nonlin_param_costs(5);
%     if fxdum ==1 % If there is a coefficient on fx rate
%         fx_par     = nonlin_param_costs(6);
%     end
% else
%     if fxdum ==1 % If there is a coefficient on fx rate
%         fx_par     = nonlin_param_costs(5);
%     end
% end

[gamma_par, tariff_par , fx_par , tau_dist_par , tau_landdist_par , tau_seadist_par, tau_dom_par , tau_contig_par, tau_land_par] = unpack_cost_para(nonlin_param_costs, tar,fxdum, sealandinter, geodummies);

%numcostvar                         = 4 + tar + fxdum; % number of geographical variables: 2 distances always in, 2 dummies for domestic and contiguity, and tariff coefficient depending on tar
numcostvar           = (1) + (tar + fxdum) + ( 1 + sealandinter) + 2*(geodummies==1) ...
                                                                 + 1*(geodummies==2) ...
                                                                 + 2*(geodummies==3) ... % was 3 -- a bug???
                                                                 + 1*(geodummies==5) ...
                                                                 + 3*(geodummies==6); % number of geographical variables
                                                             
loc_dummies_packed                 = nonlin_param_costs((numcostvar+1):end);
assert(nansum(m.include_countries) == length(loc_dummies_packed));

loc_dummies      = [-ones(m.numassloc,1); NaN]; % the last location is a NaN as it is the code for "empty location slot"
packed_idx = 1;
for kk = 1:m.numassloc
    if m.include_countries(kk) == 1
    loc_dummies(kk) = loc_dummies_packed(packed_idx);  
    packed_idx = packed_idx + 1;
    elseif m.include_countries(kk) == 0
         loc_dummies(kk) = 0;
    elseif isnan(m.include_countries(kk))
        loc_dummies(kk) = NaN;
    else
        disp('Warning: not applicable code in m.include_countries')
    end    
end


%% Nonlinear part
% Take the minimum cost of serving the market, ignoring all the NaNs
% if tar ==0
%     assembly_related_cost = loc_dummies(m.location_code) + (log(1+m.tariff_assembly_market) ./ m.sigma_v) ...
%         + (tau_dist_par *log(m.distance_assembly_market))+ tau_contig_par *  m.contiguity_assembly_market ...
%         + tau_dom_par *m.domestic_assembly_market + gamma_par * log(m.distance_assembly_hq);
%     if fxdum == 1
%         assembly_related_cost = loc_dummies(m.location_code) + (log(1+m.tariff_assembly_market) ./ m.sigma_v) ...
%             + (fx_par *log(m.fxrate_assembly)) + (tau_dist_par *log(m.distance_assembly_market)) ...
%             + tau_contig_par *  m.contiguity_assembly_market + tau_dom_par *m.domestic_assembly_market + gamma_par * log(m.distance_assembly_hq);
%     end
% elseif tar == 1
%     assembly_related_cost = loc_dummies(m.location_code) + (log(1+ tariff_par * m.tariff_assembly_market)  ./ m.sigma_v ) ...
%         + (tau_dist_par *log (m.distance_assembly_market)) + tau_contig_par *  m.contiguity_assembly_market ...
%         + tau_dom_par *m.domestic_assembly_market + gamma_par * log(m.distance_assembly_hq);
%     if fxdum == 1
%         assembly_related_cost = loc_dummies(m.location_code) + (log(1+ tariff_par * m.tariff_assembly_market)  ./ m.sigma_v ) ...
%             + (fx_par *log(m.fxrate_assembly)) + (tau_dist_par *log (m.distance_assembly_market)) ...
%             + tau_contig_par *  m.contiguity_assembly_market + tau_dom_par *m.domestic_assembly_market + gamma_par * log(m.distance_assembly_hq);
%     end
% end

assembly_related_cost = loc_dummies(m.location_code) + (log(1+ tariff_par * m.tariff_assembly_market)  ./ m.sigma_v ) ...
            + (fx_par *log(m.fxrate_assembly)) + (tau_dist_par *log (m.distance_assembly_market)) ...
            + tau_contig_par *  m.contiguity_assembly_market + tau_dom_par *m.domestic_assembly_market + gamma_par * log(m.distance_assembly_hq) ...
            + tau_landdist_par *  m.land_market_country .* log(m.distance_assembly_market) ... % this is added
            + tau_seadist_par  *  (1- m.land_market_country) .* log(m.distance_assembly_market) ...     % this is added
            + tau_land_par *  m.land_market_country; % this is added

% This is a safeguard used below, as we could run into an overflow problem otherwise and end up dividing by zero. It makes zero difference for the estimated parameters and increases stability during the optimization
a_cost_bound                 = NaN * ones(size(assembly_related_cost));
a_cost_bound(isfinite(assembly_related_cost)) = 700;               
assembly_related_cost   = min(assembly_related_cost,a_cost_bound);

if exist('noFDI') == 0 % if we do not supply noFDI indicator, then we assume FDI is allowed
    noFDI = 0;
end
assert(noFDI>=0 & noFDI<=1) % make sure we pass noFDI correctly

if noFDI == 0 % if we allow for FDI, as the full model does, then we simply follow the model
    omegaNonlinPart    =  -  m.sigma_v*log(nansum((exp(-assembly_related_cost)),2));           % Lets multiply nonlinear parameter later by m.sigma_v; maybe that's increasing numerical stability
else % otherwise, if we assume there is no FDI, then the cost is either the home plant cost or the highest oversea cost.
     load(['..' filesep 'cost_code' filesep 'costdata.mat'],'iso*');
    % first find the indicator of plant in the headquater country:
    assembly_in_hq = strcmp([iso1, iso2, iso3, iso4, iso5, iso6,iso7, iso8, iso9,iso10, iso11, iso12,iso13, iso14, iso15], repmat(isohq,1,15));
    assert(max(sum(assembly_in_hq,2)) <=1)  
    hqplant_ind = (sum(assembly_in_hq,2) == 1); % indicator of cars with assembly plant in hq -- we need to use the hq plant cost directly
    
    % construct the cost if no FDI is allowed
    
%     % The first way is to strictly follow the idea of using the highest
%     % cost  oversea cost if no home plant, but this will produce some
%     % extreme high cost for some cars. (Essentially these cars will not be supplied if no FDI allowed.)
%     omegaNonlinPart   =  m.sigma_v*max(assembly_related_cost,[],2); % we first take the highest cost of all assembly plants
%     
%     % to be on the safe side, let's do the replacement one by one:
%     for i = 1:length(iso1)
%         if hqplant_ind(i) == 1
%             this_car_cost = m.sigma_v*assembly_related_cost(i,:);
%             omegaNonlinPart(i) = this_car_cost(assembly_in_hq(i,:));
%         end
%     end
    
    % The second way is to assume that the home production cost is the
    % highest if it is reasonable high. If it is too high, the use the
    % second or third highest cost.
    
    [sorted_cost, sort_idx] = sort(-assembly_related_cost,2,'ascend'); % use  a minus so that we can get rid of NaN by take the first column later
    sorted_cost = - m.sigma_v*sorted_cost; % recover the cost by "-" 
    temp_lowest = m.sigma_v*min(assembly_related_cost,[],2); % record the lowest for reference
    
    omegaNonlinPart = sorted_cost(:,1); % first use the highest
    % to be on the safe side, let's do the replacement one by one:
    for i = 1:length(iso1)
        if hqplant_ind(i) == 1
            this_car_cost = m.sigma_v*assembly_related_cost(i,:);
            omegaNonlinPart(i) = this_car_cost(assembly_in_hq(i,:));
        end
    end
    
    diff_criteria = 1; % this is the criteria that how high is high: 1 (that is exp(1)) mean the no FDI cost will be over 3 times than the original cost.
    modify_ind = (omegaNonlinPart - temp_lowest > diff_criteria); % the cars needing modify
    omegaNonlinPart(modify_ind&(isnan(sorted_cost(:,2)) == 0) ) = sorted_cost(modify_ind&(isnan(sorted_cost(:,2)) == 0),2); %  use the second highest
    fprintf('The home production cost for some cars in the following market is changed: \n')
    disp(c2str.Mkts(unique(mktCode(modify_ind))))
    
    % find which plant is high cost that is too high and is replaced:
    plant_iso = [iso1, iso2, iso3, iso4, iso5, iso6,iso7, iso8, iso9,iso10, iso11, iso12,iso13, iso14, iso15];
    for i = 1:length(iso1)
         highest_cost_plant(i) = plant_iso(i,sort_idx(i,1)); % highest cost plant
         highest_cost_plant_2(i) = plant_iso(i,sort_idx(i,2)); % second highest cost plant
         highest_cost_plant_3(i) = plant_iso(i,sort_idx(i,3)); % third highest cost plant
    end
    highest_cost_plant = highest_cost_plant';
    highest_cost_plant_2 = highest_cost_plant_2';
    highest_cost_plant_3 = highest_cost_plant_3';
   
    modified_plant_nohq = highest_cost_plant(modify_ind & (hqplant_ind == 0)); % for car cost not produced at home being modified 
    replacement_plant = highest_cost_plant_2(modify_ind & (hqplant_ind == 0)); % for car cost not produced at home being modified
    fprintf('The production cost in these countries (not hq) are too high to serve as "home production cost": \n')
    display(unique(modified_plant_nohq))
    fprintf('These plants are used as replacement plant for the above plants for associated cars": \n')
    display(unique(replacement_plant))
    replacement_mapping = [c2str.Mkts(mktCode(modify_ind & (hqplant_ind == 0))), modified_plant_nohq, replacement_plant]; % record which is replaced by which
    
    modified_plant_hq = isohq(hqplant_ind & modify_ind); % for car cost is produced at home being modified
    fprintf('The production cost in these countries (hq) are too high to serve as "home production cost": \n')
    display(unique(modified_plant_hq))
    
    % if the first time replacement is not enough, we do it again using the
    % third highest.
    modify_ind = (omegaNonlinPart - temp_lowest > diff_criteria); % the cars needing modify
    omegaNonlinPart(modify_ind&(isnan(sorted_cost(:,3)) == 0) ) = sorted_cost(modify_ind&(isnan(sorted_cost(:,3)) == 0),3); %  use the third highest

end

share_assembly_loc = exp(-assembly_related_cost)      ./ repmat(nansum(exp(-assembly_related_cost),2),1,m.maxplantmodel);
share_assembly     = zeros(size(m.linX,1),m.numassloc + 1);

for nn =1:size(m.linX)
    for kk = 1:m.maxplantmodel
        share_assembly(nn,m.location_code(nn,kk)) = share_assembly_loc(nn,kk);
    end
end
share_assembly(:,m.numassloc+1) =[];

%% Total Costs
cost_vector = omegaNonlinPart + cost_side_error + m.linX * lin_param_costs; 