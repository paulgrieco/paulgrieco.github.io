function [fval,grad,paraLin,cost_residual,Y_beta,share_assembly_loc] = cost_objective_func_log_gradient(beta_cost,m,tar,fxdum,sealandinter, geodummies)
[gamma_par, tariff_par , fx_par , tau_dist_par , tau_landdist_par , tau_seadist_par, tau_dom_par , tau_contig_par, tau_land_par] = unpack_cost_para(beta_cost, tar,fxdum, sealandinter, geodummies);

numcostvar           = (1) + (tar + fxdum) + ( 1 + sealandinter) + 2*(geodummies==1) ...
                                                                 + 1*(geodummies==2) ...
                                                                 + 2*(geodummies==3) ... % was 3 -- a bug???
                                                                 + 1*(geodummies==5) ...
                                                                 + 3*(geodummies==6); % number of geographical variables
loc_dummies_packed   = beta_cost((numcostvar+1):end);

assert(nansum(m.include_countries) == length(loc_dummies_packed));

loc_dummies      = [-ones(m.numassloc,1); NaN]; % the last location is a NaN as it is the code for "empty location slot"
packed_idx = 1;
for kk = 1:m.numassloc
    if m.include_countries(kk) == 1
        loc_dummies(kk) = loc_dummies_packed(packed_idx);  
        packed_idx = packed_idx + 1;
    elseif m.include_countries(kk) == 0
         loc_dummies(kk) = 0;
    elseif isnan(m.include_countries(kk))
        loc_dummies(kk) = NaN;
    else
        disp('Warning: not applicable code in m.include_countries')
    end    
end


%% Nonlinear part
% Take the minimum cost of serving the market, ignoring all the NaNs
% if tar ==0
%     assembly_related_cost = loc_dummies(m.location_code) + (log(1+m.tariff_assembly_market) ./ m.sigma_v) ...
%         + (tau_dist_par *log(m.distance_assembly_market))+ tau_contig_par *  m.contiguity_assembly_market ...
%         + tau_dom_par *m.domestic_assembly_market + gamma_par * log(m.distance_assembly_hq);
%     if fxdum == 1
%         assembly_related_cost = loc_dummies(m.location_code) + (log(1+m.tariff_assembly_market) ./ m.sigma_v) ...
%             + (fx_par *log(m.fxrate_assembly)) + (tau_dist_par *log(m.distance_assembly_market)) ...
%             + tau_contig_par *  m.contiguity_assembly_market + tau_dom_par *m.domestic_assembly_market + gamma_par * log(m.distance_assembly_hq);
%     end
% elseif tar == 1
%     assembly_related_cost = loc_dummies(m.location_code) + (log(1+ tariff_par * m.tariff_assembly_market)  ./ m.sigma_v ) ...
%         + (tau_dist_par *log (m.distance_assembly_market)) + tau_contig_par *  m.contiguity_assembly_market ...
%         + tau_dom_par *m.domestic_assembly_market + gamma_par * log(m.distance_assembly_hq);
%     if fxdum == 1
%         assembly_related_cost = loc_dummies(m.location_code) + (log(1+ tariff_par * m.tariff_assembly_market)  ./ m.sigma_v ) ...
%             + (fx_par *log(m.fxrate_assembly)) + (tau_dist_par *log (m.distance_assembly_market)) ...
%             + tau_contig_par *  m.contiguity_assembly_market + tau_dom_par *m.domestic_assembly_market + gamma_par * log(m.distance_assembly_hq);
%     end
% end

assembly_related_cost = loc_dummies(m.location_code) + (log(1+ tariff_par * m.tariff_assembly_market)  ./ m.sigma_v ) ...
            + (fx_par *log(m.fxrate_assembly)) + (tau_dist_par *log (m.distance_assembly_market)) ...
            + tau_contig_par *  m.contiguity_assembly_market + tau_dom_par *m.domestic_assembly_market + gamma_par * log(m.distance_assembly_hq) ...
            + tau_landdist_par *  m.land_market_country .* log(m.distance_assembly_market) ... % this is added
            + tau_seadist_par  *  (1- m.land_market_country) .* log(m.distance_assembly_market) ...     % this is added
            + tau_land_par *  m.land_market_country; % this is added
        
        
% This is a safeguard used below, as we could run into an overflow problem otherwise and end up dividing by zero. It makes zero difference for the estimated parameters and increases stability during the optimization
a_cost_bound                 = NaN * ones(size(assembly_related_cost));
a_cost_bound(isfinite(assembly_related_cost)) = 700;               
assembly_related_cost   = min(assembly_related_cost,a_cost_bound);

omegaNonlinPart    = -   m.sigma_v*log(nansum((exp(-assembly_related_cost)),2));  % Lets multiply nonlinear parameters later by m.sigma_v; maybe that's increasing numerical stability

% The next line isn't needed for estimation, but used in the analysis
% afterwards
if nargout > 5 
    share_assembly_loc   = exp(-assembly_related_cost) ./ repmat(nansum(exp(-assembly_related_cost),2),1,m.maxplantmodel);
end

%% Linear part
% the cost minus the nonlinear part (min of distance part)
Y = m.cost - omegaNonlinPart;

% compute the linear parameters from OLS formular
X = m.linX;
%XX_inv    = eye(size(X,2))/(X'*X); % save this to speed up
paraLin   = m.XX_inv*X'*Y;
% compute the residual, 
cost_residual     = Y - X*paraLin;

%% compute the objective function as inner product of omega
fval      =  cost_residual'*cost_residual;

%% compute the gradient
% (1)
fixed_part =-m.sigma_v./nansum((exp(-assembly_related_cost)),2);

tau_dist_part    = fixed_part.* nansum(-log(m.distance_assembly_market)  .*exp(-assembly_related_cost),2);
gamma_par_part  = fixed_part.*nansum(-log(m.distance_assembly_hq) .*exp(-assembly_related_cost),2);
tau_dom_part     = fixed_part.*nansum(-m.domestic_assembly_market .*exp(-assembly_related_cost),2);
tau_contig_part  = fixed_part.*nansum(-m.contiguity_assembly_market .*exp(-assembly_related_cost),2);

tariff_par_part = fixed_part.*nansum(-(m.tariff_assembly_market ./ (1+ tariff_par * m.tariff_assembly_market)) .*exp(-assembly_related_cost),2)  ./ m.sigma_v  ;
fx_par_part = fixed_part.* nansum(-log(m.fxrate_assembly)  .*exp(-assembly_related_cost),2);

tau_landdist_part    = fixed_part.* nansum(-m.land_market_country.*log(m.distance_assembly_market)  .*exp(-assembly_related_cost),2);
tau_seadist_part    = fixed_part.* nansum(-(1-m.land_market_country).*log(m.distance_assembly_market)  .*exp(-assembly_related_cost),2);
tau_land_part  = fixed_part.*nansum(-m.land_market_country .*exp(-assembly_related_cost),2);

% if tar ==1 % With coefficient on tariff
%     %tariff_par_part = fixed_part.*nansum(-log(1+m.tariff_assembly_market) .*exp(-assembly_related_cost),2);
% % New Felix: updated where the tariff parameter enters
%     tariff_par_part = fixed_part.*nansum(-(m.tariff_assembly_market ./ (1+ tariff_par * m.tariff_assembly_market)) .*exp(-assembly_related_cost),2)  ./ m.sigma_v  ;
% end
% 
% if fxdum ==1 % With coefficient on fxrate
%     fxrate_par_part = fixed_part.* nansum(-log(m.fxrate_assembly)  .*exp(-assembly_related_cost),2);
% end

loc_position  = zeros(size(m.location_code));
loc_part      = ones(size(m.linX,1),nansum(m.include_countries));

k=0;
for i=1:length(m.include_countries)
    if m.include_countries(i) == 1
        loc_position(m.location_code==i)=1;
        k = k +1;
       loc_part(:,k)=fixed_part.*nansum(- exp(-assembly_related_cost).*loc_position,2);       
    	loc_position(m.location_code==i)=0;
    end
end

% if tar ==0
%     omegaNonlinPart_beta=[tau_dist_part,tau_dom_part,tau_contig_part,gammar_par_part,loc_part];
%     if fxdum == 1
%         omegaNonlinPart_beta=[tau_dist_part,tau_dom_part,tau_contig_part,gammar_par_part,fxrate_par_part,loc_part];
%     end
% elseif tar == 1
%     omegaNonlinPart_beta=[tau_dist_part,tau_dom_part,tau_contig_part,gammar_par_part,tariff_par_part,loc_part];
%     if fxdum == 1
%         omegaNonlinPart_beta=[tau_dist_part,tau_dom_part,tau_contig_part,gammar_par_part,tariff_par_part,fxrate_par_part,loc_part];
%     end
% end

if tar == 0
   tariff_par_part          = [];
end

if fxdum == 0
   fx_par_part              = [];
end

if sealandinter == 1
    tau_dist_part        = [];
end

if sealandinter == 0
    tau_landdist_part    = [];
    tau_seadist_part     = [];
end

if     geodummies==1    
    tau_land_part        = [];     
elseif geodummies==2
    tau_contig_part      = [];     
    tau_land_part        = [];            
elseif geodummies==3
    tau_contig_part      = [];     
elseif geodummies==4
    tau_dom_part         = [];
    tau_contig_part      = [];     
    tau_land_part        = [];
elseif geodummies==5
    tau_dom_part         = [];
    tau_contig_part      = [];   
else % when geodummies==6
    % do nothing.
end

omegaNonlinPart_beta=[gamma_par_part, tariff_par_part,fx_par_part ,tau_dist_part ,tau_landdist_part ,tau_seadist_part ,tau_dom_part,tau_contig_part,tau_land_part,loc_part];

% (2)
Y_beta=-omegaNonlinPart_beta;

% (3)
fval_Y=2*m.M*Y;
fval_beta=Y_beta'*fval_Y;
grad=fval_beta;

