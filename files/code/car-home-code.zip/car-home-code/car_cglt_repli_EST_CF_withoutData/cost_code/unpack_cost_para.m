function [gamma_par, tariff_par , fx_par , tau_dist_par , tau_landdist_par , tau_seadist_par, tau_dom_par , tau_contig_par, tau_land_par] = unpack_cost_para(beta_cost, tar,fxdum, sealandinter, geodummies)
%%%%%%%%%%%% The new set of parameters, must follow the following order to assign parameters and report parameters %%%%%%%%%%%
gamma_par           = 0;
tariff_par          = 1; % This was a bug: tariff_par should be fixed at 1 (not 0) when we say it is fixed (not estimated).
fx_par              = 0;
tau_dist_par        = 0;
tau_landdist_par    = 0;
tau_seadist_par     = 0;
tau_dom_par         = 0;
tau_contig_par      = 0;     
tau_land_par        = 0;
%%%%%%%%%%%%%%%%%%%%%%%%%  
gamma_par          = beta_cost(1);

if tar ==1 % If there is a coefficient on tariff
    tariff_par     = beta_cost(2);
    if fxdum ==1 % If there is a coefficient on fx rate
        fx_par     = beta_cost(3);
        if sealandinter ==1
            tau_landdist_par = beta_cost(4);
            tau_seadist_par = beta_cost(5);
            if     geodummies==1
              tau_dom_par        = beta_cost(6);
              tau_contig_par     = beta_cost(7);
            elseif geodummies==2
              tau_dom_par        = beta_cost(6);
            elseif geodummies==3
              tau_dom_par        = beta_cost(6);
              tau_land_par       = beta_cost(7);
            elseif geodummies==5
              tau_land_par       = beta_cost(6);
            elseif geodummies==6
              tau_dom_par        = beta_cost(6);
              tau_contig_par     = beta_cost(7);
              tau_land_par       = beta_cost(8);
            end
        else % the case of sealandinter ==0, use distance directly
            tau_dist_par         = beta_cost(4);
            if     geodummies==1
              tau_dom_par        = beta_cost(5);
              tau_contig_par     = beta_cost(6);
            elseif geodummies==2
              tau_dom_par        = beta_cost(5);
            elseif geodummies==3
              tau_dom_par        = beta_cost(5);
              tau_land_par       = beta_cost(6);
            elseif geodummies==5
              tau_land_par       = beta_cost(5);
            elseif geodummies==6
              tau_dom_par        = beta_cost(5);
              tau_contig_par     = beta_cost(6);
              tau_land_par       = beta_cost(7);  
            end
        end  
    else
        if sealandinter ==1
            tau_landdist_par = beta_cost(3);
            tau_seadist_par = beta_cost(4);
            if     geodummies==1
              tau_dom_par        = beta_cost(5);
              tau_contig_par     = beta_cost(6);
            elseif geodummies==2
              tau_dom_par        = beta_cost(5);
            elseif geodummies==3
              tau_dom_par        = beta_cost(5);
              tau_land_par       = beta_cost(6);
            elseif geodummies==5
              tau_land_par       = beta_cost(5);  
            elseif geodummies==6
              tau_dom_par        = beta_cost(5);
              tau_contig_par     = beta_cost(6);
              tau_land_par       = beta_cost(7);
            end
        else % the case of sealandinter ==0, use distance directly
            tau_dist_par         = beta_cost(3);
            if     geodummies==1
              tau_dom_par        = beta_cost(4);
              tau_contig_par     = beta_cost(5);
            elseif geodummies==2
              tau_dom_par        = beta_cost(4);
            elseif geodummies==3
              tau_dom_par        = beta_cost(4);
              tau_land_par       = beta_cost(5);
            elseif geodummies==5
              tau_land_par       = beta_cost(4);  
            elseif geodummies==6
              tau_dom_par        = beta_cost(4);
              tau_contig_par     = beta_cost(5);
              tau_land_par       = beta_cost(6);  
            end
        end 
    end
else
    if fxdum ==1 % If there is a coefficient on fx rate
        fx_par     = beta_cost(2);
        if sealandinter ==1
            tau_landdist_par = beta_cost(3);
            tau_seadist_par = beta_cost(4);
            if     geodummies==1
              tau_dom_par        = beta_cost(5);
              tau_contig_par     = beta_cost(6);
            elseif geodummies==2
              tau_dom_par        = beta_cost(5);
            elseif geodummies==3
              tau_dom_par        = beta_cost(5);
              tau_land_par       = beta_cost(6);
            elseif geodummies==5
              tau_land_par       = beta_cost(5);  
            elseif geodummies==6
              tau_dom_par        = beta_cost(5);
              tau_contig_par     = beta_cost(6);
              tau_land_par       = beta_cost(7);  
            end
        else % the case of sealandinter ==0, use distance directly
            tau_dist_par         = beta_cost(3);
            if     geodummies==1
              tau_dom_par        = beta_cost(4);
              tau_contig_par     = beta_cost(5);
            elseif geodummies==2
              tau_dom_par        = beta_cost(4);
            elseif geodummies==3
              tau_dom_par        = beta_cost(4);
              tau_land_par       = beta_cost(5);
            elseif geodummies==5
              tau_land_par       = beta_cost(4); 
            elseif geodummies==6
              tau_dom_par        = beta_cost(4);
              tau_contig_par     = beta_cost(5);
              tau_land_par       = beta_cost(6);  
            end
        end
    else
        if sealandinter ==1
            tau_landdist_par = beta_cost(2);
            tau_seadist_par = beta_cost(3);
            if     geodummies==1
              tau_dom_par        = beta_cost(4);
              tau_contig_par     = beta_cost(5);
            elseif geodummies==2
              tau_dom_par        = beta_cost(4);
            elseif geodummies==3
              tau_dom_par        = beta_cost(4);
              tau_land_par       = beta_cost(5);
            elseif geodummies==5
              tau_land_par       = beta_cost(4);  
            elseif geodummies==6
              tau_dom_par        = beta_cost(4);
              tau_contig_par     = beta_cost(5);
              tau_land_par       = beta_cost(6);
            end
        else % the case of sealandinter ==0, use distance directly
            tau_dist_par         = beta_cost(2);
            if     geodummies==1
              tau_dom_par        = beta_cost(3);
              tau_contig_par     = beta_cost(4);
            elseif geodummies==2
              tau_dom_par        = beta_cost(3);
            elseif geodummies==3
              tau_dom_par        = beta_cost(3);
              tau_land_par       = beta_cost(4);
            elseif geodummies==5
              tau_land_par       = beta_cost(3); 
            elseif geodummies==6
              tau_dom_par        = beta_cost(3);
              tau_contig_par     = beta_cost(4);
              tau_land_par       = beta_cost(5);  
            end
        end 
    end
end